//这是用户设置他发言密码的功能，要设置用户的初始密码的提示
<template>
    <div id="xh41" style="padding-top:10px;">
		<zu1caozuojishu zone_id='发言密码' :jishu="kjishu" :showloading2="loading_yn2" @zhankai="zk" @shuaxin="sx"></zu1caozuojishu>  
		<span v-if="loading_yn2===false">
			<el-row v-for="lll in lists" :key="lll.pk" class="font18px" style="color:grey;">
				设置时间:{{qian_date(lll.fields.time1)}}<el-divider direction="vertical"></el-divider>
				提示信息:<span style="color:brown;">{{lll.fields.fy}}</span><el-divider direction="vertical"></el-divider>
				<el-row><el-divider style="margin:0px;"></el-divider></el-row>
			</el-row>
			<br>
			<el-pagination v-if="countfymm>10" style="text-align:right;"
				background
				:page-size=10
				:total="countfymm"
				:current-page.sync="currentPage"
				layout="total, prev, pager, next">
			</el-pagination>
		</span>
    </div>
</template>

<script>
    export default {
        name:'xh41',
        props:[],
        data() {return {
			currentPage:1,
			fayanmima_list:[],
			countfymm:0,
			loading_yn2:false
        }},
        computed:{
			lists(){
                let pages=Math.ceil(this.countfymm/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                let sonList=[];
                sonList=this.fayanmima_list.slice(i*10,i*10+10);//10为每页设置数量
                newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },

        },
        methods:{
			zk(){this.sx();},
			sx(){
				this.loading_yn2=true;
				var _this= this;
				_this.axios
				.post('http://www.zhishiren.info/api/xunhuancaozuo/', {zhid:_this.$cookies.get('userid'),cztype:'发言密码'})
				.then(function (response) {
					_this.fayanmima_list=JSON.parse(response.data);
					_this.countfymm=_this.fayanmima_list.length;
					_this.loading_yn2=false;
				});
			},
        },
    };
</script>



