<template>
		<div id="toubu0" class="logo">知识人
			<!-- <span v-if="!welcomename" class="font18px" >你好陌生人：去登陆<el-divider direction="vertical"></el-divider>回首页</span> -->
			<span v-if="welcomename" class="font18px" >hello,{{this.welcomename}}</span>
			<span class="font19px_tuichu">
			<a class="a_white" @click="guanbi">关闭</a>
			</span>
		</div>
</template>

<script>

export default {
    name:'toubu0',
	props: {},
	
    computed:{
			// welcomename(){return "kkk"},
			welcomename(){return this.$cookies.get('username')},
    },
    methods:{
					guanbi(){
						// this.$alert('确认关闭页面？', '确认关闭？', {
						// 	confirmButtonText: '确认',
						// 	showClose:false,
						// 	callback: action => {
						// 					window.location.href="about:blank";
						// 					// window.open('location of current page', '_self', '');
						// 					window.opener=null;
						// 					window.open('','_self');
						// 					window.close();	
						// 					// open(location, '_self').close();
						// 					// window.location.href="about:blank";
						// 					// window.close();
						// 	}
						// });
							this.$confirm('', '确认关闭本页面？',{
								confirmButtonText: '确定',
								cancelButtonText: '取消',
								}).then(() => {
									window.location.href="about:blank";
									// window.open('location of current page', '_self', '');
									window.opener=null;
									window.open('','_self');
									window.close();	
									// open(location, '_self').close();
									// window.location.href="about:blank";
									// window.close();
								}).catch(() => {
								this.$message({
									type: 'info',
									message: '已取消'
								});          
								});
					},
	},

};

</script>


