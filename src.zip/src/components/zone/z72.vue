<template>
    <div id="z72">
				<el-row style="height:270px">
					<el-col :span="24">
						<img src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/aboutus21.jpg" class="bg_image" style="height:270px;width:100%;" alt="">
						<div class="huanhang font22px">
							如果代码是音符，那我就是那首《国际歌》
						</div>
					</el-col>
				</el-row>
                
        <el-row>
			<el-col :span="24">
				<div class="huanhang font18px">
                    <b>左翼应及时地发明并建立起自己的“智识平台”，提出新的意识形态和经济模型、改革媒体、重建阶级力量，按照自己的方式重新配置已有的科技成果，才能实现未来的解放。</b>
                    --《加速主义宣言》				
                </div>
			</el-col>
		</el-row>
		<br>
		<el-row>
			<el-col :span="10">
					<el-image
						src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/z72a.jpg"
						:fit="fill">
					</el-image>
			</el-col>
			<el-col :span="14">
				<div class="huanhang">
					<b class="font20px">建设一种自由自主的生产体系</b>	
					<br>
					克鲁泡特金在《面包与自由》中阐述：资本的罪恶不只是剥削劳动者，而是剥夺劳动者的生产资料，让他们不能养活自己，而不得不接受剥削。
					<br>
					因此，人民应该建设一个自由自主，人人参与的生产体系，保障人民最基本的生活需求，创造一种公用共享，极简透明的产品设计标准，这样才能摆脱资本剥削，消费主义，官僚计划的压迫。
				</div>

			</el-col>
		</el-row>
		<br>
		<el-row>
			<el-col :span="14">
				<div class="huanhang">
					<b class="font20px">全民参与管理，共享劳动经验</b>		
					<br>
					资本家及工头垄断了“生产什么“的权力，政府官僚垄断了”社会管理“的权力，并通过行政、文化、教育体系建立了一套”话语权“和”合法性“，排斥人民自己掌握自己命运的自由。
					<br>
					然而这种体系是僵化迟钝的，周期性爆发危机的。人民要设计一种最高效的方式，创造自治和互助型的组织，共享管理和劳动经验，共建基础设施和软件信息。每个人从自身出发，贡献劳动经验和见识，构建一种公平公开公正透明的社会体系。
				</div>
			</el-col>
			<el-col :span="10">
					<el-image
						src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/z72b.jpg"
						:fit="fill">
					</el-image>
			</el-col>
		</el-row>
		<br>

    </div>

</template>

<script>
    export default {
        name:'z72',
        props:['k'],//k是区分
        data() {return {

        }},
        computed:{

        },
        methods:{
            
            
        },
    };
</script>



