
//作废
<template>
<div>
            <el-select v-model="qz_id" @change="send_tixing_qunzuid(qz_id)" placeholder="请选择"  style="width:100%;">
              <el-option
                v-for="item in lists"
                :key="item.qz_id"
                :label="item.qz_title"
                :value="item.qz_id">
              </el-option>
            </el-select> 
            <br>
</div>

</template>

<script>
  export default {
    data() {
      return {
            lists: [{qz_id:80000000,qz_title:"--无--"},
                    {qz_id:90000000,qz_title:"--所有人--"},],
            qz_id:80000000,
      }
    },

    created(){
        var that = this;
        that.axios
        .post('http://www.zhishiren.info/api/listmyqunzu/', {userid: that.$cookies.get('userid')})
        .then(response=>{that.lists=that.lists.concat(response.data);});
    },

    methods:{
      send_tixing_qunzuid(qz_id){
        let data = {
          qz_id: this.qz_id
        };
        this.$emit('set_tixing',data);
      }
    }

  }
</script>