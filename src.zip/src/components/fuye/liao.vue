这是新增各类知识点的页面。
<template>
<div id="liao"  @click="turnfresh()">
		<zu2logo k=1></zu2logo>
		<el-container>
			<el-aside width="120px"  class="bgcolor_FF"></el-aside>
			<el-main class="bgcolor_FC font18px"  style="padding:7px;">
				<span class="font18px" style="font-color:grey">
					<i class="el-icon-info">聊天大厅的内容是“所有用户”可见；</i>
					<a href="http://tool.chacuo.net/cryptdes/" class="a_grey" target="_blank"><i class="el-icon-key"></i>解密链接</a><br>
				</span>
			</el-main>
		</el-container>

		<el-container>
			<el-aside width="120px" class="height_x00px">
				<el-menu :default-active="xx" class="el-menu-vertical-demo bgcolor_menu_FC height_x00px" @open="handleOpen" @close="handleClose">
			      <el-menu-item @click="daohangx1" index="x1" class="font18px">一对一聊
			      </el-menu-item>
				  <el-menu-item @click="daohangx3" index="x3" class="font18px">
			        <span slot="title">聊天大厅</span>
			      </el-menu-item>
			      <!-- <el-menu-item @click="daohangx2" index="x2" class="font18px">
			        <span slot="title">我关注的</span>
			      </el-menu-item>
			      <el-menu-item @click="daohangx4"  index="x4" class="font18px">
			        <span slot="title">关注我的</span>
			      </el-menu-item> -->
			      <el-menu-item @click="daohangx5" disabled index="x5" class="font18px">
			        <span slot="title">我的群组</span>
			      </el-menu-item>
			      <el-menu-item @click="daohangx6" v-if="disabled_yn===false" index="x6" class="font18px">
			        <span slot="title">在线审核</span>
			      </el-menu-item>
			      <el-menu-item @click="daohangx8"  disabled index="x8" class="font18px">
			        <span slot="title">精华发言</span>
			      </el-menu-item>				      
			    </el-menu>
			</el-aside>


			<el-main v-show="dhx1" class="section_xh">
					<el-row>
						<el-col :span="11">
          					<el-card class="box-card" style="height:110px;">
							<!-- <img v-if="userinfo.yonghu_touxiang===1" alt="" :src="timestamp('https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/touxiang/90000075.jpg')" style="width:10%;height:125px;"> -->
								<!-- <el-col :span="7">
								<img alt="" :src="timestamp('https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/touxiang/90000000.jpg')" style="width:80%;height:125px;">
								</el-col>
								<el-col :span="17"> -->
								<span style="font-size:18px;">用户ID号：
									<span>
										<input type="text" class="sousuolan" style="width:80px;font-size:16px;" size="mini" v-model="yh_id" placeholder="用户ID号">
									</span>
									<span>
										<a @click="souyhinfo(yh_id)" class="sousuo_alink a_noline" style="font-size:18px;" ><i class="el-icon-search"></i>搜</a>
									</span>
								</span>
								<br>
								<span style="font-size:18px;">用户名称：<b>{{this.yhinfo.yhname}}</b>
								<span v-if="yh_id!=='1'">
									<router-link class="a_black" target="_blank" :to="{name:'yonghuye',params:{id:this.yh_id}}">          
										<span><i class="el-icon-right"></i>TA主页</span>
									</router-link>
								</span>
								</span>
								<br>
								<!-- <span style="font-size:18px;">行业岗位：<b>ceshi</b><el-divider direction="vertical"></el-divider>京津冀</span>
								<br>
								<span style="font-size:18px;">国家地区：<b>ceshi</b><el-divider direction="vertical"></el-divider>京津冀</span>
								<br> -->
								<span style="font-size:18px;">联系方式：<b>{{this.yhinfo.yhcontact}}</b></span>
								<!-- </el-col> -->
							</el-card>
						</el-col>
						<el-col :span="13">
          					<el-card class="box-card" style="height:110px;">
								<el-row class="font18px">用户对我的消息列表:</el-row>
								<el-row>
									<span v-for="ul in userlist" style="font-size:20px;">
										<span class="a_black" @click="chooseyhid(ul.yhid)">{{ul.yhname[1]}}</span>
										<el-badge :id="ul.yhid" :value="ul.jishucha" class="item"></el-badge>
										<el-divider direction="vertical"></el-divider>
									</span>
								</el-row>
          					</el-card>
						</el-col>
					</el-row>
				<zu2liaolist :leixing="yh_id" ></zu2liaolist>

					
			</el-main>
			<el-main v-show="dhx2" class="section_xh">
			</el-main>
			
			<el-main v-show="dhx3" class="section_xh">  
				<zu2liaolist leixing=90000000 :jishu='jishu' :jishi='jishi'></zu2liaolist>
			</el-main>
			<el-main v-show="dhx4" class="section_xh">
               
			</el-main>  
			<el-main v-show="dhx5" class="section_xh">
					<el-row>
						<el-col :span="11">
          					<el-card class="box-card" style="height:110px;">
								<span style="font-size:18px;">群组消息列表：</span>
								<br>
								<el-badge :value="12" class="item">
									<span size="small">「测试小组」</span>
								</el-badge>
								<el-badge :value="12" class="item">
									<span size="small">「测试小组」</span>
								</el-badge>
								
							</el-card>
						</el-col>

						<!-- <el-col :span="1"></el-col> -->
						<el-col :span="13">
          					<el-card class="box-card" style="height:110px;">
								<el-row class="font18px">「测试」:80000001</el-row>
								<span style="font-size:18px;">群组介绍:。。。。。。。。</span><el-divider direction="vertical"></el-divider>
								
          					</el-card>

						</el-col>
						<!-- <el-col :span="12">未读消息：</el-col> -->
					</el-row>
					<zu2liaolist leixing=90000000 ref="huanyuan"></zu2liaolist>
			</el-main>
			<el-main v-show="dhx6" class="section_xh">              
				<span @click="zhankai_liaoshen()" class="font18px a_black">--展开--</span>
				<!-- {{this.liaoshenlist}} -->
				<el-row v-for="lsl in liaoshenlist" :key="lsl._id.$oid">
					<el-col :span="20">{{lsl.fyshen}}
					</el-col>
					<el-col :span="4"><el-divider direction="vertical"></el-divider><span class="a_black" @click="shenliao_pass(lsl._id.$oid)">pass</span></el-col>
					<br>
					.......................................................................................
				</el-row>

			</el-main>
			<el-main v-show="dhx8" class="section_xh">
			</el-main>
			<el-aside width="120px" class="bgcolor_FC">
                
            </el-aside>

		</el-container>



	</div>

</template>



<script>

export default {
    name:'liao',
    components: {},
	methods: {
		daohangx1(){this.dhx1=true;this.dhx2=this.dhx3=this.dhx4=this.dhx5=this.dhx6=this.dhx8=false;},
		daohangx2(){this.dhx2=true;this.dhx1=this.dhx3=this.dhx4=this.dhx5=this.dhx6=this.dhx8=false;},
		daohangx3(){this.dhx3=true;this.dhx1=this.dhx2=this.dhx4=this.dhx5=this.dhx6=this.dhx8=false;},
		daohangx4(){this.dhx4=true;this.dhx1=this.dhx2=this.dhx3=this.dhx5=this.dhx6=this.dhx8=false;},
		daohangx5(){this.dhx5=true;this.dhx1=this.dhx2=this.dhx3=this.dhx4=this.dhx6=this.dhx8=false;},
		daohangx6(){this.dhx6=true;this.dhx1=this.dhx2=this.dhx3=this.dhx4=this.dhx5=this.dhx8=false;},
		daohangx8(){this.dhx8=true;this.dhx1=this.dhx2=this.dhx3=this.dhx4=this.dhx5=this.dhx6=false;},
		chooseyhid(kkk){
			this.yh_id=0;
			this.yh_id=kkk;
			var t = document.getElementById(kkk);//选取id为test的元素
			t.style.display = 'none';	// 隐藏选择的元素
			this.souyhinfo(kkk);
		},		
		souyhinfo(kkk){
			var _this= this;
			_this.axios
			.post('http://www.zhishiren.info/api/sou_yh_info/', {
				// yonghuid:_this.$cookies.get('userid'),
				leixing:kkk,
				})
			.then(function (response) {
				_this.yhinfo=response.data;
				// _this.$refs.liaolistk.shuaxin();
				});
		},
		zhankai_liaoshen(){
			var _this= this;
			_this.axios
			.post('http://www.zhishiren.info/api/zhankai_liaoshen/', {
				kkk:'kkk',
				})
			.then(function (response) {
				_this.liaoshenlist=JSON.parse(response.data);
				});
		},
		shenliao_pass(kkk){
			var _this= this;
			_this.axios
			.post('http://www.zhishiren.info/api/shenliao_pass/', {
				kkk:kkk,
				})
			.then(function (response) {
				_this.zhankai_liaoshen();				
				});
		}


	

	},
	data(){ return {
			dhx3:false,dhx2:false,dhx1:true,dhx4:false,dhx5:false,dhx6:false,dhx8:false,
			showloading1:false,
			userlist:[],
			yh_id:0,
			yhinfo:[],
			xx:'x1',
			liaoshenlist:[],
			show_liaoshenlist:false,
	}},

	computed:{
		welcomename(){return this.$cookies.get('username')},
		disabled_yn(){return this.$cookies.get('usertype')==='内容整理'?false:true}
		// disabled_yn(){return false}
	},
	
	created: function () {
		this.yh_id = this.$route.params.id;//获取上个页面传递的id,在下面获取数据的时候先提交id,这里的id不用加前缀
		if(this.yh_id==='1'){this.dhx3=true;this.dhx1=false;this.xx='x3';};
		var _this= this;
		_this.axios
		.post('http://www.zhishiren.info/api/show_liao_data/', {
			yonghuid:_this.$cookies.get('userid'),
			leixing:_this.yh_id,
			})
		.then(function (response) {
			_this.userlist=response.data.userlist;
			_this.jishu=response.data.jishu;
			_this.jishi=response.data.jishi;
			});
	},

  watch: {
        yh_id: function(newVal,oldVal){
          var yhid = newVal;
          if(yhid>80000000){
            var _this= this;
			_this.axios
			.post('http://www.zhishiren.info/api/sou_yh_info/', {
				yonghuid:_this.$cookies.get('userid'),
				leixing:yhid,
				})
			.then(function (response) {
				_this.yhinfo=response.data;
				// _this.$refs.liaolistk.shuaxin();
				});
          }
        },
    },






}
</script>

