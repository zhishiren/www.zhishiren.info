<template>
    <div id="zu2logo" class="logo">知识人
                <el-row style="height:270px">
					<el-col :span="24">
						<img src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/11112.jpg" class="bg_image" style="height:270px;" alt="">
						<div class="huanhang font22px juzhong" style="color:white;">
							值得您关注的特色功能...
						</div>
					</el-col>
				</el-row>

           		这里面要加入未来规划的特色功能
			</el-main>
			<el-main v-show="dh75" class="section_xh">
             这里有各种问题，民主投票，各类型的常见的问题等。共检产品，设计之初就是有利于公用，耐用，极简

    </div>
</template>

<script>
    export default {
        name:'zu2logo',
        props:['k'],//k是区分
        data() {return {

        }},
        computed:{

        },
        methods:{
            
            
        },
    };
</script>



