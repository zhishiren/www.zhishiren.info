

<template>
    <el-row id="tj_huifu">
		<el-row>
			<span v-if="show_huifulan===false">
				<span style="color:red;" v-if="it_att==='紧急重要'||it_att==='强烈推荐'||it_att==='反对异议'||it_att==='胡说八道'||it_att==='矛盾'">{{it_att}}<el-divider direction="vertical"></el-divider></span>
				<span style="color:orange;" v-if="it_att==='疑惑不解'||it_att==='让人困惑'||it_att==='言论怪异'||it_att==='更细化'">{{it_att}}<el-divider direction="vertical"></el-divider></span>
				<span style="color:green;" v-if="it_att==='点赞支持'||it_att==='聪明绝顶'||it_att==='古道心肠'||it_att==='一言九鼎'||it_att==='互补'">{{it_att}}<el-divider direction="vertical"></el-divider></span>
				<span style="color:grey;" v-if="it_type">{{it_type}}<el-divider direction="vertical"></el-divider></span>
				<showfanwei v-if="fanwei_id" style="color:grey;" :qz_id="fanwei_id"></showfanwei>
			</span>
			
			<!-- 这里的附件放在上一行，不在本组件里显示。<span style="color:grey;" v-if="jishu_fu"><el-divider direction="vertical"></el-divider><span>附件{{jishu_fu}}</span></span> -->
			<span v-if="show_huifulan===true">
				<span>已有{{this.hfshu}}条回复。</span>
				<i class="el-icon-caret-top"></i><input placeholder="明发需审核,密发不需审核。" v-model="hf_content" type="text" class="input_jian" style="color:grey;width:350px;font-size:16px;" >
				<span v-if="show_loading2===true"><i class="el-icon-loading" style="font-size:19px;color:grey;"></i></span>
				<span v-if="show_loading2===false">
					<span>
						<el-dropdown @command="choose_taidu">
							<span class="el-dropdown-link a_grey" style="font-size:17px;"><i class="el-icon-arrow-down el-icon--right"></i>态度</span>
							<el-dropdown-menu slot="dropdown">
								<el-dropdown-item command="点赞支持">点赞支持</el-dropdown-item>
								<el-dropdown-item command="反对异议">反对异议</el-dropdown-item>
								<el-dropdown-item command="疑惑不解">疑惑不解</el-dropdown-item>
							</el-dropdown-menu>
						</el-dropdown>
						<span v-if="taidu==='点赞支持'" style="color:green;">:{{this.taidu}}·</span><span v-if="taidu==='反对异议'" style="color:red;">:{{this.taidu}}·</span><span v-if="taidu==='疑惑不解'" style="color:orange;">:{{this.taidu}}·</span><span v-if="taidu===''">·</span>
						<span><input style="color:grey;" type="checkbox" v-model="niming" unchecked>匿名·</span>
					</span>
					<span><a @click="fabujian(0)" class="a_grey"><i class="el-icon-chat-dot-round"></i>明发</a>·</span>
					<span><a @click="fabujian(1)" class="a_grey"><i class="el-icon-s-comment"></i>密发</a>·</span>
					<span><a @click="huanyuanjian()" class="a_grey"><i class="el-icon-refresh-left"></i>取消</a></span>
					<span v-if="show_kong" style="color:orange">:输入不能空</span>
					<span v-if="show_error" style="color:orange">:操作失败！</span>
					<span v-if="show_addok" style="color:orange">:添加成功！</span>
				</span>
			</span>

			<span style="float:right;color:grey;">
				<a v-if="show_huifulan===false" @click="huifujian()" class="a_grey">回复:0</a>
				<span v-if="show_huifulan===false" ><el-divider direction="vertical"></el-divider></span>

				<span v-show="yonghuid!==createrid && dingcai===true">
					<a v-if="show_loading_ding===false" @click="ding()" class="a_grey">顶:0</a>
					<span v-if="show_loading_ding"><i class="el-icon-loading"></i></span>
					<span style="color:orange" v-if="dingerror===true">操作失败!</span>
					<el-divider direction="vertical"></el-divider>
					<a v-if="show_loading_cai===false" @click="cai()" class="a_grey">踩:0</a>
					<span v-if="show_loading_cai"><i class="el-icon-loading"></i></span>
					<span style="color:orange" v-if="caierror===true">操作失败!</span>
				</span>

				<span style="color:grey" v-if="show_yiding===true">
					<span>已顶{{this.jishu_ding}}</span>
				</span>

				<span style="color:grey" v-if="show_yicai===true">
					<span>已踩{{this.jishu_cai}}</span>
				</span>

				<span v-show="yonghuid===createrid && show_huifulan===false && show_loading3===false">
					<a v-if="news_yn!=='1'" @click="shanchu()" class="a_grey"><i class="el-icon-close"></i>删</a>
					<a v-if="news_yn==='1'" @click="shanchu_news()" class="a_grey"><i class="el-icon-close"></i>删</a>
					<span style="color:orange" v-if="notok">:删除失败</span>
				</span>
				<span v-if="show_loading3===true"><i class="el-icon-loading" style="font-size:19px;color:grey;"></i></span>

				<span v-if="timek==='0'"><el-divider direction="vertical"></el-divider>{{getNowFormatDate(create_time)}}</span>
				<span v-if="timek==='1'"><el-divider direction="vertical"></el-divider>{{formatDate_hm_8(create_time)}}</span>
			</span>
		</el-row>
		<span  v-if="show_huifulan===true">
			<el-row v-if="show_loading1===true" style="font-size:30px;color:grey;"><i class="el-icon-loading"></i>正在加载...</el-row>
			<el-row v-if="hfshu!==0" v-for="hf in lists" :key="hf.pk">
				<el-row  style="padding-left:18px;" :class="blinkyellow" v-if="hf.pk==return_id">
					<router-link class="a_black" target="_blank" :to="{name:'yonghuye',params:{id:hf.fields.act_createrid}}">
						<span v-if="hf.fields.act_createrid!==yonghuid">{{hf.fields.act_creatername}}</span>
					</router-link>
					<span v-if="hf.fields.act_createrid===yonghuid">你</span>
					<span v-if="hf.fields.act_fuyanzishu===0" style="color:brown;">:{{hf.fields.act_fuyan}}</span>
					<span v-if="hf.fields.act_fuyanzishu!==0" style="color:grey;">回复了一条{{hf.fields.act_fuyanzishu}}个字<span v-if="hf.fields.act_att==='点赞支持'" style="color:green;">支持</span><span v-if="hf.fields.act_att==='反对异议'" style="color:red;">反对</span><span v-if="hf.fields.act_att==='疑惑不解'" style="color:orange;">疑问</span>的密文:		
						<input style="width:1px;border-color:white;border:0px;" type="text" v-model="hf.fields.act_fuyan.slice(2,-1)" :id="hf.pk">
						<a class="a_brown" @click="kcopy(hf.pk)">复制密文</a>
					</span>
					<tj0huifu1 @hf_shan_ok="hfshanok()" :comm_id="hf.pk" :creater_id="hf.fields.act_createrid" :creater_name="hf.fields.act_creatername"></tj0huifu1>
				</el-row>
				<el-row  style="padding-left:18px;" v-if="hf.pk!==return_id">
					<router-link class="a_black" target="_blank" :to="{name:'yonghuye',params:{id:hf.fields.act_createrid}}">
						<span v-if="hf.fields.act_createrid!==yonghuid">{{hf.fields.act_creatername}}</span>
					</router-link>
					<span v-if="hf.fields.act_createrid===yonghuid">你</span>
					<span v-if="hf.fields.act_fuyanzishu===0" style="color:brown;">:{{hf.fields.act_fuyan}}</span>
					<span v-if="hf.fields.act_fuyanzishu!==0" style="color:grey;">回复了一条{{hf.fields.act_fuyanzishu}}个字<span v-if="hf.fields.act_att==='点赞支持'" style="color:green;">支持</span><span v-if="hf.fields.act_att==='反对异议'" style="color:red;">反对</span><span v-if="hf.fields.act_att==='疑惑不解'" style="color:orange;">疑问</span>的密文:
						<input style="width:1px;border-color:white;border:0px;" type="text" v-model="hf.fields.act_fuyan.slice(2,-1)" :id="hf.pk">
						<a class="a_brown" @click="kcopy(hf.pk)">复制密文</a>
					</span>
					<tj0huifu1 @hf_shan_ok="hfshanok()" :comm_id="hf.pk" :creater_id="hf.fields.act_createrid" :creater_name="hf.fields.act_creatername"></tj0huifu1>
				</el-row>
			</el-row>
			<el-pagination v-if="hfshu!==0" style="text-align:left;"
							:page-size=5
							:total="hfshu"
							:current-page.sync="currentPage"
							layout="total, prev, pager, next">
			</el-pagination>
		</span>

    </el-row>
</template>

<script>
import showfanwei from '../fujian/showfanwei';
import tj0huifu1 from '../tijiao/tj_huifu1';


export default {
	name:'tj_huifu',
	components: {showfanwei,tj0huifu1},

	data() {return {
		notok:false,
		show_huifulan:false,
		show_huifulan1:false,
		show_kong:false,
		show_error:false,
		show_addok:false,
		dingcai:true,
		show_yicai:false,
		show_yiding:false,
		hf_content:'',
		hf_content1:'',
		hfshu:0,
		hflist:[],
		jishu_cai:0,
		jishu_ding:0,
		dingerror:false,
		caierror:false,
		currentPage: 1,//分页相关
		return_id:0,//这个return_id是用户添加评论成功之后，
		blinkyellow:'',
		actid:0,
		show_loading0:false,
		show_loading1:false,
		show_loading2:false,
		show_loading3:false,
		show_loading_ding:false,
		show_loading_cai:false,
		taidu:'',
		niming:''
	}},

	props:['shuaxinid','news_yn','act_id','act_yan','creater_id','creater_name','create_time','timek','it_att','it_type','fanwei_id','item1title','item1type'],
	// props:['list','shuaxinid','news_yn','act_id','act_yan','creater_id','creater_name','create_time','timek','it_att','it_type','fanwei_id','item1title','item1type'],
// :act_id="list.news_comm_id" :act_yan="list.news_comm_content" :create_time="list.create_time.$date" :fanwei_id="list.news_fanwei" :it_type="list.item0_type" :it_att="list.news_attitude" :creater_id="list.createrid" :item1title="'你发表了言论:'+list.news_comm_content+'|'+getNowFormatDatetime(list.create_time.$date)"

	computed: {
			yonghuid(){return parseInt(this.$cookies.get('userid'))},
			createrid(){return parseInt(this.creater_id)},
			lists(){
                let pages=Math.ceil(this.hfshu/5);//
                let newList=[];
                for(let i=0;i<pages;i++){
                let sonList=[];
                sonList=this.hflist.slice(i*5,i*5+5);//
                newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
    },

	methods:{
		hfshanok(){
			this.show_loading1=true;
			var that=this;
			that.$nextTick(() => {
				that.$axios
				.post('http://www.zhishiren.info/api/huifu_list/',{act_id: that.act_id})
				.then(response=>{
					that.hflist=JSON.parse(response.data);
					that.hfshu=JSON.parse(response.data).length;
					that.show_loading1=false;
				});
			});
		},
		choose_taidu(taidu_value){this.taidu=taidu_value;},
		
		shanchu(){
			this.$confirm('确认后会将这条附言同时删除！', '确认删除这条附言？', {
				confirmButtonText: '确定',
				cancelButtonText: '取消',
				}).then(() => {
						var that=this;
						that.show_loading3=true;
						that.$axios
						.post('http://www.zhishiren.info/api/huifu_shan/',{act_id: that.act_id})
						.then(response=>{
							if(response.data.shan_ok==0){
									that.$emit('shanchuok');
									that.notok=false;
								}
							else{
									that.notok=true;
									setTimeout(function(){that.notok=false;}, 2000);
									that.show_loading3=false;
								};
						that.show_loading3=false;
						})
						}).catch(() => {
						this.$message({
							type: 'info',
							message: '已取消「删除」操作'
						});          
						});
			
		},
		shanchu_news(){
			this.$confirm('确认后会将这条言论同时删除！', '确认删除这条言论？',{
						confirmButtonText: '确定',
						cancelButtonText: '取消',
						}).then(() => {
							var that=this;
							that.show_loading3=true;
							that.$axios
							.post('http://www.zhishiren.info/api/shan_news/',{act_id:that.act_id})
							.then(response=>{
								if(response.data.shan_ok==0){
										that.$emit('shanchuok');
										that.notok=false;
									}
								else{
										that.notok=true;
										setTimeout(function(){that.notok=false;}, 2000);
										that.show_loading3=false;
									};
							that.show_loading3=false;
							})
						}).catch(() => {
						this.$message({
							type: 'info',
							message: '已取消「删除」操作'
						});          
						});

		},
		huifujian:function(){
			this.show_huifulan=true;
			this.show_loading1=true;
			var that=this;
			that.$nextTick(() => {
				that.$axios
				.post('http://www.zhishiren.info/api/huifu_list/',{act_id: that.act_id})
				.then(response=>{
					that.hflist=JSON.parse(response.data);
					that.hfshu=JSON.parse(response.data).length;
					that.show_loading1=false;
					// if(response.data.shan_ok==0){
					// 		that.$emit('shanchuok');
					// 		that.notok=false;
					// 	}
					// else{
					// 		that.notok=true;
					// 		setTimeout(function(){that.notok=false;}, 2000);
					// 	}
				});
			});
		},
		ding:function(){
			var that=this;
			that.show_loading_ding=true;
			that.$axios
			.post('http://www.zhishiren.info/api/huifu_ding/',{act_id: that.act_id,userid:that.yonghuid,})
			.then(response=>{
				if(response.data.ding_ok==0){
						that.dingcai=false;
						that.show_yiding=true;
						that.jishu_ding=response.data.jishu;
						that.show_loading_ding=false;
					}
				if(response.data.ding_ok==1){that.dingerror==true;}
			})
		},
		cai:function(){
			var that=this;
			that.show_loading_cai=true;
			that.$axios
			.post('http://www.zhishiren.info/api/huifu_cai/',{act_id: that.act_id,userid:that.yonghuid,})
			.then(response=>{
				if(response.data.cai_ok==0){
						that.dingcai=false;
						that.show_yicai=true;
						that.jishu_cai=response.data.jishu;
						that.show_loading_cai=false;
					}
				if(response.data.cai_ok==1){that.caierror==true;}
			})
		},
		fabujian:function(mi){
			var that=this;
			if(that.hf_content==''){
				that.show_kong=true;
				setTimeout(function(){that.show_kong=false;}, 2000);		
			}
			else{
				that.show_loading2=true;
				that.$axios
				.post('http://www.zhishiren.info/api/huifu_jia/',{
					act_yan:that.act_yan,
					act_id: that.act_id,
					hf_content:that.hf_content,
					userid:that.yonghuid,
					username:that.$cookies.get('username'),
					item1id:that.creater_id,
					item1type:that.item1type,
					item1title:that.item1title,
					mi_yn:mi,
					taidu:that.taidu,
					})
				.then(response=>{
					if(response.data.jia_ok==0){
						var that=this;
						that.return_id = response.data.rrid;
						that.$nextTick(() => {
							that.$axios
								.post('http://www.zhishiren.info/api/huifu_list/',{act_id: that.act_id})
								.then(response=>{
									that.hflist=JSON.parse(response.data);
									that.hfshu=JSON.parse(response.data).length;
									that.currentPage=1;
									that.blinkyellow='blinkyellow';
									setTimeout(function(){that.blinkyellow='';}, 2000);
									that.show_addok=true;
									setTimeout(function(){that.show_addok=false;that.hf_content=''}, 2000);
									that.show_loading2=false;
									that.taidu='';
								});
						});
					}
					else{
						that.show_error=true;
						setTimeout(function(){that.show_error=false;}, 2000);
						that.taidu='';
					}
				})
			}	
		},

		huanyuanjian:function(){
			this.show_huifulan=false;
		},
		kcopy(a){
        	let copycode = document.getElementById(a);
            copycode.select(); // 选择对象
            document.execCommand("Copy"); // 执行浏览器复制命令
            alert("密文已经复制到你的粘贴板，请到首页右侧‘密’功能栏解密。");
            // alert(copycode.value);
        },

	},

    // created: function () {
    //         this.show_huifulan=false;
	// },

	watch: {
		shuaxinid: {
			handler: function(newVal,oldVal){
				this.show_huifulan=false;
			},
			immediate: true
		},

		// act_id: {
		// 	handler: function(newVal,oldVal){
		// 		var actid = newVal;
        //         var _this=this;
		// 		_this.show_loading0=true;

				
		// 	},
		// 	immediate: true
		// },

		
	},
};

</script>


<!--


				-->


