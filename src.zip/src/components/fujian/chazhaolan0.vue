<!-- 常用的组件。
这个transition是elementjs中的动画效果，要放在显示内容的外部才有效果 
在父组件中引用就要写成这样：<chazhaolan0 @shuaxin="shuaxin" @huanyuan="huanyuan" @get_list="get_list" @send_searchword="send_searchword"></chazhaolan0>
-->
<template>
    <span id="chazhaolan0" class="font18px">
				<a v-show="show_zhankai" @click="zhankaijian" class="a_black">-展开-</a> 
				<transition name="el-zoom-in-center">
					<span v-show="show_chazhaolan">
							<input type="text" class="input_jian font18px" size="mini" v-model="keyword" placeholder="在以下结果中查找">
							<a @click="chazhaojian(keyword)" class="a_black"><i class="el-icon-search"></i>查找</a>   
							&nbsp;
							<span style="color:orange" v-show="show_chazhaokong"><i class="el-icon-warning"></i>关键词不能为空！</span>
							<a v-show="show_shuaxin" @click="shuaxinjian" class="a_black"><i class="el-icon-refresh"></i>刷新</a>
                            &nbsp;
                            <span v-show="show_huanyuan" style="color:blue"><i class="el-icon-finished"></i>{{this.listNumk}}个结果</span>
                            &nbsp;
                            <a v-show="show_huanyuan" @click="huanyuanjian" class="a_black"><i class="el-icon-refresh-left"></i>还原</a>
                            &nbsp;
					</span>
				</transition>
    </span>
</template>

<script>
export default {
    name:'chazhaolan0',

    props:['listNumk'],
	data() {return {
        keyword:'',
        show_chazhaokong:false,
        show_zhankai:true,
        show_chazhaolan:false,
        show_shuaxin:true,
        show_huanyuan:false,
        }},
 
    methods:{
				zhankaijian:function(){
					this.show_zhankai=false;
                    this.show_chazhaolan=true;
                    this.$emit('get_list');
				},
				chazhaojian:function(keyword){

                    if(keyword==''){

                        // 这是说明刚展开的阶段，这是输入空值后的表现
                        this.show_chazhaokong=true;
                        this.show_huanyuan=false;
                        this.show_shuaxin=true;
                        
                    }else{
                        this.show_huanyuan=true;
                        this.show_shuaxin=false;
                        this.show_chazhaokong=false;
                        let data = {k: keyword};
                        this.$emit('send_searchword',data);
                    }
                },

				shuaxinjian:function(){
					this.show_zhankai=false;
                    this.show_chazhaolan=true;
                    this.$emit('shuaxin');
                    // this.$emit('send_searchword',data);
                    //这个nexttick是一种Vue中DOM的异步更新功能，用于刷新循环列表的数据源
                    // this.$nextTick(() => {this.$axios.get(this.url_xunhuan).then(response=>{this.$store.state['XH'+this.sectionid]=JSON.parse(response.data)});});
                },
                huanyuanjian:function(){
                    this.show_huanyuan=false;
                    this.show_shuaxin=true;
                    this.show_chazhaokong=false;
                    this.keyword='';
                    this.$emit('huanyuan');

                },
                addnew(){
					this.show_zhankai=false;
                    this.show_chazhaolan=true;
                }

	},

};

</script>


