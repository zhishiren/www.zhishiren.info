<template>
	<div id="zengwenji">
        <el-row style="line-height: 40px;" >
            <el-col :span="2" ><span >书名标题：</span></el-col>
            <el-col :span="14" >
                <el-input v-model="wj_title" placeholder="请输入文章标题"  style="width:96%;"></el-input>
            </el-col>
            <el-col :span="2" ><span >公开范围：</span></el-col>
            <el-col :span="6" >
                <zu0setfanwei ref="huanyuan" @set_fanwei="set_gongkaifanwei" style="width:90%;"></zu0setfanwei>
            </el-col>
        </el-row>
        <br>

        <el-row style="line-height: 40px;" >
            <el-col :span="2" ><span >生效日期：</span></el-col>
            <el-col :span="6" >
                <el-date-picker
                    v-model="born_time"
                    type="date"
                    value-format="yyyy-MM-dd"
                    placeholder="选择日期">
                </el-date-picker>
            </el-col>

            <el-col :span="2" ><span >文件类型：</span></el-col>
            <el-col :span="6" >
                <el-select v-model="wj_type" placeholder="请选择文章的类型" style="width:90%;">
                    <el-option value="知识百科" key="知识百科" label="知识百科"></el-option>
                    <el-option value="国家法规" key="国家法规" label="国家法规"></el-option>
                    <el-option value="行业标准" key="行业标准" label="行业标准"></el-option>
                    <el-option value="企业制度" key="企业制度" label="企业制度"></el-option>
                    <el-option value="学术著作" key="学术著作" label="学术著作"></el-option>
                    <el-option value="新闻简讯" key="新闻简讯" label="新闻简讯"></el-option>
                    <el-option value="公告通知" key="公告通知" label="公告通知"></el-option>
                    <el-option value="经验分享" key="经验分享" label="经验分享"></el-option>
                    <el-option value="历史文献" key="历史文献" label="历史文献"></el-option>
                    <el-option value="通俗读物" key="通俗读物" label="通俗读物"></el-option>
                    <!-- <el-option value="暂无类型" key="暂无类型" label="暂无类型"></el-option> -->
                </el-select>
            </el-col>
            <el-col :span="2" ><span >所属地区：</span></el-col>
            <el-col :span="6" >
                <el-input v-model="diqu" placeholder="请选择所属地区"  style="width:90%;"></el-input>
            </el-col>
        </el-row>
        <br>
        <el-row style="line-height: 40px;" >
            <el-col :span="2" ><span >失效日期：</span></el-col>
            <el-col :span="6" >
                <el-date-picker
                    v-model="dead_time"
                    type="date"
                    value-format="yyyy-MM-dd"
                    placeholder="选择日期">
                </el-date-picker>
            </el-col>

            <el-col :span="2" ><span >所属行业：</span></el-col>
            <el-col :span="6" >
                <el-input v-model="hangye" placeholder="请选择所属的行业"  style="width:90%;"></el-input>
            </el-col>

            <el-col :span="2" ><span >发文机构：</span></el-col>
            <el-col :span="6" >
                <el-input v-model="fawenjigou" placeholder="请输入发文机构或作者"  style="width:90%;"></el-input>
            </el-col>
        </el-row>

        <br>
        <zu1fabujian @fabujian="fabujian" :faloading="faloading" :return_msg="return_msg"></zu1fabujian>
        <zu1caozuojishu zone_id="xzwj" :jishu="listNum0" :showloading1="showloading1" :showloading2="showloading2" @zhankai="zhankaijian()" @shuaxin="shuaxinjian()"></zu1caozuojishu>
        <div v-if="showloading2===false">
            <el-row v-for="item in lists" :key="item.pk"  class="br10px17px">
                <el-row>
                    <router-link class="a_black" style="float:left;" target="_blank" :to="{name:'wenjiye',params:{id:item.pk}}">
                        <span style="float:left;">{{item.fields.wj_title}}</span>
                    </router-link>
                    <!-- <upload0 :uploaded="item.fields.wj_yuanwen" :id="item.pk"></upload0> -->
                    <zu0uploadfu v-if="usertype==='内容整理'" :leixing=2 :fujianshu="item.fields.fu" :id="item.pk"></zu0uploadfu>
                </el-row>
                <el-row>
                    <span :style="{'color':(item.fields.wj_status==='失效已删'?'red':'black')}">{{item.fields.wj_status}}</span>
                    <span><el-divider direction="vertical"></el-divider></span>
                    <span v-if="item.fields.wj_type">{{item.fields.wj_type}}<el-divider direction="vertical"></el-divider></span>
                    <zu0showfanwei :qz_id="item.fields.wj_fanwei"></zu0showfanwei>
                    <zu0zengshanchu :zhid="item.pk" leixing="2" :yishan_yn="item.fields.wj_status" :time="item.fields.wj_createtime" @shanchuok="shanok()" ></zu0zengshanchu>
                </el-row>
                <el-row><el-divider style="margin:0px;"></el-divider></el-row>
            </el-row>
            <br>
            <el-pagination v-if="listNum>10" style="text-align:right;"
                            background
                            :page-size=10
                            :total="listNum"
                            :current-page.sync="currentPage"
                            layout="total, prev, pager, next">
            </el-pagination>
        </div>
    </div>
</template>


<script type="text/javascript">
export default {
    name: 'zengwenji',
    components: {},
    props:['showloading1','listNum0'],

    data () {
        return {
            qunzu_id:90000000,
            wj_title:'',
            wj_type:'暂无类型',
            diqu:'',
            hangye:'',
            fawenjigou:'',
            born_time:null,
            dead_time:null,
            
            xhx2s:[],
            currentPage: 1,//当前分页的数值

            showloading2:false,
            faloading:false,
            return_msg:'',

            listNum:0
        }
    },
    
    computed: {
            lists(){
                let pages=Math.ceil(this.listNum/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                let sonList=[];
                sonList=this.xhx2s.slice(i*10,i*10+10);//10为每页设置数量
                newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
            usertype(){return this.$cookies.get('usertype')},
    },


    methods: {
        shanok(){this.shuaxinjian();},
        set_gongkaifanwei(data){this.qunzu_id = data.qz_id;},
        zhankaijian(){this.shuaxinjian();},
        shuaxinjian(){
            this.showloading2=true;
            this.axios
                    .post('http://www.zhishiren.info/api/xunhuan_zengwenji/',{userid: this.$cookies.get('userid')})
                    .then(response=>{
                        this.xhx2s=JSON.parse(response.data);
                        this.listNum=JSON.parse(response.data).length;
                        this.listNum0=JSON.parse(response.data).length;
                        this.showloading2=false;
                        this.currentPage=1;
                    });
            
        },
        fabujian(data) {
            var fuyan=data.k;
            var that = this;
            if(that.wj_title===''){
                that.return_msg='书名不能为空!';
                setTimeout(function(){that.return_msg='';}, 1500);
            }
            else{
                    that.axios
                    .post('http://www.zhishiren.info/api/zengwenji/',{
                        userid: that.$cookies.get('userid'),
                        username:that.$cookies.get('username'),
                        wj_title:that.wj_title,
                        wj_shuoming:fuyan,
                        wj_type:that.wj_type,
                        wj_diqu:that.diqu,
                        wj_hangye:that.hangye,
                        wj_fawenjigou:that.fawenjigou,
                        wj_born_time:that.born_time,
                        wj_dead_time:that.dead_time,
                        wj_fanwei:that.qunzu_id,
                        })
                    .then(function (response) {
                        that.faloading=false;
                        if (response.data.msg===1 ){
                            that.return_msg='操作成功';
                            setTimeout(function(){that.return_msg='';}, 2000);

                            that.wj_title='';
                            that.wj_type='暂无类型';
                            that.diqu='';
                            that.hangye='';
                            that.fawenjigou='';
                            that.born_time=null;
                            that.dead_time=null;
                            that.$refs.huanyuan.huanyuan();

                            that.shuaxinjian();
                        }
                        if (response.data.msg === 3){
                            that.return_msg='操作失败';
                            setTimeout(function(){that.return_msg='';}, 1500);
                            that.showloading2=false;
                        }
                    });
                }
        },
    },

}
</script>

<style scoped>

</style>