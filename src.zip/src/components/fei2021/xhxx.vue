<!-- 这是用于这个网站所有循环的模版，其中变量中带有k是指经过查找的带有关键词的变量，与原始的有所区别-->
<template>
	<div>
        <!-- 下面的div是用来显示原始未筛选的列表，通过vshow来控制是否显示 -->
        <div v-show="show_xh11" v-for="list in lists" :key="list.id">
                {{list.date}}----{{list.name}}
        </div>
        <!-- 下面的div是用来显示筛选后的列表 -->
        <div v-show="show_xhk11" v-for="listk in listks" :key="listk.id">
                {{listk.date}}----{{listk.name}}
        </div>

        <!-- 下面的div是用来显示原始的未筛选的分页条 -->
		<el-pagination v-show="show_xh11"  style="text-align:right;"
                        background
:page-size=8
						:total="listNum"
						:current-page.sync="currentPage"
						layout="total, prev, pager, next">
		</el-pagination>

        <!-- 下面的div是用来显示筛选后的分页条 -->
		<el-pagination v-show="show_xhk11" style="text-align:right;"
                        background
:page-size=8
						:total="listNumk"
						:current-page.sync="currentPagek"
						layout="total, prev, pager, next">
		</el-pagination>

    </div>


</template>

<script>
import tj0shanchu from '../tijiao/tj_shanchu';
import tj0huifu from '../tijiao/tj_huifu';

export default {
    components: {tj0shanchu,tj0huifu},

	data() {return {
        currentPage: 1,//当前分页的数值
        listNum:1,//分页总条数
        currentPagek: 1,//查找后，当前分页的数值
        listNumk:1,//查找后，分页总条数
    }},

    mounted() {
        this.listNum=this.xh11s.length;//显示所有条目的总数
        this.listNumk=this.xh11ks.length;//显示所有条目的总数，查找后
    },

    filters: {},
    
	computed: {
        keyword11(){return this.$store.state.KEYWORD11},//这是查找的关键词信息
        show_xh11(){return this.$store.state.SHOW_XH11},//这是控制是否显示的判断值
        show_xhk11(){return this.$store.state.SHOW_XHK11},
        xh11s(){return this.$store.state.XH11},//这是原始未筛选的清单信息
        xh11ks(){return search(this.keyword11,this.$store.state.XH11)},//这是筛选后的清单信息

            lists(){
                let pages=Math.ceil(this.xh11s.length/8);//
                let newList=[];
                for(let i=0;i<pages;i++){
                let sonList=[];
                sonList=this.xh11s.slice(i*10,i*10+10);//
                newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },

            listks(){
                let pages=Math.ceil(this.xh11ks.length/8);//
                let newList=[];
                for(let i=0;i<pages;i++){
                let sonList=[];
                sonList=this.xh11ks.slice(i*10,i*10+10);//
                newList.push(sonList)
                }
                return newList[this.currentPagek-1]
            },


	},
	methods:{
      handleSizeChange(val) {console.log(`每页 ${val} 条`);},
      handleCurrentChange(val) {console.log(`当前页: ${val}`);},
    },	
};
</script>

<style>
</style>


