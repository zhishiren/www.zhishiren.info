
<template>
    <span id="zu0tongjishu" style="color:green;" class="font18px;">
        <span><el-divider direction="vertical"></el-divider>点击{{this.dj}}</span>
        <span><el-divider direction="vertical"></el-divider><span v-show="this.qz_yn!=='1'">关注</span><span v-show="this.qz_yn==='1'">加入</span>{{this.gz}}</span>
        <span><el-divider direction="vertical"></el-divider>分享{{this.fx}}</span>
    </span>
</template>

<script>
export default {
	data() {return {}},
	props: ['dj','gz','fx','qz_yn'],

};

</script>

