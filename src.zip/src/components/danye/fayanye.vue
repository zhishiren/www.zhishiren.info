
//这个组件是提问页面和发言页面共用的。
<template>
<div id="fayanye"  @click="turnfresh()">
		<zu2logo k=1></zu2logo>
		<zu2errorpage v-if="errorid!==0" :errorid="errorid"></zu2errorpage>
		<el-container v-if="errorid===0">
			<el-aside width="120px" class="bgcolor_FF"></el-aside>
			<el-main v-if="fy_info.fy_status==='正常有效'" class="bgcolor_FC font18px">
				<el-card v-if="fy_info" class="box-card">
					<el-row >
						<span style="color:grey">{{formatDate_ymdhm(this.fy_info.fy_createtime)}}</span>
						<el-divider direction="vertical"></el-divider>
						<router-link class="a_black" target="_blank" :to="{name:'yonghuye',params:{id:fy_info.fy_createrid}}">
							<span class="a_black">{{this.fy_info.fy_creatername}}</span>
						</router-link>
						<span v-if="fy_info.wen_yn!=='提问'" style="color:grey">发言说</span>
						<span v-if="fy_info.wen_yn==='提问'" style="color:grey">提问说</span>
						<b>:</b>
						<el-col :span="24"  class="font21px">
							<font style="font-size:25px;"><b>“</b></font>
							<span v-html="this.fy_info.fy_content" style="color:brown;"></span>
							<font style="font-size:25px;"><b>”</b></font>
						</el-col>
					</el-row>
					<zu0fujianfutu v-if="this.fy_info.fy_fu!==0" :zhid="fy_info.fy_id"></zu0fujianfutu>
					<el-row>
						<span><b>属性<i class="el-icon-caret-right"></i></b></span>
						<span>ID:{{this.fy_info.fy_id}}<el-divider direction="vertical"></el-divider></span>
						<span style="color:red;" v-if="fy_info.fy_att==='紧急重要'">{{fy_info.fy_att}}<el-divider direction="vertical"></el-divider></span>
						<span>{{this.fy_info.fy_fytype}}<el-divider direction="vertical"></el-divider></span>
						<span style="color:red;" v-if="fy_info.fy_status==='失效已删'">{{this.fy_info.fy_status}}<el-divider direction="vertical"></el-divider></span>
						<span v-if="fy_info.fy_status!=='失效已删'">{{this.fy_info.fy_status}}<el-divider direction="vertical"></el-divider></span>
						<zu0showfanwei :qz_id="fy_info.fy_fanwei"></zu0showfanwei>
						<zu0tongjishu :dj="fy_tongji.dianji" :gz="fy_tongji.guanzhu" :fx="fy_tongji.fenxiang"></zu0tongjishu>
					</el-row>
				</el-card>
				<el-card v-if="!fy_info">
					<br>
						<div style="text-align:center;font-size:30px;"><i class="el-icon-loading"></i>正在加载...</div>
					<br>
				</el-card>
			</el-main>
			<el-aside width="120px" class="bgcolor_FC"></el-aside>
		</el-container>

		<el-container v-if="errorid===0">
			<el-aside width="120px">
				<el-menu default-active="12" class="el-menu-vertical-demo bgcolor_menu_FC" @open="handleOpen" @close="handleClose">
			      <el-menu-item v-if="fy_info.wen_yn!=='提问'" @click="daohang11" index="11" class="font18px">
			        <!-- <span v-if="fy_info.wen_yn!=='提问'" slot="title">发言全集</span>
			        <span v-if="fy_info.wen_yn==='提问'" slot="title">提问全集</span> -->
			        <span slot="title">发言全集</span>

			      </el-menu-item>
				  <el-menu-item @click="daohang12" index="12" class="font18px">
			        <span slot="title">关注分享</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang13" index="13" class="font18px">
			        <span v-if="fy_info.wen_yn!=='提问'" slot="title">评论</span>
			        <span v-if="fy_info.wen_yn==='提问'" slot="title">解答评论</span>
			      </el-menu-item>
			      <el-menu-item  v-if="fy_info.wen_yn!=='提问'" @click="daohang14" index="14" class="font18px">
			        <span slot="title">关联知识</span>
			      </el-menu-item>
			      <!-- <el-menu-item @click="daohang15" index="15" class="font18px">
			        <span slot="title">推荐阅读</span>
			      </el-menu-item>
				  <el-menu-item @click="daohang16" index="16" class="font18px">
			        <span slot="title">内容管理</span>
			      </el-menu-item>				       -->
			    </el-menu>
			</el-aside>
			<el-main v-show="dh12" class="section_xh">
				<zu1caozuojishu zone_id="分享" :zhid="fy_info.fy_id" type0="fayanye" :title0="fy_info.fy_content" :fanwei="fy_info.fy_fanwei"></zu1caozuojishu>
				<br>
				<zu1caozuojishu zone_id="关注" :zhid="fy_info.fy_id" type0="fayanye" :title0="fy_info.fy_content" ></zu1caozuojishu>
				<br>
				<zu1caozuojishu zone_id="纠错" :zhid="fy_info.fy_id" type0="fayanye" :title0="fy_info.fy_content"></zu1caozuojishu>
				<br>
				<xhcaozuo zoneid="加入标签" :zhid="fy_info.fy_id" :title0="fy_info.fy_content" type0="fayanye" :fanwei="fy_info.fy_fanwei" :listNum="fy_tongji.biaoqian"></xhcaozuo>
			</el-main>
			<el-main v-show="dh13" class="section_xh">
				<xhcaozuo v-if="fy_info.wen_yn==='提问'" zoneid="评论" :zhid="fy_info.fy_id" :title0="fy_info.fy_content" type0="fayanye" :fanwei="fy_info.fy_fanwei" :listNum="fy_tongji.pinglun"></xhcaozuo>
				<xhcaozuo v-if="fy_info.wen_yn!=='提问'" zoneid="评论" :zhid="fy_info.fy_id" :title0="fy_info.fy_content" type0="fayanye" :fanwei="fy_info.fy_fanwei" :listNum="fy_tongji.pinglun"></xhcaozuo>
			</el-main>
			<el-main v-show="dh14" class="section_xh">
			    <xhcaozuo zoneid="关联" :zhid="fy_info.fy_id" :title0="fy_info.fy_content" type0="fayanye" :fanwei="fy_info.fy_fanwei" :listNum="fy_tongji.guanlian"></xhcaozuo>
			</el-main>
			<el-main v-show="dh15" class="section_xh"></el-main>
			<el-main v-show="dh11" class="section_xh">
			    <xhcaozuo v-if="fy_info.wen_yn!=='提问'" zoneid="发言列表" :createrid="fy_info.fy_createrid" :zhid="fy_info.fy_id" :title0="fy_info.fy_content" type0="fayanye" :fanwei="fy_info.fy_fanwei" :listNum="fy_tongji.guanlian"></xhcaozuo>
			    <xhcaozuo v-if="fy_info.wen_yn==='提问'" zoneid="提问列表" :createrid="fy_info.fy_createrid" :zhid="fy_info.fy_id" :title0="fy_info.fy_content" type0="fayanye" :fanwei="fy_info.fy_fanwei" :listNum="fy_tongji.guanlian"></xhcaozuo>
			</el-main>
			<el-main v-show="dh16" class="section_xh">
				<xhchanged :zhid="fy_info.fy_id" zhitype="fayanye" :list='fy_info' :managerid="fy_info.fy_manager" :zhicontent="fy_info.fy_content" :fanwei="fy_info.fy_fanwei" :listNum="fy_tongji.xiugai"></xhchanged>
			</el-main>

			<el-aside width="120px" class="bgcolor_FC"></el-aside>


		</el-container>
	</div>

</template>

<script>

import Xhqznei from '../xunhuan/xhqznei.vue';


export default {
        name:'fayanye',
		components: {Xhqznei,},
        methods:{
                    daohang11(){this.dh11=true;this.dh12=false;this.dh13=false;this.dh14=false;this.dh15=false;this.dh16=false;},
                    daohang12(){this.dh12=true;this.dh11=false;this.dh13=false;this.dh14=false;this.dh15=false;this.dh16=false;},
                    daohang13(){this.dh13=true;this.dh11=false;this.dh12=false;this.dh14=false;this.dh15=false;this.dh16=false;},
                    daohang14(){this.dh14=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh15=false;this.dh16=false;},
                    daohang15(){this.dh15=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh14=false;this.dh16=false;},
					daohang16(){this.dh16=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh14=false;this.dh15=false;},
					//这里的k值指的是关注这种类型，以后可能会加入其他类型
					add1(k){
						if(k==1){this.fy_tongji.fenxiang++;}
						if(k==2){this.fy_tongji.guanzhu++;}
					},
					minus1(k){
						if(k==2){this.fy_tongji.guanzhu--;}
					},

        },
        data() {
			return {dh15:false,dh11:false,dh13:false,dh14:false,dh12:true,dh16:false,
			fayan_id:0,
			fy_info:[],
			fy_tongji:[],
			fulist:[],
			fucount:0,
			futuid:100000210,
			errorid:0,
			}
        },
        created() {
				this.fayan_id = this.$route.params.id;//获取上个页面传递的id,在下面获取数据的时候先提交id,这里的id不用加前缀
				var _this= this;
				_this.axios
				.post('http://www.zhishiren.info/api/show_fayanye/', {fayan_id:_this.fayan_id})
				.then(function (response) {
					_this.fy_info=response.data;
					_this.fy_tongji=JSON.parse(response.data.fy_tongji);
					_this.showloading1=false;
					if(_this.fy_info.fy_zishu!==0){
						// _this.$router.push({name: 'errorpage', params: { id: 1 } });
						_this.errorid=1;
					}else{
						_this.errorid=errorid_transfer(_this.fy_info.fy_fanwei);
					}
				});
		},
		computed: {
				
		},
};

</script>

<style scoped>

</style>




