<template>
	<div>
        <el-row style="line-height: 40px;" >
            <el-col :span="2" >
                <span >发言类型：</span>
            </el-col>
            <el-col :span="6" >
                <el-select v-model="type_value" placeholder="请选择发言的类型" style="width:90%;">
                    <!-- <el-option value="fy0" key="fy0" label="暂无类型"></el-option> -->
                    <el-option value="求助询问" key="求助询问" label="求助询问"></el-option>
					<el-option value="时事新闻" key="时事新闻" label="时事新闻"></el-option>
					<el-option value="公告通知" key="公告通知" label="公告通知"></el-option>
					<el-option value="感悟思考" key="感悟思考" label="感悟思考"></el-option>
					<el-option value="名人名言" key="名人名言" label="名人名言"></el-option>
					<el-option value="经验分享" key="经验分享" label="经验分享"></el-option>
					<el-option value="行动实践" key="行动实践" label="行动实践"></el-option>
                </el-select>
            </el-col>
            <el-col :span="2" >
                <span >发言态度：</span>
            </el-col>
            <el-col :span="6" >
                <el-select v-model="fayan_att" placeholder="请选择发言的态度" style="width:90%;">
                    <el-option value="无态度" key="无态度" label="无态度"></el-option>
					<el-option value="紧急重要" key="紧急重要" label="紧急重要"></el-option>
                </el-select>
            </el-col>
            <el-col :span="2" >
                <span>公开范围：</span>
            </el-col>
            <el-col :span="6" >
                <fanwei ref="huanyuan" @set_fanwei="set_gongkaifanwei" style="width:90%;"></fanwei>
            </el-col>
        </el-row>
        <br>
        <el-row >
                <el-col :span="2" >
                    <span class="font16px">发言内容：</span>
                </el-col>
                <el-col :span="20" >
                    <div contenteditable ref="contents" @paste="onPaste" class="pinglunlan" style="font-size:16px;width:100%;">请输入你要发言的内容。</div>
                </el-col>
                <el-col :span="2">
                    <a class="a_black" href="javascript:;" @click="f_blod">
                        <b>所选加粗</b>
                    </a>
                </el-col>
        </el-row>
        <el-row style="text-align:center;line-height: 40px;">
                <span v-show="ok_msg===0 && fa_loading!==true">
                    <a class="font20px a_black"  @click="fabujian(0)">明发</a>
                    <el-divider direction="vertical"></el-divider>
                    <a class="font20px a_black"  @click="fabujian(1)">密发</a>
                </span>
                <faloading :fa_loading="fa_loading" :ok_msg="ok_msg"></faloading>
        </el-row>

        <el-row  class="font17px">
            <span>你共曾发表过<span v-if="count_loading===false">{{this.listNum}}</span><span v-if="count_loading"><i class="el-icon-loading"></i></span>条言论。</span>
            <zhankai0 ref="zhankai0" @get_list="zhankaijian" @shuaxin="shuaxinjian"></zhankai0>
        </el-row>
        <div v-if="x3_loading===true">
            <div style="font-size:30px;color:grey;"><i class="el-icon-loading"></i>正在加载...</div>
        </div>
        <div v-if="show_zhankai==false">
                <el-row v-for="item in lists" :key="item.pk"  class="br10px17px">
                    <el-row>
                        <router-link v-if="item.fields.fy_zishu===0" class="a_black" style="float:left;" target="_blank" :to="{name:'fayanye',params:{id:item.pk}}">
                                    <span style="color:brown;max-width: 600px;max-height:25px; float: left;overflow: hidden; white-space: nowrap;text-overflow: ellipsis;-o-text-overflow: ellipsis; ">
                                        <font style="font-size:18px;color:black;"><b>“</b></font>
                                            <a class="a_brown" :title="item.fields.fy_content"><span  v-html="item.fields.fy_content"></span></a>
                                    </span>
                                    <span style="font-size:18px;"><b>”</b></span>
                        </router-link>
                        <miwen v-if="item.fields.fy_zishu!==0" :pkid='item.pk' :content='item.fields.fy_content.slice(2,-1)' :zishu='item.fields.fy_zishu'></miwen>
                        <uploadfu v-if="item.fields.fy_zishu===0 && usertype==='内容整理'" :leixing=3 :fujianshu="item.fields.fu" :id="item.pk"></uploadfu>
                    </el-row>
                    <el-row>
                            <span style="color:red;" v-if="item.fields.fy_att==='紧急重要'">{{item.fields.fy_att}}<el-divider direction="vertical"></el-divider></span>
                            <span>{{item.fields.fy_type}}</span>
                            <el-divider direction="vertical"></el-divider>
                            <showfanwei :qz_id="item.fields.fy_fanwei"></showfanwei>
                            <span> 
                                <el-divider direction="vertical"></el-divider>
                                <span style="color:red;"  v-if="item.fields.fy_status==='s5'">拒绝退回</span>
                                <span style="color:orange;" v-if="item.fields.fy_status==='s9'">正在审核</span>
                                <span style="color:green;" v-if="item.fields.fy_status==='s0' && item.fields.fy_zishu===0">审核通过</span>
                                <span style="color:grey;" v-if="item.fields.fy_zishu!==0">不需审核</span>
                            </span>
                            <span style="float:right">
                                    <tj0shanchu :zhid="item.pk" leixing="3" @shanchuok="shanok()"></tj0shanchu>
                                    {{formatDate_ymd(item.fields.fy_createtime)}}
                            </span>
                    </el-row>
                    <el-row><el-divider style="margin:0px;"></el-divider></el-row>
                </el-row>
                <br>
                <el-pagination v-if="listNum>10" style="text-align:right;"
                                background
                                :page-size=10
                                :total="listNum"
                                :current-page.sync="currentPage"
                                layout="total, prev, pager, next">
                </el-pagination>
        </div>



</div>

</template>


<script type="text/javascript">
import uploadfu from '../fujian/uploadfu';
import fanwei from '../fujian/fanwei';
import miwen from '../fujian/miwen';
import showfanwei from '../fujian/showfanwei';
import tj0shanchu from '../tijiao/tj_shanchu';
import zhankai0 from '../fujian/zhankai0';
import faloading from '../fujian/faloading.vue';

	export default {
		name: 'bdx3',
        components: {miwen,uploadfu,fanwei,showfanwei,tj0shanchu,zhankai0,faloading},

        data () {
			return {
                ok_msg:0,
                qunzu_fanwei_id:90000000,

                fayan_att:'无态度',
                type_value:'公告通知',
                show_zhankai:true,
                xhx3s:[],
                currentPage: 1,//当前分页的数值
                listNum:0,
                blinkyellow:'',
                fa_loading:false,

                x3_loading:false,
                count_loading:false,
			}
        },
        computed:{
            lists(){
                let pages=Math.ceil(this.listNum/10);//
                let newList=[];
                for(let i=0;i<pages;i++){
                let sonList=[];
                sonList=this.xhx3s.slice(i*10,i*10+10);//
                newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
            usertype(){return this.$cookies.get('usertype')},
		},
		methods: {
            shanok(){this.shuaxinjian();},
            f_blod() {document.execCommand ( 'bold', false );},
            
            onPaste: function(e) {
                    e.preventDefault()
                    e.stopPropagation()
                    let pasteValue = (e.clipboardData || window.clipboardData).getData('text/plain')
                    console.log(pasteValue)
                    var re = /<[^>]+>/gi;
                    pasteValue = pasteValue.replace(re, '').replace(/\s+|[\r\n]/g,"");
                    e.target.textContent += pasteValue
                },
            set_gongkaifanwei(data){this.qunzu_fanwei_id = data.qz_id;},
            zhankaijian(){
                this.x3_loading=true;
                this.show_zhankai=false;
                this.axios
                        .post('http://www.zhishiren.info/api/xunhuanx3/',{userid: this.$cookies.get('userid')})
                        .then(response=>{
                            this.xhx3s=JSON.parse(response.data);
                            this.listNum=JSON.parse(response.data).length;
                            this.x3_loading=false;
                        });
            },
            shuaxinjian(){
                this.x3_loading=true;
                this.$nextTick(() => {
                    this.axios
                        .post('http://www.zhishiren.info/api/xunhuanx3/',{userid: this.$cookies.get('userid')})
                        .then(response=>{
                            this.xhx3s=JSON.parse(response.data);
                            this.listNum=JSON.parse(response.data).length;
                            this.x3_loading=false;
                            this.show_zhankai=false;
                            });
                })
            },

            fabujian(mi) {
                var that = this;
                        if(that.$refs.contents.innerHTML==='请输入你要发言的内容。'){
                            that.ok_msg=2;
                            setTimeout(function(){that.ok_msg=0;}, 2000);
                        }
                        else{
                            that.fa_loading=true;
                                that.axios
                                .post('http://www.zhishiren.info/api/bdx3/',{
                                    userid: that.$cookies.get('userid'),
                                    username:that.$cookies.get('username'),
                                    fy_content:that.$refs.contents.innerHTML,
                                    fy_type:that.type_value,
                                    fy_fanwei:that.qunzu_fanwei_id,
                                    fayan_att:that.fayan_att,
                                    mi_yn:mi
                                    })
                                .then(function (response) {
                                                if (response.data.ok_id === 1){
                                                    that.ok_msg=1;
                                                    setTimeout(function(){that.ok_msg=0;}, 2000);
                                                    that.$refs.zhankai0.addnew();
                                                    
                                                    that.$refs.contents.innerHTML='请输入你要发言的内容。';
                                                    that.$refs.huanyuan.huanyuan();
                                                    that.qunzu_fanwei_id=90000000;
                                                    that.fayan_att='无态度';
                                                    that.type_value='公告通知';

                                                    that.x3_loading=true;
                                                    that.$nextTick(() => {
                                                        that.$axios
                                                            .post('http://www.zhishiren.info/api/xunhuanx3/',{userid: that.$cookies.get('userid')})
                                                            .then(response=>{
                                                                            that.xhx3s=JSON.parse(response.data);
                                                                            that.listNum=JSON.parse(response.data).length;
                                                                            that.show_zhankai=false;
                                                                            that.currentPage=1;
                                                                            that.blinkyellow='blinkyellow';
                                                                            setTimeout(function(){that.blinkyellow='';}, 2000);
                                                                            that.x3_loading=false;
                                                            });
                                                    });
                                                    that.fa_loading=false;
                                                }
                                                if (response.data.ok_id === 3){
                                                    that.ok_msg=3;
                                                    setTimeout(function(){that.ok_msg=0;}, 1500);
                                                    that.$refs.contents.innerHTML='请输入你要发言的内容。';
                                                    that.fa_loading=false;
                                                    that.x3_loading=false;
                                                }
                                });
                        }
                
                
            },
            kcopy(a){
                let copycode = document.getElementById(a);
                copycode.select(); // 选择对象
                document.execCommand("Copy"); // 执行浏览器复制命令
                alert("密文已经复制到你的粘贴板，请到首页右侧‘密’功能栏解密。");
            },

            
        },
        created: function () {
                this.count_loading=true;
                var _this= this;
                _this.axios
                .post('http://www.zhishiren.info/api/countx3/', {userid:_this.$cookies.get('userid')})
                .then(function (response) {
                    _this.listNum=JSON.parse(response.data);
                    _this.count_loading=false;
                    });
        },
	}
</script>
