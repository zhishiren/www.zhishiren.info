// 知识点页面-内容管理模块-上传附件和删除以往附件
<template>
<div>
        <el-row v-if="fujianshu!==0" class="font18px">
            <el-button  class="font18px" type="text" disabled>已有附件...</el-button>
            {{this.fujianshu}}个附件<a v-show="show_zhankai" @click="zhankaijian" class="a_black">-展开-</a>
            <span v-if="show_zhankai===false">:
                <span v-for="fu in fulist" :key="fu">
                    <span>{{fu.fields.fu_title}}</span>
                    <span>
                        <a @click="shanchujian(fu.pk)" class="a_black">
                            <i class="el-icon-delete-solid"></i><el-divider direction="vertical"></el-divider>
                        </a>
                    </span>
                </span>
                <a @click="shuaxinjian" class="a_black"><i class="el-icon-refresh"></i>刷新</a>
            </span>
        </el-row>
        <el-row  class="font18px">
            <el-upload
                name="zhifujian"
                class="upload-demo"
                ref="upload"
                :data={id:wj_list.wj_id,leixing:this.leixing}
                action='http://www.zhishiren.info/api/uploadfu/'
                Access-Control-Request-Headers: ContentType
                style="text-align:40px;display:inline;"
                :on-preview="handlePreview"
                :on-remove="handleRemove"
                :before-remove="beforeRemove"
                :on-exceed="handleExceed"
                :on-success="onsuccess"
                :file-list="fileList" 
                >
                <el-button class="font18px" type="text">
                <!-- <el-button v-if="ceshi_id===0" class="font18px" type="text"> -->
                    上传附件...
                </el-button>
                <!-- <span disabled v-if="ceshi_id===1">
                    <i class="el-icon-loading"></i>正在导入，请等待...
                </span> -->
                <span class="font18px">
                <!-- <span disabled v-show="ceshi_id===0 && chuanduanlist_okmsg===9" class="font18px"> -->
                    <span v-if="fujianshu===0">&nbsp;尚未曾传过附件,</span>
                    仅限rar/jpg格式。
                </span>
                <!-- <span v-show="chuanduanlist_okmsg===0" class="font18px" style="color:red">
                    导入失败
                </span> -->
            </el-upload>
		</el-row>

</div>
        
        
</template>

<script>
export default {
    name:'gaineirong',
	data() {return {
        ceshi_id:0,
        chuanduanlist_okmsg:9,
        fulist:[],
        show_zhankai:true
    }},
    // props:['wj_list','fujianshu'],
    props: {
            wj_list:{type: Array,default: []},
            fujianshu:{type: Number,default: 0},
            leixing:{type:String,default:''}
	    },
	methods:{
            onsuccess(response, file, fileList) {
                this.$refs.upload.clearFiles();
                this.$router.go(0);
            },
            handleRemove(file, fileList) {console.log(file, fileList);},
            handlePreview(file) {console.log(file);},
            handleExceed(files, fileList) {this.$message.warning(`每次操作只能上传一个文件！`);},
            beforeRemove(file, fileList) {return this.$confirm(`确定移除 ${ file.name }？`);},
            handleRemove(file, fileList) {console.log(file, fileList);},
            handlePreview(file) {console.log(file,fileList);},
            // onchange(file, fileList){this.ceshi_id=1;},
            shanchujian(fuid){
                var _this= this;
                _this.$alert('确认删除本条记录？', '确认删除？', {
						confirmButtonText: '确认',
						callback: action => {
							if (action === 'confirm') {
								var that = this;
								_this.$axios
                                .post('http://www.zhishiren.info/api/rm_fu/', {fuid:fuid,zhid:this.wj_list.wj_id})
                                .then(function (response) {
                                    if(response.data===0){
                                        // _this.show_zhankai=true;
                                        // _this.show_zhankai=false;
                                        // _this.$nextTick(() => {
                                        //     _this.axios
                                        //     .post('http://www.zhishiren.info/api/show_futujian/', {zhid:_this.wj_list.wj_id})
                                        //     .then(function (response) {
                                        //         _this.fulist=JSON.parse(response.data);
                                        //         _this.fujianshu=_this.fulist.length;
                                        //     });
                                        // });
                                        _this.$router.go(0);
                                    }}
                                )}
							}
						});
					},

                // _this.$axios
                //     .post('http://www.zhishiren.info/api/rm_fu/', {fuid:fuid,zhid:this.wj_list.wj_id})
                //     .then(function (response) {
                //         if(response.data===0){
                //             _this.show_zhankai=true;
                //             _this.show_zhankai=false;
                //             _this.$nextTick(() => {
                //                 _this.axios
                //                 .post('http://www.zhishiren.info/api/show_futujian/', {zhid:_this.wj_list.wj_id})
                //                 .then(function (response) {
                //                     _this.fulist=JSON.parse(response.data);
                //                     _this.fujianshu=_this.fulist.length;
                //                 });
                //             });
                //             _this.$router.go(0);
                //     }}
                // )},


            zhankaijian(){
                var _this= this;
                _this.$axios
                    .post('http://www.zhishiren.info/api/show_futujian/', {zhid:this.wj_list.wj_id})
                    .then(function (response) {
                        _this.fulist=JSON.parse(response.data);
                        _this.show_zhankai=false;
                        _this.fujianshu=_this.fulist.length;
                });
            },
            shuaxinjian(){
                var _this= this;
                _this.$axios
                    .post('http://www.zhishiren.info/api/show_futujian/', {zhid:this.wj_list.wj_id})
                    .then(function (response) {
                        _this.fulist=JSON.parse(response.data);
                        _this.show_zhankai=false;
                        _this.fujianshu=_this.fulist.length;
                });
            },

	},

};

</script>