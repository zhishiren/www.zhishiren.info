<template>
    <div id="z66">
        <el-row style="color:red;" class="font20px">仅供展示相关理念,没有实物</el-row>
		
    </div>
</template>

<script>
    export default {
        name:'z66',
        props:[],
        data() {return {

        }},
        computed:{

        },
        methods:{
            
        },
    };
</script>



