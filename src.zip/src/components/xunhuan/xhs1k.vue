
<template>
	<div id="xhs1k">
        <div>
            <el-row class="font18px">
                <span style="color:blue"><i class="el-icon-finished"></i>{{this.jishu}}条搜索结果。</span>
            </el-row>
			<el-row v-for="l in ls" :key="l.pk" class="br10px17px">
					<el-row>
                        <router-link class="a_black" target="_blank" :to="{name:'wenjiye',params:{id:l.pk}}">
                            <span v-html="gaoliangk(l.fields.wj_title, k)" ></span>
                        </router-link>
                        <span style="color:red" v-if="l.fields.wj_status!=='s0'">:{{daibiaoma(l.fields.wj_status)}}</span>
                    </el-row>
					<el-row>
						<b style="color:grey">属性<i class="el-icon-caret-right"></i></b>
                        <span v-if="l.fields.wj_type!=='无类型'">{{l.fields.wj_type}}<el-divider direction="vertical"></el-divider></span>
                        <span v-if="l.fields.wj_borntime">生效:{{getNowFormatDate(l.fields.wj_borntime)}}<el-divider direction="vertical"></el-divider></span>
                        <span v-if="l.fields.wj_deadtime">失效:{{getNowFormatDate(l.fields.wj_deadtime)}}<el-divider direction="vertical"></el-divider></span>
                        <span v-if="l.fields.wj_hangye">所属行业:{{l.fields.wj_hangye}}<el-divider direction="vertical"></el-divider></span>
                        <span v-if="l.fields.wj_area">所属地区:{{l.fields.wj_area}}<el-divider direction="vertical"></el-divider></span>
                        <span v-if="l.fields.wj_publisher">发文单位:{{l.fields.wj_publisher}}<el-divider direction="vertical"></el-divider></span>
						<!-- <span v-if="l.fields.wj_remark!=='无内容'"><b style="color:grey">说明<i class="el-icon-caret-right"></i></b><span v-html="gaoliangk(l.fields.wj_remark, k)" ></span></span> -->
						<span><b style="color:grey">说明<i class="el-icon-caret-right"></i></b><span v-html="gaoliangk(l.fields.wj_remark, k)" ></span></span>
					</el-row>
				<el-row><el-divider style="margin:0px;"></el-divider></el-row>
			</el-row>

            <br>
            <el-pagination  v-if="jishu>10" style="text-align:right;"
                            background
                            :page-size=10
                            :total="jishu"
                            :current-page.sync="currentPage"
                            layout="total, prev, pager, next">
            </el-pagination>

        </div>


    </div>
</template>
<script>

export default {
    name:'xhs1k',
    components: {},
    props:['list','jishu','k'],
	data() {return {
        currentPage: 1,//当前分页的数值

    }},

    computed: {
            ls(){
                let pages=Math.ceil(this.jishu/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                    let sonList=[];
                    sonList=this.list.slice(i*10,i*10+10);//10为每页设置数量
                    newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
    },
    methods: {
            kk1(){this.currentPage=1;}
    },



};
</script>