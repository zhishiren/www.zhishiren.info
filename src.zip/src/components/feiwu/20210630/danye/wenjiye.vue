<template>
<div id="wenjiye"  @click="turnfresh()">
	<toubu0></toubu0>
		<el-container>
			<el-aside width="120px" class="bgcolor_FF"></el-aside>
			<el-main class="bgcolor_FC font18px">
				<el-card v-if="wj_info.wj_id" class="box-card">
						<el-row >
							<el-col :span="20" >
								<p class="font21px">{{this.wj_info.wj_title}}</p>
							</el-col>
							<el-col :span="4" >
								<el-upload v-if="wj_info.wj_yuanwen===0 && wj_info.wj_manager===yonghuid"
									name="yuanwen"
									class="upload-demo"
									ref="upload"
									:data={id:this.wj_info.wj_id}
									action='http://www.zhishiren.info/api/shangchuan_yuanwen/'
									Access-Control-Request-Headers: ContentType
									style="text-align:40px;display:inline;float:right;"
									:on-preview="handlePreview"
									:on-remove="handleRemove"
									:before-remove="beforeRemove"
									:on-exceed="handleExceed"
									:on-success="onsuccess"
									:file-list="fileList" 
									>
									<a class="a_grey" type="primary" style="font-size:20px;" slot="trigger" size="small"><i class="el-icon-upload2"></i>上传原文</a>
								</el-upload>
								<a v-if="wj_info.wj_yuanwen!==0" style="font-size:20px;float:right;" class="a_grey" 
									:href="'https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/yuanwen1/'+wj_info.wj_id+'.doc'" 
									:download="wj_info.wj_id+''+wj_info.wj_title+'.doc'">
									<i class="el-icon-download"></i>下载原文
								</a>
							</el-col>
						</el-row>

						<el-row>
							<span><b>属性<i class="el-icon-caret-right"></i></b></span>
							<span>文辑ID:{{this.wj_info.wj_id}}<el-divider direction="vertical"></el-divider></span>
							<span style="color:red;" v-if="wj_info.wj_status==='s4'">{{daibiaoma(this.wj_info.wj_status)}}<el-divider direction="vertical"></el-divider></span>
							<span v-if="wj_info.wj_status!=='s4'">{{daibiaoma(this.wj_info.wj_status)}}<el-divider direction="vertical"></el-divider></span>
							<span>{{this.wj_info.wj_type}}<el-divider direction="vertical"></el-divider></span>
							<span>{{daibiaoma(this.wj_info.wj_fanwei)}}<el-divider direction="vertical"></el-divider></span>
							<span>生效:<span style="color:grey" v-show="wj_info.wj_borntime===null">缺少信息</span><span v-show="wj_info.wj_borntime!==null">{{getNowFormatDate(this.wj_info.wj_borntime)}}</span><el-divider direction="vertical"></el-divider></span>
							<span>失效:<span style="color:grey" v-show="wj_info.wj_deadtime===null">缺少信息</span><span v-show="wj_info.wj_deadtime!==null">{{getNowFormatDate(this.wj_info.wj_deadtime)}}</span><el-divider direction="vertical"></el-divider></span>
							<span>行业:<span style="color:grey" v-show="wj_info.wj_hangye===''">缺少信息</span><span v-show="wj_info.wj_hangye!==''">{{this.wj_info.wj_hangye}}</span><el-divider direction="vertical"></el-divider></span>
							<span>地区:<span style="color:grey" v-show="wj_info.wj_area===''">缺少信息</span><span v-show="wj_info.wj_area!==''">{{this.wj_info.wj_area}}</span><el-divider direction="vertical"></el-divider></span>
							<span>发文:<span style="color:grey" v-show="wj_info.wj_publisher===''">缺少信息</span><span v-show="wj_info.wj_publisher!==''">{{this.wj_info.wj_publisher}}</span><el-divider direction="vertical"></el-divider></span>
							<span>管理人:
								<router-link class="a_black" target="_blank" :to="{name:'yonghuye',params:{id:wj_info.wj_manager}}">
									{{this.wj_info.wj_manager}}
								</router-link>
							</span>
							<zu0tongjishu :dj="wj_tongji.dianji" :gz="wj_tongji.guanzhu" :fx="wj_tongji.fenxiang"></zu0tongjishu>
						</el-row>
						<el-row>
							<b>说明<i class="el-icon-caret-right"></i></b>
							<span v-html="wj_info.wj_remark"></span>{{this.in_qunzu}}
						</el-row>
						<zu0fujianfutu v-if="wj_info.fujianshu!==0" :zhid="wj_info.wj_id"></zu0fujianfutu>
				</el-card>
				<el-card v-else>
					<br>
						<div style="text-align:center;font-size:30px;"><i class="el-icon-loading"></i>正在加载</div>
					<br>
				</el-card>
			</el-main>
		</el-container>

		<el-container>
			<el-aside width="120px">
				<el-menu default-active="12" class="el-menu-vertical-demo bgcolor_menu_FC" @open="handleOpen" @close="handleClose">
			      <el-menu-item @click="daohang11" index="11" class="font18px">
			        <span slot="title">段落列表</span>
			      </el-menu-item>
				  <el-menu-item @click="daohang12" index="12" class="font18px">
			        <span slot="title">关注分享</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang13" index="13" class="font18px">
			        <span slot="title">评论</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang14" index="14" class="font18px">
			        <span slot="title">关联知识</span>
			      </el-menu-item>
			      <!-- <el-menu-item @click="daohang15" index="15" class="font18px">
			        <span slot="title">推荐阅读</span>
			      </el-menu-item>
				  				       -->
				  <el-menu-item @click="daohang16" index="16" class="font18px">
			            <span slot="title">内容管理</span>
			      </el-menu-item>
			    </el-menu>
			</el-aside>
			<el-main v-show="dh12" class="section_xh">
				<tj0fenxiang @fxadd1="add1(1)" :zhid="wj_info.wj_id" zhitype="wenjiye" :zhititle="wj_info.wj_title" :createrid="wj_info.wj_manager" :zhitype1="wj_info.wj_type" :fanwei="wj_info.wj_fanwei"></tj0fenxiang>
				<tj0guanzhu @gzadd1="add1(2)" @gzminus1="minus1(2)" :zhid="wj_info.wj_id" :zhititle="wj_info.wj_title" zhitype="wenjiye" bq_fanwei=0></tj0guanzhu>
				<tj0jiucuo :zhid="wj_info.wj_id" ></tj0jiucuo>
				<tj0jiabiaoqian zhitype="wenjiye" :zhititle="wj_info.wj_title" :zhid="wj_info.wj_id"></tj0jiabiaoqian>
			</el-main>
			<el-main v-show="dh13" class="section_xh">
            	<tj0pinglun zhitype="wenjiye" :zhititle="wj_info.wj_title" :zhid="wj_info.wj_id" :fanwei="wj_info.wj_fanwei"></tj0pinglun>
			</el-main>
			<el-main v-show="dh14" class="section_xh">
				<tj0guanlian zhitype="wenjiye" :zhititle="wj_info.wj_title" :zhid="wj_info.wj_id"  :fanwei="wj_info.wj_fanwei"></tj0guanlian>
			</el-main>
			<!-- <el-main v-show="dh15" class="section_xh">
            	<tj0tuijian :id="wj_info.wj_id" ></tj0tuijian>
			</el-main> -->
			<el-main v-show="dh11" class="section_xh">
            	<tj1duanluo :yhid="wj_info.wj_manager" :type="wj_info.wj_type" :zhid="wj_info.wj_id" :zhititle="wj_info.wj_title"></tj1duanluo>
			</el-main>
			<el-main v-show="dh16" class="section_xh">
				<bdg2 :wj_list="wj_info" :fujianshu="wj_info.fujianshu"></bdg2>
			</el-main>
			<el-aside width="120px" class="bgcolor_FC"></el-aside>

		</el-container>



	</div>

</template>

<script>
import tj0fenxiang from '../tijiao/tj_fenxiang';
import tj0guanzhu from '../tijiao/tj_guanzhu';
import tj0jiabiaoqian from '../tijiao/tj_jiabiaoqian';
import tj1duanluo from '../tijiao/tj1duanluo';
import tj0jiucuo from '../tijiao/tj_jiucuo';
import tj0pinglun from '../tijiao/tj_pinglun';
import tj0guanlian from '../tijiao/tj_guanlian';
import tj0tuijian from '../tijiao/tj_tuijian';

import bdg2 from '../biaodan/bdg2';
import xiazaiyuanwen from '../fujian/xiazaiyuanwen';
import toubu0 from '../fujian/toubu0';
import zu0tongjishu from '../fujian/zu0tongjishu';
import zu0fujianfutu from '../fujian/zu0fujianfutu';

export default {
        name:'wenjiye',
		components: {zu0fujianfutu,zu0tongjishu,tj0tuijian,toubu0,tj0guanzhu,tj0fenxiang,tj0jiabiaoqian,tj0pinglun,tj0guanlian,tj0jiucuo,tj1duanluo,bdg2,xiazaiyuanwen},
        methods:{
                    daohang11(){this.dh11=true;this.dh12=false;this.dh13=false;this.dh14=false;this.dh15=false;this.dh16=false;},
                    daohang12(){this.dh12=true;this.dh11=false;this.dh13=false;this.dh14=false;this.dh15=false;this.dh16=false;},
                    daohang13(){this.dh13=true;this.dh11=false;this.dh12=false;this.dh14=false;this.dh15=false;this.dh16=false;},
                    daohang14(){this.dh14=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh15=false;this.dh16=false;},
                    // daohang15(){this.dh15=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh14=false;this.dh16=false;},
					daohang16(){this.dh16=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh14=false;this.dh15=false;},
					//这里的k值指的是关注数或分享数等等
					add1(k){
						if(k==1){this.wj_tongji.fenxiang++;}
						if(k==2){this.wj_tongji.guanzhu++;}
					},
					minus1(k){
						if(k==2){this.wj_tongji.guanzhu--;}
					},
					handleRemove(file, fileList) {
						console.log(file, fileList);
					},
					handlePreview(file) {
						console.log(file);
					},
					onsuccess(response, file, fileList) {
						this.$refs.upload.clearFiles();
						this.wj_info.wj_yuanwen=1;
						
					},
					handleExceed(files, fileList) {
						this.$message.warning(`每次操作只能上传一个文件！`);
					},
					beforeRemove(file, fileList) {
						return this.$confirm(`确定移除 ${ file.name }？`);
					},
					handleRemove(file, fileList) {
						console.log(file, fileList);
					},
					handlePreview(file) {
						console.log(file,fileList);
					},
			
        },
        data() {
			return {dh15:false,dh11:false,dh13:false,dh14:false,dh12:true,dh16:false,
					wj_id:0,
					wj_info:[],
					wj_tongji:[],
					fulist:[],
			}
		},
		computed: {
				yonghuid(){return parseInt(this.$cookies.get('userid'))},
				welcomename(){return this.$cookies.get('username')},
				in_qunzu(){
					var kkk ='90000107_1111111_11111112'
					if(kkk.indexOf(this.wj_info.wj_manager)!=-1){return true;}
					else{return false}
					//这是用来判断这篇知识点所属的群组是否在用户所在的群组集中。
				},
		},
        created() {
				this.wj_id = this.$route.params.id;//获取上个页面传递的id,在下面获取数据的时候先提交id,这里的id不用加前缀
				var _this= this;
				_this.axios
				.post('http://www.zhishiren.info/api/show_wenjiye/', {wj_id:_this.wj_id})
				.then(function (response) {
					_this.wj_info=response.data;
					_this.wj_tongji=JSON.parse(response.data.wj_tongji);
				});
		},

};

</script>

<style scoped>

</style>




