// 暂时不用
<template>
	<div id="tj0fayan"  class="font18px">
				    <el-button @click="tianjiajian" type="text" style="padding-bottom:0px;" class="font18px">
                        <i class="el-icon-plus"></i>我要发言...
                    </el-button>
                    <span style="color:green;" v-show="ok_msg==1"><i class="el-icon-success"></i>发布成功!</span>
                    <span style="color:red;" v-show="ok_msg==3"><i class="el-icon-error"></i>操作失败!</span>
                    我已有{{this.listNum}}条言论。
                    <zhankai0 @get_list="zhankaijian" @shuaxin="shuaxinjian"></zhankai0>

		<el-dialog title="发表评论..." width="400px" :visible.sync="show_dialog">
            <el-row>
                <el-col :span="7" class="font18px" style="padding-top:10px;">
                    发言态度：
                </el-col>
                <el-col :span="17">
                    <el-select v-model="fy_type" placeholder="请选择发言的类型" style="width:100%;">
                        <el-option value="求助询问" key="求助询问" label="求助询问"></el-option>
                        <el-option value="新闻简讯" key="新闻简讯" label="新闻简讯"></el-option>
                        <el-option value="公告通知" key="公告通知" label="公告通知"></el-option>
                        <el-option value="感悟思考" key="感悟思考" label="感悟思考"></el-option>
                        <el-option value="名人名言" key="名人名言" label="名人名言"></el-option>
                        <el-option value="公开言论" key="公开言论" label="公开言论"></el-option>
                    </el-select>
                </el-col>
            </el-row>
            <br>
            <el-row>
                <el-col :span="7" class="font18px" style="padding-top:10px;" >
                    <span >发言态度：</span>
                </el-col>
                <el-col :span="17" >
                    <el-select v-model="fayan_att" placeholder="请选择发言的态度" style="width:100%;">
                        <el-option value="无态度" key="无态度" label="无态度"></el-option>
					    <el-option value="紧急重要" key="紧急重要" label="紧急重要"></el-option>
                    </el-select>                
                </el-col>
            </el-row>
            <br>
            <el-row>
                <el-col :span="7" class="font18px" style="padding-top:10px;" >
                    <span>公开范围：</span>
                </el-col>
                <el-col :span="17" >
                    <fanwei  ref="huanyuan" @set_fanwei="set_gongkaifanwei" style="width:100%;"></fanwei>
                </el-col>
            </el-row>
            <br>
            <el-row>
                <div contenteditable ref="contents" @paste="onPaste" class="pinglunlan">请输入发言的内容。</div>
            </el-row>
            <el-row>
                <el-col :span="7">
                    <a class="a_black font18px" href="javascript:;" @click="f_blod">
                        <b>所选加粗</b>
                    </a>
                </el-col>
                <el-col class="font18px" :span="11">
                    <span style="color:orange;" v-show="ok_msg==2"><i class="el-icon-warning-outline"></i>发言内容不能为空!</span>
                </el-col>
                <el-col :span="6" style="text-align:right">
                    <a @click="fabujian" class="font20px a_black" >发布</a>
                </el-col>
            </el-row>
        </el-dialog>


        <div v-show="show_xh1fy" >
                <el-row class="br10px17px" v-for="list in lists" :key="list.pk">
                    <el-row  :class="blinkyellow" v-if="list.pk==return_id">
                        <router-link class="a_black" style="float:left;" target="_blank" :to="{name:'fayanye',params:{id:list.pk}}">
                                    <span style="color:brown;max-width: 600px;max-height:25px; float: left;overflow: hidden; white-space: nowrap;text-overflow: ellipsis;-o-text-overflow: ellipsis; ">
                                        <font style="font-size:18px;color:black;"><b>“</b></font>
                                            <a class="a_brown" :title="list.fields.fy_content"><span v-html="list.fields.fy_content"></span></a>
                                    </span>
                                    <span style="font-size:18px;"><b>”</b></span>  
                        </router-link>
                        <uploadfu :leixing=3 @add1="fuaddone()" :id="list.pk"></uploadfu>
                    </el-row>
                    <el-row v-else>
                        <router-link class="a_black" style="float:left;" target="_blank" :to="{name:'fayanye',params:{id:list.pk}}">
                                    <span style="color:brown;max-width: 600px;max-height:25px; float: left;overflow: hidden; white-space: nowrap;text-overflow: ellipsis;-o-text-overflow: ellipsis; ">
                                        <font style="font-size:18px;color:black;"><b>“</b></font>
                                            <a class="a_brown" :title="list.fields.fy_content"><span  v-html="list.fields.fy_content"></span></a>
                                    </span>
                                    <span style="font-size:18px;"><b>”</b></span>
                        </router-link>
                        <uploadfu :leixing=3 @add1="fuaddone()" :id="list.pk"></uploadfu>
                    </el-row>
                    <el-row>
                            <span style="color:red;" v-if="list.fields.fy_att==='紧急重要'">{{list.fields.fy_att}}<el-divider direction="vertical"></el-divider></span>
                            <span>{{list.fields.fy_type}}</span>
                            <el-divider direction="vertical"></el-divider><showfanwei :qz_id="list.fields.fy_fanwei"></showfanwei>
                            <el-divider direction="vertical"></el-divider><span>附件{{list.fields.fu}}</span>
                            <span style="float:right">
                                    <span style="color:orange" v-if="notok">删除失败</span>
                                    <a @click="shanchu_fy(list.pk)" class="a_grey">
                                        <i class="el-icon-close"></i>删除<el-divider direction="vertical"></el-divider>
                                    </a>

                                {{getNowFormatDate(list.fields.fy_createtime)}}
                            </span>
                    </el-row>
                    <el-row><el-divider style="margin:0px;"></el-divider></el-row>
                </el-row>
                <el-pagination v-if="listNum>10" style="text-align:right;"
                                background
:page-size=10
                                :total="listNum"
                                :current-page.sync="currentPage"
                                layout="total, prev, pager, next">
                </el-pagination>
        </div>

	</div>
</template>

<script>
import tj0huifu from '../tijiao/tj_huifu';
import fanwei from '../fujian/fanwei';
import tixing from '../fujian/tixing';
import zhankai0 from '../fujian/zhankai0';
import showfanwei from '../fujian/showfanwei';
import uploadfu from '../fujian/uploadfu';

	export default {
		name: 'tj0fayan',
        components: {tixing,tj0huifu,fanwei,zhankai0,showfanwei,uploadfu},
        props:['userid','username'],
		data () {
			return {
                return_id:0,//这个return_id是用户添加评论成功之后，
                show_dialog:false,   
                show_xh1fy:false,
                blinkyellow:'',
                xh1fys:[],
                currentPage: 1,//当前分页的数值
                listNum:0,//分页总条数
                qunzu_fanwei_id:90000000,
                ok_msg:9,

                fy_type:"公告通知",
                fayan_att:"无态度"
				
            }
            
        },
        
        computed: {
            lists(){
                let pages=Math.ceil(this.listNum/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                    let sonList=[];
                    sonList=this.xh1fys.slice(i*10,i*10+10);//10为每页设置数量
                    newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
            yonghuid(){return parseInt(this.$cookies.get('userid'))},
        },


		methods: {
            shanchu_fy(fy_id){
					var that=this;
					that.$axios
					.post('http://www.zhishiren.info/api/shan_fy/',{zhid:fy_id,userid: that.userid})
					.then(response=>{
						if(response.data.changed_ok===0){
                                that.$nextTick(() => {
                                    that.$axios
                                    .post('http://www.zhishiren.info/api/xunhuanx3/',{userid: that.userid})
                                    .then(response=>{
                                        that.xh1fys=JSON.parse(response.data);
                                        that.listNum=that.xh1fys.length;});
                                });
							}
						else{
								that.notok=true;
								setTimeout(function(){that.notok=false;}, 2000);
							}
				})},

			huifujian(fy_id){
				},
			ding(fy_id){
				},
			cai(fy_id){
                },
                
            fuaddone() {
                // this.lists[k].fields.fu++;
                this.$nextTick(() => {
                    this.$axios
                    .post('http://www.zhishiren.info/api/xunhuanx3/',{userid: this.userid})
                    .then(response=>{
                        this.xh1fys=JSON.parse(response.data);
                        this.listNum=this.xh1fys.length;});
                });
            },

            f_blod() {document.execCommand ( 'bold', false );},
            
            onPaste: function(e) {
                    e.preventDefault()
                    e.stopPropagation()
                    let pasteValue = (e.clipboardData || window.clipboardData).getData('text/plain')
                    console.log(pasteValue)
                    var re = /<[^>]+>/gi;
                    pasteValue = pasteValue.replace(re, '').replace(/\s+|[\r\n]/g,"");
                    e.target.textContent += pasteValue
                },
            fabujian() {
                // 这里需要判断，
                var that = this;
                that.zhid=Number(that.zhid);
                that.item1id=Number(that.item1id);

                        if(that.$refs.contents.innerHTML==='请输入发言的内容。'){
                            that.ok_msg=2;
                            setTimeout(function(){that.ok_msg=0;}, 2000);
                        }
                        else{
                                that.axios
                                .post('http://www.zhishiren.info/api/bdx3/',{
                                    userid: that.userid,
                                    username:that.username,
                                    fy_type:that.fy_type,
                                    fayan_att:that.fayan_att,
                                    fy_content:that.$refs.contents.innerHTML,
                                    fy_fanwei:that.qunzu_fanwei_id,
                            
                                    })
                                .then(function (response) {
                                    if (response.data.ok_id === 1){
                                        that.ok_msg=1;
                                        that.return_id = response.data.rrid;
                                        setTimeout(function(){that.ok_msg=0;}, 2000);

                                        that.show_dialog=false;
                                        that.show_xh1fy=true;
                                        that.$nextTick(() => {
                                            that.$axios
                                                .post('http://www.zhishiren.info/api/xunhuanx3/',{userid: that.userid})
                                                .then(response=>{
                                                                that.xh1fys=JSON.parse(response.data);
                                                                that.listNum=that.xh1fys.length;
                                                                that.currentPage=1;
                                                                that.blinkyellow='blinkyellow';
                                                                setTimeout(function(){that.blinkyellow='';}, 2000);
                                                });
                                        });
                                    }
                                    if (response.data.ok_id === 2){
                                        that.ok_msg=3;
                                        setTimeout(function(){that.ok_msg=0;}, 2000);
                                        that.$refs.contents.innerHTML='请输入发言的内容。';
                                    }
                                    if (response.data.ok_id === 1){
                                        that.ok_msg=4;
                                        setTimeout(function(){that.ok_msg=0;}, 2000);
                                        that.$refs.contents.innerHTML='请输入发言的内容。';
                                    }
                                });
                        }
                
            },

            set_gongkaifanwei(data){this.qunzu_fanwei_id = data.qz_id;},

			f_blod() {
                document.execCommand ( 'bold', false );
                document.execCommand ( 'backColor', false, 'yellow' );
			},

			tianjiajian(){
                this.show_dialog=true;
                this.$refs.contents.innerHTML='请输入发言的内容。';
                this.fy_att="fy3";
                this.fayan_att="无态度";
                this.$refs.huanyuan.huanyuan();
            },

            zhankaijian(){
                this.show_xh1fy=true;
                this.$axios
                .post('http://www.zhishiren.info/api/xunhuanx3/',{userid: this.userid})
                .then(response=>{
                    this.xh1fys=JSON.parse(response.data);
                    this.listNum=this.xh1fys.length;});
            },

            shanok(){
                this.$nextTick(() => {
                    this.$axios
                    .post('http://www.zhishiren.info/api/xunhuanx3/',{userid: this.userid})
                    .then(response=>{
                        this.xh1fys=JSON.parse(response.data);
                        this.listNum=this.xh1fys.length;});
                });
            },

            shuaxinjian(){
                this.$nextTick(() => {
                    this.$axios
                    .post('http://www.zhishiren.info/api/xunhuanx3/',{userid: this.userid})
                    .then(response=>{
                        this.xh1fys=JSON.parse(response.data);
                        this.listNum=this.xh1fys.length;});
                });
            },


        },
        

            created() {
                this.$axios
                    .post('http://www.zhishiren.info/api/xunhuanx3/',{userid: this.userid})
                    .then(response=>{
                        this.xh1fys=JSON.parse(response.data);
                        this.listNum=this.xh1fys.length;});
            },

        watch: {
            userid: function(newVal,oldVal){
                this.yonghu_id = newVal;  
                this.$axios
                    .post('http://www.zhishiren.info/api/xunhuanx3/',{userid: this.yonghu_id})
                    .then(response=>{
                        this.xh1fys=JSON.parse(response.data);
                        this.listNum=this.xh1fys.length;});
                
            }
        },


	}
</script>

