<template>
	<div id="bdx8">
        <el-row style="line-height: 40px;" >
            <el-col :span="2" >
                <span >群组名称：</span>
            </el-col>
            <el-col :span="6" >
                <el-input v-model="qunzu_title" placeholder="请输入群组名称"  style="width:96%;"></el-input>
            </el-col>

            <el-col :span="2" >
                <span >群组类型：</span>
            </el-col>
            <el-col :span="6" >
                <el-select v-model="type_value" placeholder="请选择群组类型" style="width:90%;">
                    <el-option value="兴趣讨论" key="兴趣讨论" label="兴趣讨论"></el-option>
					<el-option value="内部团队" key="内部团队" label="内部团队"></el-option>
					<el-option value="企业社团" key="企业社团" label="企业社团"></el-option>
                </el-select>
            </el-col>

            <el-col :span="2" >
                <span >入群口令：</span>
            </el-col>
            <el-col :span="6" >
                <el-input v-model="shenqing_value" placeholder="这是用户申请入群的口令"  style="width:96%;"></el-input>
            </el-col>

        </el-row>
        <br>
        
        <el-row >
                <el-col :span="2" >
                    <span class="font16px">群组介绍：</span>
                </el-col>
                <el-col :span="20" >
                    <div contenteditable ref="contents" @paste="onPaste" class="pinglunlan" style="font-size:16px;width:100%;">请输入此群组的介绍文字。</div>
                </el-col>
                <el-col :span="2">
                    <a class="a_black" href="javascript:;" @click="f_blod">
                        <b>所选加粗</b>
                    </a>
                </el-col>
        </el-row>

        <el-row  style="line-height: 40px;padding-left:450px;">
                    <a class="font20px a_black"  @click="fabujian">发布</a>
                    <span style="color:green;" v-show="ok_msg==1"><i class="el-icon-success"></i>发布成功!</span>
                    <span style="color:orange;" v-show="ok_msg==2"><i class="el-icon-warning-outline"></i>群组名不能为空!</span>
                    <span style="color:red;" v-show="ok_msg==3"><i class="el-icon-error"></i>数据库写入失败!</span>
        </el-row>


        <el-row  class="font17px">
            你共曾新建了{{this.listNum}}个群组。<zhankai0 ref="zhankai0" @get_list="zhankaijian" @shuaxin="shuaxinjian"></zhankai0>
        </el-row>

        <div v-if="x_loading===true">
            <div style="font-size:30px;color:grey;"><i class="el-icon-loading"></i>正在加载...</div>
        </div>

        <div v-if="show_zhankai==false">
                <el-row v-for="item in lists" :key="item.pk"  class="br10px17px">
                    <el-row>
                        <router-link class="a_black" style="float:left;" target="_blank" :to="{name:'qunzuye',params:{id:item.pk}}">
                            <span style="float:left;">{{item.fields.qz_title}}</span>
                        </router-link>
                        <uploadfu :leixing=8 :fujianshu="item.fields.fu" :id="item.pk"></uploadfu>
                    </el-row>
                    <el-row>
                            <span>{{item.fields.qz_join}}</span>
                            <span><el-divider direction="vertical"></el-divider></span>
                            <span>{{item.fields.qz_type}}</span>
                            <span style="float:right">
                                    <tj0shanchu :zhid="item.pk" leixing="8" @shanchuok="shanok()"></tj0shanchu>
                                    {{formatDate_ymd(item.fields.qz_createtime)}}
                            </span>
                    </el-row>
                    <el-row><el-divider style="margin:0px;"></el-divider></el-row>
                </el-row>
                <el-pagination v-if="listNum>10" style="text-align:right;"
                                background
                                :page-size=10
                                :total="listNum"
                                :current-page.sync="currentPage"
                                layout="total, prev, pager, next">
                </el-pagination>
        </div>
</div>


    
</template>


<script>
import uploadfu from '../fujian/uploadfu';
import tj0shanchu from '../tijiao/tj_shanchu';
import zhankai0 from '../fujian/zhankai0';
import md5 from 'js-md5';

	export default {
		name: 'bdx8',
        components: {uploadfu,tj0shanchu,zhankai0},
		data () {
			return {
                ok_msg:0,

                currentPage: 1,//当前分页的数值
                listNum:0,
                xhx8s:[],
                show_zhankai:true,
                blinkyellow:'',

                type_value:'兴趣讨论',
                shenqing_value:'',//这是的value含义有变动，现在的意义是入群口令
                qunzu_title:'',

                show_dialog:false,
                kouling1:'',
                kouling2:'',
                x_loading:false,
			}
        },

        computed: {
                lists(){
                    let pages=Math.ceil(this.listNum/10);//10为每页设置数量
                    let newList=[];
                    for(let i=0;i<pages;i++){
                    let sonList=[];
                    sonList=this.xhx8s.slice(i*10,i*10+10);//10为每页设置数量
                    newList.push(sonList)
                    }
                    return newList[this.currentPage-1]
                },
        },

		methods: {
            shanok(){this.shuaxinjian();},
            f_blod() {document.execCommand ( 'bold', false );},
            
            onPaste: function(e) {
                    e.preventDefault()
                    e.stopPropagation()
                    let pasteValue = (e.clipboardData || window.clipboardData).getData('text/plain')
                    console.log(pasteValue)
                    var re = /<[^>]+>/gi;
                    pasteValue = pasteValue.replace(re, '').replace(/\s+|[\r\n]/g,"");
                    e.target.textContent += pasteValue
                },
            zhankaijian(){
                this.x_loading=true;
                this.show_zhankai=false;
                this.axios
                        .post('http://www.zhishiren.info/api/xunhuanx8/',{userid: this.$cookies.get('userid')})
                        .then(response=>{
                            this.xhx8s=JSON.parse(response.data);
                            this.listNum=this.xhx8s.length;
                            this.x_loading=false;
                            });

            },
            shuaxinjian(){
                this.x_loading=true;
                this.$nextTick(() => {
                    this.axios
                        .post('http://www.zhishiren.info/api/xunhuanx8/',{userid: this.$cookies.get('userid')})
                        .then(response=>{
                            this.xhx8s=JSON.parse(response.data);
                            this.listNum=this.xhx8s.length;
                            this.x_loading=false;
                            });
                })
            },
            fabujian() {
                var that = this;
                if(that.qunzu_title===''){
                    that.ok_msg=2;
                    setTimeout(function(){
                        that.ok_msg=0;
                    }, 1500);
                }
                else{
                        that.axios
                        .post('http://www.zhishiren.info/api/bdx8/',{
                            userid: that.$cookies.get('userid'),
                            username:that.$cookies.get('username'),
                            type_value:that.type_value,
                            shenqing_value:that.shenqing_value,
                            qunzu_title:that.qunzu_title,
                            qunzu_shuoming:that.$refs.contents.innerHTML,
                            })
                        .then(function (response) {
                                        if (response.data.ok_id === 1){
                                            that.ok_msg=1;
                                            setTimeout(function(){that.ok_msg=0;}, 2000);
                                            that.$refs.zhankai0.addnew();
                                            
                                            that.$refs.contents.innerHTML='请输入此群组的介绍文字。';
                                            that.qunzu_title='';
                                            that.type_value='兴趣讨论';
                                            that.shenqing_value='';
                                            that.x_loading=true;
                                                that.$nextTick(() => {
                                                    that.$axios
                                                        .post('http://www.zhishiren.info/api/xunhuanx8/',{userid: that.$cookies.get('userid')})
                                                        .then(response=>{
                                                            that.xhx8s=JSON.parse(response.data);
                                                            that.listNum=that.xhx8s.length;
                                                            that.show_zhankai=false;
                                                            that.currentPage=1;
                                                            that.blinkyellow='blinkyellow';
                                                            setTimeout(function(){that.blinkyellow='';}, 2000);
                                                            that.x_loading=false;
                                                        });
                                                });
                                            // };           
                                        }
                                        if (response.data.ok_id === 3){
                                            that.ok_msg=3;
                                            setTimeout(function(){that.ok_msg=0;}, 1500);
                                            that.$refs.contents.innerHTML='请输入此群组的介绍文字。';
                                            that.x_loading=false;
                                
                                        }
                        });
                }    
            },
            fabujian1() {
                var that = this;
                if(that.kouling1==='' && that.kouling2===''){
                    that.ok_msg=4;
                    setTimeout(function(){that.ok_msg=0;}, 1500);
                }
                else{
                    if(that.kouling1!==that.kouling2){
                        that.ok_msg=5;
                        setTimeout(function(){that.ok_msg=0;}, 1500);
                    }
                    else{
                        that.kouling1=md5(that.kouling1);
                        that.axios
                        .post('http://www.zhishiren.info/api/bdx8/',{
                            userid: that.$cookies.get('userid'),
                            username:that.$cookies.get('username'),
                            type_value:that.type_value,
                            shenqing_value:that.shenqing_value,
                            qunzu_title:that.qunzu_title,
                            qunzu_shuoming:that.$refs.contents.innerHTML,
                            kouling:that.kouling1,
                            })
                        .then(function (response) {
                                        if (response.data.ok_id === 1){
                                            that.ok_msg=1;
                                            setTimeout(function(){that.ok_msg=0;}, 2000);
                                            that.$refs.zhankai0.addnew();
                                            
                                            that.$refs.contents.innerHTML='请输入此群组的介绍文字。';
                                            that.qunzu_title='';
                                            that.type_value='兴趣讨论';
                                            that.shenqing_value='不需申请';
                                            // if(that.show_zhankai===false){
                                                that.$nextTick(() => {
                                                    // that.show_zhankai=true;
                                                    that.$axios
                                                        .post('http://www.zhishiren.info/api/xunhuanx8/',{userid: that.$cookies.get('userid')})
                                                        .then(response=>{
                                                            that.xhx8s=JSON.parse(response.data);
                                                            that.listNum=that.xhx8s.length;
                                                            that.show_zhankai=false;
                                                            that.currentPage=1;
                                                            that.blinkyellow='blinkyellow';
                                                            setTimeout(function(){that.blinkyellow='';}, 2000);
                                                        });
                                                });
                                            // };   
                                            that.show_dialog=false;
                                            that.kouling1='';
                                            that.kouling2='';  
                                        }
                                        if (response.data.ok_id === 3){
                                            that.ok_msg=3;
                                            setTimeout(function(){
                                                that.ok_msg=0;
                                            }, 1500);
                                            that.$refs.contents.innerHTML='请输入此群组的介绍文字。';
                                            that.show_dialog=false; 
                                            that.kouling1='';
                                            that.kouling2='';
                                        }
                        });
                    }
                }
                
            },
        },
        created: function () {
                var _this= this;
                _this.axios
                .post('http://www.zhishiren.info/api/countx8/', {userid:_this.$cookies.get('userid')})
                .then(function (response) {_this.listNum=JSON.parse(response.data);});
        },
	}
</script>

<style scoped>

</style>