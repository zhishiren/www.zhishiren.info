<template>
<span id="faloading" style="font-size:18px;">
    <span style="color:green;" v-show="ok_msg===1"><i class="el-icon-success"></i>发布成功!</span>
    <span style="color:orange;" v-show="ok_msg===2"><i class="el-icon-warning-outline"></i>发言内容不能为空!</span>
    <span style="color:red;" v-show="ok_msg===3"><i class="el-icon-error"></i>数据库写入失败!</span>
    <span style="font-size:18px;" v-show="fa_loading"><i class="el-icon-loading"></i>正在发布...</span>
</span>
                
</template>

<script>
export default {
    name:'faloading',
    props:['ok_msg','fa_loading'],
	data() {return {}},
    methods:{},
};
</script>



