<template>
    <div id="xhchanged" class="font18px" >
        <el-row v-if="zhitype==='wenjiye' && list.wj_wdshu===0" class="font18px">
            <el-upload
                name="duanlist"
                class="upload-demo"
                action="http://www.zhishiren.info/api/shangchuan999/"
                Access-Control-Request-Headers: ContentType
                :data={wj_id:list.wj_id,wj_title:list.wj_title,wd_manager:list.wj_manager,wd_type:list.wj_type,wd_createrid:list.wj_createrid,wd_creatername:list.wj_creatername,}
                :on-preview="handlePreview"
                :on-remove="handleRemove"
                :on-success="daoruchenggong"
                :before-remove="beforeRemove"
                :on-change="onchange"
                :limit="1"
                :file-list="fileList">
                <el-button v-if="ceshi_id===0" class="font18px" type="text"  style="padding:0px;">
                    <i class="el-icon-upload2"></i>段落...
                </el-button>
                <span v-if="ceshi_id===1"><i class="el-icon-loading"></i>正在导入，请等待...</span>
                <span v-show="ceshi_id===0 && chuanduanlist_okmsg===9" class="font18px">上传段落列表，仅限xls格式。</span>
                <span v-show="chuanduanlist_okmsg===0" class="font18px" style="color:red">
                    导入失败
                </span>
            </el-upload>
		</el-row>
        <el-row v-if="zhitype==='wenjiye' && list.wj_wdshu===0"><br></el-row>
        
        <el-button v-if="managerid===yonghuid" @click="xiugai()" type="text" class="font18px" style="padding:0px;"><i class="el-icon-edit"></i>修改...</el-button>
        <el-button v-if="managerid!==yonghuid" @click="xiugai()" type="text" class="font18px" style="padding:0px;" disabled><i class="el-icon-edit"></i>修改...</el-button>
        <span>该知识点共有{{this.listNum}}</span>
        <!-- <span v-if="showloading1===false">{{this.listNum}}</span>
        <span v-if="showloading1===true"><i class="el-icon-loading"></i></span> -->
        <span>修改记录。</span>

        <span class="msg_ok" v-if="msg===2">操作失败！</span>
        <span class="msg_ok" v-if="msg===1">修改成功！</span>
        <a class="a_black" v-show="show_zhankai" @click="zhankaijian()">-展开-</a> 
        <a v-if="show_zhankai===false" class="a_black" @click="shuaxinjian()"><i class="el-icon-refresh"></i>刷新</a>
        <div v-if="showloading2" style="font-size:30px;color:grey;">
            <i class="el-icon-loading"></i>正在加载...
        </div>

    
        <div v-if="showloading2===false">
            <el-row class="br10px17px" v-for="list in xiugailist" :key="list.pk" >
                <el-row>
                    <span>
                        <span v-if="list.fields.fy!=='文件说明：'&&list.fields.fy!=='发言内容：'&&list.fields.fy!=='标签说明：'&&list.fields.fy!=='群组说明：'">原内容~{{list.fields.fy}}</span>
                        <span v-if="list.fields.fy==='文件说明：'||list.fields.fy==='发言内容：'||list.fields.fy==='标签说明：'||list.fields.fy==='群组说明：'">原内容~{{list.fields.fy}}<span v-html="list.fields.fyhui"></span></span>
                        <span v-if="list.fields.fy==='生效日期：'||list.fields.fy==='失效日期：'">{{getNowFormatDate(list.fields.time0)}}</span>
                    </span>
                    <span style="float:right;">{{qian_date(list.fields.time1)}}</span>
                </el-row>
                <el-row><el-divider style="margin:0px;"></el-divider></el-row>
            </el-row>
        </div>  

		<el-dialog title="修改知识点的内容" width="400px" :visible.sync="show_dialog">
            <div v-if="onlyshuoming===false">
                <el-row class="font18px">
                    <span v-if="zhitype==='wenjiye'" >现有状态：{{list.wj_status}}<i v-if="leixing===''" @click="editzhi('wj_status')" class="el-icon-edit a_grey">修改</i><i v-if="leixing!==''" @click="quxiao()" class="el-icon-refresh a_grey">取消</i></span>
                    <span v-if="zhitype==='fayanye'" >现有状态：{{list.fystatus}}<i v-if="leixing===''" @click="editzhi('fystatus')" class="el-icon-edit a_grey">修改</i><i v-if="leixing!==''" @click="quxiao()" class="el-icon-refresh a_grey">取消</i></span>
                    <span v-if="zhitype==='qunzuye'" >现有状态：{{list.qz_status}}<i v-if="leixing===''" @click="editzhi('qz_status')" class="el-icon-edit a_grey">修改</i><i v-if="leixing!==''" @click="quxiao()" class="el-icon-refresh a_grey">取消</i></span>
                    <span v-if="zhitype==='biaoqianye'" >现有状态：{{list.bq_status}}<i v-if="leixing===''" @click="editzhi('bq_status')" class="el-icon-edit a_grey">修改</i><i v-if="leixing!==''" @click="quxiao()" class="el-icon-refresh a_grey">取消</i></span>
                </el-row>
                <el-row v-if="leixing==='wj_status'||leixing==='fystatus'||leixing==='qz_status'||leixing==='bq_status'"  class="font18px">
                    <el-select v-model="xx_status" placeholder="请选择态度" style="width:75%;">
                        <el-option value="正常有效" key="正常有效" label="正常有效"></el-option>
					    <el-option value="正在审核" key="正在审核" label="正在审核"></el-option>
                        <!-- <el-option value="已被拒绝" key="已被拒绝" label="已被拒绝"></el-option> -->
                        <el-option value="失效已删" key="失效已删" label="失效已删"></el-option>
                    </el-select>
                    <span v-if="faloading===false">
                        <i class="el-icon-check a_grey" @click="check1('xx_status')">确定</i>
                    </span>
                    <span v-if="faloading"><i class="el-icon-loading"></i>...</span>
                </el-row>
                <el-row><br></el-row>

                <el-row v-if="zhitype==='fayanye'||zhitype==='wenjiye'||zhitype==='qunzuye'" class="font18px">
                    <span v-if="zhitype==='wenjiye'" >文件类型：{{list.wj_type}}<i v-if="leixing===''" @click="editzhi('wj_type')" class="el-icon-edit a_grey">修改</i><i v-if="leixing!==''" @click="quxiao()" class="el-icon-refresh a_grey">取消</i></span>
                    <span v-if="zhitype==='fayanye'" >发言类型：{{list.fytype}}<i v-if="leixing===''" @click="editzhi('fy_type')" class="el-icon-edit a_grey">修改</i><i v-if="leixing!==''" @click="quxiao()" class="el-icon-refresh a_grey">取消</i></span>
                    <span v-if="zhitype==='qunzuye'" >群组类型：{{list.qz_type}}<i v-if="leixing===''" @click="editzhi('qz_type')" class="el-icon-edit a_grey">修改</i><i v-if="leixing!==''" @click="quxiao()" class="el-icon-refresh a_grey">取消</i></span>
                </el-row>
                <el-row v-if="leixing==='wj_type'||leixing==='fy_type'||leixing==='qz_type'" class="font18px">
                        <el-select v-model="newtype" placeholder="请选择所属类型" style="width:75%;">
                            <span v-if="leixing==='fy_type'">
                                <el-option value="求助询问" key="求助询问" label="求助询问"></el-option>
                                <el-option value="新闻简讯" key="新闻简讯" label="新闻简讯"></el-option>
                                <el-option value="公告通知" key="公告通知" label="公告通知"></el-option>
                                <el-option value="感悟思考" key="感悟思考" label="感悟思考"></el-option>
                                <el-option value="名人名言" key="名人名言" label="名人名言"></el-option>
                                <el-option value="公开言论" key="公开言论" label="公开言论"></el-option>
                            </span>
                            <span v-if="leixing==='qz_type'">
                                <el-option value="兴趣讨论" key="兴趣讨论" label="兴趣讨论"></el-option>
                                <el-option value="内部团队" key="内部团队" label="内部团队"></el-option>
                                <el-option value="企业社团" key="企业社团" label="企业社团"></el-option>
                            </span>
                            <span v-if="leixing==='wj_type'">
                                <el-option value="知识百科" key="知识百科" label="知识百科"></el-option>
                                <el-option value="国家法规" key="国家法规" label="国家法规"></el-option>
                                <el-option value="行业标准" key="行业标准" label="行业标准"></el-option>
                                <el-option value="企业制度" key="企业制度" label="企业制度"></el-option>
                                <el-option value="学术著作" key="学术著作" label="学术著作"></el-option>
                                <el-option value="新闻简讯" key="新闻简讯" label="新闻简讯"></el-option>
                                <el-option value="公告通知" key="公告通知" label="公告通知"></el-option>
                                <el-option value="经验分享" key="经验分享" label="经验分享"></el-option>
                            </span>      
                        </el-select>
                        <span v-if="faloading===false">
                            <i class="el-icon-check a_grey" @click="check1('xx_type')">确定</i>
                        </span>
                        <span v-if="faloading"><i class="el-icon-loading"></i>...</span>
                </el-row>
                <el-row v-if="zhitype==='fayanye'||zhitype==='wenjiye'||zhitype==='qunzuye'"><br></el-row>
                
                <el-row v-if="zhitype==='fayanye'" class="font18px">
                    <span>发言态度：{{list.fy_att}}<i v-if="leixing===''" @click="editzhi('fyatt')" class="el-icon-edit a_grey">修改</i><i v-if="leixing!==''" @click="quxiao()" class="el-icon-refresh a_grey">取消</i></span>
                </el-row>
                <el-row v-if="leixing==='fyatt'"  class="font18px">
                    <el-select v-model="fyatt" placeholder="请选择态度" style="width:75%;">
                        <el-option value="无态度" key="无态度" label="无态度"></el-option>
					    <el-option value="紧急重要" key="紧急重要" label="紧急重要"></el-option>
                    </el-select>
                    <span v-if="faloading===false">
                        <i class="el-icon-check a_grey" @click="check1('fyatt')">确定</i>
                    </span>
                    <span v-if="faloading"><i class="el-icon-loading"></i>...</span>
                </el-row>
                <el-row v-if="zhitype==='fayanye'"><br></el-row>

                <el-row v-if="zhitype!=='qunzuye'" class="font18px">
                    <span>公开范围：{{daibiaoma(this.fanwei)}}<i v-if="leixing===''" @click="editzhi('newfanwei')" class="el-icon-edit a_grey">修改</i><i v-if="leixing!==''" @click="quxiao()" class="el-icon-refresh a_grey">取消</i></span>
                </el-row>
                <el-row v-if="leixing==='newfanwei'"  class="font18px">
                    <zu0setfanwei ref="huanyuan" @set_fanwei="set_gongkaifanwei" style="width:75%;display:inline-block;"></zu0setfanwei>
                    <span v-if="faloading===false">
                        <i class="el-icon-check a_grey" @click="check1('newfanwei')">确定</i>
                    </span>
                    <span v-if="faloading"><i class="el-icon-loading"></i>...</span>
                </el-row>
                <el-row v-if="zhitype!=='qunzuye'" ><br></el-row>

                <el-row v-if="zhitype==='qunzuye'" class="font18px">
                    <span>入群口令：********<i v-if="leixing===''" @click="editzhi('kongling0')" class="el-icon-edit a_grey">修改</i><i v-if="leixing!==''" @click="quxiao()" class="el-icon-refresh a_grey">取消</i></span>
                </el-row>
                <el-row v-if="leixing==='kongling0'"  class="font18px">
                    <el-input v-model="kongling0" placeholder="这是用户申请入群的口令"  style="width:75%;"></el-input>
                    <span v-if="faloading===false">
                            <i class="el-icon-check a_grey" @click="check1('kongling0')">确定</i>
                    </span>
                    <span v-if="faloading"><i class="el-icon-loading"></i>...</span>
                </el-row>
                <el-row v-if="zhitype==='qunzuye'"><br></el-row>

                <div v-if="zhitype==='wenjiye'">
                    <el-row class="font18px">
                        <span>生效日期：{{getNowFormatDate(this.list.wj_borntime)}}<i v-if="leixing===''" @click="editzhi('born_time')" class="el-icon-edit a_grey">修改</i><i v-if="leixing!==''" @click="quxiao()" class="el-icon-refresh a_grey">取消</i></span>
                    </el-row>
                    <el-row v-if="leixing==='born_time'"  class="font18px">
                            <el-date-picker
                                style="width:75%;"
                                v-model="born_time"
                                type="date"
                                value-format="yyyy-MM-dd"
                                placeholder="选择日期">
                            </el-date-picker>
                        <span v-if="faloading===false">
                            <i class="el-icon-check a_grey" @click="check1('born_time')">确定</i>
                        </span>
                        <span v-if="faloading"><i class="el-icon-loading"></i>...</span>
                    </el-row>
                    <el-row><br></el-row>

                    <el-row class="font18px">
                        <span>失效日期：{{getNowFormatDate(this.list.wj_deadtime)}}<i v-if="leixing===''" @click="editzhi('dead_time')" class="el-icon-edit a_grey">修改</i><i v-if="leixing!==''" @click="quxiao()" class="el-icon-refresh a_grey">取消</i></span>
                    </el-row>
                    <el-row v-if="leixing==='dead_time'"  class="font18px">
                            <el-date-picker
                                style="width:75%;"
                                v-model="dead_time"
                                type="date"
                                value-format="yyyy-MM-dd"
                                placeholder="选择日期">
                            </el-date-picker>
                        <span v-if="faloading===false">
                            <i class="el-icon-check a_grey" @click="check1('dead_time')">确定</i>
                        </span>
                        <span v-if="faloading"><i class="el-icon-loading"></i>...</span>
                    </el-row>
                    <el-row><br></el-row>

                    <el-row class="font18px">
                        <span>所属地区：{{this.list.wj_area}}<i v-if="leixing===''" @click="editzhi('diqu')" class="el-icon-edit a_grey">修改</i><i v-if="leixing!==''" @click="quxiao()" class="el-icon-refresh a_grey">取消</i></span>
                    </el-row>
                    <el-row v-if="leixing==='diqu'"  class="font18px">
                        <el-input v-model="diqu" placeholder="请选择所属地区"  style="width:75%;"></el-input>
                        <span v-if="faloading===false">
                            <i class="el-icon-check a_grey" @click="check1('diqu')">确定</i>
                        </span>
                        <span v-if="faloading"><i class="el-icon-loading"></i>...</span>
                    </el-row>
                    <el-row><br></el-row>

                    <el-row class="font18px">
                        <span>所属行业：{{this.list.wj_hangye}}<i v-if="leixing===''" @click="editzhi('hangye')" class="el-icon-edit a_grey">修改</i><i v-if="leixing!==''" @click="quxiao()" class="el-icon-refresh a_grey">取消</i></span>
                    </el-row>
                    <el-row v-if="leixing==='hangye'"  class="font18px">
                        <el-input v-model="hangye" placeholder="请选择所属的行业"  style="width:75%;"></el-input>
                        <span v-if="faloading===false">
                            <i class="el-icon-check a_grey" @click="check1('hangye')">确定</i>
                        </span>
                        <span v-if="faloading"><i class="el-icon-loading"></i>...</span>
                    </el-row>
                    <el-row><br></el-row>

                    <el-row class="font18px">
                        <span>发文机构：{{this.list.wj_publisher}}<i v-if="leixing===''" @click="editzhi('fawenjigou')" class="el-icon-edit a_grey">修改</i><i v-if="leixing!==''" @click="quxiao()" class="el-icon-refresh a_grey">取消</i></span>
                    </el-row>
                    <el-row v-if="leixing==='fawenjigou'"  class="font18px">
                        <el-input v-model="fawenjigou" placeholder="请输入发文机构或作者"  style="width:75%;"></el-input>
                        <span v-if="faloading===false">
                            <i class="el-icon-check a_grey" @click="check1('fawenjigou')">确定</i>
                        </span>
                        <span v-if="faloading"><i class="el-icon-loading"></i>...</span>
                    </el-row>
                    <el-row><br></el-row>
                </div>
            </div>
            
            <el-row class="font18px">
                <span>内容说明：...<i v-if="leixing===''" @click="editzhi('shuoming')" class="el-icon-edit a_grey">修改</i><i v-if="leixing!==''" @click="quxiao()" class="el-icon-refresh a_grey">取消</i></span>
            </el-row>
            <el-row><br></el-row>
            
            <div v-show="leixing==='shuoming'">
                <el-row>
                    <div contenteditable ref="contents" @paste="onPaste" class="pinglunlan">请输入备注/说明/内容。</div>
                </el-row>
                <el-row class="font18px">
                    <el-col :span="7">
                        <a v-if="zhitype!=='发言密码'" class="a_black" href="javascript:;" @click="f_blod">
                            <b>所选加粗</b>
                        </a>
                    </el-col>
                    <el-col :span="7">
                    </el-col>
                    <el-col :span="10" style="text-align:right" class="font20px">
                        <span v-if="faloading===false">
                            <i class="el-icon-check a_grey" @click="check1('shuoming')">确定</i>
                        </span>
                        <span v-if="faloading"><i class="el-icon-loading"></i>...</span>
                    </el-col>
                </el-row>
            </div>
                
        </el-dialog>

    </div>
</template>

<script>
    export default {
        name:'xhchanged',
        props:[
            'zhitype',
            'zhid',
            'list',//这是传入的知识点信息列表
            'listNum',//这是传入的修改记录
            'listNum1',//这是后台计算的修改记录
            'showloading1',
            'showloading2',
            'managerid',//仅用于群组页面，用来判断是不是群组管理员
            // 'zhicontent',
            'fanwei',
        ],
        
        data() {return {
            //这是“修改”这个按键的相关变量
            show_zhankai:true,
            show_dialog:false,
            show_dialog1:false,
            msg:0,
            faloading:false,
            //这是各种输入框的相关输入内容
            newfanwei:0,
            diqu:'',
            hangye:'',
            fawenjigou:'',
            born_time:null,
            dead_time:null,
            newtype:'',
            kouling0:'',
            // qzlists: [{qz_id:90000000,qz_title:"--所有人--"}],
            shuoming:'',
            //这是用于上传段落列表组件相关的变量
            ceshi_id:0,
			chuanduanlist_okmsg:9,
            //这是页面修改框中各种变量的设计
            leixing:'',
            onlyshuoming:false,
            fyatt:'',
            xiugailist:[],
            showloading2:false,
            showloading1:false,
            xx_status:''
        }},
        computed:{
			yonghuid(){return parseInt(this.$cookies.get('userid'))},
        },
        methods:{
            // 以下是上传段落列表的控件。。。
            daoruchenggong(response) {
                if(response!==999){this.chuanduanlist_okmsg=0;setTimeout(function(){this.chuanduanlist_okmsg=9;}, 2000);}
                if(response===999){this.$router.go(0);}
            },
            handleExceed(files, fileList) {this.$message.warning(`每次操作只能上传一个文件！`);},
            beforeRemove(file, fileList) {return this.$confirm(`确定移除 ${ file.name }？`);},
            handleRemove(file, fileList) {console.log(file, fileList);},
            handlePreview(file) {console.log(file);},
            onchange(file, fileList){this.ceshi_id=1;},

            set_gongkaifanwei(data){this.newfanwei = data.qz_id;},
            // 以下是修改键和后面的展开和刷新键
            xiugai(){this.show_dialog=true;},
            zhankaijian(){this.show_zhankai=false;this.shuaxinjian();},
            shuaxinjian(){
                this.showloading1=true;
                this.showloading2=true;
                var _this= this;
                _this.axios
                .post('http://www.zhishiren.info/api/xunhuancaozuo/', {zhid:_this.zhid,cztype:'修改'})
                .then(function (response) {
                    _this.xiugailist=JSON.parse(response.data);
                    _this.listNum=_this.xiugailist.length;
                    _this.listNum1=_this.xiugailist.length;
                    _this.showloading2=false;
                    _this.showloading1=false;
                });
            },
            editzhi(kkk){
                this.leixing=kkk;
                if(kkk==='shuoming'){
                    this.onlyshuoming=true;
                }
            },
            quxiao(){this.leixing='';this.onlyshuoming=false;},
            
            f_blod() {document.execCommand ( 'bold', false );},
            onPaste: function(e) {
                    e.preventDefault()
                    e.stopPropagation()
                    let pasteValue = (e.clipboardData || window.clipboardData).getData('text/plain')
                    console.log(pasteValue)
                    var re = /<[^>]+>/gi;
                    pasteValue = pasteValue.replace(re, '').replace(/\s+|[\r\n]/g,"");
                    e.target.textContent += pasteValue
            },

            check1(kkk){
                var that = this;
                if(that.$refs.contents.innerHTML==='请输入备注/说明/内容。'){that.shuoming='';};
                if(that.$refs.contents.innerHTML!=='请输入备注/说明/内容。'){that.shuoming=that.$refs.contents.innerHTML;};
                that.faloading=true;
                that.axios
                .post('http://www.zhishiren.info/api/to_xiugai/',{
                    kkk:kkk,
                    xx_status:that.xx_status,
                    id0:that.zhid,
                    uid: that.managerid,
                    zhitype:that.zhitype,
                    newfanwei:that.newfanwei,
                    diqu:that.diqu,
                    fyatt:that.fyatt,
                    hangye:that.hangye,
                    fawenjigou:that.fawenjigou,
                    born_time:that.born_time,
                    dead_time:that.dead_time,
                    newtype:that.newtype,
                    kouling0:that.kouling0,
                    shuoming:that.shuoming,
                    })
                .then(function (response) {
                    if (response.data.msg === 1){
                        that.msg=response.data.msg;
                        setTimeout(function(){
                            that.msg=0;
                            that.$router.go(0);
                        }, 2000);
                        that.$refs.contents.innerHTML='请输入备注/说明/内容。';
                        that.newfanwei=0;
                        // that.qzlists=[{qz_id:90000000,qz_title:"--所有人--"}];

                    }
                    else{
                        that.msg=response.data.msg;
                        setTimeout(function(){that.msg=0;}, 2000);
                        that.$refs.contents.innerHTML='请输入备注/说明/内容。';
                    };
                    that.show_dialog=false;
                    that.faloading=false;
                    that.leixing='';
                    that.onlyshuoming=false;
                });
                
                
                
            },
        },
        
    };
</script>

<style scoped>
	 .msg_ok{font-size:18px;color:green;text-align: center;} 
	 .msg_orange{font-size:18px;color:orange;text-align: center;} 
	 .msg_red{font-size:18px;color:red;text-align: center;} 
</style>



