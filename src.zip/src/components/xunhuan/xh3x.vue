<template>
	<div id="xh3x">
        <zu1caozuojishu 
            :zone_id="zoneid" :jishu="listNum" :listNumk="listNumk" 
            :showloading1="showloading1" :showloading2="showloading2" 
            @send_searchword="send_searchword" @zhankai="zk" @shuaxin="shuaxin" @huanyuan="huanyuan">
        </zu1caozuojishu>  
        
        <div v-show="show_xh3x && showloading2===false">
            <el-row class="br10px17px" v-for="list in lists" :key="list.pk">
                <zu1userinfo v-if="zoneid==='31'||zoneid==='32'||zoneid==='33'||zoneid==='36'||zoneid==='37'" :list="list"></zu1userinfo>
                <zu1qzinfo v-if="zoneid==='34'||zoneid==='35'" :list="list"></zu1qzinfo>
            </el-row>
            <br>
            <el-pagination v-if="zoneid!=='31' && listNum>10" style="text-align:right;"
                            background
                            :page-size=10
                            :total="listNum"
                            :current-page.sync="currentPage"
                            layout="total, prev, pager, next">
            </el-pagination>
        </div>
        <div v-show="show_xhk3x && showloading2===false">
            <el-row class="br10px17px" v-for="listk in listks" :key="listk.pk">
                <zu1userinfo v-if="zoneid==='31'||zoneid==='32'||zoneid==='33'||zoneid==='36'||zoneid==='37'"  :list="listk" :kkk='k'></zu1userinfo>
                <zu1qzinfo v-if="zoneid==='34'||zoneid==='35'" :list="listk" :kkk='k'></zu1qzinfo>
            </el-row>
            <br>
            <el-pagination v-if="listNumk>10" style="text-align:right;"
                            background
                            :page-size=10
                            :total="listNumk"
                            :current-page.sync="currentPagek"
                            layout="total, prev, pager, next">
            </el-pagination>
        </div>
    </div>
</template>

<script>

import zu1userinfo from '../zujian1/zu1userinfo.vue';
import zu1qzinfo from '../zujian1/zu1qzinfo.vue';

export default {
    name:'xh3x',
    components: {zu1userinfo,zu1qzinfo},
    props:['zoneid','listNum'],
    // zoneid是用来区分不同类型的组件，
    
	data() {return {
        currentPage: 1,//当前分页的数值
        // listNum:0,//分页总条数
        currentPagek: 1,//查找后，当前分页的数值
        listNumk:0,//查找后，分页总条数

        show_xh3x:false,
        show_xhk3x:false,
        xh3xs:[],
        xh3xks:[],
        k:'',
        showloading2:false,
        showloading1:false,
    }},

	computed: {
            lists(){
                let pages=Math.ceil(this.listNum/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                    let sonList=[];
                    sonList=this.xh3xs.slice(i*10,i*10+10);//10为每页设置数量
                    newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
            listks(){
                let pages=Math.ceil(this.listNumk/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                    let sonList=[];
                    sonList=this.xh3xks.slice(i*10,i*10+10);//10为每页设置数量
                    newList.push(sonList)
                }
                return newList[this.currentPagek-1]
            },

    },
    
	methods:{

        send_searchword(data){
            this.show_xh3x=false;
            this.show_xhk3x=true;
            this.k=data.k;
            if(this.zoneid==='31'){
                    var _this=this;
                    _this.showloading2=true;
                    _this.$axios
                    .post('http://www.zhishiren.info/api/xunhuan31sou/', {kkk:_this.k})
                    .then(response=>{
                        _this.xh3xks=JSON.parse(response.data);
                        _this.listNumk=_this.xh3xks.length;
                        _this.showloading2=false;
                    });
            }else if(this.zoneid==='34'){
                    var _this=this;
                    _this.showloading2=true;
                    _this.$axios
                    .post('http://www.zhishiren.info/api/xunhuan34_sou/', {kkk:_this.k})
                    .then(response=>{
                        _this.xh3xks=JSON.parse(response.data);
                        _this.listNumk=_this.xh3xks.length;
                        _this.showloading2=false;
                    });
            }else if(this.zoneid==='35'){
                    var newList = [];
        　　　　　　  this.xh3xs.forEach(item=>{if(item.fields.qz_title.indexOf(this.k) !==-1||item.fields.qz_remark.indexOf(this.k) !==-1){newList.push(item)}});
                    this.listNumk = newList.length;//这里是计算筛选后的结果的数量
        　　　　　　  this.xh3xks = newList;
            }else{
        　　　　　　  var newList = [];
        　　　　　　  this.xh3xs.forEach(item=>{if(item.fields.yonghu_name.indexOf(this.k) !==-1){newList.push(item)}});
                    this.listNumk = newList.length;//这里是计算筛选后的结果的数量
        　　　　　　  this.xh3xks = newList;
            }
        },

      zk(){this.shuaxin();},

      huanyuan(){
          this.shuaxin();
          this.k='';
        },

      shuaxin(){
            this.showloading2=true;
            this.show_xh3x=true;
            this.show_xhk3x=false;
            this.$axios
            .post('http://www.zhishiren.info/api/xunhuan3x/', {userid:this.$cookies.get('userid'),chuan:this.$cookies.get('chuan'),zoneid:this.zoneid})
            .then(response=>{
                this.xh3xs=JSON.parse(response.data);
                if(this.zoneid!=='31'){this.listNum=this.xh3xs.length;}
                this.showloading2=false;
            });
      },
    },	

};
</script>

