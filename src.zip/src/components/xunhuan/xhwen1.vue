<template>
	<div id="xhwen1">
        <el-row style="line-height: 40px;" >
            <el-col :span="2" ><span >提问类型：</span></el-col>
            <el-col :span="6" >
                <el-select v-model="wen_type" placeholder="请选择提问的类型" style="width:90%;">
					<el-option value="阅读难点" key="阅读难点" label="阅读难点"></el-option>
					<el-option value="生活实践" key="生活实践" label="生活实践"></el-option>
					<el-option value="人生困惑" key="人生困惑" label="人生困惑"></el-option>
					<el-option value="理论探讨" key="理论探讨" label="理论探讨"></el-option>
                </el-select>
            </el-col>
            <el-col :span="2" ><span >是否匿名：</span></el-col>
            <el-col :span="6" >
                <el-select v-model="wen_niming" placeholder="请选择是否匿名" style="width:90%;">
                    <el-option value="匿名" key="匿名" label="匿名"></el-option>
					<el-option value="不匿名" key="不匿名" label="不匿名"></el-option>
                </el-select>
            </el-col>
            <el-col :span="2" ><span>关联ID号：</span></el-col>
            <el-col :span="6" >
                <el-input v-model="tiwen_id" placeholder="关联知识的id号"  style="width:96%;"></el-input>
            </el-col>
        </el-row>
        <br>
        <el-row >
            <el-col :span="2" ><span class="font16px">提问内容：</span></el-col>
            <el-col :span="20" >
                <div contenteditable ref="contents" @paste="onPaste" class="pinglunlan" style="font-size:16px;width:100%;">请输入你要提问的内容。</div>
            </el-col>
            <el-col :span="2"><a class="a_black" href="javascript:;" @click="f_blod"><b>所选加粗</b></a></el-col>
        </el-row>
        <el-row v-if="later24h(lastwentime)===true" style="text-align:center;line-height: 40px;">
            <span v-show="faloading!==true">
                <a class="font20px a_black"  @click="fabujian(0)">明发</a>
                <el-divider direction="vertical"></el-divider>
                <a class="font20px a_black"  @click="fabujian(1)">密发</a>
            </span>
            <span v-if="faloading"  style="font-size:18px;"><i class="el-icon-loading"></i>正在发布...</span>
            <span v-if="return_msg" style="color:orange;font-size:18px;">:{{this.return_msg}}</span>
        </el-row>
        <el-row v-if="later24h(lastwentime)===false" style="font-size:20px;text-align:center;">
            <i style="color:orange;" class="el-icon-info">距你上次提问不足24小时，请等待</i>
        </el-row>


        <zu1caozuojishu ref="jishu" zone_id="wen1" :jishu="listNum0" :showloading1="showloading1" :showloading2="showloading2" @zhankai="zhankaijian()" @shuaxin="shuaxinjian()"></zu1caozuojishu>

        <div v-if="showloading2===false">
            <el-row v-for="item in lists" :key="item.pk"  class="br10px17px">
                <!-- <span v-if="item.fields.fystatus!=='正在审核'" style="color:brown;">
                    <font style="font-size:18px;">
                        <div class="spanlimit">
                            <span><b>“</b></span>
                            <router-link class="a_black" target="_blank" :to="{name:'fayanye',params:{id:item.pk}}">
                                <span style="color:brown">{{item.fields.fy}}</span>
                            </router-link>
                            <span><b>”</b></span>
                        </div>
                        <span style="color:grey" v-if="item.fields.uname==='匿名'">(匿名)</span>
                    </font>
                </span>
                <span v-if="item.fields.fystatus==='正在审核'">提问内容:
                    <span style="background-color:grey;color:white;">正在审核</span>
                </span> -->
                <el-row>
                    <zu1yuansu v-if="item.fields.fystatus!=='正在审核'" :list="item"></zu1yuansu>
                    <span v-if="item.fields.fystatus==='正在审核'" >发言内容:<span style="background-color:grey;color:white">正在审核</span></span>
                    <span style="color:grey;border:0px;" v-if="item.fields.uname==='匿名'">(匿名)</span>
                </el-row>
                <zu1huifulan :list="item" :izeng_yn="true"  @shanchuok="shanok" @chongfaok="chongfaok"></zu1huifulan>
                
                <el-row><el-divider style="margin:0px;"></el-divider></el-row>

            </el-row>
            <br>
            <el-pagination v-if="listNum>10" style="text-align:right;"
                            background
                            :page-size=10
                            :total="listNum"
                            :current-page.sync="currentPage"
                            layout="total, prev, pager, next">
            </el-pagination>
        </div>
    </div>

</template>


<script type="text/javascript">

	export default {
		name: 'xhwen1',
        components: {},
        props:['listNum0'],

        data () {
			return {
                xhwen1:[],
                currentPage: 1,//当前分页的数值

                wen_type:'理论探讨',
                wen_niming:'匿名',
                tiwen_id:'',
                
                showloading1:false,
                showloading2:false,
                faloading:false,
                return_msg:'',

                listNum:0
            }
        },
        computed:{
            lists(){
                let pages=Math.ceil(this.listNum/10);//
                let newList=[];
                for(let i=0;i<pages;i++){
                let sonList=[];
                sonList=this.xhwen1.slice(i*10,i*10+10);//
                newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
            usertype(){return this.$cookies.get('usertype')},
            lastwentime(){return this.$cookies.get('lastwentime')},
		},
		methods: {
            shanok(){this.shuaxinjian();},
            chongfaok(){this.shuaxinjian();},
            zhankaijian(){this.shuaxinjian();},
            shuaxinjian(){
                this.showloading2=true;
                this.axios
                    .post('http://www.zhishiren.info/api/xunhuan_zengwen/',{userid: this.$cookies.get('userid')})
                    .then(response=>{
                        this.xhwen1=JSON.parse(response.data);
                        this.listNum=JSON.parse(response.data).length;
                        this.listNum0=JSON.parse(response.data).length;
                        this.showloading2=false;
                        });
            },

            fabujian(mi) {
                var that = this;
                if(that.tiwen_id===''){that.tiwen_id=0}
                if(that.$refs.contents.innerHTML==='请输入你要提问的内容。'){
                    that.return_msg='发言提问不能为空！';
                    setTimeout(function(){that.return_msg='';}, 1500);
                }
                else{
                    that.faloading=true;
                    that.axios
                    .post('http://www.zhishiren.info/api/to_caozuo/',{
                        cztype:'提问',
                        fy:that.$refs.contents.innerHTML,
                        fymm:that.$cookies.get('fayanmima'),

                        fytype:that.wen_type,
                        fyniming:that.wen_niming,
                        id0:that.tiwen_id,
                        fymi:mi,

                        uid: that.$cookies.get('userid'),
                        uname:that.$cookies.get('username'),
                        })
                    .then(function (response) {
                        if (response.data.msg===1 ){
                            that.return_msg='操作成功';
                            setTimeout(function(){that.return_msg='';}, 2000);

                            that.$refs.contents.innerHTML='请输入你要提问的内容。';
                            // that.$refs.huanyuan.huanyuan();
                            
                            that.wen_type='理论探讨';
                            that.wen_niming='匿名';
                            that.tiwen_id='';
                            let newtime=new Date();
                            that.$refs.jishu.shuaxinjian();
                            _this.$cookies.set('lastwentime',newtime,'8h');
                        }
                        else{
                            that.return_msg='操作失败';
                            setTimeout(function(){that.return_msg='';}, 1500);

                            that.$refs.contents.innerHTML='请输入你要提问的内容。';

                            that.showloading2=false;
                        }
                    });
                    that.faloading=false;
                }
            },



            f_blod() {document.execCommand ( 'bold', false );},
            onPaste: function(e) {
                    e.preventDefault()
                    e.stopPropagation()
                    let pasteValue = (e.clipboardData || window.clipboardData).getData('text/plain')
                    console.log(pasteValue)
                    var re = /<[^>]+>/gi;
                    pasteValue = pasteValue.replace(re, '').replace(/\s+|[\r\n]/g,"");
                    e.target.textContent += pasteValue
            },

            
        },

	}
</script>



