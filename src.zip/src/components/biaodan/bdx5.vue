

<template>
	<div>
        <el-row style="line-height: 40px;" >
            <el-col :span="2" >
                <span >数集标题：</span>
            </el-col>
            <el-col :span="6" >
                <el-input v-model="hangye" placeholder="请输入数集的标题"  style="width:90%;"></el-input>
            </el-col>
            <el-col :span="2" >
                <span >计量单位：</span>
            </el-col>
            <el-col :span="6" >
                <el-input v-model="hangye" placeholder="请输入计量单位"  style="width:90%;"></el-input>
            </el-col>
            <el-col :span="2" >
                <span >公开范围：</span>
            </el-col>
            <el-col :span="6" >
                <fanwei  ref="huanyuan" @set_fanwei="set_gongkaifanwei" style="width:90%;"></fanwei>
            </el-col>
        </el-row>
        <br>

        <el-row style="line-height: 40px;" >
            <el-col :span="2" >
                <span >发布频率：</span>
            </el-col>
            <el-col :span="6" >
                <el-select v-model="value" placeholder="请选择发布频率" style="width:90%;">
                <el-option></el-option>
                </el-select>
            </el-col>

            <el-col :span="2" >
                <span >所属行业：</span>
            </el-col>
            <el-col :span="6" >
                <el-input v-model="hangye" placeholder="请选择所属的行业"  style="width:90%;"></el-input>
            </el-col>


            <el-col :span="2" >
                <span >所属地区：</span>
            </el-col>
            <el-col :span="6" >
                <el-input v-model="diqu" placeholder="请选择所属地区"  style="width:90%;"></el-input>
            </el-col>


        </el-row>
 

        <!-- <el-row style="line-height: 40px;" >
            <el-col :span="2" >
                <span >失效日期：</span>
            </el-col>
            <el-col :span="6" >
                <el-select v-model="value" placeholder="发布或者生效的日期" style="width:90%;">
                <el-option></el-option>
                </el-select>
            </el-col>

            <el-col :span="2" >
                <span >所属行业：</span>
            </el-col>
            <el-col :span="6" >
                <el-select v-model="value" placeholder="发布或者生效的日期" style="width:90%;">
                <el-option></el-option>
                </el-select>
            </el-col>

            <el-col :span="2" >
                <span >发文机构：</span>
            </el-col>
            <el-col :span="6" >
                <el-select v-model="value" placeholder="发布或者生效的日期" style="width:90%;">
                <el-option></el-option>
                </el-select>
            </el-col>
        </el-row>
        <br> -->
        <br>
        <el-row >
                <el-col :span="2" >
                    <span class="font16px">发言内容：</span>
                </el-col>
                <el-col :span="20" >
                    <div contenteditable ref="contents" @paste="onPaste" class="pinglunlan" style="font-size:16px;width:100%;">
                    </div>
                </el-col>
                <el-col :span="2">
                    <a class="a_black" href="javascript:;" @click="f_blod">
                        <b>所选加粗</b>
                    </a>
                </el-col>
        </el-row>
        <el-row  style="line-height: 40px;">
                <el-upload
                    class="upload-demo"
                    ref="upload"
                    :data={user_id:this.user_id}
                    multiple
                    action="http://www.zhishiren.info/api/bdx5fu/"
                    Access-Control-Request-Headers: ContentType
                    style="padding-left:300px;"
                    :on-preview="handlePreview"
                    :on-remove="handleRemove"
                    :file-list="fileList"
                    :on-success="shuaxinyemian"
                    :auto-upload="false">
                    <el-button style="font-size:16px;" slot="trigger" size="small" type="text">附图附件...
                    </el-button><el-divider direction="vertical"></el-divider><!--
                    --><a class="font20px a_black"  @click="submitUpload">发布</a><el-divider direction="vertical"></el-divider><!--
                    --><span style="color:blue;" v-show="ok_msg==0"><i class="el-icon-info"></i>仅限jpg/zip/rar格式,小于10M</span><!--
                    --><span style="color:green;" v-show="ok_msg==1"><i class="el-icon-success"></i>发布成功!</span><!--
                    --><span style="color:orange;" v-show="ok_msg==2"><i class="el-icon-warning-outline"></i>发布内容不能为空!</span><!--
                    --><span style="color:red;" v-show="ok_msg==3"><i class="el-icon-error"></i>数据库写入失败!</span>
                </el-upload>
        </el-row>

            <el-row class="br10px17px">
                <el-row>
                    <span style="float:left;">《数集的标题》</span>
                </el-row>
                <el-row>
                        <span>公开于所有用户</span>
                        <el-divider direction="vertical"></el-divider><span>附图附件0</span>
                        <span style="float:right">
                                <a class="a_grey">
                                    <i class="el-icon-close"></i>删除
                                </a>
                                2020-01-01
                        </span>
                </el-row>
                <el-row><el-divider style="margin:0px;"></el-divider></el-row>
            </el-row>



</div>


    
</template>


<script type="text/javascript">
import fanwei from '../fujian/fanwei';


	export default {
		name: 'bdx5',
        components: {fanwei},
		data () {
			return {
                qunzu_id:80000000,
                ok_msg:0,



			}
		},
		methods: {
            fabujian() {
                // 这里需要判断，
                var that = this;
                if(that.$refs.contents.innerHTML===''){that.ok_msg=1}
                else{
                    if(that.$refs.upload.uploadFiles.length <= 0){
                        that.axios
                        .post('http://www.zhishiren.info/api/bdx5/',{
                            userid: that.$cookies.get('userid'),
                            username:that.$cookies.get('username'),
                            fayan_leixing:that.type_value,
                            fayan_divcontent:that.$refs.contents.innerHTML,
                            fy_fanwei:that.qunzu_id,
                        })
                        .then(function (response) {
                                        if (response.data.ok_id === 0){
                                            that.ok_msg=1;
                                            that.$refs.contents.innerHTML='';
                                        }
                                        if (response.data.ok_id === 1){
                                            that.ok_msg=3;
                                            that.$refs.contents.innerHTML='';
                                        }
                        });
                    }
                    else{that.$refs.upload.submit();}
                }
            },

			f_blod() {
                document.execCommand ( 'bold', false );
                document.execCommand ( 'backColor', false, 'yellow' );
			},

            set_gongkaifanwei(data){
                this.qunzu_id = data.qunzu_id;
            },

		}
	}
</script>

<style scoped>

</style>