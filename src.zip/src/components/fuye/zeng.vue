这是新增各类知识点的页面。
<template>
<div id="zeng"  @click="turnfresh()">
		<zu2logo k=1></zu2logo>
		<el-container>
			<el-aside width="120px"  class="bgcolor_FF"></el-aside>
			<el-main class="bgcolor_FC font18px"  style="padding:7px;">
				这是用户添加各类元素的页面。
				<el-button disabled class="font18px" type="text">
					<i class="el-icon-info">用户目前只能新增发言。</i>
				</el-button>
			</el-main>
		</el-container>

		<el-container>
			<el-aside width="120px" class="height_x00px">
				<el-menu default-active="x3" class="el-menu-vertical-demo bgcolor_menu_FC height_x00px" @open="handleOpen" @close="handleClose">
			      <el-menu-item @click="daohangx3"  index="x3" class="font18px">
			        <span slot="title">发言</span>
			      </el-menu-item>
				  <el-menu-item @click="daohangx1" :disabled="disabled_yn" index="x1" class="font18px">
					<span slot="title">标签</span>
			      </el-menu-item>
			      <el-menu-item @click="daohangx2" :disabled="disabled_yn" index="x2" class="font18px">
			      <!-- <el-menu-item @click="daohangx2" :disabled="disabled_yn" index="x2" class="font18px"> -->
			        <span slot="title">书名文辑</span>
			      </el-menu-item>
			      <!-- <el-menu-item @click="daohangx4"  index="x4" class="font18px">
			        <span slot="title">数集</span>
			      </el-menu-item> -->
			      <!-- <el-menu-item @click="daohangx5"  index="x5" class="font18px">
			        <span slot="title">数辑</span>
			      </el-menu-item> -->
			      <!-- <el-menu-item @click="daohangx6"  index="x6" class="font18px">
			        <span slot="title">日志</span>
			      </el-menu-item> -->
			      <el-menu-item @click="daohangx8"  :disabled="disabled_yn" index="x8" class="font18px">
			        <span slot="title">群组</span>
			      </el-menu-item>				      
			    </el-menu>
			</el-aside>

			<!-- 这里要用v-if，因为当我们在bdx8中新增群组后，切换回其他组件，自动刷新了公开范围的群组列表
			这里jishu.zengbiaoqian==0?'0':jishu.zengbiaoqian的三元运算符，因为直接用数字形式的0会不显示，所以用字符形式的。
			 -->
			<el-main v-show="dhx1" class="section_xh">
				<zengbiaoqian :showloading1="showloading1" :listNum0="jishu.zengbiaoqian"></zengbiaoqian>
			</el-main>
			<el-main v-show="dhx2" class="section_xh">
				<zengwenji :showloading1="showloading1" :listNum0="jishu.zengwenji"></zengwenji>
			</el-main>
			<el-main v-show="dhx3" class="section_xh">   
				<zengfayan :showloading1="showloading1" :listNum0="jishu.zengfayan" ></zengfayan>
			</el-main>
			<el-main v-show="dhx4" class="section_xh">
               
			</el-main>  
			<el-main v-show="dhx5" class="section_xh">

			</el-main>
			<el-main v-show="dhx6" class="section_xh">              
				
			</el-main>
			<el-main v-show="dhx8" class="section_xh">
				<zengqunzu :showloading1="showloading1" :listNum0="jishu.zengqunzu"></zengqunzu>
			</el-main>


			<el-aside width="120px" class="bgcolor_FC">
                
            </el-aside>

		</el-container>



	</div>

</template>



<script>

export default {
    name:'zeng',
    components: {},
	methods: {
		daohangx1(){this.dhx1=true;this.dhx2=this.dhx3=this.dhx4=this.dhx5=this.dhx6=this.dhx8=false;},
		daohangx2(){this.dhx2=true;this.dhx1=this.dhx3=this.dhx4=this.dhx5=this.dhx6=this.dhx8=false;},
		daohangx3(){this.dhx3=true;this.dhx1=this.dhx2=this.dhx4=this.dhx5=this.dhx6=this.dhx8=false;},
		daohangx4(){this.dhx4=true;this.dhx1=this.dhx2=this.dhx3=this.dhx5=this.dhx6=this.dhx8=false;},
		daohangx5(){this.dhx5=true;this.dhx1=this.dhx2=this.dhx3=this.dhx4=this.dhx6=this.dhx8=false;},
		daohangx6(){this.dhx6=true;this.dhx1=this.dhx2=this.dhx3=this.dhx4=this.dhx5=this.dhx8=false;},
		daohangx8(){this.dhx8=true;this.dhx1=this.dhx2=this.dhx3=this.dhx4=this.dhx5=this.dhx6=false;},
	
	

	},
	data(){ return {
			dhx1:false,dhx2:false,dhx3:true,dhx4:false,dhx5:false,dhx6:false,dhx8:false,
			showloading1:false,
	}},

	computed:{
		welcomename(){return this.$cookies.get('username')},
		disabled_yn(){return this.$cookies.get('usertype')==='内容整理'?false:true}
		// disabled_yn(){return false}
	},
	
	created: function () {
		var _this= this;
		_this.showloading1=true;
		_this.axios
		.post('http://www.zhishiren.info/api/showmydata/', {yonghuid:_this.$cookies.get('userid')})
		.then(function (response) {
			_this.jishu=JSON.parse(response.data);
			_this.showloading1=false;
			});
    },



}
</script>

