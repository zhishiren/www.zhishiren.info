

<template>
    <div id="upload_yuanwen" style="display:inline-block">
        <el-upload
            name="yuanwen"
            class="upload-demo"
            ref="upload"
            :data={id:this.id}
            action='http://www.zhishiren.info/api/shangchuan_yuanwen/'
            Access-Control-Request-Headers: ContentType
            style="text-align:40px;display:inline;"
            :on-preview="handlePreview"
            :on-remove="handleRemove"
            :before-remove="beforeRemove"
            :on-exceed="handleExceed"
            :on-success="onsuccess"
            :file-list="fileList" 
            >
            <a class="a_grey" type="primary" style="font-size:16px;" slot="trigger" size="small"><i class="el-icon-upload2"></i>上传原文</a>
            <span v-if="uploadstatus===1" style="color:grey">:已传</span>
        </el-upload> 
        <a v-if="uploadstatus!==0" style="font-size:20px;float:right;" class="a_grey" 
            :href="'https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/yuanwen1/'+wj_info.wj_id+'.doc'" 
            :download="this.id+''+this.title+'.doc'">
            <i class="el-icon-download"></i>下载原文
        </a>
    </div>
</template>

<script>
  export default {
    name: 'upload_yuanwen',
    props:['id','uploadstatus','title'],
    data() {
      return {

      }
    },

    methods:{
            handleRemove(file, fileList) {
                console.log(file, fileList);
            },
            handlePreview(file) {
                console.log(file);
            },
            onsuccess(response, file, fileList) {
                this.$refs.upload.clearFiles();
                this.uploadstatus=1;
                
            },
            handleExceed(files, fileList) {
                this.$message.warning(`每次操作只能上传一个文件！`);
            },
            beforeRemove(file, fileList) {
                return this.$confirm(`确定移除 ${ file.name }？`);
            },
            handleRemove(file, fileList) {
                console.log(file, fileList);
            },
            handlePreview(file) {
                console.log(file,fileList);
            },
    }

  }
</script>

<style scoped>
		.chazhao_alink{font-size:18px;color:black;}
		.chazhaolan{
					width:150px;
					border:none;
					border-radius:0;
					border-bottom:#8D8D8D 1px solid;
					box-shadow:0;
					outline:none;
					text-decoration: none;
					font-size:18px;
        }
        a:hover{color:orange;}

</style>