<!-- 这是用户新增标签的模版-->
<template>
	<div id="xhs1">
        <zu1caozuojishu zone_id='souwenji' :jishu="count_wj" :showloading1="showloading1" :showloading2="xhs1_loading" @zhankai="zhankaijian" @shuaxin="shuaxinjian"></zu1caozuojishu>  
        <div v-if="wj1 && xhs1_loading===false">
            <el-row v-for="l in lists" :key="l.pk" class="br10px17px">
                <el-row>
                    <router-link class="a_black" target="_blank" :to="{name:'wenjiye',params:{id:l.pk}}"><span>{{l.fields.wj_title}}</span></router-link>
                </el-row>
                <el-row>
                        <b style="color:grey">属性<i class="el-icon-caret-right"></i></b>
                        <span v-if="l.fields.wj_type!=='无类型'">{{l.fields.wj_type}}<el-divider direction="vertical"></el-divider></span>
                        <span v-if="l.fields.wj_borntime">生效:{{getNowFormatDate(l.fields.wj_borntime)}}<el-divider direction="vertical"></el-divider></span>
                        <span v-if="l.fields.wj_deadtime">失效:{{getNowFormatDate(l.fields.wj_deadtime)}}<el-divider direction="vertical"></el-divider></span>
                        <span v-if="l.fields.wj_hangye">所属行业:{{l.fields.wj_hangye}}<el-divider direction="vertical"></el-divider></span>
                        <span v-if="l.fields.wj_area">所属地区:{{l.fields.wj_area}}<el-divider direction="vertical"></el-divider></span>
                        <span v-if="l.fields.wj_publisher">发文单位:{{l.fields.wj_publisher}}<el-divider direction="vertical"></el-divider></span>          
                        <span><b style="color:grey">说明<i class="el-icon-caret-right"></i></b><span v-html="l.fields.wj_remark" ></span></span>
                        <!-- <span v-if="l.fields.wj_remark!=='无内容'"><b style="color:grey">说明<i class="el-icon-caret-right"></i></b><span v-html="l.fields.wj_remark" ></span></span> -->  
                </el-row>
                <el-row><el-divider style="margin:0px;"></el-divider></el-row>
            </el-row>

            <br>
            <el-pagination v-if="wj1.length>1" style="text-align:right;"
                background
                :page-size=10
                :total="count_wj"
                :current-page.sync="currentPage"
                layout="total, prev, pager, next">
            </el-pagination>


        </div>


    </div>
</template>
<script>

export default {
    name:'xhs1',
    components: {},
    props:['count_wj','showloading1'],
	data() {return {
        wj1:[],
        xhs1_loading:false,
        currentPage: 1,//当前分页的数值
        // listNum1:0,//这里与上面的变量区别开，用来控制分页条,listNum

    }},
    
    computed: {
            lists(){
                let pages=Math.ceil(this.count_wj/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                let sonList=[];
                sonList=this.wj1.slice(i*10,i*10+10);//10为每页设置数量
                newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
            
    },


	methods:{
        zhankaijian(){this.shuaxinjian();},

        shuaxinjian(){
            this.xhs1_loading=true;
            this.$axios
                .get('http://www.zhishiren.info/api/xunhuans1/')
                .then(response=>{
                    this.wj1=JSON.parse(response.data);
                    this.count_wj=this.wj1.length;
                    this.xhs1_loading=false;
            });
        },
    },	
};
</script>