<!-- 这是用户新增标签的模版-->
<template>
	<div id="ceshi">
        {{this.ceshishuzu}}
    </div>
</template>
<script>

export default {
    name:'ceshi',
    components: {},
    props:['ceshishuzu'],
	data() {return {}},
	methods:{},	
};
</script>




