<template>
    <router-link class="a_black" target="_blank" :to="{name:'fayanye',params:{id:pkid}}">          
        <span style="color:brown;">
            <font style="font-size:20px;"><b>“</b></font><span v-html="content" ></span><font style="font-size:20px;"><b>”</b></font>
        </span>
    </router-link>
</template>

<script>
export default {
    name:'fayan',
    props:['content','pkid'],
	data() {return {}},
    methods:{},
};

</script>



