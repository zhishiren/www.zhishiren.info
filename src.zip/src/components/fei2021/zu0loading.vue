<template>
<span id="zu0loading" style="font-size:18px;">
    <span style="font-size:18px;" v-show="faloading"><i class="el-icon-loading"></i>正在发布...</span>
</span>
                
</template>

<script>
export default {
    name:'zu0loading',
    props:['faloading'],
	data() {return {}},
    methods:{},
};
</script>



