
<template>
    <div id="tj_jiucuo" class="font18px">
		<el-button @click="jiucuojian()" type="text" class="font18px"><i class="el-icon-warning-outline"></i>纠错...</el-button>
		<span style="color:green;" v-show="ok_msg==1"><i class="el-icon-success"></i>发布成功!</span>
		<span style="color:red;" v-show="ok_msg==3"><i class="el-icon-error"></i>发布失败!</span>
		<span>你的纠错会反馈给该知识点管理人。</span>
		<el-dialog title="纠错附言..." width="400px" :visible.sync="show_dialog">
			<el-row>
				<div contenteditable ref="contents" @paste="onPaste" class="pinglunlan">请输入纠错的内容，限100字。</div>
			</el-row>
				<el-row>
					<el-col :span="7">
						<a class="a_black font18px" href="javascript:;" @click="f_bgColor">
							<b>所选加粗</b>
						</a>
					</el-col>
					<el-col  class="font18px" :span="11">
                    	<span style="color:orange;" v-show="ok_msg==2"><i class="el-icon-warning-outline"></i>内容不能为空!</span>
					</el-col>
					<el-col :span="6" style="text-align:right">
						<a @click="fabujian" class="font20px a_black" >发布</a>
					</el-col>
				</el-row>
        </el-dialog>
    </div>
</template>

<script>
export default {
	data() {return {
		show_dialog:false,
		ok_msg:0,
	}},
	props:['zhid'],
	methods:{
				onPaste: function(e) {
						e.preventDefault()
						e.stopPropagation()
						let pasteValue = (e.clipboardData || window.clipboardData).getData('text/plain')
						console.log(pasteValue)
						var re = /<[^>]+>/gi;
						pasteValue = pasteValue.replace(re, '').replace(/\s+|[\r\n]/g,"");
						e.target.textContent += pasteValue
				},


				f_bgColor() {
					document.execCommand ('backColor', false, 'yellow');
				},

				jiucuojian:function(){
					this.show_dialog=false;
					this.show_dialog=true;
				},

				fabujian:function(){
						var that = this;
						if(that.$refs.contents.innerHTML==='请输入纠错的内容，限100字。'){
							that.ok_msg=2;
                            setTimeout(function(){that.ok_msg=0;}, 2000);
						}
						else{that.fuyan=that.$refs.contents.innerHTML;
						that.axios
                        	.post('http://www.zhishiren.info/api/oojiucuo/',{
								zhid:that.zhid,
								userid: that.$cookies.get('userid'),
								divcontent:that.$refs.contents.innerHTML})
                        	.then(function (response) {
                                        if (response.data.ok_id === 0){
                                            that.ok_msg=1;
											that.$refs.contents.innerHTML='请输入纠错的内容，限100字。';
											that.show_dialog=false;
											setTimeout(function(){that.ok_msg=0;}, 2000);
										}
										else{
											that.ok_msg=3;
											setTimeout(function(){that.ok_msg=0;}, 2000);
											that.show_dialog=false;
										}
                        });
						};

				},
	},

};

</script>

