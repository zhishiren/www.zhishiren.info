<template>
    <div id="z68">
        <el-row style="color:red;" class="font20px">仅供展示相关理念,没有实物</el-row>
		<el-row>
			<el-col :span="10">
					<el-image
						src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/z68a.jpg"
						:fit="fill">
					</el-image>
			</el-col>
			<el-col :span="14">
				<div class="huanhang">
					<b class="font20px">模块化手机</b>	
                    <br>
				</div>
			</el-col>
		</el-row>
		<br>
		<el-row>
			<el-col :span="14">
				<div class="huanhang">
					<b class="font20px">自建房屋</b>		
					<br>
				</div>
			</el-col>
			<el-col :span="10">
					<el-image
						src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/z68b.gif"
						:fit="fill">
					</el-image>
			</el-col>
		</el-row>
		<br>
		<el-row>
			<el-col :span="10">
					<el-image
						src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/z68c.jpg"
						:fit="fill">
					</el-image>
			</el-col>
			<el-col :span="14">
				<div class="huanhang">
					<b class="font20px">3D打印机</b>	
				</div>
			</el-col>
		</el-row>
		<br>
		<el-row>
			<el-col :span="14">
				<div class="huanhang">
					<b class="font20px">自由能源</b>		
					<br>
				</div>
			</el-col>
			<el-col :span="10">
					<el-image
						src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/z68d.jpg"
						:fit="fill">
					</el-image>
			</el-col>
		</el-row>
    </div>
</template>

<script>
    export default {
        name:'z68',
        props:[],
        data() {return {

        }},
        computed:{

        },
        methods:{
            
        },
    };
</script>



