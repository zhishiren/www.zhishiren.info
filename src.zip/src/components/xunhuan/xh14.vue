<!-- 这是通用的模版-->
<template>
	<div id="xh14">
        <zu1caozuojishu zone_id=14 :jishu="listNum" :showloading1="showloading1" :showloading2="showloading2"  @zhankai="zk" @shuaxin="shuaxin"></zu1caozuojishu>  
        <div v-if="showloading2===false">
            <el-row class="br10px17px" v-for="list in lists" :key="list.pk">
                <el-row>
                    <span>你发布的言论:</span>
                    <span style="color:grey">“{{list.fyshen}}...”</span>
                    <span>被管理员<span style="color:red;">拒绝</span>,请改用密文发布。</span>
                    <span style="color:grey;float:right;">{{qian_date(list.time1)}}</span>
                </el-row>
                <el-row><el-divider style="margin:0px;"></el-divider></el-row>
            </el-row>
            <br>
            <el-pagination v-if="listNum>10" style="text-align:right;"
                            background
                            :page-size=10
                            :total="listNum"
                            :current-page.sync="currentPage"
                            layout="total, prev, pager, next">
            </el-pagination>
        </div>
    </div>
</template>

<script>
export default {
    name:'xh14',
    components: {},
	data() {return {
        currentPage: 1,//当前分页的数值
        listNum:0,//
        listNum1:0,//这里与上面的变量区别开，用来控制分页条
        xh14s:[],

        showloading2:false,
        showloading1:false,
    }},

	computed: {
            lists(){
                let pages=Math.ceil(this.listNum/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                    let sonList=[];
                    sonList=this.xh14s.slice(i*10,i*10+10);//10为每页设置数量
                    newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
            yonghuid(){return parseInt(this.$cookies.get('userid'))},
    },
    
	methods:{
        zk(){this.shuaxin();},
        shanok(){this.shuaxin();},
        shuaxin(){
            this.showloading2=true;
            var that=this;
            that.$axios
                .post('http://www.zhishiren.info/api/xunhuan14/', {
                    userid:that.$cookies.get('userid')})
                .then(response=>{
                    that.xh14s=response.data;
                    that.listNum=that.xh14s.length;
                    that.listNum1=that.xh14s.length;
                    that.currentPage=1;
                    that.showloading2=false;
                });
        },
    },

    created: function () {
        this.showloading1=true;
        this.$axios
            .post('http://www.zhishiren.info/api/count14/', {userid:this.$cookies.get('userid')})
            .then(response=>{
                this.listNum=response.data;
                this.showloading1=false;
                });
	}
};
</script>




