<template>
    <div id="zu2logo" class="logo">
        <div style="display:inline-block;width:120px;">知识人</div>
        <div class="font18px" style="display:inline-block;width:1040px;">
            <span>hello,{{welcomename}}</span>
            <span v-if="k==='0'">,{{getNowFormatDate(nowTime)}}</span>
            <!-- <span>{{this.$cookies.get('usertype')}}</span> -->
        </div >
        <div class="font19px_tuichu" style="text-align:center;">
            <a v-if="k==='0'" class="a_white" @click="tuichu()">退出</a>
            <a v-if="k==='1'" class="a_white" @click="guanbi()">关闭</a>
        </div>
    </div>
</template>

<script>
    export default {
        name:'zu2logo',
        props:['k'],//k是区分
        data() {return {
            nowTime: new Date(), // 当前时间
        }},
        computed:{
			welcomename(){return this.$cookies.get('username')},
        },
        methods:{
            guanbi(){
                this.$confirm('', '确认关闭本页面？',{
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    }).then(() => {
                        window.location.href="about:blank";
                        window.opener=null;
                        window.open('','_self');
                        window.close();	
                    }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消'
                    });          
                });
			},
            tuichu(){
                this.$confirm('', '确认退出登陆？',{
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    }).then(() => {
                        var _this= this;
                        _this.$cookies.remove('username');
                        _this.$cookies.remove('userid');
                        _this.$cookies.remove('status');
                        _this.$router.push({path: '/'});
                    }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消'
                    });          
                });
            },
        },
    };
</script>



