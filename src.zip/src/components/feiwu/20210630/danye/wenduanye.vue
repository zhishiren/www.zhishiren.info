<template>
<div id="wenduanye"  @click="turnfresh()">
	<toubu0></toubu0>

		<el-container>
			<el-aside width="120px" class="bgcolor_FF"></el-aside>
			<el-main class="bgcolor_FC font18px">
				<el-card  v-if="wd_info.wd_id"  class="box-card">
					<el-row >
						<el-col :span="20" >
							<router-link target="_blank" class="a_grey font21px" :to="{name:'wenjiye',params:{id:this.wd_info.wj_id}}" >{{this.wd_info.wj_title}}</router-link><!--
							--><span class="font21px">{{this.wd_info.wd_title}}</span>
						</el-col>
						<el-col style="text-align:right;" :span="4" >
							<a @click="shangduan()" class="a_black" ><i class="el-icon-arrow-left"></i>上段</a>   
								<el-divider direction="vertical"></el-divider>
							<a @click="xiaduan()" class="a_black" >下段<i class="el-icon-arrow-right"></i></a>
						</el-col>
					</el-row>

					<el-row>
						<span><b>属性<i class="el-icon-caret-right"></i></b></span>
						<span>段落ID:{{this.wd_info.wd_id}}<el-divider direction="vertical"></el-divider></span>
						<span v-if="wd_info.wj_type =='独立文段'">{{daibiaoma(this.wd_info.wd_status)}}</span>
						<span v-if="wd_info.wj_type!=='独立文段'">{{daibiaoma(this.wd_info.wj_status)}}</span>
						<el-divider direction="vertical"></el-divider>
						<span>{{this.wd_info.wj_type}}<el-divider direction="vertical"></el-divider></span>
						<span v-if="wd_info.wj_type =='独立文段'">{{daibiaoma(this.wd_info.wd_fanwei)}}<el-divider direction="vertical"></el-divider></span>
						<span v-if="wd_info.wj_type!=='独立文段'">{{daibiaoma(this.wd_info.wj_fanwei)}}<el-divider direction="vertical"></el-divider></span>
						<span>生效:<span style="color:grey" v-show="wd_info.wj_borntime===null">缺少信息</span><span v-show="wd_info.wj_borntime!==null">{{getNowFormatDate(this.wd_info.wj_borntime)}}</span><el-divider direction="vertical"></el-divider></span>
						<span>失效:<span style="color:grey" v-show="wd_info.wj_deadtime===null">缺少信息</span><span v-show="wd_info.wj_deadtime!==null">{{getNowFormatDate(this.wd_info.wj_deadtime)}}</span><el-divider direction="vertical"></el-divider></span>
						<span>行业:<span style="color:grey" v-show="wd_info.wj_hangye===''">缺少信息</span><span v-show="wd_info.wj_hangye!==''">{{this.wd_info.wj_hangye}}</span><el-divider direction="vertical"></el-divider></span>
						<span>地区:<span style="color:grey" v-show="wd_info.wj_area===''">缺少信息</span><span v-show="wd_info.wj_area!==''">{{this.wd_info.wj_area}}</span><el-divider direction="vertical"></el-divider></span>
						<span>发文:<span style="color:grey" v-show="wd_info.wj_publisher===''">缺少信息</span><span v-show="wd_info.wj_publisher!==''">{{this.wd_info.wj_publisher}}</span><el-divider direction="vertical"></el-divider></span>
						<span>管理人:
							<span v-if="wd_info.wj_type  =='独立文段'">
								<router-link class="a_black" target="_blank" :to="{name:'yonghuye',params:{id:wd_info.wd_manager}}">
									{{this.wd_info.wd_manager}}
								</router-link>
							</span>
							</span>
							<span v-if="wd_info.wj_type !=='独立文段'">
								<router-link class="a_black" target="_blank" :to="{name:'yonghuye',params:{id:wd_info.wd_manager}}">
									{{this.wd_info.wj_manager}}
								</router-link>
							</span>
						</span>
						<zu0tongjishu :dj="wd_tongji.dianji" :gz="wd_tongji.guanzhu" :fx="wd_tongji.fenxiang"></zu0tongjishu>
					</el-row>
					<el-row>
						<b>正文<i class="el-icon-caret-right"></i></b>
						<span v-html="wd_info.wd_content"></span>
					</el-row>
					<zu0fujianfutu v-if="this.wd_info.fu!==0" :zhid="wd_info.wd_id"></zu0fujianfutu>
				</el-card>
				<el-card v-else>
					<br>
						<div style="text-align:center;font-size:30px;"><i class="el-icon-loading"></i>正在加载</div>
					<br>
				</el-card>
			</el-main>
		</el-container>

		<el-container>
			<el-aside width="120px">
				<el-menu default-active="12" class="el-menu-vertical-demo bgcolor_menu_FC" @open="handleOpen" @close="handleClose">
			      <el-menu-item @click="daohang11" index="11" class="font18px">
			        <span slot="title">段落列表</span>
			      </el-menu-item>
				  <el-menu-item @click="daohang12" index="12" class="font18px">
			        <span slot="title">关注分享</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang13" index="13" class="font18px">
			        <span slot="title">评论</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang14" index="14" class="font18px">
			        <span slot="title">关联知识</span>
			      </el-menu-item>
			      <!-- <el-menu-item @click="daohang15" index="15" class="font18px">
			        <span slot="title">推荐阅读</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang16" index="16" class="font18px">
			        <span slot="title">内容管理</span>
			      </el-menu-item> -->
			    </el-menu>
			</el-aside>
			<el-main v-show="dh12" class="section_xh">
				<tj0fenxiang v-if="wd_info.wj_type !=='独立文段'" @fxadd1="add1(1)" :zhid="wd_info.wd_id" zhitype="wenduanye" :zhititle="wd_info.wj_title+wd_info.wd_title" :createrid="wd_info.wj_manager" :zhitype1="wd_info.wj_type" :fanwei="wd_info.wj_fanwei"></tj0fenxiang>
				<tj0fenxiang v-if="wd_info.wj_type ==='独立文段'" @fxadd1="add1(1)" :zhid="wd_info.wd_id" zhitype="wenduanye" :zhititle="wd_info.wj_title+wd_info.wd_title" :createrid="wd_info.wd_manager" :zhitype1="wd_info.wj_type" :fanwei="wd_info.wd_fanwei"></tj0fenxiang>
				<tj0guanzhu @gzadd1="add1(2)" @gzminus1="minus1(2)" :zhid="wd_info.wd_id" :zhititle="wd_info.wj_title+wd_info.wd_title" zhitype="wenduanye" bq_fanwei=0></tj0guanzhu>
				<!-- <tj0jiucuo :zhid="wd_info.wd_id" ></tj0jiucuo> -->
				<tj0jiabiaoqian zhitype="wenduanye" :zhid="wd_info.wd_id" :zhititle="wd_info.wj_title+wd_info.wd_title"></tj0jiabiaoqian>

			</el-main>
			<el-main v-show="dh13" class="section_xh">
            	<tj0pinglun v-if="wd_info.wj_type !=='独立文段'" :zhid="wd_info.wd_id" zhitype="wenduanye" :zhititle="wd_info.wj_title+wd_info.wd_title" :fanwei="wd_info.wj_fanwei"></tj0pinglun>            	
				<tj0pinglun v-if="wd_info.wj_type ==='独立文段'" :zhid="wd_info.wd_id" zhitype="wenduanye" :zhititle="wd_info.wj_title+wd_info.wd_title" :fanwei="wd_info.wd_fanwei"></tj0pinglun>
			</el-main>
			<el-main v-show="dh14" class="section_xh">
             	<tj0guanlian v-if="wd_info.wj_type !=='独立文段'" :zhid="wd_info.wd_id" zhitype="wenduanye" :zhititle="wd_info.wj_title+wd_info.wd_title" :fanwei="wd_info.wj_fanwei"></tj0guanlian>
             	<tj0guanlian v-if="wd_info.wj_type ==='独立文段'" :zhid="wd_info.wd_id" zhitype="wenduanye" :zhititle="wd_info.wj_title+wd_info.wd_title" :fanwei="wd_info.wd_fanwei"></tj0guanlian>
			</el-main>
			<!-- <el-main v-show="dh15" class="section_xh">
             	<tj0tuijian></tj0tuijian>
			</el-main> -->
			<el-main v-show="dh11" class="section_xh">
            	<tj1duanluo :yhid="wd_info.wj_manager" :type="wd_info.wd_type" :zhid="wd_info.wj_id" :zhititle="wd_info.wj_title"></tj1duanluo>
			</el-main>
			<!-- <el-main v-show="dh16" class="section_xh">
            	<bdg4></bdg4>
			</el-main> -->
			<el-aside width="120px" class="bgcolor_FC"></el-aside>
		</el-container>



	</div>

</template>

<script>

import tj0fenxiang from '../tijiao/tj_fenxiang';
import tj0guanzhu from '../tijiao/tj_guanzhu';
import tj0jiabiaoqian from '../tijiao/tj_jiabiaoqian';
import tj0jiucuo from '../tijiao/tj_jiucuo';
import tj0pinglun from '../tijiao/tj_pinglun';
import tj0guanlian from '../tijiao/tj_guanlian';
import tj0shangxiaduan from '../tijiao/tj_shangxiaduan';
import tj0tuijian from '../tijiao/tj_tuijian';
import tj1duanluo from '../tijiao/tj1duanluo';

import bdg4 from '../biaodan/bdg4';
import toubu0 from '../fujian/toubu0';
import zu0tongjishu from '../fujian/zu0tongjishu';
import zu0fujianfutu from '../fujian/zu0fujianfutu';

export default {
        name:'wenduanye',
		components: {zu0fujianfutu,tj1duanluo,zu0tongjishu,tj0tuijian,toubu0,tj0guanzhu,tj0fenxiang,tj0pinglun,tj0guanlian,tj0jiucuo,tj0shangxiaduan,bdg4,tj0jiabiaoqian},
        methods:{

                    daohang11(){this.dh11=true;this.dh12=false;this.dh13=false;this.dh14=false;this.dh15=false;this.dh16=false;},
                    daohang12(){this.dh12=true;this.dh11=false;this.dh13=false;this.dh14=false;this.dh15=false;this.dh16=false;},
                    daohang13(){this.dh13=true;this.dh11=false;this.dh12=false;this.dh14=false;this.dh15=false;this.dh16=false;},
                    daohang14(){this.dh14=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh15=false;this.dh16=false;},
                    daohang15(){this.dh15=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh14=false;this.dh16=false;},
					daohang16(){this.dh16=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh14=false;this.dh15=false;},
					shangduan(){
						var _this= this;
						_this.axios
						.post('http://www.zhishiren.info/api/show_shangduan/', {xuhao:_this.wd_info.wd_xuhao,wj_id:_this.wd_info.wj_id})
						.then(function (response) {
							if(response.data==="null"){alert("这已经是第一段！");}
							else{
								// location.href = '/wenduanye/'+response.data+'';
								// _this.$router.push({path: '/wenduanye/'+response.data});
								_this.$router.push({name: 'wenduanye',params: {id: response.data}});
								_this.$router.go(0);

								}
						});
					},
					xiaduan(){
						var _this= this;
						_this.axios
						.post('http://www.zhishiren.info/api/show_xiaduan/', {xuhao:_this.wd_info.wd_xuhao,wj_id:_this.wd_info.wj_id})
						.then(function (response) {
							if(response.data==="null"){alert("这已经是最后一段！");}
							else{
								// location.href = '/wenduanye/'+response.data+'';
								// _this.$router.push({path: '/wenduanye/'+response.data});
								_this.$router.push({name: 'wenduanye',params: {id: response.data}});
								_this.$router.go(0);

								}
						});

					},
					//这里的k值指的是关注数或分享数等等
					add1(k){
						if(k==1){this.wd_tongji.fenxiang++;}
						if(k==2){this.wd_tongji.guanzhu++;}
					},
					minus1(k){
						if(k==2){this.wd_tongji.guanzhu--;}
					},
			

        },
        data() {
			return {dh12:true,dh11:false,dh13:false,dh14:false,dh15:false,dh16:false,
			wenduan_id:0,wd_info:[],wd_tongji:[]}
        },
        created() {
				this.wenduan_id = this.$route.params.id;//获取上个页面传递的id,在下面获取数据的时候先提交id,这里的id不用加前缀
				var _this= this;
				_this.axios
				.post('http://www.zhishiren.info/api/show_wenduanye/', {wenduan_id:_this.wenduan_id})
				.then(function (response) {
					_this.wd_info=response.data;
					_this.wd_tongji=JSON.parse(response.data.wd_tongji);
				});
		},
		computed: {
				welcomename(){return this.$cookies.get('username')},
		},
};


</script>






