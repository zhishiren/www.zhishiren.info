<!-- 这是31模块独有的设计，这个模块里能查询所有用户的信息，但因为全部用户数据量较大和保护用户隐私的考虑，所以并不罗列出所有用户的信息，
只罗列出最新注册的用户（最新注册且已经上传了头像的用户）。
当用户搜索相关关键词的时候，后台查询后返回。
-->
<template>
	<div id="xh34">
            <!-- 下面的div是用来显示原始未筛选的列表，通过vshow来控制是否显示 -->
            <el-row class="font18px">
                <span>全站共有{{this.zongshu}}个群组，优先展示最新10个。</span>
				<a v-show="show_zhankai" @click="zhankaijian" class="a_black">-展开-</a> 
                <span v-show="show_chazhaolan">
                        <input type="text" class="input_jian font18px" size="mini" v-model="keyword" placeholder="在全部群组中查找">
                        <a @click="chazhaojian(keyword)" class="a_black"><i class="el-icon-search"></i>查找</a>   
                        &nbsp;
                        <span style="color:orange" v-show="show_chazhaokong"><i class="el-icon-warning"></i>关键词不能为空！</span>
                        <a v-show="show_shuaxin" @click="shuaxinjian" class="a_black"><i class="el-icon-refresh"></i>刷新</a>

                        &nbsp;
                        <span  v-show="show_xhk34" style="color:blue"><i class="el-icon-finished"></i>{{this.listNumk}}个结果</span>
                        &nbsp;
                        <a v-show="show_huanyuan" @click="huanyuanjian" class="a_black"><i class="el-icon-refresh-left"></i>还原</a>
                </span>
            </el-row>
               
        <div v-show="show_xh34 && show_loading===false" >
            <el-row class="br10px17px" v-for="list in lists" :key="list.pk">
                    <el-row>
                        <router-link class="a_black" target="_blank" :to="{name:'qunzuye',params:{id:list.pk}}">
                            {{list.fields.qz_title}}
                        </router-link>
                        <span style="color:red;" v-if="list.fields.qz_status==='s4'">失效已删</span>
                    </el-row>
                    <el-row>
                        <span style="color:grey">创建时间:</span>{{formatDate_ymd(list.fields.qz_createtime)}}<el-divider direction="vertical"></el-divider>
                        <span style="color:grey">群组说明:</span>{{list.fields.qz_remark}}
                    </el-row>
                <el-col :span="24"><el-divider style="margin:0px;"></el-divider></el-col>
            </el-row>
        </div>
            <div v-if="this.show_loading===true">
                <div style="font-size:30px;color:grey;"><i class="el-icon-loading"></i>正在加载...</div>
            </div>

        <div v-show="show_xhk34 && show_loading_k===false">
            <el-row class="br10px17px" v-for="list in listks" :key="list.pk">
                    <el-row>
                        <router-link class="a_black" target="_blank" :to="{name:'qunzuye',params:{id:list.pk}}">
                            <span v-html="gaoliangk(list.fields.qz_title, keyword)" ></span>
                        </router-link>
                        <span style="color:red;" v-if="list.fields.qz_status==='s4'">失效已删</span>
                    </el-row>
                    <el-row>
                        <span style="color:grey">创建时间:</span>{{formatDate_ymd(list.fields.qz_createtime)}}<el-divider direction="vertical"></el-divider>
                        <span style="color:grey">群组说明:</span>{{list.fields.qz_remark}}
                    </el-row>
                <el-col :span="24"><el-divider style="margin:0px;"></el-divider></el-col>
            </el-row>     
                
            <!-- 下面的div是用来显示筛选后的分页条 -->
            <el-pagination  v-if="listNumk>10" style="text-align:right;"
                            background
                            :page-size=10
                            :total="listNumk"
                            :current-page.sync="currentPagek"
                            layout="total, prev, pager, next">
            </el-pagination>
        </div>
            <div v-if="this.show_loading_k===true">
                <div style="font-size:30px;color:grey;"><i class="el-icon-loading"></i>正在加载...</div>
            </div>



    </div>


</template>

<script>
import tj0shanchu from '../tijiao/tj_shanchu';
import tj0huifu from '../tijiao/tj_huifu';

export default {
    name:'xh34',
    components: {tj0shanchu,tj0huifu},
    
	data() {return {
        currentPage: 1,//当前分页的数值
        listNum:0,//分页总条数
        currentPagek: 1,//查找后，当前分页的数值
        listNumk:0,//查找后，分页总条数
        show_xh34:false,
        show_xhk34:false,
        xh34s:[],
        xh34ks:[],
        keyword:'',
        show_chazhaokong:false,
        show_shuaxin:true,
        show_huanyuan:false,
        show_chazhaolan:false,
        show_zhankai:true,
        zongshu:0,
        show_loading:false,
        show_loading_k:false,

    }},

    mounted() {
  
    },

    filters: {
    },
    
	computed: {

            lists(){
                let pages=Math.ceil(this.listNum/10);//
                let newList=[];
                for(let i=0;i<pages;i++){
                let sonList=[];
                sonList=this.xh34s.slice(i*10,i*10+10);//
                newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },

            listks(){
                let pages=Math.ceil(this.listNumk/10);//
                let newList=[];
                for(let i=0;i<pages;i++){
                let sonList=[];
                sonList=this.xh34ks.slice(i*10,i*10+10);//
                newList.push(sonList)
                }
                return newList[this.currentPagek-1]
            },
    },
    
	methods:{


        zhankaijian:function(){
                this.show_loading=true;
                this.show_zhankai=false;
                this.show_chazhaolan=true;
                this.$axios.get('http://www.zhishiren.info/api/xunhuan34/').then(response=>{
                    this.xh34s=JSON.parse(response.data);
                    this.listNum=this.xh34s.length;
                    this.show_loading=false;
                });
                this.show_xh34=true;
        },

        huanyuanjian(){
                this.show_xh34=true;
                this.show_xhk34=false;
                this.show_chazhaokong=false;
                this.keyword='';
                this.show_shuaxin=true;
                this.show_huanyuan=false;

        },

        shuaxinjian(){
            this.show_loading=true;
                this.$axios.get('http://www.zhishiren.info/api/xunhuan34/').then(response=>{
                    this.xh34s=JSON.parse(response.data);
                    this.listNum=this.xh34s.length;
                    this.show_loading=false;
                    
                    });
        },

        chazhaojian:function(keyword){
            if(keyword==''){
                // 这是说明刚展开的阶段，这是输入空值后的表现
                this.show_chazhaokong=true;
                this.show_huanyuan=false;
                this.show_shuaxin=true;
            }else{
                this.show_loading=true;
                this.show_huanyuan=true;
                this.show_shuaxin=false;
                this.show_chazhaokong=false;
                this.show_xhk34=true;
                this.show_xh34=false;
            //   这个动作是用于展开之后，显示多少条记录
                this.$axios.post('http://www.zhishiren.info/api/xunhuan34_sou/', {k: this.keyword}).then(response=>{
                    this.xh34ks=JSON.parse(response.data);
                    this.listNumk=this.xh34ks.length;
                    this.currentPagek=1;
                    this.show_loading=false;
                    
                    });
            }
        },
    },	
    created: function () {
            this.$axios
                .post('http://www.zhishiren.info/api/count34/', {userid:this.$cookies.get('userid')})
                .then(response=>{this.zongshu=response.data;});
	}
};
</script>
