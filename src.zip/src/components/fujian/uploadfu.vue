<template>
    <div id="uploadfu" style="display:inline-block">
            <el-upload
                    name="zhifujian"
                    class="upload-demo"
                    ref="upload"
                    :data={id:this.id,leixing:this.leixing}
                    action='http://www.zhishiren.info/api/uploadfu/'
                    Access-Control-Request-Headers: ContentType
                    style="text-align:40px;display:inline;"
                    :on-preview="handlePreview"
                    :on-remove="handleRemove"
                    :before-remove="beforeRemove"
                    :on-exceed="handleExceed"
                    :on-success="onsuccess"
                    :file-list="fileList" 
                    >
                    <a class="a_grey" type="primary" style="font-size:17px;" slot="trigger" size="small"><i class="el-icon-paperclip"></i>上传附件</a>
                    <span v-if="fujianshu!==0" style="color:grey">:附件{{this.fujianshu}}</span>
                </el-upload> 
    </div>

</template>

<script>
  export default {
    name: 'uploadfu',
    props:['id','leixing','fujianshu'],
    data() {
      return {

      }
    },

    methods:{
            onsuccess(response, file, fileList) {
                this.$refs.upload.clearFiles();
                this.fujianshu=this.fujianshu+1;
            },
            handleRemove(file, fileList) {
                console.log(file, fileList);
            },
            handlePreview(file) {
                console.log(file);
            },

            handleExceed(files, fileList) {
                this.$message.warning(`每次操作只能上传一个文件！`);
            },
            beforeRemove(file, fileList) {
                return this.$confirm(`确定移除 ${ file.name }？`);
            },
            handleRemove(file, fileList) {
                console.log(file, fileList);
            },
            handlePreview(file) {
                console.log(file,fileList);
            },
    }

  }
</script>