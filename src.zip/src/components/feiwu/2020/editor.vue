<template>
	<div>
	             	<el-row >
					    <el-col :span="2" >
							<span class="font_yahei_17px">评论内容：</span><br>
							<a class="font_yahei_17px" href="javascript:;" @click="f_blod">
							<b>加粗</b>
							</a>
							&nbsp;
							<a class="font_yahei_17px" href="javascript:;" @click="f_bgColor">
							<span style="background:yellow;">涂黄</span>
							</a>
						</el-col>
						<el-col :span="22" >
						<div contenteditable ref="content" style="height:45px;width:70%;border:1px solid red;"></div>
						</el-col>
					</el-row>
	             	<el-row >
					    <el-col :span="2" >
							<a href="javascript:;" @click="f_publish">发布</a>	
						</el-col>
						<el-col :span="22" >
						</el-col>
					</el-row>
	</div>
    
</template>


<script type="text/javascript">
	export default {
		name: 'Editor',
		props: [ 'initContent' ],
		mounted () {
			this.$refs.content.innerHTML = this.initContent;
		},
		data () {
			return {
				content: ''
			}
		},
		methods: {
			f_publish() {
				this.$emit ( 'publish', this.$refs.content.innerHTML );
			},
			f_blod() {
				document.execCommand ( 'bold', false );
			},
			f_bgColor() {
				document.execCommand ( 'backColor', false, 'yellow' );
			}
		}
	}
</script>