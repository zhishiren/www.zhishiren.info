<template>
<div id="sou"  @click="turnfresh()">
		<zu2logo k=1></zu2logo>
		<el-container>
			<el-aside width="120px" class="bgcolor_FF"></el-aside>
			<el-main class="bgcolor_FC"  style="padding:15px;font-size:22px;">
				<input type="text" class="sousuolan" size="mini" v-model="sou_keyword" placeholder="">
				<a @click="sousuojian(sou_keyword)" class="sousuo_alink a_noline" ><i class="el-icon-search"></i>搜</a>  &nbsp;
				<span style="color:orange;" v-show="show_sousuokong"><i class="el-icon-warning"></i>关键词不能为空！</span>&nbsp;	
                <span style="color:blue;" v-show="show_sousuohou && show_loading===false"><i class="el-icon-finished"></i>共{{this.bq1_+this.wj1_+this.fy1_+this.wd1_+this.fuyan1_}}个结果</span>
                <span style="color:blue;" v-show="show_sousuohou && show_loading===true"><i class="el-icon-finished"></i>共<i class="el-icon-loading"></i>个结果</span>&nbsp;
				<a v-show="show_sousuohou" @click="qingling" class="a_black"><i class="el-icon-refresh-left"></i>清除</a>&nbsp;
				<br>
				<span style="font-size:18px;" ><i class="el-icon-time"></i>历史搜词</span><i class="el-icon-caret-right"></i>
				<span v-if="show_searchword===true">
					<span style="font-size:18px;" v-for="sou in rev_searchedword.slice(0,9)" :key="sou">{{sou}}<el-divider direction="vertical"></el-divider></span>	
					<!-- <span style="font-size:18px;" v-for="(sou,index) in rev_searchedword.slice(0,9)" :key="sou">{{sou}}<el-divider direction="vertical"></el-divider></span>	 -->
				</span>
				<span v-if="show_searchword===false"><i class="el-icon-loading"></i></span>
			</el-main>
		</el-container>
		<el-container>
			<el-aside width="120px">
				<el-menu default-active="11" class="el-menu-vertical-demo bgcolor_menu_FC height_x00px" @open="handleOpen" @close="handleClose">
			      <el-menu-item @click="daohang11" index="11" class="font18px">
			        <span slot="title">书名标题</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang12" index="12" class="font18px">
			        <span slot="title">段落内容</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang13" index="13" class="font18px">
			        <span slot="title">标签</span>
			      </el-menu-item>
				  <el-menu-item @click="daohang15" index="15" class="font18px">
			        <span slot="title">用户发言</span>
			      </el-menu-item>		
				<el-menu-item @click="daohang16" index="16" class="font18px">
			        <span slot="title">相关附言</span>
			      </el-menu-item>			      
			    </el-menu>
			</el-aside>
			<!-- 这里ref后用单引号才能有效 -->
			<el-main v-show="dh11" class="section_xh">
				<xhs1 v-if="show_sousuohou===false" :count_wj="count0.wenji" :showloading1="showloading1"></xhs1>
				<div v-if="show_loading===true" class="loadingstyle"><i class="el-icon-loading"></i>正在加载...</div>
				<xhs1k v-if="show_loading===false&&show_sousuohou" ref='xhs1k' :list="wj1" :jishu="wj1_" :k="sou_keyword"></xhs1k>
			</el-main>
			<el-main v-show="dh12" class="section_xh">
				<xhs2 v-if="show_sousuohou===false"  :count_wd="count0.wenduan" :showloading1="showloading1"></xhs2>
				<div v-if="show_loading===true" class="loadingstyle"><i class="el-icon-loading"></i>正在加载...</div>
				<xhs2k v-if="show_loading===false&&show_sousuohou" ref='xhs2k' :list="wd1" :jishu="wd1_" :k="sou_keyword"></xhs2k>
			</el-main>
			<el-main v-show="dh13" class="section_xh">
             	<xhs3 v-if="show_sousuohou===false"  :count_bq="count0.biaoqian" :showloading1="showloading1"></xhs3>
				<div v-if="show_loading===true" class="loadingstyle"><i class="el-icon-loading"></i>正在加载...</div>
				<xhs3k v-if="show_loading===false&&show_sousuohou" ref='xhs3k' :list="bq1" :jishu="bq1_" :k="sou_keyword"></xhs3k>
			</el-main>
			<el-main v-show="dh15" class="section_xh">
             	<xhs5 v-if="show_sousuohou===false"  :count_fayan="count0.fayan" :showloading1="showloading1"></xhs5>
				<div v-if="show_loading===true" class="loadingstyle"><i class="el-icon-loading"></i>正在加载...</div>
				<xhs5k v-if="show_loading===false&&show_sousuohou" ref='xhs5k' :list="fy1" :jishu="fy1_" :k="sou_keyword" @sousuoshuaxin="sousuojian(sou_keyword)"></xhs5k>
			</el-main>
			<el-main v-show="dh16" class="section_xh">
                <xhs6 v-if="show_sousuohou===false" :count_fuyan="count0.fuyan" :showloading1="showloading1"></xhs6>
				<div v-if="show_loading===true" class="loadingstyle"><i class="el-icon-loading"></i>正在加载...</div>
				<xhs6k v-if="show_loading===false&&show_sousuohou" ref='xhs6k' :list="fuyan1" :jishu="fuyan1_" :k="sou_keyword"  @sousuoshuaxin="sousuojian(sou_keyword)"></xhs6k>
			</el-main>
			<el-aside width="120px" class="bgcolor_FC"></el-aside>
		</el-container>



	</div>

</template>

<script>
import xhs1 from '../xunhuan/xhs1';
import xhs1k from '../xunhuan/xhs1k';
import xhs2 from '../xunhuan/xhs2';
import xhs2k from '../xunhuan/xhs2k';
import xhs3 from '../xunhuan/xhs3';
import xhs3k from '../xunhuan/xhs3k';
import xhs5 from '../xunhuan/xhs5';
import xhs5k from '../xunhuan/xhs5k';
import xhs6 from '../xunhuan/xhs6';
import xhs6k from '../xunhuan/xhs6k';

export default {
		name:'sou',
		components: {xhs1,xhs1k,xhs2,xhs2k,xhs3,xhs3k,xhs5,xhs5k,xhs6,xhs6k},
        methods:{
                    daohang11(){this.dh11=true;this.dh12=false;this.dh13=false;this.dh14=false;this.dh15=false;this.dh16=false;},
                    daohang12(){this.dh12=true;this.dh11=false;this.dh13=false;this.dh14=false;this.dh15=false;this.dh16=false;},
                    daohang13(){this.dh13=true;this.dh11=false;this.dh12=false;this.dh14=false;this.dh15=false;this.dh16=false;},
                    daohang14(){this.dh14=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh15=false;this.dh16=false;},
                    daohang15(){this.dh15=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh14=false;this.dh16=false;},
                    daohang16(){this.dh16=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh14=false;this.dh15=false;},
                    sousuojian(sou_keyword){
                        if(sou_keyword==''){
                            this.show_sousuokong=true;
                            this.show_sousuohou=false;
                            }
                        else{
							// 这里在点击搜索后，上一次搜索结果要清零
							this.wj1=[];this._wj1=0;
							this.wd1=[];this._wd1=0;
							this.bq1=[];this._bq1=0;
							this.fy1=[];this._fy1=0;
							this.fuyan1=[];this._fuyan1=0;
							this.show_sousuohou=false;
							this.show_sousuohou=true;
							this.show_sousuokong=false;
							this.show_loading=true;

							var _this= this;
							_this.axios
							.post('http://www.zhishiren.info/api/sou/', {k:sou_keyword,userid:_this.$cookies.get('userid')})
							.then(function (response) {
								_this.bq1=JSON.parse(response.data.biaoqian1);_this.bq1_=_this.bq1.length;
								_this.wj1=JSON.parse(response.data.wenji1);_this.wj1_=_this.wj1.length;
								_this.wd1=JSON.parse(response.data.wenduan1);_this.wd1_=_this.wd1.length;
								_this.fy1=JSON.parse(response.data.fayan1);_this.fy1_=_this.fy1.length;
								_this.fuyan1=JSON.parse(response.data.fuyan1);_this.fuyan1_=_this.fuyan1.length;
								_this.show_sousuohou=false;
								_this.show_sousuohou=true;
								_this.show_loading=false;

								// _this.$refs.xhs1k.kk1();
								// _this.$refs.xhs2k.kk2();
								// _this.$refs.xhs3k.kk3();
								// _this.$refs.xhs5k.kk5();
								// _this.$refs.xhs6k.kk6();

								_this.$nextTick(() => {
									_this.axios
									.post('http://www.zhishiren.info/api/show_searchedword/', {userid:_this.$cookies.get('userid')})
									.then(function (response) {_this.searchedword=response.data});
								});
							});

						}
					},

					todivcontent(data){this.divcontent = data.content;},
					qingling(){
							this.show_sousuohou=false;
							this.sou_keyword='';

					},
					


		},
		created () {
				var _this= this;
				_this.showloading1=true;
				_this.show_searchword=false;
				_this.axios
					.post('http://www.zhishiren.info/api/show_searchedword/', {userid:_this.$cookies.get('userid')})
					.then(function (response) {
					_this.searchedword=response.data;
					_this.show_searchword=true;
				});
				_this.axios
					.post('http://www.zhishiren.info/api/showalldata/', {k:0})
					.then(function (response) {
					_this.count0=JSON.parse(response.data);
					_this.showloading1=false;
				});
		},

        data() {
			return {dh11:true,dh12:false,dh13:false,dh14:false,dh15:false,dh16:false,
			show_sousuohou:false,show_sousuokong:false,sou_keyword:'',
			divcontent:'',ceshi1:201,sourr:[],searchedword:[],
			bq1:[],bq1_:0,
			wj1:[],wj1_:0,
			wd1:[],wd1_:0,
			fy1:[],fy1_:0,
			fuyan1:[],fuyan1_:0,
			show_loading:false,
			show_searchword:true,
			count0:[],
			showloading1:false,

			}
		},
		
		computed:{
			welcomename(){return this.$cookies.get('username')},
			rev_searchedword() {return this.searchedword.reverse();}
		},
};

</script>

<style scoped>
		


</style>




