


<template>

			<div>
            <div v-for="comment in pageTableData">
                {{comment.date}}----{{comment.name}}
            </div>

					<el-pagination style="text-align:right;"

            background
:page-size=8
						:total="listNum"
						:current-page.sync="currentPage4"
						layout="total, prev, pager, next"
						>
					</el-pagination>

					<el-pagination style="text-align:right;"

            background
:page-size=8
						:total="listNum1"
						:current-page.sync="currentPage0"
						layout="total, prev, pager, next"
						>
					</el-pagination>


            </div>


</template>

<script>
import tj0shanchu from '../tijiao/tj_shanchu';
import tj0huifu from '../tijiao/tj_huifu';

export default {
    components: {tj0shanchu,tj0huifu},

	data() {return {
        currentPage4: 1,//当前分页
        listNum:1,//分页总条数
        tabdata: [{
            date: '2016-05-02',
            name: '王小虎00000',
            address: '上海市普陀区金沙江路0000弄'
          }, {
            date: '2016-05-04',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1517 弄'
          }, {
            date: '2016-05-01',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1519 弄'
          }, {
			date: '2016-05-01',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1519 弄'
          }, {
			  			date: '2016-05-01',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1519 弄'
          }, {
			  			date: '2016-05-01',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1519 弄'
          }, {
			  			date: '2016-05-01',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1519 弄'
          }, {
			  			date: '2016-05-01',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1519 弄'
          }, {
			  			date: '2016-05-01',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1519 弄'
          }, {
			  			date: '2016-05-01',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1519 弄'
          }, {
			  			date: '2016-05-01',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1519 弄'
          }, {
			  			date: '2016-05-01',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1519 弄'
          }, {
			  			date: '2016-05-01',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1519 弄'
          }, {
			  			date: '2016-05-01',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1519 弄'
          }, {
			  			date: '2016-05-01',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1519 弄'
          }, {
			  			date: '2016-05-01',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1519 弄'
          }, {
			  			date: '2016-05-01',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1519 弄'
          }, {
			  			date: '2016-05-01',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1519 弄'
          }, {
			  			date: '2016-05-01',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1519 弄'
          }, {
			  			date: '2016-05-01',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1519 弄'
          }, {
			  			date: '2016-05-01',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1519 弄'
          }, {
			  			date: '2016-05-01',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1519 弄'
          }, {
			  			date: '2016-05-01',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1519 弄'
          }, {
			  
            date: '2016-05-03',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1516 弄'
          }, {
			  
            date: '2016-05-03',
            name: '王小虎22222',
            address: '上海市普陀区金沙江路 1516 弄'
          }, {
			  
            date: '2016-05-03',
            name: '王小虎22222',
            address: '上海市普陀区金沙江路 1516 弄'
          }, {
			  
            date: '2016-05-03',
            name: '王小虎22222',
            address: '上海市普陀区金沙江路 1516 弄'
          }, {
			  
            date: '2016-05-03',
            name: '王小虎22222',
            address: '上海市普陀区金沙江路 1516 弄'
          }, {
			  
            date: '2016-05-03',
            name: '王小虎22222',
            address: '上海市普陀区金沙江路 1516 弄'
          }, {
			  
            date: '2016-05-03',
            name: '王小虎22222',
            address: '上海市普陀区金沙江路 1516 弄'
          }, {
			  
            date: '2016-05-03',
            name: '王小虎22222',
            address: '上海市普陀区金沙江路 1516 弄'
          }, {
			  
            date: '2016-05-03',
            name: '王小虎22222',
            address: '上海市普陀区金沙江路 1516 弄'
          }, {
			  
            date: '2016-05-03',
            name: '王小虎22222',
            address: '上海市普陀区金沙江路 1516 弄'
          }, {
			  
            date: '2016-05-03',
            name: '王小虎22222',
            address: '上海市普陀区金沙江路 1516 弄'
          }, {
			  
            date: '2016-05-03',
            name: '王小虎22222',
            address: '上海市普陀区金沙江路 1516 弄'
          }, {
			  
            date: '2016-05-03',
            name: '王小虎22222',
            address: '上海市普陀区金沙江路 1516 弄'
          }, {
			  
            date: '2016-05-03',
            name: '王小虎22222',
            address: '上海市普陀区金沙江路 1516 弄'
          }, {
			  
            date: '2016-05-03',
            name: '王小虎22222',
            address: '上海市普陀区金沙江路 1516 弄'
          }, {
			  
            date: '2016-05-03',
            name: '王小虎22222',
            address: '上海市普陀区金沙江路 1516 弄'
          }, {
			  
            date: '2016-05-03',
            name: '王小虎22222',
            address: '上海市普陀区金沙江路 1516 弄'
          }, {
			  
            date: '2016-05-03',
            name: '王小虎22222',
            address: '上海市普陀区金沙江路 1516 弄'
          }],
    }},
        mounted() {
            this.listNum=this.tabdata.length;
        },
	filters: {},
	computed: {
    keyword11(){return this.$store.state.KEYWORD11},
    show_xh11(){return this.$store.state.SHOW_XH11},
    show_xhk11(){return this.$store.state.SHOW_XHK11},
    xh11s(){return this.$store.state.XH11},
    // xh_k_11s(){return this.$store.state.XH11},
            pageTableData(){
                let pages=Math.ceil(this.tabdata.length/8);//
                let newList=[];
                for(let i=0;i<pages;i++){
                let sonList=[];
                sonList=this.tabdata.slice(i*10,i*10+10);//
                newList.push(sonList)
                }
                return newList[this.currentPage4-1]
            }
	},
	methods:{
      handleSizeChange(val) {

console.log(`每页 ${val} 条`);

},

handleCurrentChange(val) {

console.log(`当前页: ${val}`);

},


    },	
};
</script>

<style>
</style>


