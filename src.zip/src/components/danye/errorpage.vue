//暂时不用，因为不能正常关闭网页，关闭之后会残留一个空白页
<template>
    <div id="errorpage"  @click="turnfresh()">
		<zu2logo k=1></zu2logo>
        <el-container>
            <el-aside width="120px" class="bgcolor_FF"></el-aside>
            <el-main>
                <el-card style="font-size:25px;">
                    <br>
                    <i class="el-icon-lock"></i>
                    <span>此内容</span>
                    <span v-if="errorid===1">是密文，无法显示</span>
                    <!-- <span v-if="errorid(this.zhifanwei,this.mizi,this.kstatus,this.ktype)===9">
                        <span>仅限于群组</span>
                        <router-link class="a_black" target="_blank" :to="{name:'qunzuye',params:{id:this.zhifanwei}}">
                            <span class="a_black">{{this.zhifanwei}}</span>
                        </router-link>
                    </span> -->
                    <br>
                    <br>
                </el-card>
            </el-main>
		</el-container>
	</div>
</template>

<script>


export default {
		name:'errorpage',
		components: {},
        methods:{},
        data() {
			return {errorid:0}
		},
        created() {
				this.errorid = this.$route.params.id;//获取上个页面传递的id,在下面获取数据的时候先提交id,这里的id不用加前缀
				
		},
};

</script>






