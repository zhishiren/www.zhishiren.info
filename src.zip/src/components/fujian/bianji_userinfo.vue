<template>
<span>
    <span v-if="show_bianji" class="font18px_black">{{inputzhi0}}</span>
    <a v-if="show_bianji" @click="bianji" class="a_grey font18px"><i class="el-icon-edit">编辑</i></a>

	<input v-if="show_queding" :placeholder="inputzhi1" v-model="changed_zhi" type="text" class="input_jian font18px" :style="{width:textlong(length)}" style="color:grey" >
    <a v-if="show_queding" @click="queding" class="a_grey font18px"><i class="el-icon-check"></i>确定</a> 
    <a v-if="show_queding" @click="huanyuan" class="a_grey font18px"><i class="el-icon-refresh-left"></i>还原</a>
    <span v-if="show_kongzhi" style="color:orange"><i class="el-icon-warning"></i>输入不能为空！</span>
</span>

</template>

<script>
  export default {
    data() {
      return {
                show_bianji:true,show_queding:false,show_kongzhi:false,changed_zhi:'',
                // userid:this.id,zhi_type:this.type,
      }
    },

    props:['inputzhi0','id','type','length','inputzhi1'],

    created(){

    },


    computed: {
        textlong () {
        return function (value) {
            return value * 19 + 'px';
            
        }
        }
    },



    methods:{
        bianji(){
        this.show_bianji=false;
        this.show_queding=true;
        },

        queding(){
                    var _this= this;
                    if(this.changed_zhi==''){this.show_kongzhi=true}
                    else{
                        this.$axios
                        .post('http://www.zhishiren.info/api/edit_mypage/', {userid: this.id,zhi:this.changed_zhi,zhi_type:this.type})
                        .then(function(response){
                            if (response.data.changed_ok === 0){
                            _this.inputzhi0=_this.changed_zhi;
                            _this.show_bianji=true;
                            _this.show_queding=false;
                            _this.show_kongzhi=false;
                            // _this.$router.go(0);
                            _this.$emit("freshinfo");

                            }
                        })
                    }
        },


        huanyuan(){
        this.show_bianji=true;
        this.show_queding=false;
        this.show_kongzhi=false;
        },
    }

  }
</script>





