<template>

    <div id="xiazaiyuanwen" class="chazhao_alink" style="text-align:right">
		<a @click="shangyitiao()" class="chazhao_alink a_noline" ><i class="el-icon-download"></i>下载原文</a>   
    </div>

</template>

<script>

export default {
    name:'xiazaiyuanwen',
    props: {},
    computed:{},
	
    methods:{
				shangyitiao:function(){

				},
				xiayitiao:function(){

                },

	},

};

</script>

<style scoped>
		.chazhao_alink{font-size:18px;color:black;}
		.chazhaolan{
					width:150px;
					border:none;
					border-radius:0;
					border-bottom:#8D8D8D 1px solid;
					box-shadow:0;
					outline:none;
					text-decoration: none;
					font-size:18px;
        }
        a:hover{color:orange;}

</style>
