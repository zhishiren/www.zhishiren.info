// 这个组件需要做一个判断，是不是开放性的文辑名，例如《知识人百科》等文辑。
<template>

<div id="tj_jiashuju">
        <el-row style="line-height: 40px;" >
            <el-col :span="2" >
                <span class="font16px">数据数值：</span>
            </el-col>
            <el-col :span="6" >
                <el-input v-model="input" placeholder="请输入文段标题"  style="width:90%;"></el-input>
            </el-col>
            <el-col :span="2" >
                <span class="font16px">数据单位：</span>
            </el-col>
            <el-col :span="6" >
                <el-input v-model="input" placeholder="请输入文段标题"  style="width:96%;"></el-input>
            </el-col>
            <el-col :span="2" >
                <span class="font16px">数据期数：</span>
            </el-col>
            <el-col :span="6" >
                <el-input v-model="input" placeholder="请输入文段标题"  style="width:96%;"></el-input>

            </el-col>
        </el-row>
        <br>
        <el-row >
                <el-col :span="2" >
                    <span class="font16px">发言内容：</span>
                </el-col>
                <el-col :span="20" >
                    <div contenteditable ref="contents" @paste="onPaste" class="pinglunlan" style="font-size:16px;width:100%;">
                    </div>
                </el-col>
                <el-col :span="2">
                    <a class="a_black" href="javascript:;" @click="f_blod">
                        <b>所选加粗</b>
                    </a>
                </el-col>
        </el-row>
        <el-row  style="line-height: 40px;">
            <el-col :span="13">
                <el-upload
                    class="upload-demo"
                    ref="upload"
                    :data={user_id:this.user_id}
                    multiple
                    action="http://www.zhishiren.info/api/zeng_fayan_fujian/"
                    Access-Control-Request-Headers: ContentType
                    style="text-align:right;"
                    :on-preview="handlePreview"
                    :on-remove="handleRemove"
                    :file-list="fileList"
                    :on-success="shuaxinyemian"
                    :auto-upload="false">
                    <!-- <span slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</span> -->
                    <el-button style="font-size:16px;" slot="trigger" size="small" type="text">添加附件...
                    </el-button><el-divider direction="vertical"></el-divider><!--
                    --><a class="font20px a_black"  @click="submitUpload">发布</a>
                </el-upload>
            </el-col>
            <el-col :span="11">
                <span style="color:green" v-show="ok_msg==0">
                    <i class="el-icon-circle-check">发布成功!</i>
                </span>
                <span style="color:orange" v-show="ok_msg==1">
                    <i class="el-icon-warning-outline">发布内容不能为空!</i>
                </span>
                <span style="color:red" v-show="ok_msg==2">
                     <i class="el-icon-error">数据库写入失败!</i>
                </span>
                <span style="color:orange" v-show="ok_msg==3">
                    <i class="el-icon-warning">只能上传jpg/rar/zip文件，且不超过1MB!</i>
                </span>
                <span></span>
            </el-col>
        </el-row>


</div>
       
    
</template>


<script>

	export default {
		name: 'tj_jiashuju',
		components: {},
		data () {
			return {
			}
		},
		methods: {
submitUpload() {
                // 这里需要判断，
                var that = this;
                if(that.$refs.contents.innerHTML===''){that.ok_msg=1}
                else{
                    if(that.$refs.upload.uploadFiles.length <= 0){
                        that.axios
                        .post('http://www.zhishiren.info/api/zeng_fayan_nofujian/',{userid: that.$cookies.get('userid'),username:that.$cookies.get('username'),fayan_leixing:that.type_value,fayan_divcontent:that.$refs.contents.innerHTML})
                        .then(function (response) {
                                        if (response.data.ok_id === 0){
                                            that.ok_msg=response.data.msg;
                                            that.$refs.contents.innerHTML='';
                                        }
                        });
                    }
                    else{that.$refs.upload.submit();}
                }
            },

			f_blod() {
                document.execCommand ( 'bold', false );
                document.execCommand ( 'backColor', false, 'yellow' );
			},

            shuaxinyemian(response) {
                // 这里是上传成功之后，刷新页面
            },

            handleExceed(files, fileList) {
                this.$message.warning(`每次操作只能上传一个文件！`);
            },
            beforeRemove(file, fileList) {
                return this.$confirm(`确定移除 ${ file.name }？`);
            },

            handleRemove(file, fileList) {
                console.log(file, fileList);
            },
            handlePreview(file) {
                console.log(file,fileList);

            },
 
		}
	}
</script>

