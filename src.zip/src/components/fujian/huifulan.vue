






作废









<template>
<el-row>
    <span style="float:left;">
            <span style="color:orange;">
                求助询问
                <el-divider direction="vertical"></el-divider>
            </span>

            <span v-if="fanwei_qunzu_id===80000000">
                    仅本人可见
            </span>
            <span v-if="fanwei_qunzu_id===90000000">
                    所有人可见
                <el-divider direction="vertical"></el-divider>
            </span>
            <span v-else>
                <router-link class="a_black" target="_blank" :to="{name:'qunzuye',params:{id:fanwei_qunzu_id}}">
                    仅{{this.fanwei_qunzu_id}}可见
                </router-link>
                <el-divider direction="vertical"></el-divider>
            </span>

<!-- 这里需要在后台django里判断，如果是90000000和属于我的群组，则返回 -->
            <span v-if="tixing_qunzu_id===90000000">
                    提醒所有人
                <el-divider direction="vertical"></el-divider>
            </span>
            <span v-if="tixing_qunzu_id<90000000 && tixing_qunzu_id>80000000" >
                <router-link class="a_black" target="_blank" :to="{name:'qunzuye',params:{id:tixing_qunzu_id}}">
                    提醒{{this.tixing_qunzu_id}}
                </router-link>
                <el-divider direction="vertical"></el-divider>
            </span>
    </span>
            
    <span style="float:right;">
            <span style="color:orange;" v-if="notok">删除失败</span>
			<a v-show="yonghuid==creater_id" @click="shanchu()" class="a_grey">
				<i class="el-icon-close"></i>删除<el-divider direction="vertical"></el-divider>
			</a><!--
    	 --><a @click="huifujian()" class="a_grey">回复</a>
		 	<span v-show="yonghuid!==creater_id">
				<el-divider direction="vertical"></el-divider><!--
			--><a @click="ding()" class="a_grey">顶</a>
				<el-divider direction="vertical"></el-divider><!--
			--><a @click="cai()" class="a_grey">踩</a>
			 </span>
		    <el-divider direction="vertical"></el-divider>
            {{getNowFormatDate(create_time)}}
    </span>
	        
</el-row>
</template>

<script>
export default {
	data() {return {notok:false}},

	props:['creater_id','comment_id','create_time','zhid','actype','fanwei_qunzu_id','tixing_qunzu_id'],

	computed: {
            yonghuid(){return parseInt(this.$cookies.get('userid'))},
    },

	methods:{
				shanchu(){
					var that=this;
					that.$axios
					.post('http://www.zhishiren.info/api/huifu_shan/',{fuyanid: that.comment_id,zhid:that.zhid,actype:that.actype})
					.then(response=>{
						if(response.data.shan_ok==0){
								that.$emit('shanchuok');
								that.notok=false;
							}
						else{
								that.notok=true;
								setTimeout(function(){that.notok=false;}, 2000);
							}
				})},

				huifujian:function(){
				},
				ding:function(){
				},
				cai:function(){
				},
	},
};

</script>

