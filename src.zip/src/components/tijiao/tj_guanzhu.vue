
<template>
    <div id="tj_guanzhu" class="font18px">
		<span v-show="focused_yn===0">
			<el-button  v-if="yonghuid!==zhid" @click="guanzhujian()" type="text" class="font18px"><i class="el-icon-view"></i>关注...</el-button>
			<el-button  v-if="yonghuid===zhid" disabled type="text" class="font18px"><i class="el-icon-view"></i>关注...</el-button>
			<span  v-if="yonghuid!==zhid">
				<span v-if="zhitype==='yonghuye'">此用户信息</span>
				<span v-if="zhitype==='wenduanye'">此文段信息</span>
				<span v-if="zhitype==='wenjiye'">此文辑信息</span>
				<span v-if="zhitype==='qunzuye'">此群组信息</span>
				<span v-if="zhitype==='fayanye'">此段言论</span>
				<span v-if="zhitype==='biaoqianye'">此标签信息</span>
				<span>会添加到在首页你的“关注收藏”中。</span>
			</span>
			<span  v-if="yonghuid===zhid">你不能关注你自己。</span>
		</span>
		<span v-show="focused_yn===1" style="color:blue">
			<el-button @click="quguanjian()" type="text" class="font18px"><i class="el-icon-close"></i>取关...</el-button>
			<span>你已经关注了。</span>
		</span>
		<span style="color:red;" v-show='this.ok_msg==2'><i class="el-icon-success"></i>操作失败！</span>
		<el-dialog title="关注附言..." width="400px" :visible.sync="show_dialog">
			<el-row>
				<!-- 这里的格式要注意，“请输入分享附言，限100字。”与上下文的标签不能有换行等。 -->
				<div contenteditable ref="contents" @paste="onPaste" class="pinglunlan">请输入关注附言，限100字。</div>
			</el-row>
            <el-row>
                <el-col :span="7">
                    <a class="a_black font18px" href="javascript:;" @click="f_blod">
                        <b>所选加粗</b>
                    </a>
                </el-col>
                <el-col class="font18px" :span="11">
                </el-col>
                <el-col :span="6" style="text-align:right">
                    <a @click="fabujian" class="font20px a_black" >发布</a>
                </el-col>
            </el-row>
        </el-dialog>
    </div>
</template>

<script>
export default {
	name:'tj_guanzhu',
	components: {},
	props:['zhid','zhititle','zhitype','bq_fanwei'],
	// 这里仅针对标签设定fanwei
	data() {return {
		show_dialog:false,
		ok_msg:0,
		fuyan:'',
		zhi_id:0,
		focused_yn:0,
		}},

	computed: {
            yonghuid(){return parseInt(this.$cookies.get('userid'))},
    },


	watch: {
            zhid: function(newVal,oldVal){
				this.zhi_id = newVal;
				this.axios
					.post('http://www.zhishiren.info/api/check_focused/',{
						zhi_id:this.zhi_id,
						userid:this.$cookies.get('userid'),
					})
					.then(response=>{
						this.focused_yn=response.data.focused_id;
				});
			},
	},
	
	methods:{
			f_blod() {document.execCommand ( 'bold', false );},
			
			onPaste: function(e) {
                    e.preventDefault()
                    e.stopPropagation()
                    let pasteValue = (e.clipboardData || window.clipboardData).getData('text/plain')
                    console.log(pasteValue)
                    var re = /<[^>]+>/gi;
                    pasteValue = pasteValue.replace(re, '').replace(/\s+|[\r\n]/g,"");
                    e.target.textContent += pasteValue
            },

			guanzhujian:function(){
					this.show_dialog=false;
					this.show_dialog=true;
			},

			quguanjian:function(){
					this.axios
						.post('http://www.zhishiren.info/api/xxguanzhu/',{
							zhi_id:this.zhid,
							userid:this.$cookies.get('userid'),
						})
						.then(response=>{
							if (response.data.ok_id === 1){
								this.$emit("gzminus1");
								this.focused_yn=0;
							}
						});
			},
			fabujian:function(){
					var that = this;
						if(that.$refs.contents.innerHTML==='请输入关注附言，限100字。'){that.fuyan='无附言信息。'}
						else{that.fuyan=that.$refs.contents.innerHTML};
						that.axios
						.post('http://www.zhishiren.info/api/ooguanzhu/',{
							zhi_id:that.zhid,
							zhi_title:that.zhititle,
							userid: that.$cookies.get('userid'),
							username:that.$cookies.get('username'),
							zhi_leixing:that.zhitype,
							bq_fanwei:that.bq_fanwei,
							divcontent:that.fuyan})
						.then(function (response) {
									if (response.data.ok_id === 0){
										that.$refs.contents.innerHTML='请输入关注附言，限100字。';
										that.show_dialog=false;
										that.$emit("gzadd1");
										that.focused_yn=1;
									}
									else{
										 that.ok_msg=2;
										 setTimeout(function(){that.ok_msg=0;}, 2000);
										 that.$refs.contents.innerHTML='请输入关注附言，限100字。';
										 that.show_dialog=false;
								    }
						});
			
					
			},
	}
}
</script>

