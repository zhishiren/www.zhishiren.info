



<template>
    <div id="tj_fenxiang" class="font18px">
        <el-button type="text" @click="kkk = true">打开</el-button>
        <el-dialog title="收货地址" :visible.sync="kkk">
        <el-table :data="gridData">
            <el-table-column property="date" label="日期" width="150"></el-table-column>
            <el-table-column property="name" label="姓名" width="200"></el-table-column>
            <el-table-column property="address" label="地址"></el-table-column>
        </el-table>
        </el-dialog>
    </div>
</template>

<script>
import axios from 'axios';
export default {
	data() {return {}},
	methods:{
				fenxiangjian:function(){

				},
	},

};

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
		.sousuo_alink{font-size:22px;color:black;}
		a:hover{color:orange;}
</style>
