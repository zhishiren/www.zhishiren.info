
<template>
        <span id="fromqunzu" style="float:left;color:grey;">
            <span v-if="qunzu_id===80000000">
                <router-link class="a_black" target="_blank" :to="{name:'qunzuye',params:{id:qunzu_id}}">
                    仅本人可见
                </router-link>
            </span>
            <span v-if="qunzu_id===90000000">
                <router-link class="a_black" target="_blank" :to="{name:'qunzuye',params:{id:qunzu_id}}">
                    所有人可见
                </router-link>
            </span>
            <span v-else>
                <router-link class="a_black" target="_blank" :to="{name:'qunzuye',params:{id:qunzu_id}}">
                    仅{{this.qunzu_id}}可见
                </router-link>
            </span>
        </span>
</template>

<script>
export default {
    name:'fromqunzu',
	data() {return {}},
	props: {
			qunzu_id: {type: Number},
	},
	methods:{

	},
};

</script>

