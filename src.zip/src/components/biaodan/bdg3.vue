
<template>
	<div>


        <el-row  class="font18px">
				<el-button @click="to_xiugai"  type="text"  class="font18px">
                    <i class="el-icon-edit"></i>修改...
                </el-button>
                已经有10次修改历史。-展开- 
		</el-row>

		<el-dialog title="修改内容..." width="400px" :visible.sync="show_dialog">
            <el-row>
                <el-col :span="7" class="font18px" style="padding-top:10px;">
                    公开范围：
                </el-col>
                <el-col :span="17">
                    <fanwei  ref="huanyuan" @set_fanwei="set_gongkaifanwei" style="width:90%;"></fanwei>
                </el-col>
            </el-row>
            <br>

			<el-row>
                <el-col :span="7" class="font18px" style="padding-top:10px;">
                    文段状态：
                </el-col>
                <el-col :span="17">
                    <el-select style="width:100%" placeholder="请在你所关注的标签中选择">
                        </el-select> 
                </el-col>
            </el-row>
            <br>

            <el-row>
                <el-col :span="7" class="font18px" style="padding-top:10px;">
                    管理人：
                </el-col>
                <el-col :span="17">
                    <el-input v-model="input" placeholder="请输入群组名称"  style="width:100%;">
                    </el-input>
                </el-col>
            </el-row>
            <br>

            <el-row>
                <!-- 这里的格式要注意，“请输入分享附言，限100字。”与上下文的标签不能有换行等。 -->
                <div contenteditable ref="contents" @paste="onPaste" class="pinglunlan">请输入数集附言，限100字。</div>
            </el-row>
            <el-row>
                <el-col :span="7">
                    <a class="a_black font18px" href="javascript:;" @click="f_blod">
                        <b>所选加粗</b>
                    </a>
                </el-col>
                <el-col class="font18px" :span="11">
                    <span style="color:green;"><i class="el-icon-success"></i>发布成功!</span>
                    <span style="color:orange;" v-show="ok_msg==2"><i class="el-icon-warning-outline"></i>标签不能为空!</span>
                    <span style="color:red;" v-show="ok_msg==3"><i class="el-icon-error"></i>数据库写入失败!</span>
                </el-col>
                <el-col :span="6" style="text-align:right">
                    <a @click="fabujian" class="font20px a_black" >发布</a>
                </el-col>
            </el-row>
        </el-dialog>
</div>


    
</template>


<script type="text/javascript">
import fanwei from '../fujian/fanwei';

	export default {
		name: 'bdg4',
        components: {fanwei},
		data () {
			return {
                show_dialog:false,
			}
		},
		methods: {
			to_xiugai(){
				this.show_dialog=true;
			},
		}
	}
</script>

<style scoped>

</style>