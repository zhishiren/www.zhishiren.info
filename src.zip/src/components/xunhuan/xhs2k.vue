<!-- 这是用户新增标签的模版-->
<template>
	<div id="xhs2k">
        <div>
            <el-row class="font18px">
                <span style="color:blue"><i class="el-icon-finished"></i>{{this.jishu}}条搜索结果。</span>
            </el-row>
			
			<el-row v-for="l in ls" :key="l.pk" class="br10px17px">
					<el-row>
                        <router-link class="a_black" target="_blank" :to="{name:'wenduanye',params:{id:l.pk}}">
                            <span>{{l.fields.wj_title}}</span>
                            <span v-html="gaoliangk(l.fields.wd_title, k)" ></span>
                        </router-link>
                        <span style="color:red" v-if="l.fields.wd_status!=='正常有效'">:{{daibiaoma(l.fields.wj_status)}}</span>
                    </el-row>
					<el-row>
                        <span><b style="color:grey">正文内容<i class="el-icon-caret-right"></i></b><span v-html="gaoliangk(l.fields.wd_content, k)"></span></span>     
					</el-row>
				    <el-row><el-divider style="margin:0px;"></el-divider></el-row>
			</el-row>

            <br>
            <el-pagination v-if="jishu>10" style="text-align:right;"
                            background
                            :page-size=10
                            :total="jishu"
                            :current-page.sync="currentPage"
                            layout="total, prev, pager, next">
            </el-pagination>

        </div>


    </div>
</template>
<script>

export default {
    name:'xhs2k',
    components: {},
    props:['list','jishu','k'],
	data() {return {
        currentPage: 1,//当前分页的数值
    }},

    computed: {
            ls(){
                let pages=Math.ceil(this.jishu/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                    let sonList=[];
                    sonList=this.list.slice(i*10,i*10+10);//10为每页设置数量
                    newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },

    },

    methods: {
            kk2(){this.currentPage=1;}
    },

};
</script>