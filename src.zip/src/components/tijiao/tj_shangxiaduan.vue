<template>

    <div id="shangxiaduan" class="chazhao_alink" style="text-align:right">
		<a @click="shangyitiao()" class="chazhao_alink a_noline" ><i class="el-icon-arrow-left"></i>上一条</a>   
							&nbsp;
		<a @click="xiayitiao()" class="chazhao_alink a_noline" >下一条<i class="el-icon-arrow-right"></i></a>   
    </div>

</template>

<script>

export default {
    name:'shangxiaduan',
    props: {},
    computed:{},
	data() {},
    methods:{
				shangyitiao:function(){

				},
				xiayitiao:function(){

                },

	},

};

</script>

<style scoped>
		.chazhao_alink{font-size:18px;color:black;}
		.chazhaolan{
					width:150px;
					border:none;
					border-radius:0;
					border-bottom:#8D8D8D 1px solid;
					box-shadow:0;
					outline:none;
					text-decoration: none;
					font-size:18px;
        }
        a:hover{color:orange;}

</style>
