

<template>
    <div id="zu0uploadyuanwen" style="display:inline-block">
            <el-upload
                    name="yuanwen"
                    class="upload-demo"
                    ref="upload"
                    :data={id:this.id}
                    action='http://www.zhishiren.info/api/shangchuan_yuanwen/'
                    Access-Control-Request-Headers: ContentType
                    style="text-align:40px;display:inline;"
                    :on-preview="handlePreview"
                    :on-remove="handleRemove"
                    :before-remove="beforeRemove"
                    :on-exceed="handleExceed"
                    :on-success="onsuccess"
                    :file-list="fileList" 
                    >
                    <a class="a_grey" type="primary" style="font-size:16px;" slot="trigger" size="small"><i class="el-icon-upload2"></i>上传原文</a>
                    <span v-if="uploaded!==0" style="color:grey">:已传</span>
                </el-upload> 
    </div>

</template>

<script>
  export default {
    name: 'zu0uploadyuanwen',
    props:['id','uploaded'],
    data() {
      return {

      }
    },

    methods:{
            handleRemove(file, fileList) {
                console.log(file, fileList);
            },
            handlePreview(file) {
                console.log(file);
            },
            onsuccess(response, file, fileList) {
                this.$refs.upload.clearFiles();
                this.uploaded=1;
                
            },
            handleExceed(files, fileList) {
                this.$message.warning(`每次操作只能上传一个文件！`);
            },
            beforeRemove(file, fileList) {
                return this.$confirm(`确定移除 ${ file.name }？`);
            },
            handleRemove(file, fileList) {
                console.log(file, fileList);
            },
            handlePreview(file) {
                console.log(file,fileList);
            },
    }

  }
</script>