<template>
	<div id="xhbqnei">
        <zu1caozuojishu 
            zone_id="标签里加入" :jishu="listNum" :showloading1="showloading1" :showloading2="showloading2"  
            :zhid="zhid" :title0="title0" :type0="type0" :managerid="manager"
            :fanwei="fanwei" :fyhui="fyhui" :createrid="createrid" :creatername="creatername"
            @zhankai="zk" @shuaxin="shuaxin">
        </zu1caozuojishu>  
        <div v-if="lists && showloading2===false">
            <el-row class="br10px17px" v-for="list in lists" :key="list.pk" >
                <el-row>
                    <zu0niming :uid1='list.fields.uid1' :uname='list.fields.uname'></zu0niming>
                    <span v-if="list.fields.cztype==='加入标签'">添加了</span>
                    <zu1yuansu onlyid1=0 :list="list" ></zu1yuansu>
                    <zu0fy :list="list"></zu0fy>
                </el-row>
                <zu1huifulan :list='list' @shanchuok="shuaxin()"></zu1huifulan>
                <el-row><el-divider style="margin:0px;"></el-divider></el-row>
            </el-row>
            <br>
            <el-pagination v-if="listNum1>10" style="text-align:right;"
                background
                :page-size=10
                :total="listNum1"
                :current-page.sync="currentPage"
                layout="total, prev, pager, next">
            </el-pagination>
        </div>
	</div>
</template>

<script>


	export default {
		name: 'xhbqnei',
        components: {},
        props:['zoneid','listNum',
        'zhid','title0','type0',//必填，这个type0是用于判断是否为用户页或群组的
        'fanwei',//选填，用于“分享”的功能
        'createrid','creatername','manager'//选填，用于操作“言论”相关,这个creatername用来录入被操作的原始人员
        ],
		data () {
			return {
                showloading2:false,
                showloading1:false,
                listNum1:0,
                xhbqnei:[],
                currentPage: 1,//当前分页的数值
			}
        },
        
        computed: {
            lists(){
                let pages=Math.ceil(this.listNum/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                    let sonList=[];
                    sonList=this.xhbqnei.slice(i*10,i*10+10);//10为每页设置数量
                    newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
            userid(){return parseInt(this.$cookies.get('userid'))},
            
        },

		methods: {
            zk(){this.shuaxin();},
            shanok(){this.shuaxin();},
            shuaxin(){
                this.showloading2=true;
                var that=this;
                that.$axios
                    .post('http://www.zhishiren.info/api/xunhuanbqnei/', {
                        zhid:parseInt(that.zhid),
                        cztype:that.zoneid,
                        })
                    .then(response=>{
                        that.xhbqnei=JSON.parse(response.data);
                        that.listNum=that.xhbqnei.length;
                        that.listNum1=that.xhbqnei.length;
                        that.currentPage=1;
                        that.showloading2=false;
                    });
            },

        }
			
        // created: function () {
		// 		this.axios
		// 		.post('http://www.zhishiren.info/api/count43/',{zhid: this.$cookies.get('userid')})
        //         .then(response=>{this.listNum=response.data});
		// }

	}
</script>

