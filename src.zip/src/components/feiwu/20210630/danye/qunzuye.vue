<template>
<div id="biaoqianye"  @click="turnfresh()">
		<toubu0></toubu0>

		<el-container>
			<el-aside width="120px" class="bgcolor_FF"></el-aside>
			<el-main class="bgcolor_FC font18px">
				<el-card  v-if="qz_info.qz_id"  class="box-card">
					<el-row class="font21px">{{this.qz_info.qz_title}}</el-row>
					<el-row>
						<span><b>属性<i class="el-icon-caret-right"></i></b></span>
						<span>群组ID:{{this.qz_info.qz_id}}<el-divider direction="vertical"></el-divider></span>
						<span v-if="qz_info.qz_status==='s4'" style="color:red;">{{daibiaoma(this.qz_info.qz_status)}}<el-divider direction="vertical"></el-divider></span>
						<span v-if="qz_info.qz_status!=='s4'">{{daibiaoma(this.qz_info.qz_status)}}<el-divider direction="vertical"></el-divider></span>
						<span>{{this.qz_info.qz_join}}<el-divider direction="vertical"></el-divider></span>
						<span>{{this.qz_info.qz_type}}<el-divider direction="vertical"></el-divider></span>
						<span>管理人:
							<router-link class="a_black" target="_blank" :to="{name:'yonghuye',params:{id:qz_info.qz_manager}}">
								{{this.qz_info.qz_manager}}
							</router-link>
						</span>
						<zu0tongjishu :dj="qz_tongji.dianji" :gz="qz_tongji.guanzhu" :fx="qz_tongji.fenxiang" qz_yn='1'></zu0tongjishu>
					</el-row>
					<el-row v-if="qz_info.qz_remark!==null">
						<b>说明<i class="el-icon-caret-right"></i></b><span v-html="qz_info.qz_remark"></span>
					</el-row>
					<zu0fujianfutu v-if="this.qz_info.fu!==0" :zhid="qz_info.qz_id"></zu0fujianfutu>
				</el-card>
				<el-card v-else>
					<br>
						<div style="text-align:center;font-size:30px;"><i class="el-icon-loading"></i>正在加载</div>
					<br>
				</el-card>
			</el-main>
		</el-container>

		<el-container>
			<el-aside width="120px">
				<el-menu default-active="12" class="el-menu-vertical-demo bgcolor_menu_FC" @open="handleOpen" @close="handleClose">
			      <el-menu-item @click="daohang11" index="11" class="font18px">
			        <span slot="title">组员列表</span>
			      </el-menu-item>
				  <el-menu-item @click="daohang12" index="12" class="font18px">
			        <span slot="title">关注分享</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang13" index="13" class="font18px">
			        <span slot="title">评论</span>
			      </el-menu-item>
			      <!-- <el-menu-item @click="daohang14" index="14" class="font18px">
			        <span slot="title">关联知识</span>
			      </el-menu-item> -->
				  <el-menu-item @click="daohang15" index="15" class="font18px">
			        <span slot="title">群内动态</span>
			      </el-menu-item>
                  <!-- <el-menu-item @click="daohang16" index="16" class="font18px">
			        <span slot="title">群组管理</span>
			      </el-menu-item> -->
			    </el-menu>
			</el-aside>
			<el-main v-show="dh12" class="section_xh">
				<el-row>
					<tj0fenxiang @fxadd1="add1(1)" :zhid="qz_info.qz_id" zhitype="qunzuye" :zhititle="qz_info.qz_title" :createrid="qz_info.qz_createrid" :zhitype1="qz_info.qz_type"></tj0fenxiang>
					<tj0jiaruqun  @gzadd1="add1(2)" @gzminus1="minus1(2)" :zhid="qz_info.qz_id" :zhititle="qz_info.qz_title" :kouling="qz_info.qz_kouling" :qzjoin="qz_info.qz_join"></tj0jiaruqun>
					<tj0jiabiaoqian zhitype="qunzuye" :zhid="qz_info.qz_id" :zhititle="qz_info.qz_title"></tj0jiabiaoqian>

				</el-row>
			</el-main>
			<el-main v-show="dh13" class="section_xh">				
				<tj0pinglun :zhid="qz_info.qz_id" zhitype="qunzuye" :zhititle="qz_info.qz_title" fanwei=90000000></tj0pinglun>
			</el-main>
			<!-- <el-main v-show="dh14" class="section_xh">
				<tj0guanlian :jishu="qz_info.guanlian" :item_id="qz_info.qz_id" :item_title="qz_info.qz_title"></tj0guanlian>
			</el-main> -->
			<el-main v-show="dh15" class="section_xh">
				<tj1qundongtai :qztitle="qz_info.qz_title" :qzid="qz_info.qz_id" :manager="qz_info.qz_manager"  :qzjoin="qz_info.qz_join"></tj1qundongtai>
			</el-main>
            <el-main v-show="dh16" class="section_xh">
				<bdg8 :jishu="qz_info.xiugai" :item_id="qz_info.qz_id" :item_title="qz_info.qz_title"></bdg8>
				</el-main>
			<el-main v-show="dh11" class="section_xh">
        		<tj1yonghu :qzid="qz_info.qz_id" :qztitle="qz_info.qz_title"  :manager="qz_info.qz_manager" :qzjoin="qz_info.qz_join"></tj1yonghu>
			</el-main>


			<el-aside width="120px" class="bgcolor_FC"></el-aside>
		</el-container>



	</div>

</template>

<script>

import tj0fenxiang from '../tijiao/tj_fenxiang';
import tj0guanzhu from '../tijiao/tj_guanzhu';
import tj0jiabiaoqian from '../tijiao/tj_jiabiaoqian';
import tj0jiaruqun from '../tijiao/tj_jiaruqun';
import tj0pinglun from '../tijiao/tj_pinglun';
import tj0guanlian from '../tijiao/tj_guanlian';
import tj1yonghu from '../tijiao/tj1yonghu';
import tj1qundongtai from '../tijiao/tj_qundongtai';
import bdg8 from '../biaodan/bdg8';
import toubu0 from '../fujian/toubu0';
import zu0tongjishu from '../fujian/zu0tongjishu';
import zu0fujianfutu from '../fujian/zu0fujianfutu';

export default {
        name:'biaoqianye',
		components: {zu0fujianfutu,tj1qundongtai,zu0tongjishu,toubu0,tj0guanzhu,tj0fenxiang,tj0jiabiaoqian,tj0pinglun,tj0guanlian,tj0jiaruqun,bdg8,tj1yonghu},
        methods:{
                    daohang11(){this.dh11=true;this.dh12=false;this.dh13=false;this.dh14=false;this.dh15=false;this.dh16=false;},
                    daohang12(){this.dh12=true;this.dh11=false;this.dh13=false;this.dh14=false;this.dh15=false;this.dh16=false;},
                    daohang13(){this.dh13=true;this.dh11=false;this.dh12=false;this.dh14=false;this.dh15=false;this.dh16=false;},
					daohang14(){this.dh14=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh15=false;this.dh16=false;},
                    daohang15(){this.dh15=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh14=false;this.dh16=false;},
					daohang16(){this.dh16=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh14=false;this.dh15=false;},
					//这里的k值指的是关注数或分享数等等，这里的关注是加入群组的意思
					add1(k){
						if(k==1){this.qz_tongji.fenxiang++;}
						if(k==2){this.qz_tongji.guanzhu++;}
					},
					minus1(k){
						if(k==2){this.qz_tongji.guanzhu--;}
					},
			
        },
        data() {
			return {dh12:true,dh11:false,dh13:false,dh14:false,dh15:false,dh16:false,
			qunzu_id:0,
			qz_info:[],
			qz_tongji:[],
			focused_yn:0,
			kkk:0}
        },
        created() {
				this.qunzu_id = this.$route.params.id;//获取上个页面传递的id,在下面获取数据的时候先提交id,这里的id不用加前缀
				var _this= this;
				_this.axios
				.post('http://www.zhishiren.info/api/show_qunzuye/', {qunzu_id:this.qunzu_id})
				.then(function (response) {
					_this.qz_info=response.data;
					_this.qz_tongji=JSON.parse(response.data.qz_tongji);
				});
		},
		computed: {
				welcomename(){return this.$cookies.get('username')},
		},
};

</script>

<style scoped>

    
</style>




