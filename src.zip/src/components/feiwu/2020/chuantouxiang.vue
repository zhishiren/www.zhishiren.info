<template>


    <el-upload
    class="upload-demo"
    action="/api/chuantouxiang/"
    Access-Control-Request-Headers: ContentType
    :on-preview="handlePreview"
    :on-remove="handleRemove"
    :before-remove="beforeRemove"
    :limit="1"
    :on-exceed="handleExceed"
    :file-list="fileList"
    >
    <el-button class="font_yahei_17px" type="text">更改头像...</el-button>
    </el-upload>




</template>
<script>
import axios from 'axios';
  export default {
      
    data() {
      return {

      };
    },
    methods: {
      handleRemove(file, fileList) {
        console.log(file, fileList);
      },
      handlePreview(file) {
        console.log(file);
  
      },
      handleExceed(files, fileList) {
        this.$message.warning(`每次操作只能上传一个文件！`);
      },
      beforeRemove(file, fileList,ceshizhi) {
        return this.$confirm(`确定移除 ${ file.name }？`);
      }
    }
  }
</script>


<style>
  .el-dropdown-link {
    cursor: pointer;
    color: #409EFF;
  }
  .el-icon-arrow-down {
    font-size: 12px;
  }
</style>