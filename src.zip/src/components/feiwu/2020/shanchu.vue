



<template>
    <div id="fenxiang">
				<a @click="fenxiangjian()" class="sousuo_alink a_noline" ><i class="el-icon-close"></i>删除</a>
                点击删除这个知识点。 
                
    </div>
</template>

<script>
import axios from 'axios';
export default {
	data() {return {}},
	methods:{
				fenxiangjian:function(){

				},
	},

};

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
		.sousuo_alink{font-size:22px;color:black;}
		a:hover{color:orange;}
</style>
