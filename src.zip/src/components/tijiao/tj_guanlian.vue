<template>
	<div id="tj_guanlian"  class="font18px">
				    <el-button @click="pinglunjian" type="text" style="padding-bottom:0px;" class="font18px">
                        <i class="el-icon-connection"></i>关联...
                    </el-button>
                    <span style="color:green;" v-show="ok_msg==1"><i class="el-icon-success"></i>发布成功!</span>
                    <span style="color:red;" v-show="ok_msg==3"><i class="el-icon-error"></i>操作失败!</span>
                    <span>
                        <span v-if="zhitype==='yonghuye'">此用户信息</span>
                        <span v-if="zhitype==='wenduanye'">此文段信息</span>
                        <span v-if="zhitype==='wenjiye'">此文辑信息</span>
                        <span v-if="zhitype==='qunzuye'">此群组信息</span>
                        <span v-if="zhitype==='fayanye'">此段言论</span>
			            <span v-if="zhitype==='biaoqianye'">此标签信息</span>
                        <span>已有{{this.listNum}}条关联知识。</span>
                    </span>
                    <zhankai0 ref="zhankai0" @get_list="zhankaijian" @shuaxin="shuaxinjian"></zhankai0>
					<!-- <a @click="shuaxinjian" class="a_black"><i class="el-icon-refresh"></i>刷新</a> -->

		<el-dialog title="关联附言..." width="400px" :visible.sync="show_dialog">
            <el-row>
                <el-col :span="7" class="font18px" style="padding-top:10px;">
                    关联ID号：
                </el-col>
                <el-col :span="17">
                    <el-input v-model="item1id" style="width:100%" placeholder="请在你所关注的标签中选择">
                    </el-input> 
                </el-col>
            </el-row>
            <br>
            <el-row>
                <el-col :span="7" class="font18px" style="padding-top:10px;">
                    两者关系：
                </el-col>
                <el-col :span="17">
                    <el-select v-model="gl_att" style="width:100%" placeholder="请选择这两个知识点的关系">
                        <el-option value="待定" key="待定" label="待定"></el-option>
                        <el-option value="矛盾" key="矛盾" label="矛盾"></el-option>
                        <el-option value="互补" key="互补" label="互补"></el-option>
                        <el-option value="更细化" key="更细化" label="更细化"></el-option>
                    </el-select> 
                </el-col>
            </el-row>
            <br>
            <el-row>
                <div contenteditable ref="contents" @paste="onPaste" class="pinglunlan">请输入关联附言。</div>
            </el-row>
            <el-row>
                <el-col :span="7">
                    <a class="a_black font18px" href="javascript:;" @click="f_blod">
                        <b>所选加粗</b>
                    </a>
                </el-col>
                <el-col class="font18px" :span="11">
                    <span style="color:orange;" v-show="ok_msg==2"><i class="el-icon-warning-outline"></i>不可与自己关联!</span>
                    <span style="color:orange;" v-show="ok_msg==4"><i class="el-icon-warning-outline"></i>两知识点已关联!</span>

                </el-col>
                <el-col :span="6" style="text-align:right">
                    <a @click="fabujian" class="font20px a_black" >发布</a>
                </el-col>
            </el-row>
        </el-dialog>

        <div v-show="show_xhgl" >
                <el-row class="br10px17px" v-for="list in lists" :key="list.fields.act_createrid">
                            <el-row  :class="blinkyellow" v-if="list.pk==return_id">
                                <router-link target="_blank" class="a_black" :to="{name:'yonghuye',params:{id:list.fields.act_createrid}}" >
                                    <span>{{list.fields.act_creatername}}</span>
                                </router-link>
                                <span style="color:grey">关联了</span>
                                <router-link v-if="list.fields.item1_type==='fayanye'" target="_blank" class="a_black" :to="{name:'fayanye',params:{id:list.fields.item1_id}}" >
                                    <font style="font-size:20px;color:brown;"><b>“</b></font><span style="color:brown;" v-html="list.fields.item1_title" ></span><font style="font-size:20px;"><b>”</b></font>
                                </router-link>
                                <router-link v-if="list.fields.item1_type!=='fayanye'" target="_blank" class="a_black" :to="{name:list.fields.item1_type,params:{id:list.fields.item1_id}}" >
                                    <span>{{list.fields.item1_title}}</span>
                                </router-link>
                                <span style="color:grey">附言:<span v-html="list.fields.act_fuyan"></span></span>
                            </el-row>
                            <el-row v-if="list.pk!==return_id">
                                <router-link target="_blank" class="a_black" :to="{name:'yonghuye',params:{id:list.fields.act_createrid}}" >
                                    <span>{{list.fields.act_creatername}}</span>
                                </router-link>
                                <span style="color:grey">关联了</span>
                                <router-link v-if="list.fields.item1_type==='fayanye'" target="_blank" class="a_black" :to="{name:'fayanye',params:{id:list.fields.item1_id}}" >
                                    <font style="font-size:20px;color:brown;"><b>“</b></font><span  style="color:brown;" v-html="list.fields.item1_title" ></span><font style="font-size:20px;"><b>”</b></font>
                                </router-link>
                                <router-link v-if="list.fields.item1_type!=='fayanye'" target="_blank" class="a_black" :to="{name:list.fields.item1_type,params:{id:list.fields.item1_id}}" >
                                    <span>{{list.fields.item1_title}}</span>
                                </router-link>
                                <span style="color:grey">附言:<span v-html="list.fields.act_fuyan"></span></span>
                            </el-row>
                            <tj0huifu :shuaxinid="shuaxinyn" timek=0 news_yn=0 @shanchuok="shanok()" :act_id="list.pk" :create_time="list.fields.act_createtime" :it_att="list.fields.act_att" :creater_id="list.fields.act_createrid" :item1title="'你关联了:'+zhititle+'&&&'+list.fields.item1_title+'>>>附言:'+list.fields.act_fuyan"></tj0huifu>
                            <el-row><el-divider style="margin:0px;"></el-divider></el-row>
                            
                </el-row>
                <!-- 下面的div是用来显示原始的未筛选的分页条 -->
                <el-pagination v-if="listNum>10" style="text-align:right;"
                                background
:page-size=10
                                :total="listNum"
                                :current-page.sync="currentPage"
                                layout="total, prev, pager, next">
                </el-pagination>
        </div>

	</div>
</template>

<script>
import tj0huifu from '../tijiao/tj_huifu';
import fanwei from '../fujian/fanwei';
import zhankai0 from '../fujian/zhankai0';

	export default {
		name: 'tj_guanlian',
        components: {tj0huifu,fanwei,zhankai0},
        props:['zhid','zhititle','zhitype','fanwei'],
		data () {
			return {
                return_id:0,//这个return_id是用户添加评论成功之后，
                show_dialog:false,   
                show_xhgl:false,
                blinkyellow:'',
                xhgls:[],
                currentPage: 1,//当前分页的数值
                listNum:0,//分页总条数
                zhitype:'',
                ok_msg:9,
                item1id:'',
                gl_att:'待定',
                fuyan:'',
                shuaxinyn:0

            }
            
        },
        
        computed: {
            lists(){
                let pages=Math.ceil(this.listNum/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                    let sonList=[];
                    sonList=this.xhgls.slice(i*10,i*10+10);//10为每页设置数量
                    newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
            
        },

		methods: {
            f_blod() {document.execCommand ( 'bold', false );},
            
            onPaste: function(e) {
                    e.preventDefault()
                    e.stopPropagation()
                    let pasteValue = (e.clipboardData || window.clipboardData).getData('text/plain')
                    console.log(pasteValue)
                    var re = /<[^>]+>/gi;
                    pasteValue = pasteValue.replace(re, '').replace(/\s+|[\r\n]/g,"");
                    e.target.textContent += pasteValue
                },
            fabujian() {
                // 这里需要判断，
                var that = this;
                that.zhid=Number(that.zhid);
                that.item1id=Number(that.item1id);

                        if(that.zhid===that.item1id){
                            that.ok_msg=2;
                            setTimeout(function(){that.ok_msg=0;}, 2000);
                        }
                        if(that.$refs.contents.innerHTML==='请输入关联附言。'){that.fuyan='无'}
                        else{that.fuyan=that.$refs.contents.innerHTML}
                                that.axios
                                .post('http://www.zhishiren.info/api/ooguanlian/',{
                                    userid: that.$cookies.get('userid'),
                                    username:that.$cookies.get('username'),
                                    gl_content:that.fuyan,
                                    gl_att:that.gl_att,
                                    zhid:that.zhid,
                                    zhititle:that.zhititle,
                                    zhitype:that.zhitype,
                                    item1id:that.item1id,
                                    fanwei:that.fanwei
                                    })
                                .then(function (response) {
                                    if (response.data.ok_id === 0){
                                        that.ok_msg=1;
                                        that.return_id = response.data.rrid;
                                        setTimeout(function(){that.ok_msg=0;}, 2000);
                                        that.$refs.contents.innerHTML='请输入关联附言。';
                                        that.show_dialog=false;
                                        that.show_xhgl=true;
                                        that.$refs.zhankai0.addnew();
                                        that.$nextTick(() => {
                                            that.$axios
                                                .post('http://www.zhishiren.info/api/xunhuangl/',{zhid: that.zhid,item1id:that.item1id})
                                                .then(response=>{
                                                                that.xhgls=JSON.parse(response.data);
                                                                that.listNum=that.xhgls.length;
                                                                that.currentPage=1;
                                                                that.blinkyellow='blinkyellow';
                                                                setTimeout(function(){that.blinkyellow='';}, 2000);
                                                });
                                        });
                                    }
                                    if (response.data.ok_id === 2){
                                        that.ok_msg=3;
                                        setTimeout(function(){that.ok_msg=0;}, 2000);
                                        that.$refs.contents.innerHTML='请输入关联附言。';
                                    }
                                    if (response.data.ok_id === 1){
                                        that.ok_msg=4;
                                        setTimeout(function(){that.ok_msg=0;}, 2000);
                                        that.$refs.contents.innerHTML='请输入关联附言。';
                                    }
                                });
                        
                
            },

			f_blod() {
                document.execCommand ( 'bold', false );
                document.execCommand ( 'backColor', false, 'yellow' );
			},

			pinglunjian(){
				this.show_dialog=true;
            },

            zhankaijian(){
                this.show_xhgl=true;
                this.$axios
                .post('http://www.zhishiren.info/api/xunhuangl/',{zhid: this.zhid,item1id:this.item1id})
                .then(response=>{
                    this.xhgls=JSON.parse(response.data);
                    this.listNum=this.xhgls.length;});
            },

            shanok(){
                this.$nextTick(() => {
                    this.$axios
                    .post('http://www.zhishiren.info/api/xunhuangl/',{zhid: this.zhid,item1id:this.item1id})
                    .then(response=>{
                        this.xhgls=JSON.parse(response.data);
                        this.listNum=this.xhgls.length;});
                });
            },

            shuaxinjian(){
                this.$nextTick(() => {
                    this.shuaxinyn=1;
                    this.$axios
                    .post('http://www.zhishiren.info/api/xunhuangl/',{zhid: this.zhid})
                    .then(response=>{
                        this.shuaxinyn=0;
                        this.xhgls=JSON.parse(response.data);
                        this.listNum=this.xhgls.length;});
                });
            },
        },
        
        watch: {
                zhid: function(newVal,oldVal){
                this.zhi_id = newVal;
                var that = this;
                that.axios
                .post('http://www.zhishiren.info/api/countgl/', {zhid:that.zhi_id})
                .then(response=>{that.listNum=response.data});
                },
        },

	}
</script>

