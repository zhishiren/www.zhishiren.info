<template>
    <div id="z62">
        <el-row style="color:red;" class="font20px">仅供展示相关理念,没有实物</el-row>
		<el-row>
			<el-col :span="10">
					<el-image
						src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/z61a.jpg"
						:fit="fill">
					</el-image>
			</el-col>
			<el-col :span="14">
				<div class="huanhang">
					<b class="font20px">全营养速成食品<br></b>	
			</div>
			</el-col>
		</el-row>
		<br>
		<el-row>
			<el-col :span="14">
				<div class="huanhang">
					<b class="font20px">多口味调味粉</b>		
					<br>
				</div>
			</el-col>
			<el-col :span="10">
					<el-image
						src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/z61b.jpg"
						:fit="fill">
					</el-image>
			</el-col>
		</el-row>
    </div>
</template>

<script>
    export default {
        name:'z62',
        props:[],
        data() {return {

        }},
        computed:{

        },
        methods:{
            
        },
    };
</script>



