<template>
	<div id="xh2x">
        <zu1caozuojishu 
            :zone_id="zoneid" :jishu="listNum" :listNumk="listNumk" 
            :showloading1="showloading1" :showloading2="showloading2" 
            @send_searchword="send_searchword" @zhankai="zk" @shuaxin="shuaxin" @huanyuan="huanyuan"></zu1caozuojishu>  
        <div v-show="show_xh2x && showloading2===false">
            <el-row class="br10px17px" v-for="list in lists" :key="list.pk">
                <zu1editfy :lll="list" :kkk='k'></zu1editfy>
            </el-row>
            <br>
            <el-pagination v-if="listNum>10" style="text-align:right;"
                            background
                            :page-size=10
                            :total="listNum"
                            :current-page.sync="currentPage"
                            layout="total, prev, pager, next">
            </el-pagination>
        </div>
        <div v-show="show_xhk2x && showloading2===false">
            <el-row class="br10px17px" v-for="listk in listks" :key="listk.pk">
                <zu1editfy :lll="listk" :kkk='k'></zu1editfy>
            </el-row>
            <br>
            <el-pagination v-if="listNumk>10" style="text-align:right;"
                            background
                            :page-size=10
                            :total="listNumk"
                            :current-page.sync="currentPagek"
                            layout="total, prev, pager, next">
            </el-pagination>
        </div>
    </div>
</template>

<script>

import zu1editfy from '../zujian1/zu1editfy.vue';

export default {
    name:'xh2x',
    components: {zu1editfy},
    props:['listNum','zoneid'],
    // zoneid是用来区分不同类型的组件，
    
	data() {return {
        currentPage: 1,//当前分页的数值
        // listNum:0,//分页总条数
        currentPagek: 1,//查找后，当前分页的数值
        listNumk:0,//查找后，分页总条数

        show_xh2x:false,
        show_xhk2x:false,
        xh2xs:[],
        xh2xks:[],
        k:'',
        showloading2:false,
        showloading1:false,

    }},

	computed: {
            lists(){
                let pages=Math.ceil(this.listNum/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                    let sonList=[];
                    sonList=this.xh2xs.slice(i*10,i*10+10);//10为每页设置数量
                    newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
            listks(){
                let pages=Math.ceil(this.listNumk/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                    let sonList=[];
                    sonList=this.xh2xks.slice(i*10,i*10+10);//10为每页设置数量
                    newList.push(sonList)
                }
                return newList[this.currentPagek-1]
            },
    },
    
	methods:{
      send_searchword(data){
          this.show_xh2x=false;
          this.show_xhk2x=true;
          this.k=data.k;
　　　　　　var newList = [];
　　　　　　this.xh2xs.forEach(item=>{if(item.fields.title0.indexOf(this.k) !==-1||item.fields.fy.indexOf(this.k) !==-1){newList.push(item)}});
          this.listNumk = newList.length;//这里是计算筛选后的结果的数量
　　　　　　this.xh2xks = newList;
      },

      zk(){this.shuaxin();},

      huanyuan(){
          this.shuaxin();
          this.k='';
        },

      shuaxin(){
           this.showloading2=true;
            this.show_xh2x=true;
            this.show_xhk2x=false;
            this.$axios
            .post('http://www.zhishiren.info/api/xunhuan2x/', {
                userid:this.$cookies.get('userid'),
                zoneid:this.zoneid})
            .then(response=>{
                this.xh2xs=JSON.parse(response.data);
                this.listNum=this.xh2xs.length;
                this.showloading2=false;
            });
      },
    },	


};
</script>

