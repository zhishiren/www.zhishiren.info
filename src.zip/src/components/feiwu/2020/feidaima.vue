<div v-show="show_input">
			<el-row style="line-height: 40px;" >
				<el-col :span="2" >
					<span >评论态度：</span>
				</el-col>
				<el-col :span="6" >
					<el-select v-model="att_value" placeholder="请选择发言态度" style="width:90%;">
						<el-option value="att0" key="att0" label="无态度"></el-option>
						<el-option value="att4" key="att4" label="吐槽异议"></el-option>
						<el-option value="att5" key="att5" label="点赞支持"></el-option>
						<el-option value="att6" key="att6" label="疑惑不解"></el-option>
					</el-select>
				</el-col>
				<!-- 这提醒谁看的功能，是写到news表中，但不用写入言论表中。 -->
				<el-col :span="2" >
					<span >是否匿名：</span>
				</el-col>
				<el-col :span="6" >
					<el-select v-model="niming" placeholder="请选择是否匿名" style="width:90%;">
						<el-option value="0" key="0" label="不需匿名"></el-option>
						<el-option value="1" key="1" label="我要匿名"></el-option>
					</el-select>
				</el-col>
				<el-col :span="2" >
					<span>公开范围：</span>
				</el-col>
				<el-col :span="6" >
					<fanwei  ref="huanyuan" @set_fanwei="set_gongkaifanwei" style="width:90%;"></fanwei>
				</el-col>
			</el-row>
			<br>
			<el-row >
					<el-col :span="2" >
						<span class="font16px">发言内容：</span>
					</el-col>
					<el-col :span="20" >
						<div contenteditable ref="contents" @paste="onPaste" class="pinglunlan" style="font-size:16px;width:100%;">
						</div>
					</el-col>
					<el-col :span="2">
						<a class="a_black" href="javascript:;" @click="f_blod">
							<b>所选加粗</b>
						</a>
					</el-col>
			</el-row>
			<el-row  style="line-height: 40px;padding-left:450px;">
                    <a class="font20px a_black"  @click="fabujian">发布</a>
                    <span style="color:green;" v-show="ok_msg==1"><i class="el-icon-success"></i>发布成功!</span>
                    <span style="color:orange;" v-show="ok_msg==2"><i class="el-icon-warning-outline"></i>群组名不能为空!</span>
                    <span style="color:red;" v-show="ok_msg==3"><i class="el-icon-error"></i>数据库写入失败!</span>
        	</el-row>
		</div>





		<div v-show="show_input">
			<el-row style="line-height: 40px;" >
				<el-col :span="2" >
					<span >关联ID号：</span>
				</el-col>
				<el-col :span="6" >
                	<el-input v-model="input" placeholder="请输入关联知识点的ID号"  style="width:90%;"></el-input>
				</el-col>
				<!-- 这提醒谁看的功能，是写到news表中，但不用写入言论表中。 -->
				<el-col :span="2" >
					<span >相关关系：</span>
				</el-col>
				<el-col :span="6" >
					<el-select v-model="att_value" placeholder="请选择发言态度" style="width:90%;">
						<el-option value="att0" key="att0" label="无态度"></el-option>
						<el-option value="att4" key="att4" label="吐槽异议"></el-option>
						<el-option value="att5" key="att5" label="点赞支持"></el-option>
						<el-option value="att6" key="att6" label="疑惑不解"></el-option>
					</el-select>
				</el-col>
				<el-col :span="2" >
					<span>公开范围：</span>
				</el-col>
				<el-col :span="6" >
					<fanwei  ref="huanyuan" @set_fanwei="set_gongkaifanwei" style="width:90%;"></fanwei>
				</el-col>
			</el-row>
			<br>
			<el-row >
					<el-col :span="2" >
						<span class="font16px">发言内容：</span>
					</el-col>
					<el-col :span="20" >
						<div contenteditable ref="contents" @paste="onPaste" class="pinglunlan" style="font-size:16px;width:100%;">
						</div>
					</el-col>
					<el-col :span="2">
						<a class="a_black" href="javascript:;" @click="f_blod">
							<b>所选加粗</b>
						</a>
					</el-col>
			</el-row>
			<el-row  style="line-height: 40px;">
				<el-col :span="13">
					<el-upload
						class="upload-demo"
						ref="upload"
						:data={user_id:this.user_id}
						multiple
						action="http://www.zhishiren.info/api/zeng_fayan_fujian/"
						Access-Control-Request-Headers: ContentType
						style="text-align:right;"
						:on-preview="handlePreview"
						:on-remove="handleRemove"
						:file-list="fileList"
						:on-success="shuaxinyemian"
						:auto-upload="false">
						<!-- <span slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</span> -->
						<el-button style="font-size:16px;" slot="trigger" size="small" type="text">添加附件...
						</el-button><el-divider direction="vertical"></el-divider><!--
						--><a class="font20px a_black"  @click="submitUpload">发布</a>
					</el-upload>
				</el-col>
				<el-col :span="11">
					<span style="color:green" v-show="ok_msg==0">
						<i class="el-icon-circle-check">发布成功!</i>
					</span>
					<span style="color:orange" v-show="ok_msg==1">
						<i class="el-icon-warning-outline">发布内容不能为空!</i>
					</span>
					<span style="color:red" v-show="ok_msg==2">
						<i class="el-icon-error">数据库写入失败!</i>
					</span>
					<span style="color:orange" v-show="ok_msg==3">
						<i class="el-icon-warning">只能上传jpg/rar/zip文件，且不超过1MB!</i>
					</span>
				</el-col>
				<br><br>
			</el-row>
		</div>
