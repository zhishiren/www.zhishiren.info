<template>
	<div id="xhzuyuan">
        <zu1caozuojishu 
            zone_id="邀请" :jishu="listNum" :listNumk="listNumk" 
            :zhid="qzid" :title0="qztitle" type0='qunzuye'
            :showloading1="showloading1" :showloading2="showloading2" 
            :managerid="managerid"
            @send_searchword="send_searchword" @zhankai="zk" @shuaxin="shuaxin" @huanyuan="huanyuan">
        </zu1caozuojishu>  
        <div v-show="show_xhzy && showloading2===false">
            <el-row class="br10px17px" v-for="list in lists" :key="list.pk">
                <el-row>
                    <router-link class="a_black" target="_blank" :to="{name:'yonghuye',params:{id:list.fields.uid0}}">
                        <span>{{list.fields.uname}}</span>
                    </router-link>
                    <span v-if="manager_yn===true && list.fields.fystatus==='正常有效'">
                        <span style="color:green;"><el-divider direction="vertical"></el-divider>{{list.fields.fystatus}}</span>
                        <span><el-divider direction="vertical"></el-divider><el-button @click="reject_zuyuan(list.pk)" type="text" class="font16px" style="padding:0px;"><i class="el-icon-close"></i>拒绝</el-button></span>
                    </span>
                    <span v-if="manager_yn===true && list.fields.fystatus!=='正常有效'">
                        <span style="color:orange;"><el-divider direction="vertical"></el-divider>{{list.fields.fystatus}}</span>
                        <span><el-divider direction="vertical"></el-divider><el-button @click="pass_zuyuan(list.pk)" type="text" class="font16px" style="padding:0px;"><i class="el-icon-check"></i>接受</el-button></span>
                    </span>
                </el-row>
                <el-row v-if="list.fields.fystatus==='正常有效'">
                    <span style="color:grey">入群附言：</span>{{list.fields.fy}}
                </el-row>
                <el-row v-if="list.fields.fystatus!=='正常有效'">
                    <span style="color:grey">入群附言：</span>{{list.fields.fyshen}}
                </el-row>
                <el-row><el-divider style="margin:0px;"></el-divider></el-row>

            </el-row>
            <br>
            <el-pagination v-if="listNum>10" style="text-align:right;"
                            background
                            :page-size=10
                            :total="listNum"
                            :current-page.sync="currentPage"
                            layout="total, prev, pager, next">
            </el-pagination>
        </div>
        <div v-show="show_xhkzy && showloading2===false">
            <el-row class="br10px17px" v-for="listk in listks" :key="listk.pk">
                <el-row>
                    <router-link class="a_black" target="_blank" :to="{name:'yonghuye',params:{id:list.fields.uid0}}">
                        <span v-html="gaoliangk(listk.fields.uname, k)"></span>
                    </router-link>
                    <span v-if="manager_yn===true && listk.fields.fystatus==='正常有效'">
                        <span style="color:green;"><el-divider direction="vertical"></el-divider>{{listk.fields.fystatus}}</span>
                        <span><el-divider direction="vertical"></el-divider><el-button @click="reject_zuyuan(listk.pk)" type="text" class="font16px" style="padding:0px;"><i class="el-icon-close"></i>拒绝</el-button></span>
                    </span>
                    <span v-if="manager_yn===true && listk.fields.fystatus!=='正常有效'">
                        <span style="color:orange;"><el-divider direction="vertical"></el-divider>{{listk.fields.fystatus}}</span>
                        <span><el-divider direction="vertical"></el-divider><el-button @click="pass_zuyuan(listk.pk)" type="text" class="font16px" style="padding:0px;"><i class="el-icon-check"></i>接受</el-button></span>
                    </span>
                </el-row>
                <el-row v-if="listk.fields.fystatus==='正常有效'">
                    <span style="color:grey">入群附言：</span>
                    <span v-html="gaoliangk(listk.fields.fy, k)"></span>
                </el-row>
                <el-row v-if="listk.fields.fystatus!=='正常有效'">
                    <span style="color:grey">入群附言：</span>
                    <span v-html="gaoliangk(listk.fields.fyshen, k)"></span>
                </el-row>
            </el-row>
            <br>
            <el-pagination v-if="listNumk>10" style="text-align:right;"
                            background
                            :page-size=10
                            :total="listNumk"
                            :current-page.sync="currentPagek"
                            layout="total, prev, pager, next">
            </el-pagination>
        </div>
    </div>
</template>

<script>


export default {
    name:'xhzuyuan',
    components: {},
    props:['qzid','qztitle','managerid','listNum'],
    // zoneid是用来区分不同类型的组件，
	data() {return {
        currentPage: 1,//当前分页的数值
        // listNum:0,//分页总条数
        currentPagek: 1,//查找后，当前分页的数值
        listNumk:0,//查找后，分页总条数

        show_xhzy:false,
        show_xhkzy:false,
        xhzys:[],
        xhzyks:[],
        k:'',
        showloading2:false,
        showloading1:false,

    }},

	computed: {
            lists(){
                let pages=Math.ceil(this.listNum/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                    let sonList=[];
                    sonList=this.xhzys.slice(i*10,i*10+10);//10为每页设置数量
                    newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
            listks(){
                let pages=Math.ceil(this.listNumk/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                    let sonList=[];
                    sonList=this.xhzyks.slice(i*10,i*10+10);//10为每页设置数量
                    newList.push(sonList)
                }
                return newList[this.currentPagek-1]
            },
            manager_yn(){return parseInt(this.managerid)===parseInt(this.$cookies.get('userid'))},
    },
    
	methods:{
      send_searchword(data){
          this.show_xhzy=false;
          this.show_xhkzy=true;
          this.k=data.k;
　　　　　　var newList = [];
　　　　　　this.xhzys.forEach(item=>{if(item.fields.uname.indexOf(this.k)!==-1||item.fields.fy.indexOf(this.k)!==-1||item.fields.fyshen.indexOf(this.k)!==-1){newList.push(item)}});
          this.listNumk = newList.length;//这里是计算筛选后的结果的数量
　　　　　　this.xhzyks = newList;
      },

      zk(){this.shuaxin();},

      huanyuan(){
          this.show_xhzy=true;
          this.show_xhkzy=false;
          this.k='';
        },

      shuaxin(){
            this.showloading2=true;
            this.show_xhzy=true;
            this.show_xhkzy=false;
            this.$axios
            .post('http://www.zhishiren.info/api/xunhuan_zuyuan/', {
                manager_yn:this.manager_yn,
                qzid:this.qzid})
            .then(response=>{
                this.xhzys=JSON.parse(response.data);
                this.listNum=this.xhzys.length;
                this.showloading2=false;
            });
      },
      pass_zuyuan(kkk){
        this.$axios
        .post('http://www.zhishiren.info/api/change_caozuo/', {czid:kkk,czxxx:'正常有效'})
        .then(response=>{
            this.shuaxin();});
      },
      reject_zuyuan(kkk){
        this.$axios
        .post('http://www.zhishiren.info/api/change_caozuo/', {czid:kkk,czxxx:'已被拒绝'})
        .then(response=>{
            this.shuaxin();});
      },


    },	
    

};
</script>

