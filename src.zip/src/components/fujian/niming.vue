<!-- 这是转换为匿名或者用户名的功能-->
<template>
    <span id="niming">
        <span v-if="niming_yn==='匿名' && createrid===userid">你<span>(匿名)</span></span>
        <span v-if="niming_yn==='匿名' && createrid!==userid">匿名</span>
        <span v-if="niming_yn!=='匿名'">
            <router-link class="a_black" target="_blank" :to="{name:'yonghuye',params:{id:createrid}}">{{creatername}}</router-link>
        </span>
    </span>
</template>
<script>
export default {
    name:'niming',
    props:['niming_yn','createrid','creatername'],
	data() {return {}},
    methods:{},
    computed: {userid(){return parseInt(this.$cookies.get('userid'))},},
};
</script>



