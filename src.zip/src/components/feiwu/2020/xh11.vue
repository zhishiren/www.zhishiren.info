// 参考https://www.cnblogs.com/zhuchenglin/p/6841990.html，设计一个依靠屏幕高度的下拉菜单
// 从mongoengine取出来的数据，用{{xh11._id.$oid}}来调阅。前提是在flask后台要引用bson.objectid
// 这是原稿，其中可以展示用户头像的那稿，待时机成熟后完成。
<template>
		<transition name="el-zoom-in-top">
			<div>
				<el-row v-show="show_xh11" v-for="xh11 in this.$store.state.XH11" :key="xh11.creater_id"  style="padding-top:5px;">
						<el-col :span="1">
							<router-link target="_blank" :to="{name:'yonghuye',params:{id:1}}">
								<img :src="require('../../../public/header_image/'+xh11.creater_id+'.jpg')" alt="" class="header_image">
							</router-link>
						</el-col>
						<el-col :span="22" style="padding-left:5px;">
							<el-row>
								<el-col :span="23">
									<router-link target="_blank" class="a_noline_black" :to="{name:'yonghuye',params:{id:1}}">
										{{xh11.creater_name}}
									</router-link>
									分享了文章/段落/标签/用户？
								</el-col>
								<el-col :span="1">			
									<tj0shanchu></tj0shanchu>
								</el-col>
							</el-row>
							<el-row>
								<router-link class="a_noline_black" target="_blank" :to="{name:'wenjiye',params:{wenji_id:1}}">
										{{xh11.news_item1title}}
								</router-link>
								附言:{{xh11.news_comm}}<tj0huifu></tj0huifu>
							</el-row>
						</el-col>
						<el-col :span="1">{{formatDate_hm(xh11.news_createtime.$date)}}</el-col>
				</el-row>

				<el-row v-show="show_xhk11" v-for="xh_k_11 in search(this.keyword11,this.xh11s)" :key="xh_k_11.creater_id"  style="padding-top:5px;">
					<div>		
						<el-col :span="1">
							<router-link target="_blank" :to="{name:'yonghuye',params:{id:1}}">
								<img :src="require('../../../public/header_image/'+xh_k_11.creater_id+'.jpg')" alt="" class="header_image">
							</router-link>
						</el-col>
						<el-col :span="22" style="padding-left:5px;">
							<el-row>
								<el-col :span="23">
									<router-link target="_blank" class="a_noline_black" :to="{name:'yonghuye',params:{id:1}}">
										{{xh_k_11.creater_name}}
									</router-link>
									分享了
								</el-col>
								<el-col :span="1">
									<tj0shanchu></tj0shanchu>
								</el-col>
							</el-row>
							<el-row>
								<router-link class="a_noline_black" target="_blank" :to="{name:'wenjiye',params:{wenji_id:1}}">
										<span v-html="gaoliangk(xh_k_11.news_item1title, keyword11)" ></span>
								</router-link>
								附言:<span v-html="gaoliangk(xh_k_11.news_comm, keyword11)" ></span><tj0huifu></tj0huifu>
							</el-row>
						</el-col>
						<el-col :span="1">{{formatDate_hm(xh_k_11.news_createtime.$date)}}</el-col>
					</div>

				</el-row>
			</div>
		</transition>
</template>

<script>
import tj0shanchu from '../tijiao/tj_shanchu';
import tj0huifu from '../tijiao/tj_huifu';

export default {
	components: {tj0shanchu,tj0huifu},
	data() {return {}},
	filters: {},
	computed: {
    keyword11(){return this.$store.state.KEYWORD11},
    show_xh11(){return this.$store.state.SHOW_XH11},
    show_xhk11(){return this.$store.state.SHOW_XHK11},
    xh11s(){return this.$store.state.XH11},
	// xh_k_11s(){return this.$store.state.XH11},
	},
	methods:{},	
};
</script>

<style>
</style>


