<template>
<div>
             <el-select v-model="qz_id" @focus="show_qzlist" @change="send_fanwei_qunzuid(qz_id)" placeholder="请选择"  style="width:100%;">
                <el-option
                  v-for="item in lists"
                  :key="item.qz_id"
                  :label="item.qz_title"
                  :value="item.qz_id">
                </el-option>

            </el-select> 
</div>

</template>

<script>
  export default {
    data() {
      return {
            lists: [{qz_id:80000000,qz_title:"--仅本人--"},
                    {qz_id:90000000,qz_title:"--所有人--"}],
            qz_id:90000000,
      }
    },

    methods:{
      send_fanwei_qunzuid(qz_id){
        let data = {
          qz_id: this.qz_id
        };
        this.$emit('set_fanwei',data);

      },
      huanyuan(){
        this.lists=[{qz_id:80000000,qz_title:"--仅本人--"},
                    {qz_id:90000000,qz_title:"--所有人--"}];
        this.qz_id=90000000;
      },
      // 这是设计在fanwei组件点击时触发询问群组列表
      show_qzlist(){
        var that = this;
        that.axios
        .post('http://www.zhishiren.info/api/listmyqunzu/', {userid: that.$cookies.get('userid')})
        .then(response=>{
          that.lists=response.data;
          });
      },
    },
    // created: function () {
    //     this.lists=[{qz_id:80000000,qz_title:"--仅本人--"},
    //                 {qz_id:90000000,qz_title:"--所有人--"}];
    //     this.qz_id=80000000;
    // },

  }
</script>