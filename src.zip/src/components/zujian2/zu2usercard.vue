<template>
    <div id="zu2usercard">
        <el-card class="box-card">
            <el-col v-if="userinfo.yonghu_touxiang===1" :span="5" style="text-align:center;background-size:100% 100%;height:260px;">
                <div v-if="show_touxiang1===false" style="padding-top:100px;" class="a_grey font18px">
                    <a @click="showtouxiang1()">
                        <i class="el-icon-s-custom" style="font-size:30px;"></i>
                        <br>
                        查看头像
                    </a>
                </div>
                <img v-if="show_touxiang1===true" alt="" :src="timestamp('https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/touxiang/'+this.userinfo.yonghu_id+'.jpg')" style="width:100%;height:250px;">
            </el-col>
            <el-col v-if="userinfo.yonghu_touxiang===0" :span="5" style="background-size:100% 100%;height:260px;text-align:center;padding-top:100px;">
                <i class="el-icon-user" style="font-size:30px;"></i>
                <br>
                尚无头像
            </el-col>
            <el-col :span="19">
                <div v-if="userinfo.yonghu_type==='普通用户' || userinfo.yonghu_type==='内容整理'" class="font18px_gray section_userinfo">
                    <span>名称类型：</span>
                    <span class="font18px_black">{{this.userinfo.yonghu_name}}<el-divider direction="vertical"></el-divider>{{this.userinfo.yonghu_type}}</span>
                    <br>

                    <!-- <span>用户类型：</span>
                    <span class="font18px_black">{{this.userinfo.yonghu_type}}</span>
                    <br> -->

                    <span>用户ID号：</span>
                    <span class="font18px_black">{{this.userinfo.yonghu_id}}</span>
                    <span v-if="mypage_yn===false"><el-divider direction="vertical"></el-divider></span>
                    <span v-if="mypage_yn===false">
                        <router-link class="a_grey" target="_blank" :to="{name:'liao',params:{id:this.userinfo.yonghu_id}}">          
                            <span>聊TA</span>
                        </router-link>
                    </span>
                    <br>

                    <span>注册时间：</span>
                    <span class="font18px_black">{{getNowFormatDate(this.userinfo.yonghu_borntime)}}</span>
                    <br>

                    <span>上次登录：</span>
                    <span class="font18px_black">{{getNowFormatDate(this.userinfo.yonghu_updatetime)}}</span>
                    <br>

                    <span>行业岗位：</span>
                    <zu0z41edituserinfo @freshinfo="freshinfo" :inputzhi0="userinfo.yonghu_job" :id="userinfo.yonghu_id" length=20 type="1" inputzhi1="请输入你所属的行业岗位，如金融-银行-内审" ></zu0z41edituserinfo>
                    <br>

                    <span>国家地区：</span>
                    <zu0z41edituserinfo @freshinfo="freshinfo" :inputzhi0="userinfo.yonghu_area" :id="userinfo.yonghu_id" length=15 type="2" inputzhi1="请输入你所属的地区，如江苏-南京" ></zu0z41edituserinfo>
                    <br>

                    <span>联系方式：</span>
                    <zu0z41edituserinfo @freshinfo="freshinfo" :inputzhi0="userinfo.yonghu_contact" :id="userinfo.yonghu_id" length=17 type="3" inputzhi1="请输入你的联系方式，如邮箱或微信号" ></zu0z41edituserinfo>
                    <br>

                    <span>爱好特长：</span>
                    <zu0z41edituserinfo @freshinfo="freshinfo" :inputzhi0="userinfo.yonghu_hobby" :id="userinfo.yonghu_id" length=9 type="4" inputzhi1="请输入你的兴趣爱好" ></zu0z41edituserinfo>
                    <br>

                    <span>个人签名：</span>
                    <zu0z41edituserinfo @freshinfo="freshinfo" :inputzhi0="userinfo.yonghu_remark" :id="userinfo.yonghu_id" length=14 type="5" inputzhi1="请输入你的个人签名，限20个字" ></zu0z41edituserinfo>
                    <br>

                    <span>数据统计：</span>
                    <span class="font18px" style="color:green">
                        <span>被来访{{this.userjishu.dianji}}<el-divider direction="vertical"></el-divider></span>
                        <span>被关注{{this.userjishu.guanzhu}}<el-divider direction="vertical"></el-divider></span>
                        <span>被分享{{this.userjishu.fenxiang}}</span>
                    </span>						
                </div>

                <div v-if="userinfo.yonghu_type==='人物名片'"  class="font18px_gray section_userinfo">
                    
                    <span>名称类型：</span>
                    <span class="font18px_black">{{this.userinfo.yonghu_name}}
                        <!-- <el-divider direction="vertical"></el-divider>{{this.userinfo.yonghu_type}} -->
                    </span>
                    <br>
                    
                    <span>用户ID号：</span>
                    <span class="font18px_black">{{this.userinfo.yonghu_id}}</span>
                    <br>

                    <span>生卒年月：</span>
                    <span class="font18px_black">{{this.userinfo.yonghu_born}}</span>
                    <br>

                    <span>职业身份：</span>
                    <zu0z41edituserinfo @freshinfo="freshinfo" :inputzhi0="userinfo.yonghu_job" :id="userinfo.yonghu_id" length=20 type="1" inputzhi1="请输入你所属的行业岗位，如金融-银行-内审" ></zu0z41edituserinfo>
                    <br>

                    <span>国家地区：</span>
                    <zu0z41edituserinfo @freshinfo="freshinfo" :inputzhi0="userinfo.yonghu_area" :id="userinfo.yonghu_id" length=15 type="2" inputzhi1="请输入你所属的地区，如江苏-南京" ></zu0z41edituserinfo>
                    <br>

                    <span>人物名言：</span>
                    <zu0z41edituserinfo @freshinfo="freshinfo" :inputzhi0="userinfo.yonghu_remark" :id="userinfo.yonghu_id" length=14 type="5" inputzhi1="请输入你的个人签名，限20个字" ></zu0z41edituserinfo>
                    <br>

                    <span>数据统计：</span>
                    <span class="font18px" style="color:green">
                        <span>被来访{{this.userjishu.dianji}}<el-divider direction="vertical"></el-divider></span>
                        <span>被关注{{this.userjishu.guanzhu}}<el-divider direction="vertical"></el-divider></span>
                        <span>被分享{{this.userjishu.fenxiang}}</span>
                    </span>	
                    <br>

                    <!-- 职业生涯+目前状态+联系方式 -->
                    <span>生平介绍：</span>
                    <zu0z41edituserinfo @freshinfo="freshinfo" :inputzhi0="userinfo.yonghu_life" :id="userinfo.yonghu_id" length=15 type="6" inputzhi1="请输入生平事迹，限120字" ></zu0z41edituserinfo>		
                </div>

    

                <div v-else-if="userinfo.yonghu_type==='工团组织'" class="font18px_gray" style="height:250px;padding-left:10px;">
                    
                    <span>组织名称：</span>
                    <span class="font18px_black">{{this.userinfo.yonghu_name}}<el-divider direction="vertical"></el-divider>左翼组织</span>
                    <br>

                    <span>用户ID号：</span>
                    <span class="font18px_black">{{this.userinfo.yonghu_id}}</span>
                    <br>

                    <span>地区行业：</span>
                    <zu0z41edituserinfo @freshinfo="freshinfo" :inputzhi0="userinfo.yonghu_area" :id="userinfo.yonghu_id" length=15 type="2" inputzhi1="请输入你所属地区行业，如江苏南京" ></zu0z41edituserinfo>
                    <br>

                    <span>联系方式：</span>
                    <zu0z41edituserinfo @freshinfo="freshinfo" :inputzhi0="userinfo.yonghu_contact" :id="userinfo.yonghu_id" length=17 type="3" inputzhi1="请输入你的联系方式，如邮箱或微信号" ></zu0z41edituserinfo>
                    <br>

                    <span>数据统计：</span>
                    <span class="font18px" style="color:green">
                        <span>被来访{{this.userjishu.dianji}}<el-divider direction="vertical"></el-divider></span>
                        <span>被关注{{this.userjishu.guanzhu}}<el-divider direction="vertical"></el-divider></span>
                        <span>被分享{{this.userjishu.fenxiang}}</span>
                    </span>
                    <br>

                    <span>组织介绍：</span>
                    <zu0z41edituserinfo @freshinfo="freshinfo" :inputzhi0="userinfo.yonghu_life" :id="userinfo.yonghu_id" length=15 type="6" inputzhi1="请输入组织介绍，限120字" ></zu0z41edituserinfo>		
                </div>
            </el-col>
        </el-card>
    </div>
</template>

<script>
    export default {
        name:'zu2usercard',
        props:['userinfo','userjishu'],//
        data() {return {
            show_touxiang1:false,
        }},
        computed:{
            userid(){return this.$cookies.get('userid')},
            mypage_yn(){return parseInt(this.$cookies.get('userid'))===this.userinfo.yonghu_id}
            //这个mypage_yn是用来区分是自己的页面还是其他用户的页面
        },
        methods:{
            showtouxiang1(){
				this.show_touxiang1=false;
				this.show_touxiang1=true;
		    },
            freshinfo(){
                var _this= this;
                _this.axios
                .post('http://www.zhishiren.info/api/show_yonghuye/', {
                    userid:_this.userinfo.yonghu_id,
                    kkk:_this.mypage_yn
                })
                .then(function (response) {
                    _this.userinfo=response.data;
                    _this.userjishu=JSON.parse(response.data.yh_tongji)
                });
            },

        },

    };
</script>



