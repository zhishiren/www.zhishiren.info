<template>
           <el-select v-model="kkkvalue" @change="to_gongkaifanwei(kkkvalue)" placeholder="请选择">
              <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select> 
          </template>

<script>
  export default {


    data() {
      return {
            options: [{value: 1,label: '仅本人'},
                      {value: 9,label: '所有人'}],
            kkkvalue:1
      }
    },

    created(){
        var that = this;
        this.axios({
            method: 'get',
            url: '/api/selectfortags',
        })
        .then(function (response) {
                that.options = that.options.concat(response.data);
                console.log(that.options)
        });
    },

    methods:{
      to_gongkaifanwei(id){
        let data = {
          kkkid: id
        };
        this.$emit('to_fuzujian',data);
      }
    }

  }
</script>