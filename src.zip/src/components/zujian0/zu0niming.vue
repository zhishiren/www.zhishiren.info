<!-- 这是转换为匿名或者用户名的功能-->
<template>
    <span id="zu0niming">
        <!-- <span v-if="uid1===90000000 && uid0===userid">你<span>(匿名)</span></span> -->
        <span style="background-color:yellow;" v-if="uid1===userid">你</span>
        <span v-if="uid1===90000000">匿名</span>
        <span v-if="uid1!==90000000&&uid1!==userid">
            <router-link class="a_black" target="_blank" :to="{name:'yonghuye',params:{id:uid1}}">{{uname}}</router-link>
        </span>
    </span>
</template>
<script>
export default {
    name:'zu0niming',
    props:['uid1','uname'],
	data() {return {}},
    methods:{},
    computed: {userid(){return parseInt(this.$cookies.get('userid'))},},
};
</script>



