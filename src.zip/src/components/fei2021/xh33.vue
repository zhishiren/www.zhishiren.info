<!-- 这是33模块独有的设计，这个模块里能查询所有用户的信息，但因为全部用户数据量较大和保护用户隐私的考虑，所以并不罗列出所有用户的信息，
只罗列出最新注册的用户（最新注册且已经上传了头像的用户）。
当用户搜索相关关键词的时候，后台查询后返回。
-->
<template>
	<div id="xh33">
            <!-- 下面的div是用来显示原始未筛选的列表，通过vshow来控制是否显示 -->
            <el-row class="font18px">
                <span >我共关注了{{this.listNum}}名用户。</span>
				<chazhaolan0 :message="按姓名查找" @shuaxin="shuaxin" @huanyuan="huanyuan" @get_list="get_list" @send_searchword="send_searchword" :listNumk="listNumk"></chazhaolan0>
            </el-row>

            <div v-show="show_xh33" >
                <el-row class="br10px17px" v-for="list in lists" :key="list.pk">
                        <el-row>
                                <b>{{list.fields.yonghu_name}}</b>
                                <el-divider direction="vertical"></el-divider>
                                <span style="color:grey">
                                    <i class="el-icon-close-notification"></i>屏蔽
                                </span>
                        </el-row>
                        <el-row>
                            <span>
                            {{list.fields.yonghu_area?list.fields.yonghu_area:'所属地区:暂无'}}<el-divider direction="vertical"></el-divider><!--
                            -->{{list.fields.yonghu_job?list.fields.yonghu_job:'所属职业:暂无'}}<el-divider direction="vertical"></el-divider>
                            <span style="color:grey">签名:</span>{{list.fields.yonghu_remark?list.fields.yonghu_remark:'暂无'}}
                            </span>
                        </el-row>

                    <el-col :span="24"><el-divider style="margin:0px;"></el-divider></el-col>
                </el-row>
                
                <el-pagination v-if="listNum>10" style="text-align:right;"
                                background
                                :page-size=10
                                :total="listNum"
                                :current-page.sync="currentPage"
                                layout="total, prev, pager, next">
                </el-pagination>
            </div>
            
            <div v-show="show_xhk33">
                <el-row class="br10px17px" v-for="list in listks" :key="list.pk">
                    <el-row>
                            <b>{{list.fields.yonghu_name}}</b>
                            <el-divider direction="vertical"></el-divider>
                            <span style="color:grey">
                                <i class="el-icon-close-notification"></i>屏蔽
                            </span>
                    </el-row>
                    <el-row>
                        <span>
                        {{list.fields.yonghu_area?list.fields.yonghu_area:'所属地区:暂无'}}<el-divider direction="vertical"></el-divider><!--
                        -->{{list.fields.yonghu_job?list.fields.yonghu_job:'所属职业:暂无'}}<el-divider direction="vertical"></el-divider>
                        <span style="color:grey">签名:</span>{{list.fields.yonghu_remark?list.fields.yonghu_remark:'暂无'}}
                        </span>
                    </el-row>

                    <el-col :span="24"><el-divider style="margin:0px;"></el-divider></el-col>
                </el-row>     
                    
                <!-- 下面的div是用来显示筛选后的分页条 -->
                <el-pagination  v-if="listNumk>10" style="text-align:right;"
                                background
                                :page-size=10
                                :total="listNumk"
                                :current-page.sync="currentPagek"
                                layout="total, prev, pager, next">
                </el-pagination>

            </div>
        

    </div>


</template>

<script>
import chazhaolan0 from '../fujian/chazhaolan0';

export default {
    name:'xh33',
    components: {chazhaolan0},
    props:['listNum'],    
	data() {return {
        currentPage: 1,//当前分页的数值
        listNum:0,//分页总条数
        currentPagek: 1,//查找后，当前分页的数值
        listNumk:0,//查找后，分页总条数
        show_xh33:false,
        show_xhk33:false,
        xh33s:[],
        xh33ks:[],
        show_chazhaokong:false,
        show_shuaxin:true,
        show_huanyuan:false,
        show_chazhaolan:false,
        show_zhankai:true,
        zongshu:1,

    }},

    mounted() {
  
    },

    filters: {
    },
    
	computed: {

            lists(){
                let pages=Math.ceil(this.listNum/10);//
                let newList=[];
                for(let i=0;i<pages;i++){
                let sonList=[];
                sonList=this.xh33s.slice(i*10,i*10+10);//
                newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },

            listks(){
                let pages=Math.ceil(this.listNumk/10);//
                let newList=[];
                for(let i=0;i<pages;i++){
                let sonList=[];
                sonList=this.xh33ks.slice(i*10,i*10+10);//
                newList.push(sonList)
                }
                return newList[this.currentPagek-1]
            },
    },
    
	methods:{

      send_searchword(data){
          this.show_xh33=false;
          this.show_xhk33=true;
          this.k=data.k;
　　　　　　　　var newList = [];
　　　　　　　　this.xh33s.forEach(item=>{if(item.fields.item0_title.indexOf(this.k) !==-1){newList.push(item)}});
             this.listNumk = newList.length;//这里是计算筛选后的结果的数量
　　　　　　   this.xh33ks = newList;
      },

      get_list(){
        this.show_xh33=true;
        this.$axios.post('http://www.zhishiren.info/api/xunhuan33/', {userid:this.$cookies.get('userid')})
        .then(response=>{this.xh33s=JSON.parse(response.data);this.listNum=this.xh33s.length;});
      },

      huanyuan(){
            this.show_xh33=true;
            this.show_xhk33=false;
      },
      shuaxin(){
        this.datachange=false;
        this.$nextTick(() => {
            this.$axios.post('http://www.zhishiren.info/api/xunhuan33/', {userid:this.$cookies.get('userid')})
            .then(response=>{this.xh33s=JSON.parse(response.data);this.listNum=this.xh33s.length;});
        });
      },
    },	
};
</script>

<style>
</style>


