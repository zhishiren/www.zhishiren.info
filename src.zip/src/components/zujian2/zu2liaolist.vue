
<template>
    <div id="zu2liaolist">
        <el-row style="font-size:18px;">
          <el-card class="box-card">
            <span v-if="leixing==='90000000'"><input style="color:grey;" type="checkbox" v-model="niming" unchecked>匿名</span>
            <el-dropdown @command="choose_taidu">
							<span class="el-dropdown-link a_grey" style="font-size:17px;"><i class="el-icon-arrow-down el-icon--right"></i>态度</span>
							<el-dropdown-menu slot="dropdown">
								<el-dropdown-item command="点赞支持">点赞支持</el-dropdown-item>
								<el-dropdown-item command="反对异议">反对异议</el-dropdown-item>
								<el-dropdown-item command="疑惑不解">疑惑不解</el-dropdown-item>
							</el-dropdown-menu>
            </el-dropdown>
            <span v-if="taidu==='点赞支持'" style="color:green;">:赞·</span><span v-if="taidu==='反对异议'" style="color:red;">:反·</span><span v-if="taidu==='疑惑不解'" style="color:orange;">:疑·</span><span v-if="taidu===''">·</span>
            <span>引用:<input placeholder="引用知识点ID号" v-model="zhid" type="text" class="input_jian" style="color:grey;width:120px;font-size:16px;" ></span>
            <span>
                <!-- <span v-if="leixing<90000001">·回复<i class="el-icon-caret-right"></i><input placeholder="用户ID号" v-model="hf_yhid" type="text" class="input_jian" style="color:grey;width:80px;font-size:18px;background-color:yellow;" ></span> -->
                <span v-if="leixing==='0'">·回复<i class="el-icon-caret-right"></i>未指定</span>
                <span v-if="leixing!=='90000000' && leixing!=='1'">·回复<i class="el-icon-caret-right"></i>{{this.leixing}}</span>
                <span v-if="leixing==='90000000' && hf_yhid!==0">
                  <span style="background-color:orange;">·回复<i class="el-icon-caret-right"></i>{{this.hf_yhid}}</span><i @click="shanhfid()" class="el-icon-close a_black">删</i>
                </span>
                <span v-if="leixing==='90000000' && hf_yhid===0">·回复<i class="el-icon-caret-right"></i>未指定</span>

                
                <span>·发言:<input placeholder="在此输入,明发需审,密发不需审" v-model="hf_content" type="text" class="input_jian" style="color:grey;width:350px;font-size:16px;" >
                <span @click="fabu(0)" class="a_black">明发·</span>
                <span @click="fabu(1)" class="a_black">密发</span>
                </span>
            </span>
            <el-row v-if="fabu_msg!==''" style="color:red;text-align:center;">{{this.fabu_msg}}</el-row>
          </el-card>
            
        </el-row>

        
      
        <el-divider v-if="liaolist.length!==0||leixing==='90000000'">
            <!-- <span style="font-size:17px;">未读消息:</span> -->
            <!-- <span style="font-size:17px;">{{this.jishu}}条</span> -->
            <span v-if="show_zhankai===false&&leixing==='90000000'" @click="shuaxin()" class="font20px a_black">--刷新--</span>
            <span v-if="leixing!=='90000000'" @click="shuaxin0()" class="font20px a_black">--刷新--</span>
            <span v-if="show_zhankai&&leixing==='90000000'" class="a_black font20px" @click="zhankai()">--展开--</span>
            <!-- <span style="font-size:17px;">上次刷新:</span> -->
            <!-- <span style="font-size:17px;">{{qian_date(this.jishi)}}</span> -->
        </el-divider>
     
      <br>
      <el-row v-if="show_loading" style="font-size:30px;text-align:center;">
        <i class="el-icon-loading"></i>正在加载...
      </el-row>
      
      <el-row v-if="liaolist.length===0&&parseInt(leixing)>90000000" style="font-size:30px;text-align:center;color:grey">
        <i class="el-icon-info"></i>无聊天记录
      </el-row>
        <el-row v-for="ll in liaolist" :key="ll.shentime" style="font-color:black;font-size:20px;">
            <el-row v-if="ll.userid1!==user_id">
              <div v-if="ll.leixing===90000000" style="float:left;display:inline-block;">
                <el-avatar shape="square" style="font-size:24px;">{{ll.username.slice(0,1).toUpperCase()}}</el-avatar>
              </div>
              <div style="display:inline-block;width:500px;padding:5px;">
                <span v-if="ll.username==='匿名'">{{ll.username}}:</span>
                <router-link v-if="ll.username!=='匿名'" class="a_black" target="_blank" :to="{name:'yonghuye',params:{id:ll.userid1}}">
                  <span class="a_black">{{ll.username}}:</span>
                </router-link>
                <span v-if="ll.taidu==='点赞支持'" style="color:green;">赞</span>
                <span v-if="ll.taidu==='反对异议'" style="color:red;">反</span>
                <span v-if="ll.taidu==='疑惑不解'" style="color:orange;">疑</span>
                <router-link v-if="ll.huifuname!==''&&ll.leixing===90000000" class="a_grey" target="_blank" :to="{name:'yonghuye',params:{id:ll.huifuid}}">          
                    <span><i class="el-icon-caret-right"></i>{{ll.huifuname}}</span>
                </router-link>
                <span class="green_msg" v-if="ll.fyshu!==0">
                    <span>{{ll.fyshu}}字密文</span>
                    <input v-if="ll.leixing!==90000000" style="width:1px;border-color:white;border:0px;" type="text" v-model="ll.fy" :id="ll.shentime">
                    <input v-if="ll.leixing===90000000" style="width:1px;border-color:white;border:0px;" type="text" v-model="ll.fy" :id="ll._id.$oid">
                    <a class="a_brown" v-if="ll.leixing!==90000000" @click="kcopy(ll.shentime)" style="color:blue;"><i class="el-icon-document-copy"></i>复制</a>
                    <a class="a_brown" v-if="ll.leixing===90000000" @click="kcopy(ll._id.$oid)" style="color:blue;"><i class="el-icon-document-copy"></i>复制</a>
                </span>
                <span class="green_msg" v-if="ll.fyshu===0&&ll.fystatus==='正常有效'">{{ll.fy}}</span>
                <span class="grey_msg" v-if="ll.fyshu===0&&ll.fystatus==='正在审核'">正在审核</span>
                <span class="grey_msg" v-if="ll.fystatus==='删除失效'">已被删除</span>
                <span v-if="ll.zhid!==0" style="font-size:17px;">
                  <i class="el-icon-paperclip"></i>
                  <router-link class="a_black" target="_blank" :to="{name:ll.zhitype,params:{id:ll.zhid}}">          
                      <span><i v-if="ll.type==='yonghuye'" class="el-icon-s-custom"></i>{{ll.zhititle}}</span>
                  </router-link>
                </span>
                <br>
                <span v-if="ll.leixing!==90000000" style="color:grey;font-size:17px;">{{qian_date(ll.shentime)}}</span>
                <span v-if="ll.leixing===90000000" style="color:grey;font-size:17px;">{{qian_date_8(ll.shentime.$date)}}</span>
                <span class="a_black" @click="huifujian(ll.userid1,ll.username)" style="font-size:17px;" v-if="leixing<'90000001'&&ll.userid1!==99999999"><el-divider direction="vertical"></el-divider>回复TA</span>
              </div>
              <br>
            </el-row>

          <el-row v-if="ll.userid1===user_id" style="padding-top:5px;">
            <div style="float:right;display:inline-block;width:30px;">
              <el-avatar shape="square" style="font-size:24px;">你</el-avatar>
            </div>
            <div style="float:right;display:inline-block;width:500px;padding:5px;text-align:right;">
              
              <router-link v-if="ll.huifuname!==''&&ll.leixing===90000000" class="a_grey" target="_blank" :to="{name:'yonghuye',params:{id:ll.huifuid}}">          
                  <span><i class="el-icon-caret-right"></i>{{ll.huifuname}}</span>
              </router-link>
              <span v-if="ll.taidu==='点赞支持'" style="color:green;">赞</span>
              <span v-if="ll.taidu==='反对异议'" style="color:red;">反</span>
              <span v-if="ll.taidu==='疑惑不解'" style="color:orange;">疑</span>
              <span class="yellow_msg" v-if="ll.fyshu!==0">
                  <span>{{ll.fyshu}}字密文</span>
                  <input v-if="ll.leixing!==90000000" style="width:1px;border-color:white;border:0px;" type="text" v-model="ll.fy" :id="ll.shentime">
                  <input v-if="ll.leixing===90000000" style="width:1px;border-color:white;border:0px;" type="text" v-model="ll.fy" :id="ll._id.$oid">
                  <a class="a_brown" v-if="ll.leixing!==90000000" @click="kcopy(ll.shentime)" style="color:blue;"><i class="el-icon-document-copy"></i>复制</a>
                  <a class="a_brown" v-if="ll.leixing===90000000" @click="kcopy(ll._id.$oid)" style="color:blue;"><i class="el-icon-document-copy"></i>复制</a>
              </span>
              <span class="green_msg" v-if="ll.fyshu===0&&ll.fystatus==='正常有效'">{{ll.fy}}</span>
              <span class="grey_msg" v-if="ll.fyshu===0&&ll.fystatus==='正在审核'">正在审核</span>
              <span class="grey_msg" v-if="ll.fystatus==='删除失效'">已被删除</span>
              <span v-if="ll.zhid!==0" style="font-size:17px;">
                <i class="el-icon-paperclip"></i>
                  <router-link class="a_black" target="_blank" :to="{name:ll.zhitype,params:{id:ll.zhid}}">          
                      <span><i v-if="ll.type==='yonghuye'" class="el-icon-s-custom"></i>{{ll.zhititle}}</span>
                  </router-link>
              </span>
              
              <br>
              <span v-if="ll.leixing!==90000000" style="color:grey;font-size:17px;">{{qian_date(ll.shentime)}}</span>
              <span v-if="ll.leixing===90000000" style="color:grey;font-size:17px;">{{qian_date_8(ll.shentime.$date)}}</span>
              <span v-if="ll.fystatus!=='删除失效'" class="a_black" @click="shanliao(ll._id.$oid)" style="font-size:17px;"><i class="el-icon-close"></i>删</span>
            </div>
            <br>
          </el-row>

        </el-row>

        <!-- <el-row style="padding-top:5px;">
          <div style="float:left;display:inline-block;">
            <el-avatar shape="square" style="font-size:24px;">赵</el-avatar>
          </div>
          <div style="display:inline-block;width:700px;padding:5px;">
            <span>zhao:</span>
            <span>引用了《测试》</span>
            <span class="yellow_msg"><span style="color:grey;">12字密文</span><span class="a_brown" style="color:blue;"><i class="el-icon-document-copy"></i>复制</span></span>
            <span><i class="el-icon-caret-left"></i>回</span>
          </div>
          <br>
        </el-row>  -->

      <!-- <el-divider style="font-size:17px;" v-if="liaolist.length!==0 && parseInt(leixing)<90000001">-24小时内已读消息<span style="font-size:20px;">-展开-</span></el-divider> -->
				
    </div>
</template>

<script>
  export default {
    name:'zu2liaolist',
    data() {
      return {
          taidu:'',
          niming:false,
          zhid:'',
          hf_yhid:0,
          hf_yhname:'',
          hf_content:'',
          // jishu:'',
          lastfreshtime:'',
          liaolist:[],
          fabu_msg:'',

          show_zhankai:true,
          show_loading:false,


      }
    },

    computed:{
      user_id(){return parseInt(this.$cookies.get('userid'))},
    },

    props:['leixing','jishu','jishi'],//这个类型就是用户聊天的类型，90000000是在聊天大厅聊天，<90000000是在群组内聊天，>90000000是一对一聊天

    methods:{
      shanhfid(){
        this.hf_yhid=0;
      },
      shanliao(kkk){
        var _this= this;
        _this.axios
        .post('http://www.zhishiren.info/api/shanliao/',{
          kkk:kkk,
        })
        .then(response=>{
            _this.shuaxin();
        });
      },
      huifujian(kkk,uuu){
        this.hf_yhid=kkk;
        this.hf_yhname=uuu;
      },
      zhankai(){
        this.show_zhankai=false;
        this.shuaxin();
      },
      kcopy(a){
        let copycode = document.getElementById(a);
            copycode.select(); // 选择对象
            document.execCommand("Copy"); // 执行浏览器复制命令
            const h = this.$createElement;
            this.$notify({
                title: '密文已经复制到你的粘贴板',
                type: 'success',
				    message: h('i', { style: 'color: teal;font-size:19px;'}, '请到‘密’功能栏解密。')});
            // alert("密文已经复制到你的粘贴板，请到首页右侧‘密’功能栏解密。");
        },
      
      choose_taidu(taidu_value){this.taidu=taidu_value;},

      fabu(kkk){
        var _this= this;
        if(_this.zhid===''&&_this.zhid<10000000){_this.zhid=0};
        if(parseInt(_this.leixing)===parseInt(_this.user_id)||parseInt(_this.hf_yhid)===parseInt(_this.user_id)){
          _this.fabu_msg='回复对象不能为自己！';
          setTimeout(function(){_this.fabu_msg='';}, 1500);
        }else{
          if(_this.hf_content===''){
          _this.fabu_msg='发言内容不能为空！';
          setTimeout(function(){_this.fabu_msg='';}, 1500);
          }
          else{
            _this.axios
            .post('http://www.zhishiren.info/api/add_liaomsg/', {
              yonghuid:_this.$cookies.get('userid'),
              yonghuname:_this.$cookies.get('username'),
              fymm:_this.$cookies.get('fayanmima'),
              mi:kkk,
              taidu:_this.taidu,
              zhid:_this.zhid,
              hf_yhid:_this.hf_yhid,
              hf_yhname:_this.hf_yhname,
              hf_content:_this.hf_content,
              leixing:_this.leixing,
              niming:_this.niming,
              })
            .then(function (response) {
              _this.show_loading=true;
              _this.axios
                .post('http://www.zhishiren.info/api/show_liao_list/',{
                  leixing:_this.leixing,
                  userid:_this.$cookies.get('userid'),
                })
                .then(response=>{
                  if(_this.leixing==='90000000'){
                      _this.liaolist=JSON.parse(response.data.ll0);       
                      _this.liaolist=_this.liaolist.sort( function ( a , b ){ return  a.shentime - b.shentime } );
                  }else{
                      _this.liaolist=response.data.ll0;
                      _this.jishi=response.data.jishi;
                      _this.jishu=response.data.jishu;
                  }
                      _this.show_loading=false;
                      _this.hf_yhid=0;
                      _this.hf_yhname='';
                      _this.taidu='';
                      _this.zhid='';
                      _this.hf_content='';

                });
            });
          }
        }
      },
          shuaxin(){
                var _this= this;
                _this.show_zhankai=false;
                _this.show_loading=true;
                _this.axios
                  .post('http://www.zhishiren.info/api/show_liao_list/',{
                    leixing:_this.leixing,
                    userid:_this.$cookies.get('userid'),
                  })
                  .then(response=>{
                    _this.liaolist=JSON.parse(response.data.ll0);
                    _this.liaolist=_this.liaolist.sort( function ( a , b ){ return  a.shentime - b.shentime } );
                    _this.show_loading=false;
                  });
          },

          shuaxin0(){
                var _this= this;
                _this.show_loading=true;
                _this.axios
                  .post('http://www.zhishiren.info/api/show_liao_list/',{
                    leixing:_this.leixing,
                    userid:_this.$cookies.get('userid'),
                  })
                  .then(response=>{
                    _this.liaolist=response.data.ll0;
                    _this.jishi=response.data.jishi;
                    _this.jishu=response.data.jishu;
                    _this.show_loading=false;
                  });
          },
    },

   
    watch: {
        // leixing: function(newVal,oldVal){
        //   var lei_xing = newVal;
        //     if(parseInt(lei_xing)>80000000){
        //     var _this= this;
        //     _this.show_loading=true;
        //     _this.axios
        //       .post('http://www.zhishiren.info/api/show_liao_list/',{
        //         leixing:lei_xing,
        //         userid:_this.$cookies.get('userid'),
        //       })
        //       .then(response=>{
        //         _this.liaolist=response.data.ll0;
        //         _this.jishi=response.data.jishi;
        //         _this.jishu=response.data.jishu;

        //         _this.show_loading=false;
        //       });
        //     } 
        // },
        leixing:{
        　　　　handler:function(newVal,oldVal){
                var lei_xing = newVal;
                if(parseInt(lei_xing)>90000000){
                var _this= this;
                _this.show_loading=true;
                _this.axios
                  .post('http://www.zhishiren.info/api/show_liao_list/',{
                    leixing:lei_xing,
                    userid:_this.$cookies.get('userid'),
                  })
                  .then(response=>{
                    _this.liaolist=response.data.ll0;
                    _this.jishi=response.data.jishi;
                    _this.jishu=response.data.jishu;

                    _this.show_loading=false;
                  });
                } 
        　　　　},
        　　　　	immediate: true
        //	immediate: true是为了从用户页跳转过来后，对话记录列表立即展开的功能
        }


    },
}

</script>

<style scoped>
		.grey_msg{font-size:22px;height:30px;background-color:rgb(215, 221, 215);border-radius: 50px;box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);width:auto;padding-right:10px;padding-left:10px;} 

		.green_msg{font-size:22px;height:30px;background-color:rgb(0,255,0);border-radius: 50px;box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);width:auto;padding-right:10px;padding-left:10px;} 
		.yellow_msg{font-size:20px;height:30px;background-color:rgb(255, 255, 0);border-radius: 50px;box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);width:auto;padding-right:10px;padding-left:10px;} 
</style>





