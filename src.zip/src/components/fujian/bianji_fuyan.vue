<template>
<span>
    <span v-if="show_edit===false" v-html="fuyan" ></span>
    <a v-if="show_edit===false" @click="bianji" class="a_grey font18px"><i class="el-icon-edit">编辑</i></a>
	<input v-if="show_edit" placeholder="请输入关注的附言..." v-model="changed_fuyan" type="text" class="input_jian font18px" style="color:grey" >
    <a v-if="show_edit" @click="queding" class="a_grey font18px"><i class="el-icon-check"></i>确定</a> 
    <a v-if="show_edit" @click="huanyuan" class="a_grey font18px"><i class="el-icon-refresh-left"></i>还原</a>
    <span v-if="show_kong" style="color:orange"><i class="el-icon-warning"></i>输入不能为空！</span>
    <span v-if="show_error" style="color:red"><i class="el-icon-warning"></i>修改失败！</span>
</span>

</template>

<script>
  export default {
    data() {
      return {
                show_edit:false,
                show_kong:false,
                changed_fuyan:'',
                show_error:false,
                
                
      }
    },

    props:['fuid','fuyan'],

    methods:{
        bianji(){
        this.show_edit=true;
        },

        queding(){
                    var _this= this;
                    if(_this.changed_fuyan==''){_this.show_kong=true}
                    else{
                        _this.$axios
                        .post('http://www.zhishiren.info/api/edit_fuyan/', {fuid: _this.fuid,fuyan:_this.changed_fuyan})
                        .then(function(response){
                            if (response.data.changed_ok === 0){
                                _this.fuyan=_this.changed_fuyan;
                                _this.show_edit=false;
                                _this.show_kong=false;
                            }
                            else{
                                _this.show_error=true,
                                setTimeout(function(){
                                    _this.show_error=false;
                                    _this.show_edit=false;
                                    _this.show_kong=false;
                                }, 2000);

                            }
                        })
                    }
        },


        huanyuan(){
        this.show_edit=false;
        this.show_kong=false;
        },
    }

  }
</script>





