



<template>
    <span id="fromyonghu" style="float:left;color:grey;">
        来自
        <router-link target="_blank" class="a_black" :to="{name:'yonghuye',params:{id:id}}" >
            {{name}}
        </router-link>
        <!-- 这里需要判断，是否来自用户本人，如果是，显示来自我 -->
    </span>
</template>

<script>
export default {
    name:'fromyonghu',
	data() {return {}},
	props: {name: {type: String},
			id: {type: Number},
	},
	methods:{

	},
};

</script>