import Vue from 'vue';
import VueRouter from 'vue-router';
import dengluye from '../components/dengluye';
import zhutiye from '../components/zhutiye';
import sou from '../components/fuye/sou';
// import ce from '../components/fuye/ce';
import shen from '../components/fuye/shen';
import wen from '../components/fuye/wen';
import zeng from '../components/fuye/zeng';
import liao from '../components/fuye/liao';

import fayanye from '../components/danye/fayanye';
import wenjiye from '../components/danye/wenjiye';
import shujiye from '../components/danye/shujiye';
import shujuye from '../components/danye/shujuye';
import wenduanye from '../components/danye/wenduanye';
import biaoqianye from '../components/danye/biaoqianye';
import qunzuye from '../components/danye/qunzuye';
import yonghuye from '../components/danye/yonghuye';
import errorpage from '../components/danye/errorpage';

Vue.use(VueRouter);

export default new VueRouter({
    mode: 'hash',
    // mode: 'history',
    routes:[
        {
            // path:'/zhutiye/:k',
            path:'/zhutiye',
            component:zhutiye,
            name:'zhutiye',
        },

        {
            path:'/',
            name:'dengluye',
            component:dengluye,

        },


        {
            path:'/sou',
            name:'sou',
            component:sou,

        },

        // {
        //     path:'/ce',
        //     name:'ce',
        //     component:ce,

        // },

        {
            path: '/wen',
            name: 'wen',
            component: wen,
        },


        {
            path:'/shen',
            name:'shen',
            component:shen,

        },

        {
            path:'/zeng',
            name:'zeng',
            component:zeng,

        },

        {
            path:'/liao/:id',
            name:'liao',
            component:liao,
        },

        {
            path: '/errorpage/:id',
            name: 'errorpage',
            component: errorpage,
        },

        {
            path:'/fayanye/:id',
            name:'fayanye',
            component:fayanye,
        },

        {
            path:'/wenjiye/:id',
            name:'wenjiye',
            component:wenjiye,

        },

        {
            path:'/shujiye/:id',
            name:'shujiye',
            component:shujiye,

        },

        {
            path:'/shujuye/:id',
            name:'shujuye',
            component:shujuye,

        },

        {
            path:'/wenduanye/:id',
            name:'wenduanye',
            component:wenduanye,
        },


        {
            path:'/biaoqianye/:id',
            name:'biaoqianye',
            component:biaoqianye,
        },

        {
            path:'/qunzuye/:id',
            name:'qunzuye',
            component:qunzuye,
        },

        {
            path:'/yonghuye/:id',
            name:'yonghuye',
            component:yonghuye,
        },
    ]




});