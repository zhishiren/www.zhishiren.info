<template>
	<div id="xh12">
            <zu1caozuojishu zone_id=12 :jishu="listNum" :showloading1="showloading1" :showloading2="showloading2"  @zhankai="zk" @shuaxin="shuaxin"></zu1caozuojishu>  
            <div v-if="showloading2===false">
            <el-row class="br10px17px" v-for="list in lists" :key="list.pk" >
                <el-row>
                    <zu1yuansu :list="list" onlyid1=0></zu1yuansu>
                    <span>被<zu0niming :uid1='list.fields.uid1' :uname='list.fields.uname'></zu0niming></span>
                    <span v-if="list.fields.cztype==='加入标签'">添加</span>
                    <span v-if="list.fields.cztype==='关联'">关联了</span>
                    <span v-if="list.fields.cztype==='评论'">评论了：</span>
                    <zu1yuansu :list="list" onlyid1=1></zu1yuansu>
                    <span v-if="list.fields.cztype==='关联'">，</span>
                    <zu0fy :list="list"></zu0fy>
                    <!-- <span>来自</span> -->
                </el-row>
                <zu1huifulan :list='list' @shanchuok="shuaxin()"></zu1huifulan>
                <el-row><el-divider style="margin:0px;"></el-divider></el-row>
            </el-row>
                <br>
                <el-pagination v-if="listNum>10" style="text-align:right;"
                                background
                                :page-size=10
                                :total="listNum"
                                :current-page.sync="currentPage"
                                layout="total, prev, pager, next">
                </el-pagination>
            </div>
    </div>
</template>

<script>

export default {
    name:'xh12',
    components: {},
    
	data() {return {
        currentPage: 1,//当前分页的数值
        listNum:0,//分页总条数
        listNum1:0,//分页总条数
        xh12s:[],
        show_xh12:false,

        showloading2:false,
        showloading1:false,
    }},

	computed: {
            lists(){
                let pages=Math.ceil(this.listNum/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                    let sonList=[];
                    sonList=this.xh12s.slice(i*10,i*10+10);//10为每页设置数量
                    newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
    },
    
	methods:{
        zk(){this.shuaxin();},
        shanok(){this.shuaxin();},
        shuaxin(){
            this.showloading2=true;
            var that=this;
            that.$axios
                .post('http://www.zhishiren.info/api/xunhuan12/', {
                    userid:that.$cookies.get('userid'),
                    chuan:that.$cookies.get('chuan')})
                .then(response=>{
                    that.xh12s=JSON.parse(response.data);
                    that.listNum=that.xh12s.length;
                    that.listNum1=that.xh12s.length;
                    that.currentPage=1;
                    that.showloading2=false;
                });
        },
    },

    created: function () {
            this.showloading1=true;
            this.$axios
                .post('http://www.zhishiren.info/api/count12/', {userid:this.$cookies.get('userid'),chuan:this.$cookies.get('chuan')})
                .then(response=>{
                    this.listNum=response.data;
                    this.showloading1=false;
                    });
	}
};
</script>

