<template>
		<div id="loadingjiazai">
            <br>
                <div style="font-size:30px;color:grey;"><i class="el-icon-loading"></i>正在加载...</div>
            <br>
		</div>
</template>

<script>
export default {
    name:'loadingjiazai',
};
</script>


