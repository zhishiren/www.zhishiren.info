// 这是用于关联，评论，评价，加标签，标签内涵，群组成员，
<template>
	<div id="xhduanluo">
        <zu1caozuojishu 
            zone_id="添加段落" :jishu="listNum" :listNumk="listNumk" 
            :showloading1="showloading1" :showloading2="showloading2"  
            :zhid="zhid" :title0="title0" :type0="type0" :managerid="managerid"
            :fanwei="fanwei" :createrid="createrid" :creatername="creatername"
            @send_searchword="send_searchword" @zhankai="zk" @shuaxin="shuaxin"  @shuaxinduanluo1="shuaxindl1" @huanyuan="huanyuan">
        </zu1caozuojishu>  
        <div v-if="show_xhdl===true && showloading2===false">
            <el-row class="br10px17px" v-for="list in lists" :key="list.pk" >
                <router-link target="_blank" class="a_black" :to="{name:'wenduanye',params:{id:list.pk}}" >
                    <el-row>{{list.fields.wd_title}}</el-row>
                </router-link>
                <el-row v-html="list.fields.wd_content" ></el-row>
                <el-row><el-divider style="margin:0px;"></el-divider></el-row>
            </el-row>
            <br>
            <el-pagination v-if="listNum>10" style="text-align:right;"
                background
                :page-size=10
                :total="listNum"
                :current-page.sync="currentPage"
                layout="total, prev, pager, next">
            </el-pagination>
        </div>
        <div v-if="show_xhkdl===true && showloading2===false">
            <el-row class="br10px17px" v-for="listk in listks" :key="listk.pk" >
                <router-link target="_blank" class="a_black" :to="{name:'wenduanye',params:{id:listk.pk}}" >
                    <el-row v-html="gaoliangk(listk.fields.wd_title, k)"></el-row>
                </router-link>
                <el-row v-html="gaoliangk(listk.fields.wd_content, k)" ></el-row>
                <el-row><el-divider style="margin:0px;"></el-divider></el-row>
            </el-row>
            <br>
            <el-pagination v-if="listNumk>10" style="text-align:right;"
                background
                :page-size=10
                :total="listNumk"
                :current-page.sync="currentPagek"
                layout="total, prev, pager, next">
            </el-pagination>
        </div>
	</div>
</template>

<script>


	export default {
		name: 'xhduanluo',
        components: {},
        props:['zoneid','listNum',
        'zhid','title0','type0',//必填，这个type0是用于判断是否为用户页或群组的
        'fanwei',//选填，用于“分享”的功能
        'createrid','creatername',//选填，用于操作“言论”相关,这个creatername用来录入被操作的原始人员
        'managerid'
        ],
		data () {
			return {
                currentPage: 1,//当前分页的数值
                currentPagek: 1,//查找后，当前分页的数值
                showloading2:false,
                showloading1:false,
                // listNum:0,
                listNumk:0,
                xhdl:[],
                xhkdl:[],
                show_xhdl:false,
                show_xhkdl:false,
                k:''
			}
        },
        
        computed: {
            lists(){
                let pages=Math.ceil(this.listNum/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                    let sonList=[];
                    sonList=this.xhdl.slice(i*10,i*10+10);//10为每页设置数量
                    newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
            listks(){
                let pages=Math.ceil(this.listNumk/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                    let sonList=[];
                    sonList=this.xhkdl.slice(i*10,i*10+10);//10为每页设置数量
                    newList.push(sonList)
                }
                return newList[this.currentPagek-1]
            },
            userid(){return parseInt(this.$cookies.get('userid'))},
        },

		methods: {
            send_searchword(data){
                this.show_xhdl=false;
                this.show_xhkdl=true;
                this.k=data.k;
        　　　　　　　　var newList = [];
        　　　　　　　　this.xhdl.forEach(item=>{if(item.fields.wd_title.indexOf(this.k) !==-1||item.fields.wd_content.indexOf(this.k)!==-1){newList.push(item)}});
                     this.listNumk = newList.length;//这里是计算筛选后的结果的数量
        　　　　　　   this.xhkdl = newList;
            },
            zk(){this.shuaxin();},
            shuaxin(){
                this.show_xhdl=true;
                this.show_xhkdl=false;
                this.showloading2=true;
                var that=this;
                that.$axios
                    .post('http://www.zhishiren.info/api/xunhuan_duanluo/', {
                        sss:0,
                        wj_id:parseInt(that.zhid),
                        })
                    .then(response=>{
                        that.xhdl=JSON.parse(response.data);
                        that.listNum=that.xhdl.length;
                        that.currentPage=1;
                        that.showloading2=false;
                    });
            },
            shuaxindl1(){
                this.show_xhdl=true;
                this.show_xhkdl=false;
                this.showloading2=true;
                var that=this;
                that.$axios
                    .post('http://www.zhishiren.info/api/xunhuan_duanluo/', {
                        sss:1,
                        wj_id:parseInt(that.zhid),
                        })
                    .then(response=>{
                        that.xhdl=JSON.parse(response.data);
                        that.listNum=that.xhdl.length;
                        that.currentPage=1;
                        that.showloading2=false;
                    });
            },
            huanyuan(){
                this.show_xhdl=true;
                this.show_xhkdl=false;
                this.k='';
            },
        }
			
        // created: function () {
		// 		this.axios
		// 		.post('http://www.zhishiren.info/api/count43/',{zhid: this.$cookies.get('userid')})
        //         .then(response=>{this.listNum=response.data});
		// }

	}
</script>

