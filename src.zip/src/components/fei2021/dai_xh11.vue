                        <div v-if="list.news_type==='a05'">
                                <el-row>
                                    <niming :createrid='list.createrid' :creatername='list.creatername'></niming>
                                    <span>发言说：</span>
                                    <zu0fy v-if="list.item0_type==='fayanye'" futype='fa'></zu0fy>
                                    <!-- <fayan v-if="list.news_zishu===0" :pkid='list.item0_id' :content='list.news_comm_content'></fayan> -->
                                    <!-- <miwen v-if="list.news_zishu!==0" :pkid='list.news_comm_id' :content='list.news_comm_content' :zishu='list.news_zishu'></miwen> -->
                                </el-row>
                                <zu0zu0fujianfutu v-if="list.fujian!==0" :zhid="list.item0_id" :futujian="list.fujian"></zu0zu0fujianfutu>
                                <tj0huifu  :shuaxinid="shuaxinyn" timek=1 news_yn=1 @shanchuok="shanok()" :act_id="list.news_comm_id" :act_yan="list.news_comm_content" :create_time="list.create_time.$date" :fanwei_id="list.news_fanwei" :it_type="list.item0_type" :it_att="list.news_attitude" :creater_id="list.createrid" :item1title="'你发表了言论:'+list.news_comm_content+'|'+getNowFormatDatetime(list.create_time.$date)"></tj0huifu>
                        </div>