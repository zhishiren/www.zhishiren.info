<template>
<div id="zu0showfanwei" style="display:inline-block">
    <span v-if="qz_id===80000000">仅本人可见</span>
    <span v-if="qz_id>80000000 && qz_id<89999999">
        仅<router-link class="a_black" target="_blank" :to="{name:'qunzuye',params:{id:this.qz_id}}">{{this.qz_id}}</router-link>可见
    </span>
    <span v-if="qz_id===90000000">所有人可见</span>
</div>

</template>

<script>
  export default {
      name:'zu0showfanwei',
      props:['qz_id'],
      data() {
        return {}
      },
      methods:{}

  }
</script>