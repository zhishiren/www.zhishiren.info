// 这个回复组件比较简单，用于news模块，回复用户的回复和评价。
<template>
    <span id="tj_huifu0" style="float:right">
	   	<a @click="shanchu()" class="a_grey">
           <i class="el-icon-close"></i>删除<el-divider direction="vertical"></el-divider>
    	</a><!--
    --><a @click="huifujian()" class="a_grey">回复</a><!--
	--><el-divider direction="vertical"></el-divider>
        {{getNowFormatDate(create_time)}}
    </span>
</template>

<script>
export default {
	data() {return {}},
	props: {
			comment_id: {type: Number},
			create_time:{type: Date},
	},

	methods:{
				shanchu:function(id){
				},
				huifujian:function(id){
				},
	},
};

</script>

