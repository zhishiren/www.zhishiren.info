<template>

    <div id="zhankai1" class="chazhao_alink " style="display: inline-block;">
				<a class="chazhao_alink a_noline" @click="zhankaijian" v-show="show_zhankai">-展开-</a> 
				<transition name="el-zoom-in-center">
					<!-- 这个transition是elementjs中的动画效果，要放在显示内容的外部才有效果 -->
					<div v-show="show_chazhao">
							<input type="text" class="chazhaolan" v-model="zhi" size="mini" placeholder="在以下结果中查找">
							<a @click="chazhaojian" class="chazhao_alink a_noline" ><i class="el-icon-search"></i>查找</a>   
							&nbsp;
							<a @click="paixujian" class="chazhao_alink a_noline" >排序<i class="el-icon-sort"></i>最热</a>
							&nbsp;
							<a @click="shuaxinjian" class="chazhao_alink a_noline" >刷新<i class="el-icon-refresh"></i>还原{{zhi}}</a>
					</div>

				</transition>
    </div>

</template>

<script>
export default {

//   props: {chazhaotype: String},
	data() {return {zhi: '',serverResponse: 'resp',content:'',show_zhankai:true,show_chazhao:false}},
	methods:{
				zhankaijian:function(){
					this.show_zhankai=false;
					this.show_chazhao=true;
				},
				paixujian:function(){},
				chazhaojian:function(){alert(this.zhi);},
				shuaxinjian:function(){
					var that = this;
					const path = 'http://127.0.0.1:5000/getMsg';
					axios.get(path).then(function (response) {
						var msg = response.data.msg;
						that.serverResponse = msg;
						alert('Success ' + response.status + ', ' + response.data + ', ' + msg);
						}).catch(function (error) {alert('Error ' + error);})
				}
	},

};

</script>

<!-- Add "scoped" attribute to limit CSS to this component only 
<transition name="el-zoom-in-center">
-->
<style scoped>
		.chazhao_alink{font-size:18px;color:black;}
		.chazhaolan{
					width:200px;
					border:none;
					border-radius:0;
					border-bottom:#8D8D8D 1px solid;
					box-shadow:0;
					outline:none;
					text-decoration: none;
					font-size:18px;
		}
    
</style>
