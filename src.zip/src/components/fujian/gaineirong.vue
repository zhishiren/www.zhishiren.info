
<template>
    <div>
        <el-row  class="font18px">
				<el-button @click="to_xiugai" type="text"  class="font18px">
                    修改属性...
                </el-button>
                已经有10次修改历史。-展开- 
		</el-row>
		<el-dialog title="修改内容..." width="400px" :visible.sync="show_dialog">
            <el-row v-if="fanwei_yn===1">
                <el-col :span="7" class="font18px" style="padding-top:10px;">
                    公开范围：
                </el-col>
                <el-col :span="17">
                    <fanwei  ref="huanyuan" @set_fanwei="set_gongkaifanwei" style="width:90%;"></fanwei>
                </el-col>
            </el-row>
            <br v-if="fanwei_yn===1">

			<el-row v-if="status_yn===1">
                <el-col :span="7" class="font18px" style="padding-top:10px;">
                    时效状态：
                </el-col>
                <el-col :span="17">
                <el-select v-model="zhi_status" placeholder="请选择时效状态" style="width:90%;">
                    <el-option value="s0" key="s0" label="正常有效"></el-option>
                    <el-option value="s4" key="s4" label="过时失效"></el-option>
                </el-select>
                </el-col>
            </el-row>
            <br v-if="status_yn===1">

            <el-row v-if="manager_yn===1">
                <el-col :span="7" class="font18px" style="padding-top:10px;">
                    管理人员：
                </el-col>
                <el-col :span="17">
                    <el-input v-model="zhi_managerid" placeholder="请输入管理人员id号"  style="width:90%;">
                    </el-input>
                </el-col>
            </el-row>
            <br v-if="manager_yn===1">

            <el-row>
                <p class="font18px">内容备注：</p>
                <!-- 这里的格式要注意，“请输入分享附言，限100字。”与上下文的标签不能有换行等。 -->
                <div contenteditable ref="contents" @paste="onPaste" class="pinglunlan">
                   <span v-html="zhi_remark"></span>
                </div>
            </el-row>
            <el-row>
                <el-col :span="7">
                    <a class="a_black font18px" href="javascript:;" @click="f_blod">
                        <b>所选加粗</b>
                    </a>
                </el-col>
                <el-col class="font18px" :span="11">
                    <span style="color:green;"  v-show="ok_msg==1"><i class="el-icon-success"></i>发布成功!</span>
                    <span style="color:orange;" v-show="ok_msg==2"><i class="el-icon-warning-outline"></i>标签不能为空!</span>
                    <span style="color:red;"    v-show="ok_msg==3"><i class="el-icon-error"></i>数据库写入失败!</span>
                </el-col>
                <el-col :span="6" style="text-align:right">
                    <a @click="fabujian" class="font20px a_black" >发布</a>
                </el-col>
            </el-row>



        </el-dialog>
            
    </div>
</template>

<script>
import fanwei from '../fujian/fanwei';
export default {
    components: {fanwei},
    name:'gaineirong',
	data() {return {
        ok_msg:0,
        show_dialog:false,
        zhi_status:'s0',
        manager_id:0,
    }},
    props:['zhitype','fanwei_yn','manager_yn','status_yn','zhi_remark','zhi_managerid'],
	// props: {
	// 		zhitype: {type: Number},
	// 		fanwei_yn: {type: Number},
	// 		manager_yn: {type: Number},
	// 		status_yn: {type: Number},
	// },
    //这里要先判断哪些元素被修改了，然后定意0和1，把所有元素发到后台，统一一次修改。
	methods:{
            onPaste: function(e) {
                    e.preventDefault()
                    e.stopPropagation()
                    let pasteValue = (e.clipboardData || window.clipboardData).getData('text/plain')
                    console.log(pasteValue)
                    var re = /<[^>]+>/gi;
                    pasteValue = pasteValue.replace(re, '').replace(/\s+|[\r\n]/g,"");
                    e.target.textContent += pasteValue
            },
            f_blod() {document.execCommand ( 'bold', false );},
            fabujian(){},


            
            to_xiugai(){
                this.show_dialog=false;
				this.show_dialog=true;
            },
	},
};

</script>