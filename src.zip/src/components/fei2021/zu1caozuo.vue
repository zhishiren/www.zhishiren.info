<template>
    <span id="zu1caozuo" class="font18px">
        <el-button @click="caozuo(cz_type)" type="text" class="font18px">
            <span v-if="cz_type==='分享'"><i class="el-icon-share"></i>分享...</span>
            <span v-show="focused_yn===0" v-if="cz_type==='关注'"><i class="el-icon-share"></i>关注...</span>
            <span v-if="cz_type==='加入群组'"><i class="el-icon-share"></i>加入...</span>
            <span v-if="cz_type==='纠错'"><i class="el-icon-share"></i>纠错...</span>
            <span v-if="cz_type==='发言密码'">发言密码...</span>

            <span v-if="cz_type==='邀请'"><i class="el-icon-share"></i>邀请...</span>
            <span v-if="cz_type==='评论'"><i class="el-icon-share"></i>评论...</span>
            <span v-if="cz_type==='关联'"><i class="el-icon-share"></i>关联...</span>
            <span v-if="cz_type==='加入标签'"><i class="el-icon-share"></i>标签...</span>
            <span v-if="cz_type==='评价'"><i class="el-icon-share"></i>评价...</span>
            <span v-if="cz_type==='发言'"><i class="el-icon-share"></i>发言...</span>

            <span v-if="cz_type==='标签里加入'">添加内容...</span>
            <!-- <span v-if="cz_type==='添加段落'"><i class="el-icon-share"></i>段落...</span> -->
        </el-button>

		<span v-show="cz_type==='关注'&&focused_yn===1" style="color:blue">
			<el-button @click="quguanjian()" type="text" class="font18px"><i class="el-icon-close"></i>取关...</el-button>
			<span>你已经关注了。</span>
		</span>

		<span v-show="cz_type==='加入群组'&&focused_yn===1" style="color:blue">
			<el-button @click="quguanjian()" type="text" class="font18px"><i class="el-icon-close"></i>退出...</el-button>
			<span>你已经加入这个群组了。</span>
		</span>

		<span v-if="yonghuid===parseInt(zhid) && cz_type==='关注' && type0==='yonghuye'">你不能关注你自己。</span>

        <span v-if="cz_type==='分享'"><span class="msg_ok" v-if="msg===1">分享成功！</span>分享后将在“今日动态”中显示。</span>
        <span v-if="cz_type==='关注'&&focused_yn!==1"><span class="msg_ok" v-if="msg===1">关注成功！</span>关注后将在“关注收藏”中显示。</span>
        <span v-if="cz_type==='加入群组'"><span class="msg_ok" v-if="msg===1">加群成功！</span>加入群组后将在“用户与群”中显示。</span>
        <span v-if="cz_type==='纠错'"><span class="msg_ok" v-if="msg===1">发送成功！</span>纠错信息将反馈给后台管理员。</span>
        <span v-if="cz_type==='邀请'"><span class="msg_ok" v-if="msg===1">操作成功！</span></span>
        <!-- 你将向用户发送邀请信息。 -->
        
		<el-dialog :title="cz_type+'的设置...'" width="400px" :visible.sync="show_dialog">
            <br>
            <el-row v-if="cz_type==='发言'" class="font18px" >
                <el-col :span="7" style="padding-top:10px;">
                    <span>发言类型：</span>
                </el-col>
                <el-col :span="17">
                    <el-select v-model="fytype" placeholder="请选择发言的类型" style="width:90%;">
                            <el-option value="求助询问" key="求助询问" label="求助询问"></el-option>
                            <el-option value="新闻简讯" key="新闻简讯" label="新闻简讯"></el-option>
                            <el-option value="公告通知" key="公告通知" label="公告通知"></el-option>
                            <el-option value="感悟思考" key="感悟思考" label="感悟思考"></el-option>
                            <el-option value="名人名言" key="名人名言" label="名人名言"></el-option>
                            <el-option value="公开言论" key="公开言论" label="公开言论"></el-option>
                    </el-select>
                </el-col>
            </el-row>
            <el-row v-if="cz_type==='发言'"><br></el-row>


            <el-row v-if="cz_type==='评价' || cz_type==='评论'">
                <el-col :span="7" class="font18px" style="padding-top:10px;">
                    是否匿名：
                </el-col>
                <el-col :span="17">
                    <el-select v-model="niming" placeholder="请选择发言的类型" style="width:90%;">
                        <el-option value="不匿名" key="不匿名" label="不匿名"></el-option>
                        <el-option value="匿名" key="匿名" label="匿名"></el-option>
                    </el-select>
                </el-col>
            </el-row>
            <el-row v-if="cz_type==='评价' || cz_type==='评论'"><br></el-row>


            <el-row v-if="cz_type==='关联'||cz_type==='加入群组'||cz_type==='邀请'||cz_type==='标签里加入'||cz_type==='发言密码'" class="font18px">
                <el-col :span="7" class="font18px" style="padding-top:10px;">
                    <span v-if="cz_type==='标签里加入'">知识ID号：</span>
                    <span v-if="cz_type==='关联'">关联ID号：</span>
                    <span v-if="cz_type==='加入群组'">八位密码：</span>
                    <span v-if="cz_type==='发言密码'">八位密码：</span>
                    <span v-if="cz_type==='邀请'">用户ID号：</span>
                </el-col>
                <el-col :span="17">
                    <el-input v-model="id1" style="width:90%" placeholder="请输入数字">
                    </el-input> 
                </el-col>
            </el-row>
            <el-row v-if="cz_type==='关联'||cz_type==='加入群组'||cz_type==='邀请'||cz_type==='标签里加入'||cz_type==='发言密码'"><br></el-row>

            <el-row v-if="cz_type==='发言' || cz_type==='分享' || cz_type==='评论' || cz_type==='关联'|| cz_type==='评价'"  class="font18px" >
                <el-col :span="7" style="padding-top:10px;" >
                    <span >{{this.cz_type}}态度：</span>
                </el-col>
                <el-col :span="17" >
                    <el-select v-model="fyatt" placeholder="请选择态度" style="width:90%;">
                        <el-option value="无态度" key="无态度" label="无态度"></el-option>
					    <el-option v-if="cz_type==='发言'" value="紧急重要" key="紧急重要" label="紧急重要"></el-option>
						<el-option v-if="cz_type==='分享'" value="强烈推荐" key="强烈推荐" label="强烈推荐"></el-option>
                        <span v-if="cz_type==='评论'">
                            <el-option value="反对异议" key="反对异议" label="反对异议"></el-option>
                            <el-option value="点赞支持" key="点赞支持" label="点赞支持"></el-option>
                            <el-option value="疑惑不解" key="疑惑不解" label="疑惑不解"></el-option>
                        </span>
                        <span v-if="cz_type==='评价'">
                            <el-option value="聪明绝顶" key="聪明绝顶" label="聪明绝顶"></el-option>
                            <el-option value="古道心肠" key="古道心肠" label="古道心肠"></el-option>
                            <el-option value="一言九鼎" key="一言九鼎" label="一言九鼎"></el-option>
                            <el-option value="言论怪异" key="言论怪异" label="言论怪异"></el-option>
                            <el-option value="让人困惑" key="让人困惑" label="让人困惑"></el-option>
                            <el-option value="胡说八道" key="胡说八道" label="胡说八道"></el-option>
                        </span>
                        <span v-if="cz_type==='关联'">
                            <el-option value="矛盾" key="矛盾" label="矛盾"></el-option>
                            <el-option value="互补" key="互补" label="互补"></el-option>
                            <el-option value="更细化" key="更细化" label="更细化"></el-option>
                        </span>
                    </el-select>                
                </el-col>
            </el-row>
            <el-row v-if="cz_type==='发言' || cz_type==='分享' || cz_type==='评论' || cz_type==='关联'|| cz_type==='评价'" ><br></el-row>

            <el-row v-if="cz_type==='发言'"  class="font18px">
                <el-col :span="7" style="padding-top:10px;" >
                    <span>公开范围：</span>
                </el-col>
                <el-col :span="17" >
                    <fanwei ref="huanyuan" @set_fanwei="set_gongkaifanwei" style="width:90%;"></fanwei>
                </el-col>
            </el-row>
            <el-row v-if="cz_type==='发言'"><br></el-row>

            <el-row v-if="cz_type==='分享'"  class="font18px">
				<el-col :span="7" class="font18px" style="padding-top:10px;">
					公开范围：
				</el-col>
				<el-col :span="17">
					<el-select v-if="fanwei0===0 || fanwei0===1" v-model="qz_id" @focus="show_qzlist" placeholder="请选择"  style="width:90%;">
						<el-option
						v-for="item in lists"
						:key="item.qz_id"
						:label="item.qz_title"
						:value="item.qz_id">
						</el-option>
					</el-select> 
					<el-select v-if="fanwei0===8" :placeholder="'仅'+fanwei+'可见'" disabled style="width:90%;"></el-select>
				</el-col>
			</el-row>
            <el-row  v-if="cz_type==='分享'"><br></el-row>


            <el-row v-if="cz_type==='加入标签'" class="font18px">
                <el-col :span="7" class="font18px" style="padding-top:10px;">
                    选择标签：
                </el-col>
                <el-col :span="17">
                    <el-select v-model="bq_id" placeholder="在我创建或关注的标签中选择"  style="width:90%;">
                        <el-option
                            v-for="item in bqlists"
                            :key="item.bq_id"
                            :label="item.bq_title"
                            :value="item.bq_id+item.bq_title+item.bq_fanwei">
                        </el-option>
                    </el-select> 
                </el-col>
            </el-row>
            <el-row v-if="cz_type==='加入标签'"><br></el-row>

            <el-row >
                <div contenteditable ref="contents" @paste="onPaste" class="pinglunlan">请输入发言/附言的内容。</div>
            </el-row>

            <el-row class="font18px">
                <el-col :span="7">
                    <a v-if="cz_type!=='发言密码'" class="a_black" href="javascript:;" @click="f_blod">
                        <b>所选加粗</b>
                    </a>
                </el-col>
                <el-col :span="7">
                </el-col>
                <el-col :span="10" style="text-align:right" class="font20px">
                    <span v-if="faloading===false">
                        <span v-if="cz_type==='分享'||cz_type==='评论'||cz_type==='关联'||cz_type==='加入标签'||cz_type==='评价'||cz_type==='发言'||cz_type==='标签里加入'">
                            <a class="a_black" @click="fabujian(0)">明发</a>
                            <el-divider direction="vertical"></el-divider>
                            <a class="a_black" @click="fabujian(1)">暗发</a>
                        </span>
                        <span  v-if="cz_type==='关注'||cz_type==='纠错'||cz_type==='邀请'||cz_type==='加入群组'||cz_type==='发言密码'">
                            <a class="a_black" @click="fabujian(0)">确定</a>
                        </span>
                    </span>
                    <span v-if="faloading"><i class="el-icon-loading"></i>正在发布...</span>
                </el-col>
            </el-row>

			<el-row class="msg_orange" v-show="fanwei0===8 && cz_type==='分享'"><i class="el-icon-info"></i>你只能分享给指定的群组{{this.fanwei}}</el-row>
            <el-row class="msg_orange" v-show="fanwei0===1 && cz_type==='分享'"><i class="el-icon-info"></i>原知识点的公开范围<b>并非</b>所有人</el-row>
            <el-row class="msg_red" v-if="msg===2"><i class="el-icon-info"></i>操作失败！</el-row>
            <el-row class="msg_red" v-if="msg===5"><i class="el-icon-info"></i>评论内容不能为空！</el-row>
        </el-dialog>
    </span>
</template>

<script>
    export default {
        name:'zu1caozuo',
        props:['cz_type','zhid','title0','type0','fanwei','createrid','creatername'],
        data() {return {
            show_dialog:false,
            fytype:'',
            fyatt:'',
            id1:null,
            lists: [{qz_id:90000000,qz_title:"--所有人--"}],
		    qz_id:90000000,
            bq_id:null,
            fyfanwei:90000000,
            faloading:false,
            msg:0,
            focused_yn:0,
            bglists:[],
            niming:'不匿名',
            fy:''
        }},
        computed:{
                fanwei0(){
                    var cid=parseInt(this.createrid);
                    var coid=parseInt(this.$cookies.get('userid'));
                    var fanwei9=parseInt(this.fanwei);
                    if(this.type0==='yonghuye' || this.type0==='qunzuye' || fanwei9===90000000){return 0}
                    else{
                        if(cid===coid){return 1}//这说明分享者是创建者本人
                        else{
                            if(this.fanwei===80000000){return 2}//这代表分享者不是创建人且原知识点的范围仅为本人
                            else{return 8}//这代表分享者不是创建人且原知识点的范围为某群组
                        }
                    }
                },

                yonghuid(){return parseInt(this.$cookies.get('userid'))},
        },
        methods:{

                caozuo(){this.show_dialog=true;},

                set_gongkaifanwei(data){this.fyfanwei = data.qz_id;},

                show_qzlist(){
                    var that = this;
                    that.axios
                    .post('http://www.zhishiren.info/api/listmyqunzu1/', {userid: that.$cookies.get('userid')})
                    .then(response=>{
                    that.lists=response.data;
                    });
                },

                f_blod() {document.execCommand ( 'bold', false );},
                
                onPaste: function(e) {
                        e.preventDefault()
                        e.stopPropagation()
                        let pasteValue = (e.clipboardData || window.clipboardData).getData('text/plain')
                        console.log(pasteValue)
                        var re = /<[^>]+>/gi;
                        pasteValue = pasteValue.replace(re, '').replace(/\s+|[\r\n]/g,"");
                        e.target.textContent += pasteValue
                },

                quguanjian(){
					this.axios
						.post('http://www.zhishiren.info/api/xxguanzhu/',{
							zhi_id:this.zhid,
							userid:this.$cookies.get('userid'),
						})
						.then(response=>{
							if (response.data.ok_id === 1){
								this.$emit("gzminus1");
								this.focused_yn=0;
							}
						});
			    },

            	fabujian(mi){
					var that = this;
                    that.faloading=true;
					if(that.$refs.contents.innerHTML==='请输入发言/附言的内容。' && that.cz_type==='评论'){
                        that.msg=5;
                        setTimeout(function(){that.msg=0;}, 2000);
                    };
                    if(that.cz_type!=='评论'){
                        if(that.$refs.contents.innerHTML==='请输入发言/附言的内容。'){that.fy='无';};
                        if(that.$refs.contents.innerHTML!=='请输入发言/附言的内容。'){
                            that.fy=that.$refs.contents.innerHTML;
                        };
                        that.axios
						.post('http://www.zhishiren.info/api/to_caozuo/',{
                            cztype:that.cz_type,
                            fy:that.fy,

                            fytype:that.fytype,
                            fyatt:that.fyatt,
                            fymi:that.mi,
                            fyniming:that.niming,
                            fyfanwei_fx:that.qz_id,
                            fyfanwei:that.fyfanwei,
                            bq_id:that.bq_id,

							id0:that.zhid,
							title0:that.title0,
                            type0:that.type0,
                            id1:that.id1,

							uid: that.$cookies.get('userid'),
							uname:that.$cookies.get('username'),
                            })
						.then(function (response) {
									if (response.data.msg === 1){
										that.msg=response.data.msg;
										that.$refs.contents.innerHTML='请输入发言/附言的内容。';
										that.show_dialog=false;
										that.qz_id=90000000;
										that.lists=[{qz_id:90000000,qz_title:"--所有人--"}];
                                        that.bq_id=null;
                                        that.focused_yn=1;
                                        that.faloading=false;
                                        setTimeout(function(){that.msg=0;}, 2000);
                                        that.$emit('shuaxin0');
                                        that.$emit('shuaxinjishu');
									}
									else{
                                         that.msg=response.data.msg;
										 setTimeout(function(){that.msg=0;}, 2000);
										 that.$refs.contents.innerHTML='请输入发言/附言的内容。';
										 that.show_dialog=false;
                                         that.faloading=false;
								    }
						});
                    }
						
			    },
        },

        watch: {
            zhid: function(newVal,oldVal){
				this.zhi_id = newVal;
				this.axios
					.post('http://www.zhishiren.info/api/check_focused/',{
						zhi_id:this.zhi_id,
						userid:this.$cookies.get('userid'),
					})
					.then(response=>{
						this.focused_yn=response.data.focused_id;
			    });

            },
        },

        created() {
            if(this.cz_type==='加入标签'){
                this.axios
                .post('http://www.zhishiren.info/api/listmybiaoqian/', {userid: this.$cookies.get('userid')})
                .then(response=>{this.bqlists=response.data;});
            };
        }
    };
</script>

<style scoped>
	 .msg_ok{font-size:18px;color:green;} 
	 .msg_orange{font-size:18px;color:orange;} 
	 .msg_red{font-size:18px;color:red;} 
</style>



