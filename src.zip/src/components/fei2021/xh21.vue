<template>
	<div id="xh21">
        <zu1caozuojishu zone_id=21 :jishu="listNum" :listNumk="listNumk" :showloading1="showloading1" :showloading2="showloading2" @send_searchword="send_searchword" @zhankai="zk" @shuaxin="shuaxin" @huanyuan="huanyuan"></zu1caozuojishu>  
        <div v-show="show_xh21 && showloading2===false">
            <el-row class="br10px17px" v-for="list in lists" :key="list.pk">
                <zu0editfy :lll="list" :kkk='k'></zu0editfy>
            </el-row>
            <br>
            <el-pagination v-if="listNum>10" style="text-align:right;"
                            background
                            :page-size=10
                            :total="listNum"
                            :current-page.sync="currentPage"
                            layout="total, prev, pager, next">
            </el-pagination>
        </div>
        <div v-show="show_xhk21 && showloading2===false">
            <el-row class="br10px17px" v-for="listk in listks" :key="listk.pk">
                <zu0editfy :lll="listk" :kkk='k'></zu0editfy>
            </el-row>
            <br>
            <el-pagination v-if="listNumk>10" style="text-align:right;"
                            background
                            :page-size=10
                            :total="listNumk"
                            :current-page.sync="currentPagek"
                            layout="total, prev, pager, next">
            </el-pagination>
        </div>
    </div>
</template>

<script>

import Zu0editfy from '../zujian0/zu0editfy.vue';

export default {
    name:'xh21',
    components: {Zu0editfy},
    props:['listNum'],
    
	data() {return {
        currentPage: 1,//当前分页的数值
        // listNum:0,//分页总条数
        currentPagek: 1,//查找后，当前分页的数值
        listNumk:0,//查找后，分页总条数

        show_xh21:false,
        show_xhk21:false,
        xh21s:[],
        xh21ks:[],
        k:'',
        showloading2:false,
        showloading1:false,
    }},

	computed: {
            lists(){
                let pages=Math.ceil(this.listNum/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                    let sonList=[];
                    sonList=this.xh21s.slice(i*10,i*10+10);//10为每页设置数量
                    newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
            listks(){
                let pages=Math.ceil(this.listNumk/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                    let sonList=[];
                    sonList=this.xh21ks.slice(i*10,i*10+10);//10为每页设置数量
                    newList.push(sonList)
                }
                return newList[this.currentPagek-1]
            },

    },
    
	methods:{

      send_searchword(data){
          this.show_xh21=false;
          this.show_xhk21=true;
          this.k=data.k;
　　　　　　var newList = [];
　　　　　　this.xh21s.forEach(item=>{if(item.fields.title0.indexOf(this.k) !==-1||item.fields.fy.indexOf(this.k) !==-1){newList.push(item)}});
          this.listNumk = newList.length;//这里是计算筛选后的结果的数量
　　　　　　this.xh21ks = newList;
      },

      zk(){this.shuaxin();},

      huanyuan(){
          this.shuaxin();
          this.k='';
        },

      shuaxin(){
           this.showloading2=true;
            this.show_xh21=true;
            this.show_xhk21=false;
            this.$nextTick(() => {
                this.$axios
                .post('http://www.zhishiren.info/api/xunhuan21/', {userid:this.$cookies.get('userid')})
                .then(response=>{
                    this.xh21s=JSON.parse(response.data);
                    this.listNum=this.xh21s.length;
                    this.showloading2=false;
                    });
            });
      },
    },	



    // created: function () {
    //     this.$axios
    //     .post('http://www.zhishiren.info/api/count21/', {chuan:this.$cookies.get('chuan')})
    //     .then(response=>{this.listNum=response.data;});
	// }
};
</script>

<style>
</style>


                <!-- <el-row>
                    <router-link class="a_black" target="_blank" :to="{name:'biaoqianye',params:{id:list.fields.id0}}">
                        <span v-html="gaoliangk(list.fields.title0, k)" ></span>
                    </router-link>
                    <span style="float:right;">{{qian_date(list.fields.time1)}}</span>
                </el-row>
                <el-row>
                    <span style="float:left;color:grey">关注附言:</span>
                    <zu0editfy :fuid="list.pk" :fuyan="list.fields.fy"></zu0editfy>
                </el-row>
                <el-row><el-divider></el-divider></el-row> -->


