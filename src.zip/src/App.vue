<template>
  <div id="app">


<router-view />

  </div>
</template>

<script>

export default {
  name: 'app',
}
</script>

<style>
#app {
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        margin: 0px;
        /* min-width: 1420px; */
      }
body{
  /* position: relative; */
	width: 1280px;  
	margin: 0 auto;}
body > .el-container {margin-bottom: 0px;}
.el-container:nth-child(5) .el-aside,
.el-container:nth-child(6) .el-aside {line-height: 260px;}
.el-container:nth-child(7) .el-aside {line-height: 320px;}

* {margin: 0;padding: 0;}   
/* 这是去除页面周围空白的设置 */

</style>