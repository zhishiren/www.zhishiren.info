<template>
    <el-container id="zu2errorpage">
		<el-aside width="120px" class="bgcolor_FF"></el-aside>
        <el-main>
            <el-card style="font-size:25px;">
                <br>
                <i class="el-icon-lock"></i>
                <span>此内容</span>
                <span v-if="errorid===1">是密文，无法显示</span>
                <span v-if="errorid===9">
                    <span>仅限于群组</span>
                    <router-link class="a_black" target="_blank" :to="{name:'qunzuye',params:{id:this.errorid}}">
                        <span class="a_black">{{this.errorid}}</span>
                    </router-link>
                </span>
                <br>
                <br>
            </el-card>
		</el-main>
		</el-container>
</template>

<script>
    export default {
        name:'zu2errorpage',
        props:['errorid'],
        data(){return {}  },
        computed:{},
        methods:{
            
        },
    };
</script>



