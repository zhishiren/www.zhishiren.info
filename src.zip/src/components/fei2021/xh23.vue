<template>
	<div id="xh23">
            <el-row class="font18px">
                <span>你共关注了{{this.listNum}}条段落。</span>
                <chazhaolan0 @shuaxin="shuaxin" @huanyuan="huanyuan" @get_list="get_list" @send_searchword="send_searchword" :listNumk="listNumk"></chazhaolan0>
            </el-row>

            <div v-show="show_xh23 && show_loading===false">
                <el-row class="br10px17px" v-for="list in lists" :key="list.pk">
						<el-row>
                            <router-link class="a_black" target="_blank" :to="{name:'wenduanye',params:{id:list.fields.item0_id}}">
                                    {{list.fields.item0_title}}
                            </router-link> 
                            <!-- <a @click="quguan(list.fields.act_id)" class="a_grey"><i class="el-icon-close">取关</i></a> -->
                            <span style="float:right;">{{formatDate_ymd(list.fields.act_createtime)}}</span>
						</el-row>
						<el-row>
                            <span style="float:left;color:grey">关注附言:</span>
                                <bianji0fuyan :fuid="list.pk" :fuyan="list.fields.act_fuyan"></bianji0fuyan>
						</el-row>
					    <el-row><el-divider></el-divider></el-row>
				</el-row>
                <el-pagination  v-if="listNum>10" style="text-align:right;"
                                background
                                :page-size=10
                                :total="listNum"
                                :current-page.sync="currentPage"
                                layout="total, prev, pager, next">
                </el-pagination>
            </div>
                            <div v-if="this.show_loading===true">
                    <div style="font-size:30px;color:grey;"><i class="el-icon-loading"></i>正在加载...</div>
                </div>

            <div v-show="show_xhk23">
                <el-row class="br10px17px" v-for="listk in listks" :key="listk.pk">
						<el-row>
                            <router-link class="a_black" target="_blank" :to="{name:'wenduanye',params:{id:listk.fields.item0_id}}">
                                    <span v-html="gaoliangk(listk.fields.item0_title, k)" ></span>
                            </router-link>
                            <!-- <a @click="quguan(listk.fields.act_id)" class="a_grey"><i class="el-icon-close">取关</i></a> -->
                            <span style="float:right;">{{formatDate_ymd(listk.fields.act_createtime)}}</span>
						</el-row>
						<el-row>
                            <span style="float:left;color:grey">关注附言:</span>
                                <bianji0fuyan0k :k="k" :fuid="listk.pk" :fuyan="listk.fields.act_fuyan"></bianji0fuyan0k>
                            
						</el-row>
					    <el-row><el-divider></el-divider></el-row>
                        
				</el-row>
                <!-- 下面的div是用来显示筛选后的分页条 -->
                <el-pagination  v-if="listNumk>10" style="text-align:right;"
                                background
                                :page-size=10
                                :total="listNumk"
                                :current-page.sync="currentPagek"
                                layout="total, prev, pager, next">
                </el-pagination>
            </div>
    </div>
</template>

<script>
import chazhaolan0 from '../fujian/chazhaolan0';
import bianji0fuyan from '../fujian/bianji_fuyan';
import bianji0fuyan0k from '../fujian/bianji_fuyan_k';

export default {
    name:'xh23',
    components: {chazhaolan0,bianji0fuyan,bianji0fuyan0k},
    
	data() {return {
        currentPage: 1,//当前分页的数值
        listNum:0,//分页总条数
        currentPagek: 1,//查找后，当前分页的数值
        listNumk:0,//查找后，分页总条数

        show_xh23:false,
        show_xhk23:false,
        xh23s:[],
        xh23ks:[],
        k:'',
        show_loading:false,
    }},

	computed: {
            lists(){
                let pages=Math.ceil(this.listNum/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                    let sonList=[];
                    sonList=this.xh23s.slice(i*10,i*10+10);//10为每页设置数量
                    newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
            listks(){
                let pages=Math.ceil(this.listNumk/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                    let sonList=[];
                    sonList=this.xh23ks.slice(i*10,i*10+10);//10为每页设置数量
                    newList.push(sonList)
                }
                return newList[this.currentPagek-1]
            },
    },
    
	methods:{

      send_searchword(data){
          this.show_xh23=false;
          this.show_xhk23=true;
          this.k=data.k;
　　　　　　　　var newList = [];
　　　　　　　　this.xh23s.forEach(item=>{if(item.fields.item0_title.indexOf(this.k) !==-1||item.fields.act_fuyan.indexOf(this.k) !==-1){newList.push(item)}});
             this.listNumk = newList.length;//这里是计算筛选后的结果的数量
　　　　　　   this.xh23ks = newList;
      },

      get_list(){
          this.show_loading=true;
        this.show_xh23=true;
        this.show_xhk23=false;
        this.$axios
        .post('http://www.zhishiren.info/api/xunhuan23/', {userid:this.$cookies.get('userid')})
        .then(response=>{
            this.xh23s=JSON.parse(response.data);
            this.listNum=this.xh23s.length;
            this.show_loading=false;
            });
      },

      huanyuan(){
          this.show_loading=true;
            this.show_xh23=true;
            this.show_xhk23=false;
            this.$nextTick(() => {
                this.$axios
                .post('http://www.zhishiren.info/api/xunhuan23/', {userid:this.$cookies.get('userid')})
                .then(response=>{
                    this.xh23s=JSON.parse(response.data);
                    this.listNum=this.xh23s.length;
                    this.show_loading=false;
                    });
            });
      },

      shuaxin(){
          this.show_loading=true;
            this.show_xh23=true;
            this.show_xhk23=false;
            this.$nextTick(() => {
                this.$axios
                .post('http://www.zhishiren.info/api/xunhuan23/', {userid:this.$cookies.get('userid')})
                .then(response=>{
                    this.xh23s=JSON.parse(response.data);
                    this.listNum=this.xh23s.length;
                    this.show_loading=false;
                    });
            });
      },
    },	
    created: function () {
            this.$axios
                .post('http://www.zhishiren.info/api/count23/', {userid:this.$cookies.get('userid')})
                .then(response=>{this.listNum=response.data;});
	}
};
</script>

<style>
</style>


