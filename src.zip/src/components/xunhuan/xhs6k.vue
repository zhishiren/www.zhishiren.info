<template>
	<div id="xhs6k">
            <el-row class="font18px">
                <span style="color:blue"><i class="el-icon-finished"></i>{{this.jishu}}条搜索结果。</span>
            </el-row>
			
			<el-row v-for="l in ls" :key="l.pk" class="br10px17px">
                <zu0niming :uname="l.fields.uname" :uid1="l.fields.uid1"></zu0niming>
                <span v-if="l.fields.cztype==='加入标签'">添加了</span>
                <span v-if="l.fields.cztype==='关联'">关联了</span>
                <span v-if="l.fields.cztype==='分享'">分享了</span>
                <span v-if="l.fields.cztype==='评论'">评论了</span>
                <zu1yuansu :list="l"></zu1yuansu>
                <span style="color:grey;">:<span v-html="gaoliangk(l.fields.fy, k)"></span></span>
                <zu1huifulan :list='l' @shanchuok="shuaxinjian()"></zu1huifulan>
                <el-row><el-divider style="margin:0px;"></el-divider></el-row>
			</el-row>
            <br>
            <el-pagination  v-if="jishu>10" style="text-align:right;"
                            background
                            :page-size=10
                            :total="jishu"
                            :current-page.sync="currentPage"
                            layout="total, prev, pager, next">
            </el-pagination>

    </div>
</template>
<script>

export default {
    name:'xhs6k',
    components: {},
    props:['list','jishu','k'],
	data() {return {
        currentPage: 1,//当前分页的数值
    }},

    computed: {
            ls(){
                let pages=Math.ceil(this.jishu/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                    let sonList=[];
                    sonList=this.list.slice(i*10,i*10+10);//10为每页设置数量
                    newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },


    },

    methods: {
        kk6(){this.currentPage=1;},
        shuaxinjian(){this.$emit('sousuoshuaxin');},

    },

};
</script>


<!-- <el-row>
                    <niming :niming_yn='l.fields.item1_title' :createrid='l.fields.act_createrid' :creatername='l.fields.act_creatername'></niming>
                    <span v-if="l.fields.act_type==='a04'">
                        <span style="color:grey;">评论了</span>
                        <router-link class="a_black" target="_blank" :to="{name:l.fields.item0_type,params:{id:l.fields.item0_id}}">
                            <span><i v-if="l.fields.item0_type==='yonghuye'" class="el-icon-s-custom"></i>{{l.fields.item0_title}}</span>
                        </router-link>
                    </span>
                    <span v-if="l.fields.act_type==='a03'">
                        <span style="color:grey;">添加了</span>
                        <router-link class="a_black" target="_blank" :to="{name:l.fields.item1_type,params:{id:l.fields.item1_id}}">
                            <span><i v-if="l.fields.item1_type==='yonghuye'" class="el-icon-s-custom"></i>{{l.fields.item1_title}}</span>
                        </router-link>
                        <span style="color:grey;">到标签</span>
                        <router-link class="a_black" target="_blank" :to="{name:l.fields.item0_type,params:{id:l.fields.item0_id}}">
                            <span>{{l.fields.item0_title}}</span>
                        </router-link>
                    </span>
                    <span v-if="l.fields.act_type==='a18'">
                        <span style="color:grey;">关联了</span>
                        <router-link class="a_black" target="_blank" :to="{name:l.fields.item0_type,params:{id:l.fields.item0_id}}">
                            <span>{{l.fields.item0_title}}</span>
                        </router-link>
                        <span style="color:grey;">和</span>
                        <router-link class="a_black" target="_blank" :to="{name:l.fields.item1_type,params:{id:l.fields.item1_id}}">
                            <span><i v-if="l.fields.item1_type==='yonghuye'" class="el-icon-s-custom"></i>{{l.fields.item1_title}}</span>
                        </router-link>
                    </span>
                </el-row> -->