        <el-card class="box-card" v-if="!userinfo.yonghu_id" style="height:250px;padding-left:10px;">
            <br><br><br>
            <div style="text-align:center;font-size:50px;color:grey;"><i class="el-icon-loading"></i>正在加载...</div>
        </el-card>
        <el-card class="box-card" v-if="userinfo.yonghu_id">
            <el-col v-if="userinfo.yonghu_touxiang===1" :span="5" style="text-align:center;background-size:100% 100%;height:260px;">
                <div v-if="show_touxiang1===false" style="padding-top:100px;" class="a_grey font18px">
                    <a @click="showtouxiang1()">
                        <i class="el-icon-s-custom" style="font-size:30px;"></i>
                        <br>
                        查看头像
                    </a>
                </div>
                <img v-if="show_touxiang1===true" alt="" :src="timestamp('https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/touxiang/'+this.userid+'.jpg')" style="width:100%;height:250px;">
            </el-col>
            <el-col v-if="userinfo.yonghu_touxiang===0" :span="5" style="background-size:100% 100%;height:250px;text-align:center;padding-top:100px;">
                <i class="el-icon-user" style="font-size:30px;"></i>
                <br>
                尚无头像
            </el-col>
            <el-col :span="19">
                <div v-if="userinfo.yonghu_type==='普通用户' || userinfo.yonghu_type==='内容整理'" class="font18px_gray section_userinfo">
                    用户名称：<span class="font18px_black">{{this.userinfo.yonghu_name}}</span><br>
                    <!-- 用户类型：<span class="font18px_black">{{this.userinfo.yonghu_type}}</span><a class="el-icon-thumb a_grey">升级</a><br> -->
                    用户类型：<span class="font18px_black">{{this.userinfo.yonghu_type}}</span><br>
                    用户ID号：<span class="font18px_black">{{this.userinfo.yonghu_id}}</span><br>
                    注册时间：<span class="font18px_black">{{getNowFormatDate(this.userinfo.yonghu_borntime)}}</span><br>
                    <!-- 上次登录：<span class="font18px_black">{{getNowFormatDate(this.userinfo.yonghu_updatetime)}}</span><br> -->
                    行业岗位：<zu0z41edituserinfo @freshinfo="freshinfo" :inputzhi0="userinfo.yonghu_job" :id="userid" length=20 type="1" inputzhi1="请输入你所属的行业岗位，如金融-银行-内审" ></zu0z41edituserinfo>
                    <br>
                    国家地区：<zu0z41edituserinfo @freshinfo="freshinfo" :inputzhi0="userinfo.yonghu_area" :id="userid" length=15 type="2" inputzhi1="请输入你所属的地区，如江苏-南京" ></zu0z41edituserinfo>
                    <br>
                    联系方式：<zu0z41edituserinfo @freshinfo="freshinfo" :inputzhi0="userinfo.yonghu_contact" :id="userid" length=17 type="3" inputzhi1="请输入你的联系方式，如邮箱或微信号" ></zu0z41edituserinfo>
                    <br>
                    爱好特长：<zu0z41edituserinfo @freshinfo="freshinfo" :inputzhi0="userinfo.yonghu_hobby" :id="userid" length=9 type="4" inputzhi1="请输入你的兴趣爱好" ></zu0z41edituserinfo>
                    <br>
                    个人签名：<zu0z41edituserinfo @freshinfo="freshinfo" :inputzhi0="userinfo.yonghu_remark" :id="userid" length=14 type="5" inputzhi1="请输入你的个人签名，限20个字" ></zu0z41edituserinfo>
                    <br>
                    数据统计：<span class="font18px" style="color:green">
                        <span>来访主页{{this.userjishu.dianji}}<el-divider direction="vertical"></el-divider></span>
                        <span>关注我{{this.userjishu.guanzhu}}<el-divider direction="vertical"></el-divider></span>
                        <span>分享我{{this.userjishu.fenxiang}}</span>
                    </span>						
                </div>

                <div v-if="userinfo.yonghu_type==='历史人物'"  class="font18px_gray section_userinfo">
                    名称类型：<span class="font18px_black">{{this.userinfo.yonghu_name}}<el-divider direction="vertical"></el-divider>{{this.userinfo.yonghu_type}}</span><br>
                    用户ID号：<span class="font18px_black">{{this.userinfo.yonghu_id}}</span><br>
                    生卒年月：<span class="font18px_black">{{this.userinfo.yonghu_born}}</span><br>
                    职业身份：<zu0z41edituserinfo @freshinfo="freshinfo" :inputzhi0="userinfo.yonghu_job" :id="userid" length=20 type="1" inputzhi1="请输入你所属的行业岗位，如金融-银行-内审" ></zu0z41edituserinfo>
                    <br>
                    国家地区：<zu0z41edituserinfo @freshinfo="freshinfo" :inputzhi0="userinfo.yonghu_area" :id="userid" length=15 type="2" inputzhi1="请输入你所属的地区，如江苏-南京" ></zu0z41edituserinfo>
                    <br>
                    人物签名：<zu0z41edituserinfo @freshinfo="freshinfo" :inputzhi0="userinfo.yonghu_remark" :id="userid" length=14 type="5" inputzhi1="请输入你的个人签名，限20个字" ></zu0z41edituserinfo>
                    <br>
                    数据统计：<span class="font18px" style="color:green">
                        <span>来访主页{{this.userjishu.dianji}}<el-divider direction="vertical"></el-divider></span>
                        <span>关注我{{this.userjishu.guanzhu}}<el-divider direction="vertical"></el-divider></span>
                        <span>分享我{{this.userjishu.fenxiang}}</span>
                    </span>	
                    <br>
                    生平事迹：<zu0z41edituserinfo @freshinfo="freshinfo" :inputzhi0="userinfo.yonghu_life" :id="userid" length=15 type="6" inputzhi1="请输入生平事迹，限120字" ></zu0z41edituserinfo>		
                </div>

                <div v-else-if="userinfo.yonghu_type==='当代人物'" class="font18px_gray" style="height:250px;padding-left:10px;">
                    &nbsp;人物名称：<span class="font18px_black">{{this.userinfo.yonghu_name}}<el-divider direction="vertical"></el-divider><span>{{this.userinfo.yonghu_type}}</span>
                                </span><br>
                    &nbsp;用户ID号：<span class="font18px_black">{{this.userinfo.yonghu_id}}</span><span style="color:grey">
                                </span><br>
                    &nbsp;生日地区：<span class="font18px_black">{{this.userinfo.yonghu_born}}<span style="color:grey">-</span>{{this.userinfo.yonghu_area}}</span><br>
                    <!-- &nbsp;生卒年月：<span class="font18px_black">{{this.userinfo.yonghu_born}}<el-divider direction="vertical"></el-divider>{{this.userinfo.yonghu_dead}}</span><br> -->
                    &nbsp;联系方式：<span class="font18px_black">{{this.userinfo.yonghu_contact}}</span><br>
                    &nbsp;人物名言：<span class="font18px" style="color:brown;">{{this.userinfo.yonghu_remark}}</span><br>
                    &nbsp;数据统计：<span class="font18px" style="color:green">
                                        <span>访问他{{this.userjishu.dianji}}<el-divider direction="vertical"></el-divider></span>
                                        <span>关注他{{this.userjishu.guanzhu}}<el-divider direction="vertical"></el-divider></span>
                                        <span>分享他{{this.userjishu.fenxiang}}</span>
                                </span>
                    <br>
                    生平事迹：<span>{{this.userinfo.yonghu_life}}职业生涯+目前状态</span>
                </div>

                <div v-else-if="userinfo.yonghu_type==='安人组织'" class="font18px_gray" style="height:250px;padding-left:10px;">
                    &nbsp;组织名称：<span class="font18px_black">{{this.userinfo.yonghu_name}}<el-divider direction="vertical"></el-divider><span>{{this.userinfo.yonghu_type}}</span>
                                </span><br>
                    &nbsp;用户ID号：<span class="font18px_black">{{this.userinfo.yonghu_id}}</span><span style="color:grey">
                                </span><br>
                    &nbsp;地区行业：<span class="font18px_black">{{this.userinfo.yonghu_area}}</span><br>
                    &nbsp;联系方式：<span class="font18px" style="color:brown;">{{this.userinfo.yonghu_contact}}</span><br>
                    &nbsp;数据统计：<span class="font18px" style="color:green">
                                        <span>访问它{{this.userjishu.dianji}}<el-divider direction="vertical"></el-divider></span>
                                        <span>关注它{{this.userjishu.guanzhu}}<el-divider direction="vertical"></el-divider></span>
                                        <span>分享它{{this.userjishu.fenxiang}}</span>
                                </span>
                    <br>
                    组织介绍：<span>{{this.userinfo.yonghu_life}}</span>
                </div>
            </el-col>
        </el-card>



        <el-col v-if="userinfo.yonghu_touxiang===1" :span="5" style="background-repeat:no-repeat;background-size:100% 100%;height:260px;text-align:center;">
						<div style="padding-top:100px;" class="a_grey font18px" v-if="show_touxiang===false">
							<a @click="showtouxiang()">
								<i class="el-icon-s-custom font20px"></i>
								<br>
								查看头像
							</a>
						</div>
						<img v-if="show_touxiang" alt="" :src="timestamp('https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/touxiang/'+this.yonghuid+'.jpg')" style="width:100%;height:250px;"> 
					</el-col>
					<el-col v-if="userinfo.yonghu_touxiang===0" :span="5" >
						<div v-if="userinfo.yonghu_type!=='工团企业'" style="background-repeat:no-repeat;background-size:100% 100%;height:255px;background-image:url(https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/touxiang/90000000.jpg);"></div>
						<div v-if="userinfo.yonghu_type==='工团企业'" style="background-repeat:no-repeat;background-size:100% 100%;height:255px;background-image:url(https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/touxiang/qiyelogo0.jpg);"></div>
					<!-- <el-col v-if="userinfo.yonghu_touxiang===0 && userinfo.yonghu_type==='工团企业'" :span="5" style="background-repeat:no-repeat;background-size:100% 100%;height:255px;background-image:url(https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/touxiang/qiyelogo.jpg);"> -->
					</el-col>
					<el-col :span="19">
						<div v-if="!userinfo.yonghu_id" style="height:250px;padding-left:10px;">
							<br><br><br><div style="text-align:center;font-size:50px;color:grey;"><i class="el-icon-loading"></i>正在加载</div>
						</div>
						<div v-if="userinfo.yonghu_type==='普通用户' || userinfo.yonghu_type==='内容整理'" class="font18px_gray" style="height:250px;padding-left:10px;">
							&nbsp;名称类型：<span class="font18px_black">{{this.userinfo.yonghu_name}}<el-divider direction="vertical"></el-divider><span>{{this.userinfo.yonghu_type}}</span>
												<!-- <a @click="xiugai_type"><i v-if="xiaozhi_id===90000106" class="el-icon-edit"></i></a>
												<input v-if="show_queding"  v-model="changed_type" type="text" class="font18px" style="width:80px;" >
												<a v-if="show_queding" @click="queding" class="font18px"><i class="el-icon-check"></i>确定</a> 
												<a v-if="show_queding" @click="huanyuan" class="font18px"><i class="el-icon-refresh-left"></i>还原</a> -->
										</span><br>
							&nbsp;用户ID号：<span class="font18px_black">{{this.userinfo.yonghu_id}}</span><span style="color:grey">
											<!-- <i class="el-icon-chat-dot-round"></i>聊天 -->
										</span><br>
							&nbsp;注册时间：<span class="font18px_black">{{getNowFormatDate(this.userinfo.yonghu_borntime)}}</span><br>
							&nbsp;最近登录：<span class="font18px_black">{{getNowFormatDate(this.userinfo.yonghu_updatetime)}}</span><br>
							&nbsp;行业岗位：<span class="font18px_black">{{this.userinfo.yonghu_job}}</span><br>
							&nbsp;国家地区：<span class="font18px_black">{{this.userinfo.yonghu_area}}</span><br>
							&nbsp;联系方式：<span class="font18px_black">{{this.userinfo.yonghu_contact}}</span><br>
							&nbsp;爱好特长：<span class="font18px_black">{{this.userinfo.yonghu_hobby}}</span><br>
							&nbsp;个人签名：<span class="font18px" style="color:brown;">{{this.userinfo.yonghu_remark}}</span><br>
							&nbsp;数据统计：<span class="font18px" style="color:green">
												<span>访问他{{this.userjishu.dianji}}<el-divider direction="vertical"></el-divider></span>
												<span>关注他{{this.userjishu.guanzhu}}<el-divider direction="vertical"></el-divider></span>
												<span>分享他{{this.userjishu.fenxiang}}</span><el-divider direction="vertical"></el-divider></span>
												<span style="color:black">屏蔽他{{this.userjishu.fenxiang}}</span>
										</span>
						</div>
						<div v-else-if="userinfo.yonghu_type==='历史人物'" class="font18px_gray" style="height:250px;padding-left:10px;">
							&nbsp;名称类型：<span class="font18px_black">{{this.userinfo.yonghu_name}}<el-divider direction="vertical"></el-divider><span>{{this.userinfo.yonghu_type}}</span>
										</span><br>
							&nbsp;用户ID号：<span class="font18px_black">{{this.userinfo.yonghu_id}}</span><span style="color:grey">
										</span><br>
							&nbsp;生卒年月：<span class="font18px_black">{{this.userinfo.yonghu_born}}</span><br>
							<!-- &nbsp;生卒年月：<span class="font18px_black">{{this.userinfo.yonghu_born}}<el-divider direction="vertical"></el-divider>{{this.userinfo.yonghu_dead}}</span><br> -->
							&nbsp;职业身份：<span class="font18px_black">{{this.userinfo.yonghu_job}}</span><br>
							&nbsp;国家地区：<span class="font18px_black">{{this.userinfo.yonghu_area}}</span><br>
							&nbsp;人物名言：<span class="font18px" style="color:brown;">{{this.userinfo.yonghu_remark}}</span><br>
							&nbsp;数据统计：<span class="font18px" style="color:green">
												<span>访问他{{this.userjishu.dianji}}<el-divider direction="vertical"></el-divider></span>
												<span>关注他{{this.userjishu.guanzhu}}<el-divider direction="vertical"></el-divider></span>
												<span>分享他{{this.userjishu.fenxiang}}</span>
										</span>
							<br>
							生平事迹：<span>{{this.userinfo.yonghu_life}}</span>
						</div>
						<div v-else-if="userinfo.yonghu_type==='当代人物'" class="font18px_gray" style="height:250px;padding-left:10px;">
							&nbsp;人物名称：<span class="font18px_black">{{this.userinfo.yonghu_name}}<el-divider direction="vertical"></el-divider><span>{{this.userinfo.yonghu_type}}</span>
										</span><br>
							&nbsp;用户ID号：<span class="font18px_black">{{this.userinfo.yonghu_id}}</span><span style="color:grey">
										</span><br>
							&nbsp;生日地区：<span class="font18px_black">{{this.userinfo.yonghu_born}}<span style="color:grey">-</span>{{this.userinfo.yonghu_area}}</span><br>
							<!-- &nbsp;生卒年月：<span class="font18px_black">{{this.userinfo.yonghu_born}}<el-divider direction="vertical"></el-divider>{{this.userinfo.yonghu_dead}}</span><br> -->
							&nbsp;联系方式：<span class="font18px_black">{{this.userinfo.yonghu_contact}}</span><br>
							&nbsp;人物名言：<span class="font18px" style="color:brown;">{{this.userinfo.yonghu_remark}}</span><br>
							&nbsp;数据统计：<span class="font18px" style="color:green">
												<span>访问他{{this.userjishu.dianji}}<el-divider direction="vertical"></el-divider></span>
												<span>关注他{{this.userjishu.guanzhu}}<el-divider direction="vertical"></el-divider></span>
												<span>分享他{{this.userjishu.fenxiang}}</span>
										</span>
							<br>
							生平事迹：<span>{{this.userinfo.yonghu_life}}职业生涯+目前状态</span>
						</div>
						<div v-else-if="userinfo.yonghu_type==='工团企业'" class="font18px_gray" style="height:250px;padding-left:10px;">
							&nbsp;企业名称：<span class="font18px_black">{{this.userinfo.yonghu_name}}<el-divider direction="vertical"></el-divider><span>{{this.userinfo.yonghu_type}}</span>
										</span><br>
							&nbsp;企业ID号：<span class="font18px_black">{{this.userinfo.yonghu_id}}</span><span style="color:grey">
										</span><br>
							&nbsp;地区行业：<span class="font18px_black">{{this.userinfo.yonghu_area}}</span><br>
							&nbsp;联系方式：<span class="font18px" style="color:brown;">{{this.userinfo.yonghu_contact}}</span><br>
							&nbsp;数据统计：<span class="font18px" style="color:green">
												<span>访问它{{this.userjishu.dianji}}<el-divider direction="vertical"></el-divider></span>
												<span>关注它{{this.userjishu.guanzhu}}<el-divider direction="vertical"></el-divider></span>
												<span>分享它{{this.userjishu.fenxiang}}</span>
										</span>
							<br>
						    组织介绍：<span>{{this.userinfo.yonghu_life}}</span>
						</div>
					</el-col>