
// 这是用于“提问”的小组件
<template>
    <div id="zu1wenda">

        <el-row>
            <span style="color:brown;">
                <font style="font-size:18px;">
                    <span><b>“</b></span>
                    <!-- <router-link class="a_black" target="_blank" :to="{name:'fayanye',params:{id:l.pk}}"> -->
                        <span style="color:brown">测试测试测试</span>
                    <!-- </router-link> -->
                    <span><b>”</b></span>
                </font>
            </span>
            <!-- 这个正在审核的功能是在全部用户问答列表中使用。 -->
            <!-- <span>提问内容:<span style="background-color:grey;color:white;">正在审核</span></span> -->
            <!-- <i class="el-icon-right a_grey" style="float:right;">重发</i>  -->
        </el-row>
        <el-row>
            <span style="color:orange;">正在审核|</span>
            <span style="color:red;">已经删除|</span>
            <span style="color:grey;">人生困惑|</span>
            <span><i class="el-icon-paperclip"></i>《测试的文字》</span>
            <span style="float:right;color:grey;">
                <i class="el-icon-close"></i>删|10天前</span>
        </el-row>
        <el-row><el-divider style="margin:0px;"></el-divider></el-row>  
    </div>
</template>

<script>
  export default {
    name:'zu1wenda',
    data() {
      return {

      }
    },

    props:['list','kkk'],

    methods:{
        

    }

  }
</script>





