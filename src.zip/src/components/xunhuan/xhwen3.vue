
<template>
	<div id="xhwen3">
        <zu1caozuojishu zone_id="wen3" :jishu="listNum0" :showloading1="showloading1" :showloading2="showloading2" @zhankai="zhankaijian()" @shuaxin="shuaxinjian()"></zu1caozuojishu>
        <div v-if="showloading2===false">
            <el-row v-for="item in lists" :key="item.pk"  class="br10px17px">
                <el-row>
                    <zu0niming :uname="item.fields.uname" :uid1="item.fields.uid1"></zu0niming>:
                    <zu1yuansu :list="item"></zu1yuansu>
                </el-row>
                <zu1huifulan :list="item"  @shanchuok="shanok"></zu1huifulan>
                <el-row><el-divider style="margin:0px;"></el-divider></el-row>
            </el-row>
            <br>
            <el-pagination v-if="listNum>10" style="text-align:right;"
                            background
                            :page-size=10
                            :total="listNum"
                            :current-page.sync="currentPage"
                            layout="total, prev, pager, next">
            </el-pagination>
        </div>
        <!-- <div v-if="fy1 && xhs5_loading===false">
            <el-row v-for="l in fy1" :key="l.pk" class="br10px17px">
                <zu0niming :uname="l.fields.uname" :uid1="l.fields.uid1" :uid0="l.fields.uid0"></zu0niming>:
                <span style="color:brown;">
                    <font style="font-size:18px;">
                        <span><b>“</b></span>
                        <router-link class="a_black" target="_blank" :to="{name:'fayanye',params:{id:l.pk}}">
                            <span style="color:brown" v-html="l.fields.fy" ></span>
                        </router-link>
                        <span><b>”</b></span>
                    </font>
                </span>
                <zu1huifulan :list='l' @shanchuok="shuaxinjian()"></zu1huifulan>
                <el-row><el-divider style="margin:0px;"></el-divider></el-row>
            </el-row>
        </div> -->
    </div>
</template>
<script>

export default {
    name:'xhwen3',
    components: {},
    props:['listNum0'],
	data() {return {
        showloading1:false,
        showloading2:false,
        xhwen3:[],
        currentPage: 1,//当前分页的数值
        listNum:0,
    }},

    computed:{
            lists(){
                let pages=Math.ceil(this.listNum/10);//
                let newList=[];
                for(let i=0;i<pages;i++){
                let sonList=[];
                sonList=this.xhwen3.slice(i*10,i*10+10);//
                newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
		},

	methods:{
            shanok(){this.shuaxinjian();},
            zhankaijian(){this.shuaxinjian();},
            shuaxinjian(){
                this.showloading2=true;
                this.$nextTick(() => {
                    this.$axios
                        .get('http://www.zhishiren.info/api/xunhuan_wen3/')
                        .then(response=>{
                            this.xhwen3=JSON.parse(response.data);
                            this.listNum=this.xhwen3.length;
                            this.listNum0=this.xhwen3.length;
                            this.showloading2=false;
                    });
                });
            },

    },	
};
</script>

