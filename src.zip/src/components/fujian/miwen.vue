<template>
    <span v-if="zishu!==0"  style="color:grey;" id="miwen">
        <span>一段{{this.zishu}}字的密文</span>
        <input style="width:1px;border-color:white;border:0px;" type="text" v-model="content" :id="pkid">
        <a class="a_brown" @click="kcopy(pkid)" style="color:brown;"><i class="el-icon-document-copy"></i>点击复制密文</a>
    </span>
</template>

<script>
export default {
    name:'miwen',
    props:['zishu','content','pkid'],
	data() {return {}},
    methods:{
        kcopy(a){
        let copycode = document.getElementById(a);
            copycode.select(); // 选择对象
            document.execCommand("Copy"); // 执行浏览器复制命令
            alert("密文已经复制到你的粘贴板，请到首页右侧‘密’功能栏解密。");
        },
	},
};

</script>



