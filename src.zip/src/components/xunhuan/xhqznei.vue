<template>
	<div id="xhqznei">
        <zu1caozuojishu v-if="dongtaitype==='我'" zone_id="发言" :jishu="listNum" :showloading1="showloading1" :showloading2="showloading2"  @zhankai="zk" @shuaxin="shuaxin"></zu1caozuojishu>  
        <zu1caozuojishu v-if="dongtaitype==='群'" zone_id="群发言" :jishu="listNum0" :showloading1="showloading1" :showloading2="showloading2"  @zhankai="zk" @shuaxin="shuaxin" :fanwei='qzid'></zu1caozuojishu>  
        <zu1caozuojishu v-if="dongtaitype==='TA'" zone_id="TA动态" :jishu="listNum" :showloading1="showloading1" :showloading2="showloading2"  @zhankai="zk" @shuaxin="shuaxin"></zu1caozuojishu>  
        <zu1caozuojishu v-if="dongtaitype==='发言列表'" zone_id="发言列表" :jishu="listNum0" :showloading1="showloading1" :showloading2="showloading2"  @zhankai="zk" @shuaxin="shuaxin"></zu1caozuojishu>  
        <div v-if="showloading2===false">
            <el-row class="br10px17px" v-for="list in lists" :key="list.pk" >
                <el-row>
                    <zu0niming v-if="dongtaitype==='群'" :uid1='list.fields.uid1' :uname='list.fields.uname'></zu0niming>
                    <span v-if="dongtaitype==='我'">我</span>
                    <span v-if="dongtaitype==='TA'">TA</span>
                    <span v-if="list.fields.cztype==='发言'&&dongtaitype!=='发言列表'">发言：</span>
                    <span v-if="list.fields.cztype==='分享'">分享了</span>
                    <zu1yuansu onlyid1=0 :list="list"></zu1yuansu>
                    <zu0fy v-if="list.fields.cztype!=='发言'" :list="list" ></zu0fy>
                </el-row>
                <!-- <zu0zu0fujianfutu v-if="list.fujian!==0" :zhid="list.item0_id" :futujian="list.fujian"></zu0zu0fujianfutu> -->
                <zu1huifulan :list='list' :qzid_yn='dongtaitype' @shanchuok="shuaxin()"></zu1huifulan>
                <el-row><el-divider style="margin:0px;"></el-divider></el-row>
            </el-row>
            <br>
            <el-pagination v-if="listNum1>10" style="text-align:right;"
                background
                :page-size=10
                :total="listNum1"
                :current-page.sync="currentPage"
                layout="total, prev, pager, next">
            </el-pagination>
        </div>
    </div>
</template>

<script>

export default {
    name:'xhqznei',
    props:['qzid','yonghuid','dongtaitype','listNum'],
    components: {},
    
	data() {return {
        currentPage: 1,//当前分页的数值
        listNum0:0,
        listNum1:0,//这里与上面的变量区别开，用来控制分页条,listNum
        xhqznei:[],

        showloading2:false,
        showloading1:false,
    }},

	computed: {
            lists(){
                let pages=Math.ceil(this.listNum/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                let sonList=[];
                sonList=this.xhqznei.slice(i*10,i*10+10);//10为每页设置数量
                newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
            watchObj () {
                let {qzid,dongtaitype} = this;
                return {qzid,dongtaitype}
            },
            
    },
    
	methods:{
        zk(){this.shuaxin();},
        shanok(){this.shuaxin();},
        shuaxin(){
            this.showloading2=true;
            var that=this;
            that.$axios
                .post('http://www.zhishiren.info/api/xunhuanqznei/', {
                    qzid:that.qzid,
                    yonghuid:that.yonghuid,
                    dongtaitype:that.dongtaitype,
                    userid:that.$cookies.get('userid'),
                    chuan:that.$cookies.get('chuan'),
                    })
                .then(response=>{
                    that.xhqznei=JSON.parse(response.data);
                    that.listNum=that.xhqznei.length;
                    that.listNum0=that.xhqznei.length;
                    that.listNum1=that.xhqznei.length;
                    that.currentPage=1;
                    that.showloading2=false;
                });
        },

    },	
    watch:{
        watchObj:{
            handler(newVal, oldVal){
                if(newVal.dongtaitype==='群'||newVal.dongtaitype==='发言列表'){
                    this.showloading1=true;
                    this.$axios
                    .post('http://www.zhishiren.info/api/countqznei/', {
                            qzid:newVal.qzid,
                            dongtaitype:newVal.dongtaitype,
                        })
                    .then(response=>{
                        this.listNum0=response.data;
                        this.showloading1=false;
                        });
                }
            },
            deep: true,
            immediate: true
        },
    },
    // watch: {
    //             qzid: function(newVal,oldVal){
    //                 this.user_id = newVal;
    //                 var that = this;
    //                 that.axios
    //                 .post('http://www.zhishiren.info/api/countyhy11/', {userid: that.user_id})
    //                 .then(response=>{that.listNum=response.data;});
    //             },
    //         },
};
</script>




