<template>
	<div id="zengbiaoqian">
        <el-row style="line-height: 40px;" >
            <el-col :span="2" ><span>标签标题：</span></el-col>
            <el-col :span="14" >
                <el-input v-model="bq_title" placeholder="请输入标签标题"  style="width:96%;" maxlength="10" show-word-limit></el-input>
            </el-col>
            <el-col :span="2" ><span >公开范围：</span></el-col>
            <el-col :span="6" >
                <zu0setfanwei ref="huanyuan" @set_fanwei="set_gongkaifanwei" style="width:90%;"></zu0setfanwei>            
            </el-col>
        </el-row>
        <br>
        <zu1fabujian @fabujian="fabujian" :faloading="faloading" :return_msg="return_msg"></zu1fabujian>
        <zu1caozuojishu zone_id="xzbq" :jishu="listNum0" :showloading1="showloading1" :showloading2="showloading2" @zhankai="zhankaijian()" @shuaxin="shuaxinjian()"></zu1caozuojishu>

        <div v-if="showloading2===false">
            <el-row v-for="item in lists" :key="item.pk"  class="br10px17px">
                <el-row>
                    <router-link class="a_black" style="float:left;" target="_blank" :to="{name:'biaoqianye',params:{id:item.pk}}">
                        <span style="float:left;">{{item.fields.bq_title}}</span>
                    </router-link>
                    <zu0uploadfu v-if="usertype==='内容整理'" :leixing=1 :fujianshu="item.fields.fu" :id="item.pk"></zu0uploadfu>
                </el-row>
                <el-row>
                    <span :style="{'color':(item.fields.bq_status==='失效已删'?'red':'black')}">{{item.fields.bq_status}}</span>
                    <span><el-divider direction="vertical"></el-divider></span>
                    <zu0showfanwei :qz_id="item.fields.bq_fanwei"></zu0showfanwei>
                    <zu0zengshanchu :zhid="item.pk" leixing="1" :yishan_yn="item.fields.bq_status" :time="item.fields.bq_createtime" @shanchuok="shanok()" ></zu0zengshanchu>
                </el-row>
                <el-row><el-divider style="margin:0px;"></el-divider></el-row>
            </el-row>
            <br>
            <el-pagination v-if="listNum>10" style="text-align:right;"
                            background
                            :page-size=10
                            :total="listNum"
                            :current-page.sync="currentPage"
                            layout="total, prev, pager, next">
            </el-pagination>
        </div>

</div>
    
</template>

<script type="text/javascript">

	export default {
		name: 'zengbiaoqian',
        props:['showloading1','listNum0'],
        components: {},
        data () {
			return {
                currentPage: 1,//当前分页的数值
                xhx1s:[],

                qunzu_id:90000000,
                bq_title:'',

                showloading2:false,
                faloading:false,
                return_msg:0,

                listNum:0
			}
        },
        computed:{
            lists(){
                let pages=Math.ceil(this.listNum/10);//
                let newList=[];
                for(let i=0;i<pages;i++){
                let sonList=[];
                sonList=this.xhx1s.slice(i*10,i*10+10);//
                newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
            usertype(){return this.$cookies.get('usertype')},

		},
		methods: {
            shanok() {this.shuaxinjian();},
            set_gongkaifanwei(data){this.qunzu_id = data.qz_id;},
            zhankaijian(){this.shuaxinjian();},
            shuaxinjian(){
                this.showloading2=true;
                this.axios
                .post('http://www.zhishiren.info/api/xunhuan_zengbiaoqian/',{userid: this.$cookies.get('userid')})
                .then(response=>{
                    this.xhx1s=JSON.parse(response.data);
                    this.listNum=JSON.parse(response.data).length;
                    this.listNum0=JSON.parse(response.data).length;
                    this.showloading2=false;
                    this.currentPage=1;
                    });
            },

            fabujian(data) {
                var fuyan=data.k;
                var that = this;
                if(that.bq_title===''){
                    that.return_msg='标签名不能为空!';
                    setTimeout(function(){that.return_msg='';}, 1500);
                }
                else{
                        that.axios
                        .post('http://www.zhishiren.info/api/zengbiaoqian/',{
                            userid: that.$cookies.get('userid'),
                            username:that.$cookies.get('username'),
                            bq_fanwei:that.qunzu_id,
                            bq_title:that.bq_title,
                            bq_remark:fuyan,
                            })
                        .then(function (response) {
                            that.faloading=false;
                            if (response.data.msg===1 ){
                                that.return_msg='操作成功';
                                setTimeout(function(){that.return_msg='';}, 2000);
                                that.bq_title='';
                                that.$refs.huanyuan.huanyuan();
                                that.shuaxinjian();
                            }
                            if (response.data.msg===3){
                                that.return_msg='操作失败';
                                setTimeout(function(){that.return_msg='';}, 1500);
                                that.showloading2=false;
                            }
                        });
                }
            },	
        },

	}
</script>

