<!-- 这个transition是elementjs中的动画效果，要放在显示内容的外部才有效果 -->
<template>
    <span id="zhankai0" class="font_yahei_18px">
		<a @click="zhankaijian" v-show="show_zhankai"  class="a_noline_black">-展开-</a> 
		<a @click="shuaxinjian" v-show="show_shuaxin"  class="a_noline_black"><i class="el-icon-refresh"></i>刷新</a>
    </span>
</template>

<script>
export default {
    name:'zhankai0',
    props: {sectionid: {type: Number,default: 0,}},
    computed:{
            url_xunhuan(){return '/api/xunhuan' + this.sectionid+'/'},
            url_xunhuanjishu(){return '/api/xunhuanjishu' + this.sectionid+'/'},
// 这里是对这个循环列表的计数的功能，在展开/查找/刷新的时候，会发送后台计算数据后，返回给全局变量
            },
            
	data() {return {show_zhankai:true,show_shuaxin:false,}},
        
    methods:{
				zhankaijian:function(){
					this.show_zhankai=false;
					this.show_shuaxin=true;

                    // this.$store.state['SHOW_XH'+this.sectionid]=true;
                    this.$store.state.SHOW_XH31=true;
				},

				shuaxinjian:function(){
					this.show_zhankai=false;
                    // this.$store.state.SHOW_XH31=false;
                    this.$store.state.SHOW_XH31=true;

                    // this.$store.state['SHOW_XH'+this.sectionid]=false;
                    // this.$store.state['SHOW_XH'+this.sectionid]=true;
                },
	},

};

</script>

<style scoped>


</style>
