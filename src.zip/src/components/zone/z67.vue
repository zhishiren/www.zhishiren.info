<template>
    <div id="z63">
        <el-row class="font20px">有实物</el-row>
		<el-row>
			<el-col :span="10">
					<el-image
						src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/z67a.jpg"
						:fit="fill">
					</el-image>
			</el-col>
			<el-col :span="14">
				<div class="huanhang">
					<b class="font20px">匿名聊天软件</b>	
					<br>
				</div>
			</el-col>
		</el-row>
		<br>
		<el-row>
			<el-col :span="14">
				<div class="huanhang">
					<b class="font20px">自由开源的软件市场</b>		
					<br>
				</div>
			</el-col>
			<el-col :span="10">
					<el-image
						src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/z67b.jpg"
						:fit="fill">
					</el-image>
			</el-col>
		</el-row>
		<br>
				<el-row>
			<el-col :span="10">
					<el-image
						src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/z67c.jpg"
						:fit="fill">
					</el-image>
			</el-col>
			<el-col :span="14">
				<div class="huanhang">
					<b class="font20px">模拟经营游戏《安那其社区》</b>(虚构无实例)
					<br>
				</div>
			</el-col>
		</el-row>
    </div>
</template>

<script>
    export default {
        name:'z63',
        props:[],
        data() {return {

        }},
        computed:{

        },
        methods:{
            
        },
    };
</script>



