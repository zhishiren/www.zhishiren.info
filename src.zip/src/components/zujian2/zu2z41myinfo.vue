<template>
<div id="zu2z41myinfo">
    <el-card class="box-card"  v-if="!userinfo" style="height:270px;font-size:40px;text-align:center;">
        <br><i class="el-icon-loading"></i>正在加载...
    </el-card>
    <zu2usercard  v-if="userinfo" :userinfo="userinfo" :userjishu="userjishu"></zu2usercard>
	<el-row>
        <br>
        <el-upload
            name="touxiang"
            class="upload-demo"
            action="http://www.zhishiren.info/api/shangchuan1/"
            Access-Control-Request-Headers: ContentType
            :data={user_id:this.userid}
            :on-preview="handlePreview"
            :on-remove="handleRemove"
            :on-success="shuaxintouxiang"
            :before-remove="beforeRemove"
            :on-change="onchange"
            :limit="1"
            :file-list="fileList"
            >
            <el-button v-if="ceshi_id===0" class="font18px" type="text">
                更改头像...
            </el-button>
            <el-button v-if="ceshi_id===1" disabled class="font18px" type="text">
                更改头像...
            </el-button>
            <span v-if="ceshi_id===1"><i class="el-icon-loading"></i>正在上传，请等待...</span>
            <span v-show="ceshi_id===0 && chuantouxiang_okmsg===9" class="font18px">仅限jpg/jpeg格式</span>
            <span v-show="chuantouxiang_okmsg===0" class="font18px" style="color:red">上传失败</span>
        </el-upload>
    </el-row>
    <el-row>
        <el-button @click="denglumima()" type="text" class="font18px">登陆密码...</el-button>
        <span v-if="dlmmok!==true" class="font18px">修改你的登陆密码。</span>
        <span v-if="dlmmok===true" style="color:red;font-size:18px;">修改成功！</span>
        <el-dialog title="修改你的登陆密码..." width="400px" :visible.sync="show_denglumima_dialog">
            <el-row>
                <el-col :span="7" class="font18px" style="padding-top:10px;">
                    修改密码：
                </el-col>
                <el-col :span="17">
                    <el-input v-model="denglumima0" placeholder="请输入你的登陆密码" style="width:90%;" show-password>
                    </el-input>
                </el-col>
            </el-row>
            <br>
            <el-row>
                <el-col :span="7" class="font18px" style="padding-top:10px;">
                    再次确认：
                </el-col>
                <el-col :span="17">
                    <el-input v-model="denglumima1" placeholder="请再次确认..." style="width:90%;" show-password>
                    </el-input>
                </el-col>
            </el-row>
            <br>
            <el-row style="text-align:center;">
                <span style="color:red;font-size:18px;">{{this.dlmm_kong}}</span>
                <span style="color:red;font-size:18px;">{{this.errormsg_dlmm}}</span>
            </el-row>
            <el-row style="text-align:center;">
                <a @click="commit_denglumima()" class="font20px a_black">确定</a>
            </el-row>
        </el-dialog>
    </el-row>
    <el-row>
        <el-button disabled type="text" class="font18px">下载我的...</el-button>
        <span class="font18px">下载我的所有评论附言。</span>
    </el-row>
    <!-- <el-row>
        <el-button type="text" class="font18px" disabled>个性设置...</el-button>
        <span class="font18px">选择你的历史动态公开的时间段。</span>
    </el-row> -->
</div>

</template>

<script>
import zu2usercard from './zu2usercard';

    export default {
        name:'zu2z41myinfo',
        props:['userinfo','userjishu'],//
        components: {zu2usercard},
        data() {return {
            dlmm_kong:'',
            errormsg_dlmm:'',
            dlmmok:false,
            denglumima0:'',
            denglumima1:'',
            ceshi_id:0,
            chuantouxiang_okmsg:9,
            show_denglumima_dialog:false,
        }},
        computed:{
            userid(){return this.$cookies.get('userid')},
        },
        methods:{

            shuaxintouxiang(response, file, fileList) {
                if(response===0){
                    this.chuantouxiang_okmsg=0;
                    setTimeout(function(){this.chuantouxiang_okmsg=9;}, 2000);
                }
                if(response===1){
                    this.$router.go(0);
                    // this.ceshi2=false;
                    // this.ceshi2=true;
                    // this.$refs.upload.clearFiles();
                    // this.chuantouxiang_okmsg=9;
                    // this.ceshi_id=0;
                }
            },

            handleExceed(files, fileList) {this.$message.warning(`每次操作只能上传一个文件！`);},
            beforeRemove(file, fileList) {return this.$confirm(`确定移除 ${ file.name }？`);},
            handleRemove(file, fileList) {console.log(file, fileList);},
            handlePreview(file) {console.log(file);},
            onchange(file, fileList){this.ceshi_id=1;},

            freshinfo(){
                var _this= this;
                _this.axios
                .post('http://www.zhishiren.info/api/show_mypage/', {userid:_this.$cookies.get('userid')})
                .then(function (response) {
                    _this.userinfo=response.data;
                    _this.userjishu=JSON.parse(response.data.yh_tongji)
                });
            },

            denglumima(){this.show_denglumima_dialog=true;},

            commit_denglumima(){
                var _this= this;
                if(_this.denglumima0===''||_this.denglumima1===''){
                    _this.dlmm_kong='输入不能为空！';
                    setTimeout(function(){_this.dlmm_kong='';}, 1500);
                }
                else{
                    if(_this.denglumima0!==_this.denglumima1){
                        _this.dlmm_kong='两次输入不一致！';
                        setTimeout(function(){_this.dlmm_kong='';}, 1500);
                    }
                    else{
                        _this.axios
                        .post('http://www.zhishiren.info/api/reset_denglumima/', {userid:_this.$cookies.get('userid'),dlmm0: _this.denglumima0})
                        .then(function (response) {
                            if (response.data.resetmm === 1){_this.errormsg_dlmm='操作失败';}
                            if (response.data.resetmm === 0){
                                _this.show_denglumima_dialog=false;
                                _this.dlmmok=true;
                                setTimeout(function(){_this.dlmmok='';}, 1500);
                            }
                        })
                    }
                }
            },
        },

        created: function () {
            var _this= this;
            _this.axios
            .post('http://www.zhishiren.info/api/show_mypage/', {userid:_this.$cookies.get('userid')})
            .then(function (response) {
                _this.userinfo=response.data;
                _this.userjishu=JSON.parse(response.data.yh_tongji);
            });
        },
    };
</script>



