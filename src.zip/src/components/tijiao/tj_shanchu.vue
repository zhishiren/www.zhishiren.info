
<template>
    <a id="tj_shanchu" @click="shanchujian()">
		<i class="el-icon-close a_grey">删</i>
		<span style="color:orange" v-if="notok">删除失败</span>
	</a>
</template>

<script>
export default {
	data() {return {notok:false}},
	props:['zhid','leixing'],
	methods:{
		shanchujian:function(){
					this.$alert('确认删除本条记录？', '确认删除？', {
						confirmButtonText: '确认',
						callback: action => {
							if (action === 'confirm') {
								var that = this;
								that.axios
								.post('http://www.zhishiren.info/api/shanchu/', {zhid:that.zhid,leixing:that.leixing,userid:that.$cookies.get('userid')})
								.then(response=>{
									if(response.data.changed_ok==0){
										that.$emit('shanchuok');
										that.notok=false;
									}
									else{
										that.notok=true;
									}
								});
							}
						}
					});
		},
	},
};

</script>

