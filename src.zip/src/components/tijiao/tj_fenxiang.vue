// 这是用户分享的功能，需要用户id，用户name,
<template>
    <div id="tj_fenxiang" class="font18px">
		<el-button v-if="fanwei_all!==2" @click="fenxiangjian()" type="text" class="font18px"><i class="el-icon-share"></i>分享...</el-button>
		<el-button v-if="fanwei_all===2" disabled type="text" class="font18px"><i class="el-icon-share"></i>分享...</el-button>
		<span v-if="fanwei_all!==2">
			<span v-if="zhitype==='yonghuye'">此用户信息</span>
			<span v-if="zhitype==='wenduanye'">此文段信息</span>
			<span v-if="zhitype==='wenjiye'">此文辑信息</span>
			<span v-if="zhitype==='qunzuye'">此群组信息</span>
			<span v-if="zhitype==='fayanye'">此段言论</span>
			<span v-if="zhitype==='biaoqianye'">此标签信息</span>
			<span>会分享到首页的“今日动态”中。</span>
		</span>
		<span v-if="fanwei_all===2">该知识点的公开范围为用户本人，你无权分享。</span>
		<span style="color:blue;" v-show='this.ok_msg==1'><i class="el-icon-success"></i>分享成功！</span>
		<span style="color:red;" v-show='this.ok_msg==2'><i class="el-icon-success"></i>操作失败！</span>
		<el-dialog title="分享附言..." width="400px" :visible.sync="show_dialog">

			<el-row>
				<el-col :span="7" class="font18px" style="padding-top:10px;">
					分享态度：
				</el-col>
				<el-col :span="17">
					<el-select v-model="fx_att" placeholder="请选择分享的态度" style="width:90%;">
                    	<el-option value="无态度" key="无态度" label="无态度"></el-option>
						<el-option value="强烈推荐" key="强烈推荐" label="强烈推荐"></el-option>
                	</el-select>
				</el-col>
			</el-row>
			<br>

			<el-row>
				<el-col :span="7" class="font18px" style="padding-top:10px;">
					公开范围：
				</el-col>
				<el-col :span="17">
					<el-select v-if="fanwei_all===0 || fanwei_all===1" v-model="qz_id" @focus="show_qzlist" placeholder="请选择"  style="width:90%;">
						<el-option
						v-for="item in lists"
						:key="item.qz_id"
						:label="item.qz_title"
						:value="item.qz_id">
						</el-option>
					</el-select> 

					<el-select v-if="fanwei_all===8" :placeholder="'仅'+fanwei+'可见'" disabled style="width:100%;"></el-select>
				</el-col>
			</el-row>
			<br>

			<el-row>
				<!-- 这里的格式要注意，“请输入分享附言，限100字。”与上下文的标签不能有换行等。 -->
				<div contenteditable ref="contents" @paste="onPaste" class="pinglunlan">请输入分享附言，限100字。</div>
			</el-row>
			<el-row style="font-size:18px;color:orange;text-align:center;" v-show="fanwei_all===8"><i class="el-icon-info"></i>你只能分享给指定的群组{{this.fanwei}}</el-row>
            <el-row style="font-size:18px;color:orange;text-align:center;" v-show="fanwei_all===1"><i class="el-icon-info"></i>原知识点的公开范围<b>并非</b>所有人</el-row>
            <el-row>
                <el-col :span="6">
                    <a class="a_black font18px" href="javascript:;" @click="f_blod">
                        <b>所选加粗</b>
                    </a>
                </el-col>
                <el-col class="font18px" :span="8"></el-col>
                <el-col :span="10" style="text-align:right">
                    <a @click="fabujian(0)" class="font20px a_black" >明发</a>
					<el-divider direction="vertical"></el-divider>
                    <a @click="fabujian(1)" class="font20px a_black" >密发</a>
					<faloading :fa_loading="fa_loading" :ok_msg="ok_msg"></faloading>
                </el-col>
            </el-row>
 					
        </el-dialog>
    </div>
</template>

<script>
import fanwei from '../fujian/fanwei';
import faloading from '../fujian/faloading.vue';


export default {
	name:'tj_fenxiang',
	components: {faloading,fanwei},
	props:['zhid','zhititle','zhitype','fanwei','zhitype1','createrid'],
	
	computed:{
            fanwei_all(){
				var cid=parseInt(this.createrid);
				var coid=parseInt(this.$cookies.get('userid'));
				if(this.zhitype==='yonghuye' || this.zhitype==='qunzuye' || this.fanwei===90000000){return 0}
				else{
					if(cid===coid){return 1}//这说明分享者是创建者本人
					else{
						if(this.fanwei===80000000){return 2}//这代表分享者不是创建人且原知识点的范围仅为本人
						else{return 8}//这代表分享者不是创建人且原知识点的范围为某群组
					}
				}
            },
	},
	data() {return {
		show_dialog:false,
		fuyan:'',
		ok_msg:0,
		// lists: [],
		lists: [{qz_id:90000000,qz_title:"--所有人--"}],
		qz_id:90000000,
		fx_att:'无态度',
		}},
	methods:{
			show_qzlist(){
				var that = this;
				that.axios
				.post('http://www.zhishiren.info/api/listmyqunzu/', {userid: that.$cookies.get('userid')})
				.then(response=>{
					that.lists=response.data;
				});
			},
			f_blod() {document.execCommand ( 'bold', false );},
			
			onPaste: function(e) {
                    e.preventDefault()
                    e.stopPropagation()
                    let pasteValue = (e.clipboardData || window.clipboardData).getData('text/plain')
                    console.log(pasteValue)
                    var re = /<[^>]+>/gi;
                    pasteValue = pasteValue.replace(re, '').replace(/\s+|[\r\n]/g,"");
                    e.target.textContent += pasteValue
				},
				
			fenxiangjian:function(){
					this.show_dialog=false;
					this.show_dialog=true;
			},
			fabujian:function(mi){
				var that = this;
				if(that.$refs.contents.innerHTML==='请输入分享附言，限100字。'){that.fuyan='无'}
				else{that.fuyan=that.$refs.contents.innerHTML};
				that.axios
				.post('http://www.zhishiren.info/api/oofenxiang/',{
					zhi_id:that.zhid,
					zhi_title:that.zhititle,
					userid: that.$cookies.get('userid'),
					username:that.$cookies.get('username'),
					zhi_leixing:that.zhitype,
					zhi_fanwei:that.qz_id,
					fx_att:that.fx_att,
					zhitype1:that.zhitype1,
					mi:mi,
					divcontent:that.fuyan})
				.then(function (response) {
					if (response.data.ok_msg === 1){
						that.ok_msg=response.data.ok_msg;
						setTimeout(function(){that.ok_msg=0;}, 2000);
						that.$refs.contents.innerHTML='请输入分享附言，限100字。';
						that.show_dialog=false;
						that.$emit("fxadd1");
						that.qz_id=90000000;
						that.lists=[{qz_id:90000000,qz_title:"--所有人--"}];
					}
					else{that.ok_msg=2;
							setTimeout(function(){that.ok_msg=0;}, 2000);
							that.$refs.contents.innerHTML='请输入分享附言，限100字。';
							that.show_dialog=false;
					}
				});
			},
	},
};

</script>

