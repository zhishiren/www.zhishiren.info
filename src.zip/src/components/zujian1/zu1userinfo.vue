
// 这是用于“用户与群”的用户信息
<template>
    <div>
        <el-row>
            <router-link class="a_black" target="_blank" :to="{name:'yonghuye',params:{id:list.pk}}">
                <b><span v-html="gaoliangk(list.fields.yonghu_name, kkk)" ></span></b>
            </router-link>
        </el-row>
        <el-row>
            <span v-if="list.fields.yonghu_area">{{list.fields.yonghu_area}}</span><span v-else><font style="color:grey">地区:暂无</font></span>
            <el-divider direction="vertical"></el-divider>
            <span v-if="list.fields.yonghu_type!=='工团组织'">
                <span v-if="list.fields.yonghu_job">{{list.fields.yonghu_job}}</span><span v-else><font style="color:grey">职业:暂无</font></span>
                <el-divider direction="vertical"></el-divider>
                <span v-if="list.fields.yonghu_remark"><font style="color:grey">签名:</font>{{list.fields.yonghu_remark}}</span>
                <span v-else><font style="color:grey">签名:无</font></span>
            </span>
            <span v-if="list.fields.yonghu_type==='工团组织'">
                <span v-if="list.fields.yonghu_remark"><font style="color:grey">签名:</font>{{list.fields.yonghu_remark}}</span>
                <span v-else><font style="color:grey">签名:无</font></span>
            </span>
        </el-row>
        <el-row :span="24"><el-divider style="margin:0px;"></el-divider></el-row>
    </div>
</template>

<script>
  export default {
    data() {
      return {

      }
    },

    props:['list','kkk'],

    methods:{
        

    }

  }
</script>





