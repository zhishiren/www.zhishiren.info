// 这个评论栏是用在每个知识点页面之下的评论功能，他有异议和匿名两个多选框
<template>
	<div id="tj_pinglun"  class="font18px">
				    <el-button @click="pinglunjian" type="text" style="padding-bottom:0px;" class="font18px">
                        <i class="el-icon-s-comment"></i>评论...
                    </el-button>
                    <span style="color:green;" v-show="ok_msg==1"><i class="el-icon-success"></i>发布成功!</span>
                    <span style="color:red;" v-show="ok_msg==3"><i class="el-icon-error"></i>操作失败!</span>
                    <span>
                        <span v-if="zhitype==='yonghuye'">此用户信息</span>
                        <span v-if="zhitype==='wenduanye'">此文段信息</span>
                        <span v-if="zhitype==='wenjiye'">此文辑信息</span>
                        <span v-if="zhitype==='qunzuye'">此群组信息</span>
                        <span v-if="zhitype==='fayanye'">此段言论</span>
			            <span v-if="zhitype==='biaoqianye'">此标签信息</span>
                        <span>已有{{this.listNum}}条评论。</span>
                    </span>
                    <zhankai0 ref="zhankai0" @get_list="zhankaijian" @shuaxin="shuaxinjian"></zhankai0>
					<!-- <a @click="shuaxinjian" class="a_black"><i class="el-icon-refresh"></i>刷新</a> -->

		<el-dialog title="发表评论..." width="400px" :visible.sync="show_dialog">
            <el-row>
                <el-col :span="7" class="font18px" style="padding-top:10px;">
                    是否匿名：
                </el-col>
                <el-col :span="17">
                    <el-select v-model="niming" placeholder="请选择发言的类型" style="width:90%;">
                        <el-option value="不匿名" key="不匿名" label="不匿名"></el-option>
                        <el-option value="匿名" key="匿名" label="匿名"></el-option>
                    </el-select>
                </el-col>
            </el-row>
            <br>

			<el-row>
                <el-col :span="7" class="font18px" style="padding-top:10px;">
                    评论态度：
                </el-col>
                <el-col :span="17">
                    <el-select v-model="att_value" placeholder="请选择评论的类型" style="width:90%;">
                        <el-option value="-无态度-" key="-无态度-" label="-无态度-"></el-option>
                        <el-option value="反对异议" key="反对异议" label="反对异议"></el-option>
                        <el-option value="点赞支持" key="点赞支持" label="点赞支持"></el-option>
                        <el-option value="疑惑不解" key="疑惑不解" label="疑惑不解"></el-option>
                    </el-select>
                </el-col>
            </el-row>
            <br>
            <el-row>
                <div contenteditable ref="contents" @paste="onPaste" class="pinglunlan">请输入你要评论的内容。</div>
            </el-row>
            <el-row>
                <el-col :span="7">
                    <a class="a_black font18px" href="javascript:;" @click="f_blod">
                        <b>所选加粗</b>
                    </a>
                </el-col>
                <el-col class="font18px" :span="11">
                    <span style="color:orange;" v-show="ok_msg==2"><i class="el-icon-warning-outline"></i>评论不能为空!</span>
                </el-col>
                <el-col :span="6" style="text-align:right">
                    <a @click="fabujian" class="font20px a_black" >发布</a>
                </el-col>
            </el-row>
        </el-dialog>

        <div v-show="show_xhpl" >
                <el-row class="br10px17px" v-for="list in lists" :key="list.fields.act_createrid">
                            <el-row  :class="blinkyellow" v-if="list.pk==return_id">
                                <niming :niming_yn='list.fields.item1_title' :createrid='list.fields.act_createrid' :creatername='list.fields.act_creatername'></niming>
                                <span>：</span>
                                <span v-if="list.fields.act_fuyanzishu===0" style="color:grey"><span v-html="list.fields.act_fuyan"></span></span>
                                <miwen v-if="list.fields.act_fuyanzishu!==0" :pkid='list.pk' :content='list.fields.act_fuyan' :zishu='list.fields.act_fuyanzishu'></miwen>
                            </el-row>
                            <el-row v-if="list.pk!==return_id">
                                <niming :niming_yn='list.fields.item1_title' :createrid='list.fields.act_createrid' :creatername='list.fields.act_creatername'></niming>
                                <span>：</span>
                                <span v-if="list.fields.act_fuyanzishu===0" style="color:grey"><span v-html="list.fields.act_fuyan"></span></span>
                                <miwen v-if="list.fields.act_fuyanzishu!==0" :pkid='list.pk' :content='list.fields.act_fuyan' :zishu='list.fields.act_fuyanzishu'></miwen>
                            </el-row>
                            <tj0huifu :shuaxinid="shuaxinyn" timek=0 news_yn=0 @shanchuok="shanok()" :act_id="list.pk" :create_time="list.fields.act_createtime" :it_att="list.fields.act_att" :creater_id="list.fields.act_createrid" :item1title="'你关联了:'+zhititle+'&&&'+list.fields.item1_title+'>>>附言:'+list.fields.act_fuyan"></tj0huifu>
                            <el-row><el-divider style="margin:0px;"></el-divider></el-row>
                </el-row>
                <br>
                <el-pagination v-if="listNum>10" style="text-align:right;"
                                background
                                :page-size=10
                                :total="listNum"
                                :current-page.sync="currentPage"
                                layout="total, prev, pager, next">
                </el-pagination>
        </div>

	</div>
</template>

<script>
import tj0huifu from '../tijiao/tj_huifu';
import fanwei from '../fujian/fanwei';
import miwen from '../fujian/miwen';
import niming from '../fujian/niming';
import zhankai0 from '../fujian/zhankai0';

	export default {
		name: 'tj_pinglun',
        components: {tj0huifu,fanwei,zhankai0,miwen,niming},
        props:['zhid','zhititle','zhitype','fanwei'],
		data () {
			return {
                return_id:0,//这个return_id是用户添加评论成功之后，
                show_dialog:false,   
                show_xhpl:false,
                blinkyellow:'',
                xhpls:[],
                currentPage: 1,//当前分页的数值
                listNum:0,//分页总条数
                zhitype:'',
                ok_msg:9,
				att_value:'-无态度-',
                niming:'不匿名',
                zhi_id:1,
                c1:0,
                c2:0,
                shuaxinyn:0
			}
        },
        
        computed: {
            lists(){
                let pages=Math.ceil(this.listNum/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                    let sonList=[];
                    sonList=this.xhpls.slice(i*10,i*10+10);//10为每页设置数量
                    newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
            userid(){return parseInt(this.$cookies.get('userid'))},
            
        },

		methods: {
            f_blod() {document.execCommand ( 'bold', false );},
            
            onPaste: function(e) {
                    e.preventDefault()
                    e.stopPropagation()
                    let pasteValue = (e.clipboardData || window.clipboardData).getData('text/plain')
                    console.log(pasteValue)
                    var re = /<[^>]+>/gi;
                    pasteValue = pasteValue.replace(re, '').replace(/\s+|[\r\n]/g,"");
                    e.target.textContent += pasteValue
                },
            fabujian() {
                // 这里需要判断，
                var that = this;
                        if(that.$refs.contents.innerHTML==='请输入你要评论的内容。'){
                            that.ok_msg=2;
                            setTimeout(function(){that.ok_msg=0;}, 2000);
                        }
                        else{
                                that.axios
                                .post('http://www.zhishiren.info/api/oopinglun/',{
                                    userid: that.$cookies.get('userid'),
                                    username:that.$cookies.get('username'),
                                    pl_content:that.$refs.contents.innerHTML,
                                    pl_att:that.att_value,
                                    pl_niming:that.niming,
                                    zhid:that.zhid,
                                    zhititle:that.zhititle,
                                    zhitype:that.zhitype,
                                    fanwei:that.fanwei,
                                    })
                                .then(function (response) {
                                    if (response.data.ok_id === 1){
                                        that.ok_msg=1;
                                        that.return_id = response.data.rrid;
                                        setTimeout(function(){that.ok_msg=0;}, 2000);
                                        that.$refs.contents.innerHTML='请输入你要评论的内容。';
                                        that.show_xhpl=true;
                                        that.show_dialog=false;
                                        that.$refs.zhankai0.addnew();
                                        that.$nextTick(() => {
                                            that.$axios
                                                .post('http://www.zhishiren.info/api/xunhuanpl/',{zhid: that.zhid})
                                                .then(response=>{
                                                                that.xhpls=JSON.parse(response.data);
                                                                that.listNum=that.xhpls.length;                                                                
                                                                that.currentPage=1;
                                                                that.blinkyellow='blinkyellow';
                                                                setTimeout(function(){that.blinkyellow='';}, 2000);
                                                });
                                        });
          
                                    }
                                    if (response.data.ok_id === 3){
                                        that.ok_msg=3;
                                        setTimeout(function(){that.ok_msg=0;}, 2000);
                                        that.$refs.contents.innerHTML='请输入你要评论的内容。';
                                    }
                                });
                        }
                
            },

			f_blod() {
                document.execCommand ( 'bold', false );
                // document.execCommand ( 'backColor', false, 'yellow' );
			},

			pinglunjian(){
				this.show_dialog=true;
            },

            zhankaijian(){
                this.show_xhpl=true;
                this.$axios
                .post('http://www.zhishiren.info/api/xunhuanpl/',{zhid: this.zhid})
                .then(response=>{
                    this.xhpls=JSON.parse(response.data);
                    this.listNum=this.xhpls.length;});
            },

            shuaxinjian(){
                this.$nextTick(() => {
                this.shuaxinyn=1;
                this.$axios
                .post('http://www.zhishiren.info/api/xunhuanpl/',{zhid: this.zhid})
                .then(response=>{
                    this.xhpls=JSON.parse(response.data);
                    this.shuaxinyn=0;
                    this.listNum=this.xhpls.length;});
                });
                
            },

            shanok(){
                this.$nextTick(() => {
                this.$axios
                .post('http://www.zhishiren.info/api/xunhuanpl/',{zhid: this.zhid})
                .then(response=>{
                    this.xhpls=JSON.parse(response.data);
                    this.listNum=this.xhpls.length;});
                });

            },



            
            
        },
        // 由于created不能收到props的传值，所以只能用watch的方法。
        watch: {
            zhid: function(newVal,oldVal){
                this.zhi_id = newVal;  
                this.$axios
                .post('http://www.zhishiren.info/api/countpl/',{zhid: this.zhi_id})
                .then(response=>{this.listNum=response.data});
        }},

        // created: function () {
        //     this.$axios
        //         .post('http://www.zhishiren.info/api/xunhuanpl/',{zhid: this.zhid})
        //         .then(response=>{
        //             this.xhpls=JSON.parse(response.data);
        //             this.listNum=this.xhpls.length;});
        // }

	}
</script>

