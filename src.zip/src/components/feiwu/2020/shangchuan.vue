<template>

<div>

  <el-select v-model="value" type="text" placeholder="请选择">
    <el-option
      v-for="item in options"
      :key="item.value"
      :label="item.label"
      :value="item.value">
    </el-option>
  
  </el-select>



&nbsp;
    <el-upload
    style="display:inline;"
    class="upload-demo"
    action="/api/shangchuan/"
    Access-Control-Request-Headers: ContentType
    :on-preview="handlePreview"
    :on-remove="handleRemove"
    :before-remove="beforeRemove"
    :limit="1"
    :on-exceed="handleExceed"
    :file-list="fileList"
    >
    <el-button class="font16px" type="text">上传附件</el-button>
    </el-upload>


</div>

</el-row>



</template>
<script>
import axios from 'axios';
  export default {
      
    data() {
      return {
        content:'',
        fileList: [],
        options: [{
          value: '选项1',
          label: '图片'
        }, {
          value: '选项2',
          label: '表格'
        }, {
          value: '选项3',
          label: '原文档'
        }, {
          value: '选项4',
          label: '影音'
        }, {
          value: '选项5',
          label: '压缩包'
        }],
        value: ''
      };
    },
    methods: {
      handleRemove(file, fileList) {
        console.log(file, fileList);
      },
      handlePreview(file) {
        console.log(file);
  
      },
      handleExceed(files, fileList) {
        this.$message.warning(`每次操作只能上传一个文件！`);
      },
      beforeRemove(file, fileList,ceshizhi) {
        return this.$confirm(`确定移除 ${ file.name }？`);
      }
    }
  }
</script>


<style>
  .el-dropdown-link {
    cursor: pointer;
    color: #409EFF;
  }
  .el-icon-arrow-down {
    font-size: 12px;
  }
</style>