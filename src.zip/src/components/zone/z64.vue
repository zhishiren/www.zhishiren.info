<template>
    <div id="z73">
	<el-row style="height:270px">
		<el-col :span="24">
			<img src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/z64.jpg" class="bg_image" style="width:100%;height:270px;" alt="">
		</el-col>
	</el-row>
	<el-row>
		<el-col :span="24">
			<div class="huanhang font18px">
				本站认为：让每个劳动者都拥有足够的生产资料和劳动能力，才能走向人类最终的自由和解放！
				<br>
				通过劳动者的自由联合，形成<b>工团企业联盟</b>和<b>劳动者智库</b>，建成一种<b>共检产品</b>生产体系和<b>共享网络</b>。
			</div>
		</el-col>
	</el-row>

<br>
		<el-row>
			<el-col :span="10">
					<el-image
						src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/z64a.jpg"
						:fit="fill">
					</el-image>
			</el-col>
			<el-col :span="14">
				<div class="huanhang">
					<b class="font20px">共检产品：</b>
					<br>
					人民参与设计与监督生产流程，极简、公用、耐用的生活必需品。
					<br>
					<b class="font20px">共享网络：</b>
					<br>
					用于共检产品的销售平台，
					<br>
					人民监督生产的直播视频社区，
					<br>
					人民参与设计和贡献劳动经验的知识库，
					<br>
					工团企业共享的信息与软件平台，
					<br>
					工团的资金众筹与人民的职业流动。

				</div>
			</el-col>
		</el-row>
		<br>
		<el-row>
			<el-col :span="14">
				<div class="huanhang">
					<b class="font20px">工团企业联盟</b>
						<br>
						全世界的工团企业应该通过共享劳动经验，共享信息与软件，工团员工之间的流动，资金与设备的互相支援，基础科技的共同研发，实现一种“自由的联合”。避免重复试错，摊平基建成本。
					<br>
					<b class="font20px">劳动者智库</b>
					<br>
					知识与教育，不应该是区别人群的铁丝网，而是指导人类解放的火把。
					<br>
					通过共享经验与软件，以最通俗简单的形式简化劳动与管理流程，让每个员工同时具备执行者，管理者，创造者三种角色的能力，真正做到“全面发展的人”。
					<br>

				</div>
			</el-col>
			<el-col :span="10">
					<el-image
						src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/z64b.jpg"
						:fit="fill">
					</el-image>
			</el-col>
		</el-row>
		<br>



    </div>
</template>

<script>
    export default {
        name:'z73',
        props:['k'],//k是区分
        data() {return {

        }},
        computed:{

        },
        methods:{
            
            
        },
    };
</script>



