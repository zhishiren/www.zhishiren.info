<template>
	<div id="tj_biaoqianneihan"  class="font18px">
				    <el-button @click="pinglunjian" type="text" style="padding-bottom:0px;" class="font18px">
                        <i class="el-icon-plus"></i>添加...
                    </el-button>
                    <span style="color:green;" v-show="ok_msg==1"><i class="el-icon-success"></i>发布成功!</span>
                    <span style="color:red;" v-show="ok_msg==3"><i class="el-icon-error"></i>操作失败!</span>
                    已有{{this.listNum}}条标签内容。
                    <!-- <span v-if="c2===0">。</span> -->
                    <!-- <span v-if="c2!==0">，其中{{this.c2}}条是由我添加。</span> -->
                    <zhankai0 @get_list="zhankaijian" @shuaxin="shuaxinjian"></zhankai0>
					<!-- <a @click="shuaxinjian" class="a_black"><i class="el-icon-refresh"></i>刷新</a> -->

		<el-dialog title="发表评论..." width="400px" :visible.sync="show_dialog">
            <el-row>
                <el-col :span="7" class="font18px" style="padding-top:10px;">
                    知识点ID：
                </el-col>
                <el-col :span="17">
                    <el-input v-model="item1id" style="width:100%" placeholder="请在你所关注的标签中选择">
                    </el-input> 
                </el-col>
            </el-row>
            <br>
         
            <el-row>
                <div contenteditable ref="contents" @paste="onPaste" class="pinglunlan">请输入标签附言。</div>
            </el-row>
            <el-row>
                <el-col :span="7">
                    <a class="a_black font18px" href="javascript:;" @click="f_blod">
                        <b>所选加粗</b>
                    </a>
                </el-col>
                <el-col class="font18px" :span="11">
                    <span style="color:orange;" v-show="ok_msg==2"><i class="el-icon-warning-outline"></i>不可与自己关联!</span>
                    <span style="color:orange;" v-show="ok_msg==4"><i class="el-icon-warning-outline"></i>该条已在标签内!</span>

                </el-col>
                <el-col :span="6" style="text-align:right">
                    <a @click="fabujian" class="font20px a_black" >发布</a>
                </el-col>
            </el-row>
        </el-dialog>

        <div v-show="show_xhbqh" >
                <el-row class="br10px17px" v-for="list in lists" :key="list.pk">
                            <el-row  :class="blinkyellow" v-if="list.pk===return_id">
                                <router-link v-if="yonghuid!==list.fields.act_createrid" target="_blank" class="a_black" :to="{name:'yonghuye',params:{id:list.createrid}}" >
                                    {{list.fields.act_creatername}}
                                </router-link>
                                <span v-if="yonghuid===list.fields.act_createrid">你</span><span>添加了</span>
                                <router-link class="a_black" target="_blank" :to="{name:list.fields.item1_type,params:{id:list.fields.item1_id}}">          
                                    <span v-if="list.fields.item1_type==='fayanye'" style="color:brown;">
                                        <font style="font-size:20px;"><b>“</b></font><span v-html="list.fields.item1_title" ></span><font style="font-size:20px;"><b>”</b></font>
                                    </span>
                                    <span v-if="list.fields.item1_type!=='fayanye'">
                                        <i v-if="list.fields.item1_type==='yonghuye'" class="el-icon-s-custom"></i>{{list.fields.item1_title}}
                                    </span>
                                </router-link>
                                <span style="color:grey">
                                    附言:<span v-html="list.fields.act_fuyan"></span>
                                </span>
                            </el-row>
                            <el-row v-if="list.pk!==return_id">
                                <router-link v-if="yonghuid!==list.fields.act_createrid" target="_blank" class="a_black" :to="{name:'yonghuye',params:{id:list.createrid}}" >
                                    {{list.fields.act_creatername}}
                                </router-link>
                                <span v-if="yonghuid===list.fields.act_createrid">你</span><span>添加了</span>
                                <router-link class="a_black" target="_blank" :to="{name:list.fields.item1_type,params:{id:list.fields.item1_id}}">          
                                    <span v-if="list.fields.item1_type==='fayanye'" style="color:brown;">
                                        <font style="font-size:20px;"><b>“</b></font><span v-html="list.fields.item1_title" ></span><font style="font-size:20px;"><b>”</b></font>
                                    </span>
                                    <span v-if="list.fields.item1_type!=='fayanye'">
                                        <i v-if="list.fields.item1_type==='yonghuye'" class="el-icon-s-custom"></i>{{list.fields.item1_title}}
                                    </span>
                                </router-link>
                                <span style="color:grey">
                                    附言:<span v-html="list.fields.act_fuyan"></span>
                                </span>
                            </el-row>
                            <tj0huifu :shuaxinid="shuaxinyn" timek=0 news_yn=0 @shanchuok="shanok()" :act_id="list.pk" :create_time="list.fields.act_createtime" :it_att="list.fields.act_att" :creater_id="list.fields.act_createrid" :fanwei_id="list.fields.act_fanwei" :item1title="'你关联了:'+zhititle+'&&&'+list.fields.item1_title+'>>>附言:'+list.fields.act_fuyan"></tj0huifu>
                            <el-row><el-divider style="margin:0px;"></el-divider></el-row>
                </el-row>
                <!-- 下面的div是用来显示原始的未筛选的分页条 -->
                <el-pagination v-if="listNum>10" style="text-align:right;"
                                background
:page-size=10
                                :total="listNum"
                                :current-page.sync="currentPage"
                                layout="total, prev, pager, next">
                </el-pagination>
        </div>

	</div>
</template>

<script>
import tj0huifu from '../tijiao/tj_huifu';
import fanwei from '../fujian/fanwei';
import zhankai0 from '../fujian/zhankai0';

	export default {
		name: 'tj_biaoqianneihan',
        components: {tj0huifu,fanwei,zhankai0},
        props:['bqid','bqtitle','fanwei_id'],
		data () {
			return {
                return_id:0,//这个return_id是用户添加评论成功之后，
                show_dialog:false,   
                show_xhbqh:false,
                blinkyellow:'',
                xhbqhs:[],
                currentPage: 1,//当前分页的数值
                listNum:0,//分页总条数
                zhitype:'',
                ok_msg:9,
				att_value:'att0',
                niming:'nm0',
                item1id:0,
				gl_att:"att0",
                fuyan:"",
                c1:0,
                c2:0,
                shuaxinyn:0
            }
            
        },
        
        computed: {
            lists(){
                let pages=Math.ceil(this.listNum/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                    let sonList=[];
                    sonList=this.xhbqhs.slice(i*10,i*10+10);//10为每页设置数量
                    newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
            yonghuid(){return parseInt(this.$cookies.get('userid'))},
            
        },

		methods: {
            f_blod() {document.execCommand ( 'bold', false );},
            
            onPaste: function(e) {
                    e.preventDefault()
                    e.stopPropagation()
                    let pasteValue = (e.clipboardData || window.clipboardData).getData('text/plain')
                    console.log(pasteValue)
                    var re = /<[^>]+>/gi;
                    pasteValue = pasteValue.replace(re, '').replace(/\s+|[\r\n]/g,"");
                    e.target.textContent += pasteValue
                },
            fabujian() {
                // 这里需要判断，
                var that = this;
                that.zhid=Number(that.zhid);
                that.item1id=Number(that.item1id);

                        if(that.zhid===that.item1id){
                            that.ok_msg=2;
                            setTimeout(function(){that.ok_msg=0;}, 2000);
                        }
                        if(that.$refs.contents.innerHTML==='请输入标签附言。'){that.fuyan=''}
                        if(that.$refs.contents.innerHTML!=='请输入标签附言。'){that.fuyan=that.$refs.contents.innerHTML}
                                that.axios
                                .post('http://www.zhishiren.info/api/oojia_bqn/',{
                                    userid: that.$cookies.get('userid'),
                                    username:that.$cookies.get('username'),
                                    bqn_att:that.att_value,
                                    bqid:that.bqid,
									bqtitle:that.bqtitle,
									item1id:that.item1id,
                                    fuyan:that.fuyan,
                                    fanwei:that.fanwei_id
                                    })
                                .then(function (response) {
                                    if (response.data.ok_id === 0){
                                        that.ok_msg=1;
                                        that.return_id = response.data.rrid;
                                        setTimeout(function(){that.ok_msg=0;}, 2000);
                                        that.$refs.contents.innerHTML='请输入标签附言。';
                                        that.show_dialog=false;
                                        that.show_xhbqh=true;
                                        that.$nextTick(() => {
                                            that.zhankaijian()
                                        });
                                        that.currentPage=1;
                                        that.blinkyellow='blinkyellow';
                                        setTimeout(function(){that.blinkyellow='';}, 2000);  
                                    }
                                    if (response.data.ok_id === 2){
                                        that.ok_msg=3;
                                        setTimeout(function(){that.ok_msg=0;}, 2000);
                                        that.$refs.contents.innerHTML='请输入标签附言。';
                                    }
                                    if (response.data.ok_id === 1){
                                        that.ok_msg=4;
                                        setTimeout(function(){that.ok_msg=0;}, 2000);
                                        that.$refs.contents.innerHTML='请输入标签附言。';
                                    }
                                });
                
            },

			f_blod() {
                document.execCommand ( 'bold', false );
                document.execCommand ( 'backColor', false, 'yellow' );
			},

			pinglunjian(){
				this.show_dialog=true;
            },

            zhankaijian(){
                this.show_xhbqh=true;
                this.$axios
                .post('http://www.zhishiren.info/api/xunhuan_bqneihan/',{bqid: this.bqid})
                .then(response=>{
                    this.xhbqhs=JSON.parse(response.data);
                    this.listNum=this.xhbqhs.length;});
            },

            shanok(){
                this.$nextTick(() => {
                    this.$axios
                    .post('http://www.zhishiren.info/api/xunhuan_bqneihan/',{bqid: this.bqid})
                    .then(response=>{
                        this.xhbqhs=JSON.parse(response.data);
                        this.listNum=this.xhbqhs.length;});
                });
            },

            shuaxinjian(){
                this.$nextTick(() => {
                    this.shuaxinyn=1;
                    this.$axios
                    .post('http://www.zhishiren.info/api/xunhuan_bqneihan/',{bqid: this.bqid})
                    .then(response=>{
                        this.shuaxinyn=0;
                        this.xhbqhs=JSON.parse(response.data);
                        this.listNum=this.xhbqhs.length;});
                });
            },
        },

        watch: {
                bqid: function(newVal,oldVal){
                    this.bq_id = newVal;
                    var that = this;
                    that.axios
                    .post('http://www.zhishiren.info/api/count_bqneihan/', {userid: that.$cookies.get('userid'),bqid:that.bq_id})
                    .then(response=>{that.listNum=JSON.parse(response.data);});
                },
        },
        
	}
</script>

