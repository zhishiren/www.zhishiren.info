<!-- 这是用户新增标签的模版-->
<template>
	<div id="xhx1">
            <!-- 下面的div是用来显示原始未筛选的列表，通过vshow来控制是否显示 -->
            <el-row class="font18px">
                <span>你共新增了{{this.listNum}}条标签。</span>
                <a @click="zhankai" class="a_black">-展开-</a>
            </el-row>


            <div  v-show="show_xhx1" >
                <el-row  class="br10px17px" v-for="list in lists" :key="list.biaoqian_id">
					<el-col :span="21">
						<el-row>
                            {{list.biaoqian_name}}
							<span class="a_grey">
								正在审核
							</span>
						</el-row>
						<el-row>
							<span style="color:grey">附言:{{list.biaoqian_remark}}</span>
						</el-row>
					</el-col>
					<el-col :span="3">{{list.create_time}}</el-col>
					<el-col :span="24"><el-divider style="margin:0px;"></el-divider></el-col>
				</el-row>
                <!-- 下面的div是用来显示原始的未筛选的分页条 -->
                <el-pagination style="text-align:right;"
                                background
:page-size=10
                                :total="listNum"
                                :current-page.sync="currentPage"
                                layout="total, prev, pager, next">
                </el-pagination>
            </div>
    </div>
</template>
<script>
import tj0shanchu from '../tijiao/tj_shanchu';
import tj0huifu from '../tijiao/tj_huifu';
import chazhaolan0 from '../fujian/chazhaolan0';
import zu0fujianfutu from '../fujian/zu0fujianfutu';
import fromqunzu from '../fujian/fromqunzu';
import fromyonghu from '../fujian/fromyonghu';

export default {
    name:'xhx1',
    components: {tj0shanchu,tj0huifu,chazhaolan0,zu0fujianfutu,fromqunzu,fromyonghu},
    props:['jishu'],
	data() {return {
        currentPage: 1,//当前分页的数值
        listNum:this.jishu,//分页总条数
        show_xhx1:false,
        xhx1s:[],
        datachange:true,
    }},

	computed: {
            lists(){
                let pages=Math.ceil(this.listNum/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                    let sonList=[];
                    sonList=this.xhx1s.slice(i*10,i*10+10);//10为每页设置数量
                    newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
    },
    
	methods:{
      handleSizeChange(val) {console.log(`每页 ${val} 条`);},
      handleCurrentChange(val) {console.log(`当前页: ${val}`);},

      zhankai(){
        this.show_xhx1=true;
        this.$axios
        .post('http://www.zhishiren.info/api/xunhuanx1/',{userid:this.$cookies.get('userid')})
        .then(response=>{this.xhx1s=response.data.list;this.listNum=response.data.list.length;});
      },

      shuaxin(){
            this.datachange=false;
            this.$nextTick(() => {
                this.$axios
                .post('http://www.zhishiren.info/api/xunhuanx1/',{userid:this.$cookies.get('userid')})
                .then(response=>{this.xhx1s=response.data.list;this.listNum=response.data.list.length;});
                this.datachange=true;
            });
      },
    },	
};
</script>




