
// 这是bianji_fuyan组件的变体，增加了搜索词的功能
<template>
    <div>
        <el-row>
            <router-link v-if="lll.fields.type0!=='fayanye'" class="a_black" target="_blank" :to="{name:lll.fields.type0,params:{id:lll.fields.id0}}">
                <span v-html="gaoliangk(lll.fields.title0, kkk)" ></span>
            </router-link>
            <router-link v-if="lll.fields.type1==='wenjiye'" class="a_black" target="_blank" :to="{name:lll.fields.type1,params:{id:lll.fields.id1}}">
                <span>{{lll.fields.title1}}</span>
            </router-link>
            <router-link v-if="lll.fields.type0==='fayanye'" class="a_black" style="float:left;" target="_blank" :to="{name:'fayanye',params:{id:lll.fields.id0}}">
                <span style="color:brown;max-width: 600px;max-height:25px; float: left;overflow: hidden; white-space: nowrap;text-overflow: ellipsis;-o-text-overflow: ellipsis; ">
                    <font style="font-size:18px;color:black;"><b>“</b></font>
                    <a class="a_brown"><span v-html="gaoliangk(lll.fields.title0, kkk)"></span></a>
                </span>
                <span style="font-size:18px;"><b>”</b></span>
            </router-link>
            <!-- <router-link v-if="lll.fields.type0==='fayanye'" class="a_black" target="_blank" :to="{name:'yonghuye',params:{id:lll.fields.id1}}">
                <span style="color:grey">来自</span><span>{{lll.fields.title1}}</span>
            </router-link> -->
            <span style="float:right;">{{qian_date(lll.fields.time1)}}</span>
        </el-row>
        <el-row>
            <span style="float:left;color:grey">
                <span v-if="zoneid!=='35'">关注</span>
                <span v-if="zoneid==='35'">加群</span>
                <span>附言:</span>
            </span>
            <span v-if="lll.fields.fystatus==='正常有效'">
                <span v-if="show_edit===false" v-html="gaoliangk(lll.fields.fy, kkk)" ></span>
                <a v-if="show_edit===false" @click="bianji" class="a_grey font18px"><i class="el-icon-edit">编辑</i></a>
                <input v-if="show_edit" placeholder="请输入关注的附言..." v-model="changed_fuyan" type="text" class="input_jian font18px" style="color:grey" >
                <a v-if="show_edit" @click="queding(lll.pk)" class="a_grey font18px"><i class="el-icon-check"></i>确定</a> 
                <a v-if="show_edit" @click="huanyuan" class="a_grey font18px"><i class="el-icon-refresh-left"></i>还原</a>
                <span v-if="show_kong" style="color:orange"><i class="el-icon-warning"></i>输入不能为空！</span>
                <span v-if="show_error" style="color:red"><i class="el-icon-warning"></i>修改失败！</span>
            </span>
            <span v-if="lll.fields.fystatus==='正在审核'" style="background-color:grey;color:white;">正在审核</span>

        </el-row>
        <el-row><el-divider></el-divider></el-row>
    </div>
</template>

<script>
  export default {
    data() {
      return {
        show_edit:false,
        show_kong:false,
        changed_fuyan:'',
        show_error:false,
      }
    },

    props:['lll','kkk'],

    methods:{
        bianji(){this.show_edit=true;},
        queding(ccc){
            var _this= this;
            if(_this.changed_fuyan==''){_this.show_kong=true}
            else{
                _this.$axios
                .post('http://www.zhishiren.info/api/edit_fuyan/', {
                    fuid: ccc,
                    fuyan:_this.changed_fuyan})
                .then(function(response){
                    if (response.data.changed_ok === 0){
                        _this.lll.fields.fy=_this.changed_fuyan;
                        _this.show_edit=false;
                        _this.show_kong=false;
                    }
                    else{
                        _this.show_error=true,
                        setTimeout(function(){
                            _this.show_error=false;
                            _this.show_edit=false;
                            _this.show_kong=false;
                        }, 2000);

                    }
                })
            }
        },


        huanyuan(){
        this.show_edit=false;
        this.show_kong=false;
        },
    }

  }
</script>





