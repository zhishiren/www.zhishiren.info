<template>
    <div id="z73">
        <el-row style="color:red;" class="font20px">仅供展示相关理念,没有实物</el-row>
<!-- 	
		<el-row>
			<el-col :span="10">
					<el-image
						src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/z64a.jpg"
						:fit="fill">
					</el-image>
			</el-col>
			<el-col :span="14">
				<div class="huanhang">
					<b class="font20px">工团员工能力培训</b>	
				</div>
			</el-col>
		</el-row>
		<br>
		<el-row>
			<el-col :span="14">
				<div class="huanhang">
					<b class="font20px">工团企业联盟、劳动者智库</b>		
					<br>

				</div>
			</el-col>
			<el-col :span="10">
					<el-image
						src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/z64b.jpg"
						:fit="fill">
					</el-image>
			</el-col>
		</el-row>
		<br> -->



    </div>
</template>

<script>
    export default {
        name:'z73',
        props:['k'],//k是区分
        data() {return {

        }},
        computed:{

        },
        methods:{
            
            
        },
    };
</script>



