<template>
    <div id="zu0zu0fujianfutu" >
        <el-row  v-show="fujianshu!==0">
            <b>附件<i class="el-icon-caret-right"></i></b>
            <span v-for="fujian in fujians" :key="fujian">
                <a :href="'	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/fujian/'+fujian.pk+'.zip'" :download="fujian.fields.item_id+''+fujian.fields.fu_title+'.zip'">{{fujian.fields.fu_title}}</a>；
            </span>
        </el-row>
        <!-- <el-row  v-show="futushu!==0" >
            <span style="float:left;">
                <b>附图:<i class="el-icon-caret-right"></i></b>
                <span>{{this.futushu}}个附图。</span>
                <span>-展开-</span>
            </span>
        </el-row> -->
        <!-- <el-row>
            <el-carousel indicator-position="outside">
                <el-carousel-item v-for="futu in futus" :key="futu" style="text-align:center;" >
                    <el-image style="height:100%;" :src="'https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/fujian/'+futu.pk+'.jpg'" fit="contain"></el-image>
                </el-carousel-item>
            </el-carousel>
        </el-row> -->
        <el-row  v-show="futushu!==0" >
            <el-carousel indicator-position="outside">
                <el-carousel-item v-for="futu in futus" :key="futu" style="text-align:center;" >
                    <el-image style="height:100%;" :src="'https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/fujian/'+futu.pk+'.jpg'" fit="contain"></el-image>
                </el-carousel-item>
            </el-carousel>
        </el-row>
    </div>
</template>

<script>
    export default {
        name:'zu0zu0fujianfutu',
        components: {},
        methods:{},
        data() {
            return {
                    futus:[],
                    fujians:[],
                    fujianshu:0,
                    futushu:0,
            }
        },
        props: {
            zhid: {type: Number,default: 0},
            futujian: {type: Number},
        },
        // 由于created不能收到props的传值，所以只能用watch的方法。当父组件向子组件动态传值时，子组件props首次获取到父组件传来的默认值时，也需要执行函数，此时就需要将immediate设为true,之前我们写的 watch 方法其实默认写的就是这个handler，Vue.js会去处理这个逻辑，最终编译出来其实就是这个handler。immediate:true代表如果在 wacth 里声明了 viewDetials之后，就会立即先去执行里面的handler方法，如果为 false就跟我们以前的效果一样，不会在绑定的时候就执行
        //这里futujian是监听这个值是否有变化，例如新增了附图的数量再刷新
        watch: {
            zhid:{
                handler: function(newVal,oldVal){
                    var _this=this;
                    var zhi_id = newVal;
                    _this.$axios
                    .post('http://www.zhishiren.info/api/show_futujian/', {zhid:zhi_id})
                    .then(function (response) {
                        _this.fulist=JSON.parse(response.data);
                        _this.fucount=_this.fulist.length;
            　　　　　　　var tulist = [];
                        var jianlist = [];
            　　　　　　　_this.fulist.forEach(item=>{
                            if(item.fields.fu_type==".jpg"){tulist.push(item);}
                            else{jianlist.push(item);}
                        });
                        _this.futushu = tulist.length;//这里是计算筛选后的结果的数量
                        _this.fujianshu = jianlist.length;//这里是计算筛选后的结果的数量
            　　　　　　  _this.futus = tulist;
                        _this.fujians = jianlist;
                    });
                },
                immediate: true
            },
        },

        // watch: {
        //     zhid: function(newVal,oldVal){
		// 		var _this=this;
        //             var zhi_id = newVal;
        //             _this.$axios
        //             .post('http://www.zhishiren.info/api/show_futujian/', {zhid:zhi_id})
        //             .then(function (response) {
        //                 _this.fulist=JSON.parse(response.data);
        //                 _this.fucount=_this.fulist.length;
        //     　　　　　　　var tulist = [];
        //                 var jianlist = [];
        //     　　　　　　　_this.fulist.forEach(item=>{
        //                     if(item.fields.fu_type==".jpg"){tulist.push(item);}
        //                     else{jianlist.push(item);}
        //                 });
        //                 _this.futushu = tulist.length;//这里是计算筛选后的结果的数量
        //                 _this.fujianshu = jianlist.length;//这里是计算筛选后的结果的数量
        //     　　　　　　  _this.futus = tulist;
        //                 _this.fujians = jianlist;
        //             });

        //     },
        // },
    };
</script>




