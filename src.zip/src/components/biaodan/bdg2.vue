
<template>
<div>
    <div v-if='this.userid!==wj_list.wj_manager' class="font20px">
      <i class="el-icon-lock">你不是该知识点的管理人，无权修改...</i>
    </div>
	<div v-if='this.userid===wj_list.wj_manager'>
        <gaifujian :leixing=2 :fujianshu="fujianshu" :wj_list="wj_list" :zhid="wj_list.wj_id"></gaifujian>

        <el-row  class="font18px" v-if='wj_list.wj_wdshu===0'>
            <el-upload
                name="duanlist"
                class="upload-demo"
                action="http://www.zhishiren.info/api/shangchuan999/"
                Access-Control-Request-Headers: ContentType
                :data={wj_id:wj_list.wj_id,wj_title:wj_list.wj_title,wd_manager:wj_list.wj_manager,wd_type:wj_list.wj_type,wd_createrid:wj_list.wj_createrid,wd_creatername:wj_list.wj_creatername,}
                :on-preview="handlePreview"
                :on-remove="handleRemove"
                :on-success="daoruchenggong"
                :before-remove="beforeRemove"
                :on-change="onchange"
                :limit="1"
                :file-list="fileList">
                <el-button v-if="ceshi_id===0" class="font18px" type="text">
                    段落列表...
                </el-button>
                <span v-if="ceshi_id===1">
                    <i class="el-icon-loading"></i>正在导入，请等待...
                </span>
                <span v-show="ceshi_id===0 && chuanduanlist_okmsg===9" class="font18px">
                    你可以批量上传段落内容的列表，仅限xls格式。
                </span>
                <span v-show="chuanduanlist_okmsg===0" class="font18px" style="color:red">
                    导入失败
                </span>
            </el-upload>
		</el-row>
        <gaineirong :zhitype=1 :fanwei_yn=1 :manager_yn=1 :status_yn=1 :zhi_remark="wj_list.wj_remark" :zhi_managerid="wj_list.wj_manager" :zhid="wj_list.wj_id"></gaineirong>
    </div>
</div>

    
</template>


<script type="text/javascript">
import fanwei from '../fujian/fanwei';
import gaineirong from '../fujian/gaineirong';
import gaifujian from '../fujian/gaifujian';

	export default {
		name: 'bdg2',
        components: {fanwei,gaineirong,gaifujian},
        props:['wj_list','fujianshu'],
		data () {
			return {
                show_dialog:false,
                ceshi_id:0,
				chuanduanlist_okmsg:9,
			}
		},

        computed:{
			userid(){return parseInt(this.$cookies.get('userid'))},
        },


		methods: {


            daoruchenggong(response) {
                    if(response!==999){
                        this.chuanduanlist_okmsg=0;
                        setTimeout(function(){this.chuanduanlist_okmsg=9;}, 2000);
                    }
                    if(response===999){
                        this.$router.go(0);
                    }
            },

            handleExceed(files, fileList) {
                this.$message.warning(`每次操作只能上传一个文件！`);
            },
            beforeRemove(file, fileList) {
                return this.$confirm(`确定移除 ${ file.name }？`);
            },
            handleRemove(file, fileList) {
                console.log(file, fileList);
            },
            handlePreview(file) {
                console.log(file);
            },
            onchange(file, fileList){
                this.ceshi_id=1;
                //这是用于显示文件是否正在导入...
            },

		}
	}
</script>

<style scoped>

</style>