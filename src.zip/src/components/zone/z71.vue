<template>
    <div id="z71">
		<el-row style="height:270px">
			<el-col :span="24">
				<img src="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/aboutus11.jpg" class="bg_image" style="height:270px;width:100%;" alt="">
				<div class="huanhang font22px juzhong">
					一种全新的知识库设计
					<br>片段化阅读+隐性知识挖掘+内容精准推荐
				</div>
			</el-col>
		</el-row>
		<el-row>
			<el-col :span="24">
				<div class="huanhang font18px">
					这是一个信息过载的时代。我们都将挣扎在知识和信息的混沌之海中，我们拼命翻腾，才不会被浪涛淹没头顶。<b>长篇和空洞的报告文体，已经成为新一代“祭司”和“贵族”装神弄鬼的马戏。劳动者是没时间看长篇大论的。劳动者需要一种快捷高效的分享劳动经验的工具。</b>各类知识太多，哪些是最重要的？常用的？与我劳动岗位最相关的？这些问题日夜困扰着我，而一种灵感渐渐在我眼前明晰，那就是设计一种知识库，以段落(知识片段)的形式呈现文章内容、关注收藏、分享评论，展示关联知识、用户行为数据、历史变迁版本，智能推荐。这种想法基于以下三个假设前提：片段化阅读、隐性知识挖掘、内容精准推荐。						
				</div>
			</el-col>
		</el-row>
		<br>
		<el-row>
			<el-col :span="10">
					<el-image
						src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/aboutus_8.jpg"
						:fit="fill">
					</el-image>
			</el-col>
			<el-col :span="14">
				<div class="huanhang">
					<b class="font20px">这是一个繁巨的基础工程，一场深刻的社会实验<br></b>	
			<b>劳动经验，是劳动者的宝贵财富。</b>截止目前，全世界范围存在的数以千万计的行业标准、学术论文、优秀案例、经验分享，指标数据，这些都是大众常用的公共信息。整理这些信息，是一个繁巨的公共信息基础工程，也是建设一个“人民互助”世界的社会实验，公众参与如同核裂变一样的链式反应，它产生的能量和成果让全民共治共有共享，从而打破垄断资本、官僚集团的知识霸权和话语霸权，协助人民自我组织和自我管理，提高社会管理效率，减少社会运行成本。					</div>
			</el-col>
		</el-row>
		<!-- <el-row><el-divider style="margin:0px;"></el-divider></el-row> -->

		<br>
		<el-row>
			<el-col :span="14">
				<div class="huanhang">
					<b class="font20px">片段化阅读：当我们在阅读公文时，我们真正在读什么？</b>		
					<br>
					现代心理学认为，<b>人类注意力的最佳范围是150字之内</b>，所以在写作时人脑潜意识里就会把一个小主题凝结成一个相对独立的、150字左右的段落。尤其是对于法律法规类的公文，我们寻找的、关注的、记住的是某些段落，而不是整篇文章。只有把精度细化到文章中的那些段落之上，用户的收藏、评论等动作才有意义，才是真正对知识进行管理。
				</div>
			</el-col>
			<el-col :span="10">
					<el-image
						src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/aboutus_1.jpg"
						:fit="fill">
					</el-image>
			</el-col>
		</el-row>
		<br>
		<el-row>
			<el-col :span="10">
					<el-image
						src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/aboutus_2.jpg"
						:fit="fill">
					</el-image>
			</el-col>
			<el-col :span="14">
				<div class="huanhang">
					<b class="font20px">隐形知识：水面下的冰山<br></b>	
					显性知识是知识片段的表面文字信息。隐形知识是知识片段背后的用户行为：点击量和关注量、评论和解释、支持或反对的意见、用户归类标签，知识片段之间关系（相互矛盾还是互为补充），语句中的强调关键词。这些隐形知识都是组织内员工多次试错后慢慢积累的，极具价值但很难被记录、传播和继承。在本网站中，知识片段的各种隐形知识均被挖掘和展示。
				</div>
			</el-col>

		</el-row>
		<br>
		<el-row>
			<el-col :span="14">
				<div class="huanhang">	
					<b class="font20px">内容精准推荐：将信息推送给合适的用户<br></b>	
					推荐系统是信息过载时代下信息过滤的重要手段，基于内容文本相似度和用户画像相似度的推荐系统，将相应的“知识片段”推送给合适的用户。内容文本相似度：根据用户的关注列表，分析其中的高频关键词和语法结构，查找库内相似度高的“知识片段”推荐给用户。用户画像相似度：分析用户的岗位、地域、爱好、历史行为等用户画像，查找库内相似度高的用户群类，将该用户群类的交集信息推送给用户。
				</div>
			</el-col>
			<el-col :span="10">
					<el-image
						src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/aboutus_3.jpg"
						:fit="fill">
					</el-image>
			</el-col>
		</el-row>
		<br>
		<el-row>
			<el-col :span="10">
					<el-image
						src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/aboutus_4.jpg"
						:fit="fill">
					</el-image>
			</el-col>
			<el-col :span="14">
				<div class="huanhang">
					<b class="font20px">烂笔头的时代已经过去，我们需要更快捷的知识归纳方式<br></b>	
					手写摘抄到纸面之上，这种“烂笔头”方式已经完全不适合现今信息流，我们需要更快捷的知识归纳方式。在本网站中，用户只需轻点按钮，就可以把知识片段收入到自己的关注列表中，为相关的知识片段建立归纳标签。
				</div>
			</el-col>

		</el-row>
		<br>
		<el-row>
			<el-col :span="14">
				<div class="huanhang">	
					<b class="font20px">利用六度空间理论，提高组织内信息传播效率<br></b>	
					传统的科层金字塔体制的信息是自上而下单链分发，这种模式相对封闭、路径长、速度慢、容易产生中断、阻塞和死角。六度空间是指信息通过多层熟人关系就能到达任何用户。利用此理论设计的信息发布平台，每个用户都是一个转发源，更高效传播给相近岗位用户。
				</div>
			</el-col>
			<el-col :span="10">
					<el-image
						src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/aboutus_5.jpg"
						:fit="fill">
					</el-image>
			</el-col>
		</el-row>
		<br>
		<el-row>
			<el-col :span="10">
					<el-image
						src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/aboutus_6.jpg"
						:fit="fill">
					</el-image>
			</el-col>
			<el-col :span="14">
				<div class="huanhang">
					<b class="font20px">构建每个岗位角色的知识图谱，加强组织内的知识传承<br></b>	
			每个用户都代表着组织内的某一个岗位角色，用户日常关注和评论等历史行为，都是某个岗位角色的知识图谱，这是组织内的极为重要但常被忽视的隐形知识。在传统的组织内岗位的管理水平严重依赖个人的历史经验和认知水平，人员流动就会造成一段时期的业务混乱。本知识库可以记录用户的历史行为，形成对岗位角色的知识图谱，可以有效加强组织内各个岗位角色的知识传承。
				</div>
			</el-col>

		</el-row>
		<br>
		<el-row>
			<el-col :span="14">
				<div class="huanhang">	
					<b class="font20px">劳动经验的共享，促成劳动者的全面发展<br></b>	
					传统组织过度依靠人工重复劳动，将整体工作划分部门和岗位各司其职，只能依靠增加部门和人力来应对业务变化，造成了组织内人力架构的僵化和膨胀，也造成人的单向度化。在组织内利用这种知识库系统，员工更高效的适应多个岗位的知识，促成人的全面发展。
				</div>
			</el-col>
			<el-col :span="10">
					<el-image
						src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/aboutus_7.jpg"
						:fit="fill">
					</el-image>
			</el-col>

		</el-row>
		<br>
    </div>
</template>

<script>
    export default {
        name:'z71',
        props:[],
        data() {return {

        }},
        computed:{

        },
        methods:{
            
        },
    };
</script>



