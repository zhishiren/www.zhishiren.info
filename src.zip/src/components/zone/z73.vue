<template>
    <div id="z73">
	<el-row style="height:270px">
		<el-col :span="24">
			<img src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/aboutus31.jpg" class="bg_image" style="height:270px;width:100%;" alt="">
			<div class="huanhang font22px juzhong">
				<!-- 站长一个人太难了，期待您的各种参与... -->
				期待您的参与...
			</div>
		</el-col>
	</el-row>
	<el-row>
		<el-col :span="24">
			<div class="huanhang font18px">
				<b>践行自治和互助的理念，贡献你特有的劳动经验，共建一个“共有共享共治”的知识库平台，你可以通过以下方式参与：</b>
			</div>
		</el-col>
	</el-row>

             		<!-- 不分主客，皆为同志！践行自由和互助的理念，摒弃中心化领导的旧思维。 源代码公开，遵守gnu协议，任意使用.宣传到微信朋友圈，内容编辑，写代码，联系我们微信号，关注微信公众号，贴吧，知乎，今日头条，github.捐助(资金将全部用于购买服务器资源) -->
					<!-- 让我们践行自由和互助的理念，贡献您特有的专业能力，共建一个“共有共享共治”的知识库平台，我们需要以下志愿者： -->
<br>
		<el-row>
			<el-col :span="10">
					<el-image
						src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/z73a.jpg"
						:fit="fill">
					</el-image>
			</el-col>
			<el-col :span="14">
				<div class="huanhang">
					<b class="font20px">整理、解释、翻译精华文章</b>	
					<br>
					归类总结历史名人言论，摘抄名著精华，制作成段落列表，发送管理员；
					<br>
					对本站中较为晦涩的文段进行通俗化的解释。
					<br>
					翻译本站的英文内容，写在文段评论栏。

				</div>

			</el-col>
		</el-row>
		<br>
		<el-row>
			<el-col :span="14">
				<div class="huanhang">
					<b class="font20px">贡献协作网站代码</b>		
					<br>
					本网站使用vuejs+django+mysql+mongodb等技术。网站代码已经上传github，项目名称：CyberAnarchism，欢迎纠错，并对总架构提供建议。
					<br>
					计划未来增加的功能：手机端应用，手机端页面设计，用户加密聊天，网站数据分布式存储，劳动培训视频社区，极简产品销售平台，众筹捐助，闲置物品捐献等功能，欢迎大家分包协作。
				</div>
			</el-col>
			<el-col :span="10">
					<el-image
						src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/z73b.jpg"
						:fit="fill">
					</el-image>
			</el-col>
		</el-row>
		<br>



    </div>
</template>

<script>
    export default {
        name:'z73',
        props:['k'],//k是区分
        data() {return {

        }},
        computed:{

        },
        methods:{
            
            
        },
    };
</script>



