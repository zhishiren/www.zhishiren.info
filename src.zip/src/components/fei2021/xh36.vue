<!-- 这是用户关注的标签的页面-->
<template>
	<div id="xh36">
            <!-- 下面的div是用来显示原始未筛选的列表，通过vshow来控制是否显示 -->
            <el-row class="font18px">
                <span>全站共有{{this.listNum}}条人物名片。</span>
                <chazhaolan0 @shuaxin="shuaxin" @huanyuan="huanyuan" @get_list="get_list" @send_searchword="send_searchword" :listNumk="listNumk"></chazhaolan0>
            </el-row>

            <div v-show="show_xh36">
                <div v-if="xh36s && show_loading===false">
                <!-- <div v-if="xh36s.length>0"> -->
                    <el-row class="br10px17px" v-for="list in lists" :key="list.pk">
                        <el-row>
                                <router-link class="a_black" target="_blank" :to="{name:'yonghuye',params:{id:list.pk}}">
                                    <b>{{list.fields.yonghu_name}}</b>
                                </router-link>
                                <span v-if="list.fields.yonghu_type==='yh5'" style="color:grey"><el-divider direction="vertical"></el-divider>公众人物</span>
                                <span v-if="list.fields.yonghu_type==='yh6'" style="color:grey"><el-divider direction="vertical"></el-divider>历史名人</span>
                        </el-row>
                        <el-row>
                            <span>
                                <span v-if="list.fields.yonghu_area">{{list.fields.yonghu_area}}</span>
                                <el-divider direction="vertical"></el-divider>
                                <span v-if="list.fields.yonghu_job">{{list.fields.yonghu_job}}</span>
                            </span>
                        </el-row>
                        <el-row :span="24"><el-divider style="margin:0px;"></el-divider></el-row>
                    </el-row>
                    <br>
                    <el-pagination  v-if="listNum>10" style="text-align:right;"
                                    background
                                    :page-size=10
                                    :total="listNum"
                                    :current-page.sync="currentPage"
                                    layout="total, prev, pager, next">
                    </el-pagination>
                </div>
                <div v-if="this.show_loading===true">
                        <div style="font-size:30px;color:grey;"><i class="el-icon-loading"></i>正在加载...</div>
                </div>
            </div>

            <div v-show="show_xhk36">
                    <el-row class="br10px17px" v-for="listk in listks" :key="listk.pk">
                            <el-row>
                                <router-link class="a_black" target="_blank" :to="{name:'yonghuye',params:{id:listk.fields.item0_id}}">
                                        <span v-html="gaoliangk(listk.fields.yonghu_name, k)" ></span>
                                </router-link>
                                <!-- <a @click="quguan(listk.fields.act_id)" class="a_grey"><i class="el-icon-close">取关</i></a> -->
                                <!-- <span style="float:right;">{{formatDate_ymd(listk.fields.act_createtime)}}</span> -->
                            </el-row>
                            <el-row>
                                <span>
                                    <span v-if="listk.fields.yonghu_area">{{listk.fields.yonghu_area}}</span>
                                    <el-divider direction="vertical"></el-divider>
                                    <span v-if="listk.fields.yonghu_job">{{listk.fields.yonghu_job}}</span>
                                </span>
                            </el-row>
                            <el-row><el-divider></el-divider></el-row>
                            
                    </el-row>
                    <el-pagination  v-if="listNumk>10" style="text-align:right;"
                                    background
                                    :page-size=10
                                    :total="listNumk"
                                    :current-page.sync="currentPagek"
                                    layout="total, prev, pager, next">
                    </el-pagination>
            </div>
    </div>
</template>

<script>
import chazhaolan0 from '../fujian/chazhaolan0';
import bianji0fuyan from '../fujian/bianji_fuyan';
import bianji0fuyan0k from '../fujian/bianji_fuyan_k';

export default {
    name:'xh36',
    components: {chazhaolan0,bianji0fuyan,bianji0fuyan0k},
    
	data() {return {
        currentPage: 1,//当前分页的数值
        listNum:0,//分页总条数
        currentPagek: 1,//查找后，当前分页的数值
        listNumk:0,//查找后，分页总条数

        show_xh36:false,
        show_xhk36:false,
        xh36s:[],
        xh36ks:[],
        k:'',
        show_loading:false,

    }},

	computed: {
            lists(){
                let pages=Math.ceil(this.listNum/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                    let sonList=[];
                    sonList=this.xh36s.slice(i*10,i*10+10);//10为每页设置数量
                    newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
            listks(){
                let pages=Math.ceil(this.listNumk/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                    let sonList=[];
                    sonList=this.xh36ks.slice(i*10,i*10+10);//10为每页设置数量
                    newList.push(sonList)
                }
                return newList[this.currentPagek-1]
            },
    },
    
	methods:{
      send_searchword(data){
          this.show_xh36=false;
          this.show_xhk36=true;
          this.k=data.k;
　　　　　　　　var newList = [];
// 　　　　　　　　this.xh36s.forEach(item=>{if(item.fields.item0_title.indexOf(this.k) !==-1||item.fields.act_fuyan.indexOf(this.k) !==-1){newList.push(item)}});
　　　　　　　　this.xh36s.forEach(item=>{if(item.fields.yonghu_name.indexOf(this.k) !==-1){newList.push(item)}});
             this.listNumk = newList.length;//这里是计算筛选后的结果的数量
　　　　　　   this.xh36ks = newList;
      },

      get_list(){
        this.show_xh36=true;
        this.show_xhk36=false;
        this.show_loading=true;
        this.$axios
        .post('http://www.zhishiren.info/api/xunhuan36/', {userid:this.$cookies.get('userid')})
        .then(response=>{
            this.xh36s=JSON.parse(response.data);
            this.listNum=this.xh36s.length;
            this.show_loading=false;
        });
        // .then(response=>{this.xh36s=JSON.parse(response.data);this.listNum='zero';});
      },

      huanyuan(){
            this.show_xh36=true;
            this.show_xhk36=false;
            this.show_loading=true;
            this.$nextTick(() => {
                this.$axios
                .post('http://www.zhishiren.info/api/xunhuan36/', {userid:this.$cookies.get('userid')})
                .then(response=>{
                    this.xh36s=JSON.parse(response.data);
                    this.listNum=this.xh36s.length;
                    this.show_loading=false;
                    });
            });
      },

      shuaxin(){
            this.show_xh36=true;
            this.show_xhk36=false;
            this.show_loading=true;
            this.$nextTick(() => {
                this.$axios
                .post('http://www.zhishiren.info/api/xunhuan36/', {userid:this.$cookies.get('userid')})
                .then(response=>{
                    this.xh36s=JSON.parse(response.data);
                    this.listNum=this.xh36s.length;
                    this.show_loading=false;
                    });
            });
      },
    },	
    created: function () {
            this.$axios
                .post('http://www.zhishiren.info/api/count36/', {userid:this.$cookies.get('userid')})
                .then(response=>{this.listNum=response.data;});
	}
};
</script>

<style>
</style>


