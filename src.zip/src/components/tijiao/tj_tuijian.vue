// 这个评论栏是用在每个知识点页面之下的评论功能，他有异议和匿名两个多选框
<template>
	<div id="tj_tuijian"  class="font18px">
		<el-row  class="font18px">
			<el-button type="text" class="font18px" style="padding-bottom:0px;"><i class="el-icon-setting"></i>设置...</el-button>
			这个群共有3条动态。-展开-
		</el-row>
	</div>
</template>

<script>
	export default {
		name: 'tj_tuijian',
		data () {
			return {
			}
		},
		methods: {
		}
	}
</script>

