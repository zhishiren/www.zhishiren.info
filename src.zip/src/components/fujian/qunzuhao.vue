<template>
<div id="qunzuhao" style="display:inline-block">
<span v-if="this.qz_id==90000000">仅本人可见</span>
<span v-if="this.qz_id>80000000 && this.qz_id<89999999">
    仅<router-link class="a_black" target="_blank" :to="{name:'qunzuye',params:{id:this.qz_id}}">{{this.qz_id}}</router-link>可见
</span>
<span v-if="this.qz_id==99999999">所有人可见</span>
</div>

</template>

<script>
  export default {
      name:'qunzuhao',
    props:['qz_id'],
    data() {
      return {
      }
    },

    methods:{


    }

  }
</script>