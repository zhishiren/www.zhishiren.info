<template>
    <div id="tj1duanluo" class="font18px">
        <el-button v-show="this.userid===this.yhid" @click="jiaduanluo1()" type="text" class="font18px"  style="padding-bottom:0px;"><i class="el-icon-plus"></i>添加...</el-button>
        <span style="color:green;" v-show="ok_msg==1"><i class="el-icon-success"></i>发布成功!</span>
        <span style="color:red;" v-show="ok_msg==2"><i class="el-icon-error"></i>操作失败!</span>
        <!-- <el-button v-show="this.type!s=='wj8'" @click="jiaduanluo1()" type="text" class="font18px"><i class="el-icon-plus"></i>添加...</el-button> -->
		<!-- 该文辑已经有{{this.c1+this.c2}}条段落<span v-if="type==='wj8'">。</span>
        <span v-if="type!=='wj8'">，其中{{this.c2}}条是由我创建。</span> -->
        <span>该文辑已经有{{this.listNum}}条段落。</span>
        <chazhaolan0 v-show="listNum!==0" ref="zhankai0" @shuaxin="shuaxin" @huanyuan="huanyuan" @get_list="get_list" @send_searchword="send_searchword" :listNumk="listNumk"></chazhaolan0>

        <el-dialog title="新增段落内容..." width="400px" :visible.sync="show_dialog1">
			<el-row v-if="this.type==='wj8'">
				<el-col :span="7" class="font18px" style="padding-top:10px;">
					公开范围：
				</el-col>
				<el-col :span="17">
					<fanwei  ref="huanyuan" @set_fanwei="set_gongkaifanwei"></fanwei>
				</el-col>
			</el-row>
			<br>
			<el-row>
				<el-col :span="7" class="font18px" style="padding-top:10px;">
					段落标题：
				</el-col>
				<el-col :span="17">
                <el-input v-model="wd_title" placeholder="请输入段落标题"  style="width:100%;"></el-input>
				</el-col>
			</el-row>
			<br>
			<el-row>
				<!-- 这里的格式要注意，“请输入分享附言，限100字。”与上下文的标签不能有换行等。 -->
				<div contenteditable ref="contents" @paste="onPaste" class="pinglunlan">请输入新段落的内容。</div>
			</el-row>
			
            <el-row>
                <el-col :span="6">
                    <a class="a_black font18px" href="javascript:;" @click="f_blod">
                        <b>所选加粗</b>
                    </a>
                </el-col>
                <el-col class="font18px" :span="12">
                    <span style="color:red;" v-show="ok_msg==3"><i class="el-icon-error"></i>正文不能为空!</span>
                </el-col>
                <el-col :span="6" style="text-align:right">
                    <a @click="fabujian" class="font20px a_black" >发布</a>
                </el-col>
            </el-row>
        </el-dialog>

            <div v-show="show_xh1d" >
                <div v-if="show_loading">
                    <br><br><br>
                    <div style="text-align:center;font-size:50px;color:grey;"><i class="el-icon-loading"></i>正在加载</div>
                </div>
                <!-- <div v-if="lists.length > 0"> -->
                <div v-if="lists">
                    <el-row class="br10px17px" v-for="list in lists" :key="list.pk">
                                <el-row :class="blinkyellow" v-if="list.pk===return_id">
                                    <!-- 这里s3是该段落的状态被手动改为失效的情况，与那些内容录入错误导致的删除，s4是有区别的。 -->
                                        <router-link target="_blank" class="a_black" :to="{name:'wenduanye',params:{id:list.pk}}" >
                                            <span style="max-width: 600px;float: left;overflow: hidden; white-space: nowrap;text-overflow: ellipsis;-o-text-overflow: ellipsis; ">{{list.fields.wd_title}}</span>
                                        </router-link>
                                        <el-divider direction="vertical"></el-divider>
                                        <span v-if="list.fields.wd_type=='wd8' && list.fields.wd_status=='s3'" style="color:red">已失效<el-divider direction="vertical"></el-divider></span>
                                        <uploadfu leixing=21 :fujianshu="list.fields.fu" :id="list.pk"></uploadfu>
                                        <tj0shanchu :zhid="list.pk" leixing="21" @shanchuok="deleteok()"  style="float:right"></tj0shanchu>
                                </el-row>
                                <el-row v-if="list.pk!==return_id">
                                        <router-link target="_blank" class="a_black" :to="{name:'wenduanye',params:{id:list.pk}}" >
                                            <span style="max-width: 600px;float: left;overflow: hidden; white-space: nowrap;text-overflow: ellipsis;-o-text-overflow: ellipsis; ">{{list.fields.wd_title}}</span>
                                        </router-link>
                                        <el-divider direction="vertical"></el-divider>
                                        <span v-if="list.fields.wd_type=='wd8' && list.fields.wd_status=='s3'" style="color:red">已失效<el-divider direction="vertical"></el-divider></span>
                                        <uploadfu leixing=21 :fujianshu="list.fields.fu" :id="list.pk"></uploadfu>
                                        <tj0shanchu :zhid="list.pk" leixing="21" @shanchuok="deleteok()"  style="float:right"></tj0shanchu>
                                </el-row>
                                <el-row>
                                    <router-link target="_blank" class="a_black" :to="{name:'wenduanye',params:{id:list.pk}}" >
                                        <span v-html="list.fields.wd_content" ></span>
                                    </router-link>
                                </el-row>
                                <el-row><el-divider style="margin:0px;"></el-divider></el-row>
                    </el-row>

                    <br>
                    <el-pagination v-if="listNum>10" style="text-align:right;"
                                    background
                                    :page-size=10
                                    :total="listNum"
                                    :current-page.sync="currentPage"
                                    layout="total, prev, pager, next">
                    </el-pagination>
                </div>
            </div>

            <div v-show="show_xhk1d">
                <div style="text-align:center;" v-if="listNumk===0">
                    <br><br><i class="el-icon-warning">查询无结果</i><br><br>
                </div>
                <div v-if="listNumk!==0">
                    <div v-if="show_loading">
                        <br><br><br>
                        <div style="text-align:center;font-size:50px;color:grey;"><i class="el-icon-loading"></i>正在加载</div>
                    </div>
                    <el-row class="br10px17px" v-for="listk in listks" :key="listk.pk">
                        <el-row>
                                <router-link target="_blank" class="a_black" :to="{name:'wenduanye',params:{id:listk.pk}}" >
                                    <span v-html="gaoliangk(listk.fields.wd_title, k)"  style="max-width: 600px;float: left;overflow: hidden; white-space: nowrap;text-overflow: ellipsis;-o-text-overflow: ellipsis; "></span>
                                </router-link>    
                                <el-divider direction="vertical"></el-divider>
                                <span v-if="listk.fields.wd_type=='wd8' && listk.fields.wd_status=='s3'" style="color:red">已失效<el-divider direction="vertical"></el-divider></span>
                                <uploadfu leixing=21 :fujianshu="listk.fields.fu" :id="listk.pk"></uploadfu>
                                <tj0shanchu :zhid="listk.pk" leixing="21" @shanchuok="deleteok()"  style="float:right"></tj0shanchu>
                        </el-row>
                        <el-row>
                            <router-link target="_blank" class="a_black" :to="{name:'wenduanye',params:{id:listk.pk}}" >
                                <span v-html="gaoliangk(listk.fields.wd_content, k)" ></span>
                            </router-link>
                        </el-row>
                        <el-row><el-divider style="margin:0px;"></el-divider></el-row>
                        
                    </el-row>
                    <!-- 下面的div是用来显示筛选后的分页条 -->
                    <el-pagination v-if="listNumk>10" style="text-align:right;"
                                    background
                                    :page-size=10
                                    :total="listNumk"
                                    :current-page.sync="currentPagek"
                                    layout="total, prev, pager, next">
                    </el-pagination>
                </div>
            </div>

    </div>
</template>

<script>
import fanwei from '../fujian/fanwei';
import chazhaolan0 from '../fujian/chazhaolan0';
import tj0shanchu from '../tijiao/tj_shanchu';
import uploadfu from '../fujian/uploadfu';

export default {
	name:'tj1duanluo',
	components: {fanwei,chazhaolan0,uploadfu,tj0shanchu},
    props:['type','zhid','zhititle','yhid'],
	data() {return {
        return_id:0,
        blinkyellow:'',
		show_dialog1:false,
		ok_msg:0,
        qunzu_fanwei_id:90000000,
        wd_title:'',

        currentPage: 1,//当前分页的数值
        listNum:0,//分页总条数
        currentPagek: 1,//查找后，当前分页的数值
        listNumk:1,//查找后，分页总条数
        
        show_xh1d:false,
        show_xhk1d:false,
        xh1ds:[],
        xh1dks:[],
        k:'',

        zhi_id:0,
        show_loading:false,
        }},
        
    computed: {
            lists(){
                let pages=Math.ceil(this.listNum/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                    let sonList=[];
                    sonList=this.xh1ds.slice(i*10,i*10+10);//10为每页设置数量
                    newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
            listks(){
                let pages=Math.ceil(this.listNumk/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                    let sonList=[];
                    sonList=this.xh1dks.slice(i*10,i*10+10);//10为每页设置数量
                    newList.push(sonList)
                }
                return newList[this.currentPagek-1]
            },
            userid(){return Number(this.$cookies.get('userid'))},
    },


	methods:{
            deleteok(){
                this.show_loading=true;
                this.$nextTick(() => {
                    this.show_xh1d=true;
                    this.show_xhk1d=false;
                    this.get_list();
                });
            },

            f_blod() {document.execCommand ( 'bold', false );},
            
            onPaste: function(e) {
                    e.preventDefault()
                    e.stopPropagation()
                    let pasteValue = (e.clipboardData || window.clipboardData).getData('text/plain')
                    console.log(pasteValue)
                    var re = /<[^>]+>/gi;
                    pasteValue = pasteValue.replace(re, '').replace(/\s+|[\r\n]/g,"");
                    e.target.textContent += pasteValue
                },
			set_gongkaifanwei(data){this.qunzu_fanwei_id = data.qz_id;},
			// jiaduanluo0:function(){
			// 		this.show_dialog0=false;
			// 		this.show_dialog0=true;
            // },
            jiaduanluo1:function(){
					this.show_dialog1=false;
					this.show_dialog1=true;
			},
			fabujian:function(){
                this.show_loading=true;
					var that = this;
					if(that.$refs.contents.innerHTML==='请输入段落正文内容。'){
                        that.ok_msg=3;
                        setTimeout(function(){that.ok_msg=0;}, 2000);}
					else{
                            that.axios
                            .post('http://www.zhishiren.info/api/oojiaduanluo/',{
                                wj_id:that.zhid,
                                wj_title:that.zhititle,
                                wd_title:that.wd_title,
                                wd_type:that.type,
                                userid: that.$cookies.get('userid'),
                                username:that.$cookies.get('username'),
                                wd_fanwei:that.qunzu_fanwei_id,
                                divcontent:that.$refs.contents.innerHTML
                            })
                            .then(function (response) {
                                    if (response.data.ok_id === 1){
                                        that.ok_msg=1;
                                        setTimeout(function(){that.ok_msg=0;}, 2000);
                                        that.return_id = response.data.rid;
                                        that.$refs.zhankai0.addnew();
                                        that.$refs.contents.innerHTML='请输入你要评论的内容。';
                                        that.wd_title='';
                                        that.show_dialog1=false;

                                        // that.show_xh1d=true;
                                        // that.show_xhk1d=false;
                                        that.$refs.zhankai0.huanyuanjian();
                                        that.show_loading=false;

                                        that.$nextTick(() => {
                                            that.show_xh1d=true;
                                            that.$axios
                                            .post('http://www.zhishiren.info/api/xunhuan1d_x/',{wj_id: that.zhid})
                                            .then(response=>{
                                                that.xh1ds=JSON.parse(response.data);
                                                that.listNum=that.xh1ds.length;});
                                                that.blinkyellow='blinkyellow';
                                                setTimeout(function(){that.blinkyellow='';}, 2000);
                                                
                                            
                                        });
                                    }
                                    if (response.data.ok_id === 2){
                                        that.ok_msg=2;
                                        setTimeout(function(){that.ok_msg=0;}, 2000);
                                        that.$refs.contents.innerHTML='请输入你要评论的内容。';
                                        that.wd_title='';
                                    }
                            });
                        };
            },


            send_searchword(data){
                this.show_xh1d=false;
                this.show_xhk1d=true;
                this.k=data.k;
        　　　　　　　　var newList = [];
        　　　　　　　　this.xh1ds.forEach(item=>{if(item.fields.wd_title.indexOf(this.k) !==-1||item.fields.wd_content.indexOf(this.k)!==-1){newList.push(item)}});
                     this.listNumk = newList.length;//这里是计算筛选后的结果的数量
        　　　　　　   this.xh1dks = newList;
            },

            get_list(){
                this.show_xh1d=true;
                this.show_loading=true;
                this.$axios
                .post('http://www.zhishiren.info/api/xunhuan1d/',{wj_id: this.zhid})
                .then(response=>{
                    this.xh1ds=JSON.parse(response.data);
                    this.listNum=this.xh1ds.length;
                    this.show_loading=false;
                    });
            },

            huanyuan(){
                this.show_xh1d=true;
                this.show_xhk1d=false;
            },

            shuaxin(){
                this.show_xh1d=true;
                this.show_loading=true;

                this.$nextTick(() => {
                this.$axios
                .post('http://www.zhishiren.info/api/xunhuan1d/',{wj_id: this.zhid})
                .then(response=>{
                    this.xh1ds=JSON.parse(response.data);
                    this.listNum=this.xh1ds.length;
                    this.show_loading=false;
                    });
                });
            },
    },
            watch: {
                zhid: function(newVal,oldVal){
                    this.zhi_id = newVal;
                    var that = this;
                    that.axios
                    .post('http://www.zhishiren.info/api/countdl/', {userid: that.$cookies.get('userid'),zhid:that.zhi_id})
                    .then(response=>{that.listNum=response.data;});
                },
            },

};

</script>

