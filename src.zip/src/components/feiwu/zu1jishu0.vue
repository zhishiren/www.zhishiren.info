<template>
    <div id="zu1jishu0" class="font18px">
        <!-- <zu0fayanmima @return_shuaxin="shuaxinjian()"></zu0fayanmima> -->
        <zu1caozuo v-if="zone_id==='评论'" cz_type='评论' zhid=90000107 createrid=90000106 fanwei=80000001 @shuaxin0="shuaxinjian()"></zu1caozuo>
        <zu1caozuo v-if="zone_id==='关联'" cz_type='关联' zhid=90000107 createrid=90000106 fanwei=80000001 @shuaxin0="shuaxinjian()"></zu1caozuo>
        <zu1caozuo v-if="zone_id==='加入标签'" cz_type='加入标签' zhid=90000107 createrid=90000106 fanwei=80000001 @shuaxin0="shuaxinjian()"></zu1caozuo>
        <zu1caozuo v-if="zone_id==='评价'" cz_type='评价' zhid=90000107 createrid=90000106 fanwei=80000001 @shuaxin0="shuaxinjian()"></zu1caozuo>
        <zu1caozuo v-if="zone_id==='发言'" cz_type='发言' zhid=90000107 createrid=90000106 fanwei=80000001 @shuaxin0="shuaxinjian()"></zu1caozuo>
        <zu1caozuo v-if="zone_id==='标签里加入'" cz_type='标签里加入' zhid=90000107 createrid=90000106 fanwei=80000001 @shuaxin0="shuaxinjian()"></zu1caozuo>

        <span>
            <span v-if="zone_id==='11'">你和关注用户共有</span>
            <span v-if="zone_id==='12'">你关注的知识点共有</span>
            <span v-if="zone_id==='13'">你共有</span>
            <span v-if="zone_id==='21'">你共关注了</span>
            <span v-if="zone_id==='22'">你共关注了</span>
            <span v-if="zone_id==='23'">你共关注了</span>
            <span v-if="zone_id==='24'">你共关注了</span>
            <span v-if="zone_id==='27'">你共关注了</span>

            <span v-if="zone_id==='32'">你共关注了</span>
            <span v-if="zone_id==='31'">全站共有</span>
            <span v-if="zone_id==='36'">全站共有</span>
            <span v-if="zone_id==='37'">全站共有</span>
            <span v-if="zone_id==='33'">你被</span>
            <span v-if="zone_id==='34'">全站共有</span>
            <span v-if="zone_id==='35'">你共加入了</span>
            
            <span v-if="zone_id==='souwenji'">全站共计</span>
            <span v-if="zone_id==='souwenduan'">全站共计</span>
            <span v-if="zone_id==='soubiaoqian'">全站共计</span>
            <span v-if="zone_id==='soufayan'">全站共计</span>
            <span v-if="zone_id==='soufuyan'">全站共计</span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span v-if="zone_id==='xzwj'">你共曾新增</span>
            <span v-if="zone_id==='xzqz'">你共曾新增</span>
            <span v-if="zone_id==='xzfy'">你共曾有</span>
            <span v-if="zone_id==='xzbq'">你共曾新增</span>
            <span v-if="zone_id==='评论'">该知识点共有</span>
            <span v-if="zone_id==='评价'">该用户共有</span>
            <span v-if="zone_id==='加入标签'">该知识点共有</span>
            
            <span v-if="jishu!==undefined">
                <span v-if="showloading1===false">{{this.jishu}}</span>
                <span v-if="showloading1"><i class="el-icon-loading"></i></span>
            </span>

            <span v-if="zone_id==='11'">条动态。</span>
            <span v-if="zone_id==='12'">条动态。</span>
            <span v-if="zone_id==='13'">条互动信息。</span>
            <span v-if="zone_id==='21'">条标签。</span>
            <span v-if="zone_id==='22'">条书辑。</span>
            <span v-if="zone_id==='23'">条段落。</span>
            <span v-if="zone_id==='24'">条言论。</span>
            <span v-if="zone_id==='27'">名用户。</span>
            
            <span v-if="zone_id==='32'">名用户。</span>
            <span v-if="zone_id==='34'">个群组。</span>
            <span v-if="zone_id==='35'">个群组。</span>
            <span v-if="zone_id==='31'">名用户，优先展示最新10名。</span>
            <span v-if="zone_id==='36'">名历史人物名片。</span>
            <span v-if="zone_id==='37'">个工团组织。</span>
            <span v-if="zone_id==='33'">名用户关注。</span>

            <span v-if="zone_id==='souwenji'">部文集，为你推荐最新的10部。</span>
            <span v-if="zone_id==='souwenduan'">条文段，为你推荐最新的10条。</span>
            <span v-if="zone_id==='soubiaoqian'">条标签，为你推荐最新的10条。</span>
            <span v-if="zone_id==='soufayan'">条用户发言，为你推荐最新的10条。</span>
            <span v-if="zone_id==='soufuyan'">条附言，为你推荐最新的10条。</span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span v-if="zone_id==='xzwj'">部文集。</span>
            <span v-if="zone_id==='xzqz'">个群组。</span>
            <span v-if="zone_id==='xzfy'">条发言。</span>
            <span v-if="zone_id==='xzbq'">条标签。</span>
            <span v-if="zone_id==='评论'">条评论。</span>
            <span v-if="zone_id==='评价'">条评价。</span>
            <span v-if="zone_id==='加入标签'">条标签。</span>

            <!-- <span v-if="jishu1">
                <span>，其中</span>
                <span v-if="showloading1===false">{{this.jishu1}}</span>
                <span v-if="showloading1"><i class="el-icon-loading"></i></span>
                <span>条正在审核</span>            
            </span> -->

        </span>
        <span v-if="zone_id!=='1'">
            <a class="a_black" v-show="show_zhankai" @click="zhankaijian()">-展开-</a> 
            <transition name="el-zoom-in-center">
                <a v-if="show_search!=='1' && show_zhankai===false" class="a_black" @click="shuaxinjian()"><i class="el-icon-refresh"></i>刷新</a>
            </transition>
            <transition name="el-zoom-in-center">
                <span v-if="show_search==='1' && show_zhankai===false">
                    <input type="text" class="input_jian font18px" size="mini" v-model="keyword" placeholder="在以下结果中查找">
                    <a class="a_black" @click="chazhaojian(keyword)"><i class="el-icon-search"></i>查找</a>
                    <span style="color:orange"  v-show="show_chazhaokong"><i class="el-icon-warning"></i>关键词不能为空!</span>
                    <span style="color:blue"    v-show="show_huanyuan"><i class="el-icon-finished"></i>{{this.listNumk}}个结果</span>
                    <a class="a_black" @click="huanyuanjian()"  v-show="show_huanyuan"><i class="el-icon-refresh-left"></i>还原</a>
                    <a class="a_black" @click="shuaxinjian()"   v-show="show_huanyuan===false"><i class="el-icon-refresh"></i>刷新</a>
                </span>
            </transition>
        </span>
        <br>
        <div v-if="listNumk===0 && show_huanyuan" style="font-size:30px;color:grey;text-align:center;">
            <i class="el-icon-info"></i>查询无结果
        </div>
        <span v-if="showloading2" style="font-size:30px;color:grey;">
            <i class="el-icon-loading"></i>正在加载...
        </span>
    </div>
</template>

<script>
    export default {
        name:'zu1jishu0',
        props:['zone_id','jishu','showloading1','showloading2','listNumk','show_search'],
        //
        data() {return {
            show_zhankai:true,
            keyword:'',
            show_chazhaokong:false,
            show_huanyuan:false,
        }},
        computed:{
			// jishu0(){return this.jishu==0?'0':this.jishu},
        },
        methods:{
            zhankaijian(){
                this.show_zhankai=false;
                this.$emit('zhankai');
            },

            shuaxinjian(){
                this.show_zhankai=false;
                this.$emit('shuaxin');
            },

			chazhaojian(keyword){
                var _this= this;
                if(keyword==''){
                    // 这是说明刚展开的阶段，这是输入空值后的表现
                    _this.show_chazhaokong=true;
                    setTimeout(function(){_this.show_chazhaokong=false;}, 1500);
                }else{
                    _this.show_huanyuan=false;
                    _this.show_huanyuan=true;
                    _this.show_chazhaokong=false;
                    let data = {k: keyword};
                    this.$emit('send_searchword',data);
                    _this.keyword='';
                }
            },

            huanyuanjian(){
                this.show_huanyuan=false;
                this.keyword='';
                this.$emit('huanyuan');
            },

        },
    };
</script>



