// 这个评论栏是用在每个知识点页面之下的评论功能，他有异议和匿名两个多选框
<template>
	<div id="tj_yinxiang"  class="font18px">
				    <el-button v-if="zhid!==userid" @click="pinglunjian" type="text" style="padding-bottom:0px;" class="font18px">
                        <i class="el-icon-star-off"></i>印象...
                    </el-button>
                    <span style="color:green;" v-show="ok_msg==1"><i class="el-icon-success"></i>发布成功!</span>
                    <span style="color:red;" v-show="ok_msg==3"><i class="el-icon-error"></i>操作失败!</span>
                    该用户已有{{this.listNum}}条大家印象。
                    <zhankai0 ref="zhankai0" @get_list="zhankaijian" @shuaxin="shuaxinjian"></zhankai0>
					<!-- <a @click="shuaxinjian" class="a_black"><i class="el-icon-refresh"></i>刷新</a> -->

		<el-dialog title="用户印象..." width="400px" :visible.sync="show_dialog">
            <el-row>
                <el-col :span="7" class="font18px" style="padding-top:10px;">
                    是否匿名：
                </el-col>
                <el-col :span="17">
                    <el-select v-model="niming" placeholder="请选择发言的类型" style="width:90%;">
                        <el-option value="不匿名" key="不匿名" label="不匿名"></el-option>
                        <el-option value="匿名" key="匿名" label="匿名"></el-option>
                    </el-select>
                </el-col>
            </el-row>
            <br>

			<el-row>
                <el-col :span="7" class="font18px" style="padding-top:10px;">
                    对他印象：
                </el-col>
                <el-col :span="17">
                    <el-select v-model="att_value" placeholder="请选择对他的印象" style="width:90%;">
                        <el-option value="-无态度-" key="-无态度-" label="-无态度-"></el-option>
                        <el-option value="聪明绝顶" key="聪明绝顶" label="聪明绝顶"></el-option>
                        <el-option value="古道心肠" key="古道心肠" label="古道心肠"></el-option>
                        <el-option value="一言九鼎" key="一言九鼎" label="一言九鼎"></el-option>
                        <el-option value="言论怪异" key="言论怪异" label="言论怪异"></el-option>
                        <el-option value="让人困惑" key="让人困惑" label="让人困惑"></el-option>
                        <el-option value="胡说八道" key="胡说八道" label="胡说八道"></el-option>
                    </el-select>
                </el-col>
            </el-row>
            <br>
            <el-row>
                <div contenteditable ref="contents" @paste="onPaste" class="pinglunlan">请输入你对他的评价。</div>
            </el-row>
            <el-row>
                <el-col :span="7">
                    <a class="a_black font18px" href="javascript:;" @click="f_blod">
                        <b>所选加粗</b>
                    </a>
                </el-col>
                <el-col class="font18px" :span="11">
                    <span style="color:orange;" v-show="ok_msg==2"><i class="el-icon-warning-outline"></i>评论不能为空!</span>
                </el-col>
                <el-col :span="6" style="text-align:right">
                    <a @click="fabujian" class="font20px a_black" >发布</a>
                </el-col>
            </el-row>
        </el-dialog>

        <div v-show="show_xhyx" >
                <el-row class="br10px17px" v-for="list in lists" :key="list.fields.act_createrid">
                            <el-row  :class="blinkyellow" v-if="list.pk==return_id">
                                <niming :niming_yn='list.fields.item1_title' :createrid='list.fields.act_createrid' :creatername='list.fields.act_creatername'></niming>
                                <span>：</span>
                                <span style="color:grey">
                                    <span v-html="list.fields.act_fuyan"></span>
                                </span>
                            </el-row>
                            <el-row v-if="list.pk!==return_id">
                                <niming :niming_yn='list.fields.item1_title' :createrid='list.fields.act_createrid' :creatername='list.fields.act_creatername'></niming>
                                <span>：</span>
                                <span style="color:grey">
                                    <span v-html="list.fields.act_fuyan"></span>
                                </span>
                            </el-row>
                            <tj0huifu :shuaxinid="shuaxinyn" timek=0 news_yn=0 @shanchuok="shanok()" :act_id="list.pk" :create_time="list.fields.act_createtime" :it_att="list.fields.act_att" :creater_id="list.fields.act_createrid" :item1title="'你评价了:用户'+zhititle+'>>>附言:'+list.fields.act_fuyan"></tj0huifu>
                            <el-row><el-divider style="margin:0px;"></el-divider></el-row>
                </el-row>
                <br>
                <el-pagination v-if="listNum>10" style="text-align:right;"
                                background
                                :page-size=10
                                :total="listNum"
                                :current-page.sync="currentPage"
                                layout="total, prev, pager, next">
                </el-pagination>
        </div>

	</div>
</template>

<script>
import tj0huifu from '../tijiao/tj_huifu';
import zhankai0 from '../fujian/zhankai0';
import niming from '../fujian/niming';

	export default {
		name: 'tj_yinxiang',
        components: {niming,tj0huifu,zhankai0},
        props:['zhid','zhititle'],
		data () {
			return {
                return_id:0,//这个return_id是用户添加评论成功之后，
                show_dialog:false,   
                show_xhyx:false,
                blinkyellow:'',
                xhyxs:[],
                currentPage: 1,//当前分页的数值
                listNum:0,//分页总条数
                ok_msg:9,
				att_value:"-无态度-",
                niming:'不匿名',
                zhi_id:1,
                shuaxinyn:0
			}
        },
        
        computed: {
            lists(){
                let pages=Math.ceil(this.listNum/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                    let sonList=[];
                    sonList=this.xhyxs.slice(i*10,i*10+10);//10为每页设置数量
                    newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
            userid(){return parseInt(this.$cookies.get('userid'))},


        },

		methods: {
            f_blod() {document.execCommand ( 'bold', false );},
            
            onPaste: function(e) {
                    e.preventDefault()
                    e.stopPropagation()
                    let pasteValue = (e.clipboardData || window.clipboardData).getData('text/plain')
                    console.log(pasteValue)
                    var re = /<[^>]+>/gi;
                    pasteValue = pasteValue.replace(re, '').replace(/\s+|[\r\n]/g,"");
                    e.target.textContent += pasteValue
                },
            fabujian() {
                // 这里需要判断，
                var that = this;
                        if(that.$refs.contents.innerHTML==='请输入你对他的评价。'){
                            that.ok_msg=2;
                            setTimeout(function(){that.ok_msg=0;}, 2000);
                        }
                        else{
                                that.axios
                                .post('http://www.zhishiren.info/api/ooyinxiang/',{
                                    userid: that.$cookies.get('userid'),
                                    username:that.$cookies.get('username'),
                                    yx_content:that.$refs.contents.innerHTML,
                                    yx_att:that.att_value,
                                    yx_niming:that.niming,
                                    zhid:that.zhid,
                                    zhititle:that.zhititle,
                                    })
                                .then(function (response) {
                                    if (response.data.ok_id === 1){
                                        that.ok_msg=1;
                                        that.return_id = response.data.rrid;
                                        setTimeout(function(){that.ok_msg=0;}, 2000);
                                        that.$refs.contents.innerHTML='请输入你对他的评价。';
                                        that.show_xhyx=true;
                                        that.show_dialog=false;
                                        that.$refs.zhankai0.addnew();
                                        that.$nextTick(() => {
                                            that.$axios
                                                .post('http://www.zhishiren.info/api/xunhuanyx/',{zhid: that.zhid})
                                                .then(response=>{
                                                                that.xhyxs=JSON.parse(response.data);
                                                                that.listNum=that.xhyxs.length;                                                                
                                                                that.currentPage=1;
                                                                that.blinkyellow='blinkyellow';
                                                                setTimeout(function(){that.blinkyellow='';}, 2000);
                                                });
                                        });
          
                                    }
                                    if (response.data.ok_id === 3){
                                        that.ok_msg=3;
                                        setTimeout(function(){that.ok_msg=0;}, 2000);
                                        that.$refs.contents.innerHTML='请输入你对他的评价。';
                                    }
                                });
                        }
                
            },

			f_blod() {
                document.execCommand ( 'bold', false );
			},

			pinglunjian(){
				this.show_dialog=true;
            },

            zhankaijian(){
                this.show_xhyx=true;
                this.$axios
                .post('http://www.zhishiren.info/api/xunhuanyx/',{zhid: this.zhid})
                .then(response=>{
                    this.xhyxs=JSON.parse(response.data);
                    this.listNum=this.xhyxs.length;});
            },

            shuaxinjian(){
                this.$nextTick(() => {
                this.shuaxinyn=1;
                this.$axios
                .post('http://www.zhishiren.info/api/xunhuanyx/',{zhid: this.zhid})
                .then(response=>{
                    this.xhyxs=JSON.parse(response.data);
                    this.shuaxinyn=0;
                    this.listNum=this.xhyxs.length;});
                });
            },

            shanok(){
                this.$nextTick(() => {
                this.$axios
                .post('http://www.zhishiren.info/api/xunhuanyx/',{zhid: this.zhid})
                .then(response=>{
                    this.xhyxs=JSON.parse(response.data);
                    this.listNum=this.xhyxs.length;});
                });
            },
        },
        //由于created不能收到props的传值，所以只能用watch的方法。
            watch: {
                zhid: function(newVal,oldVal){
                    this.zhi_id = newVal;  
                    this.$axios
                    .post('http://www.zhishiren.info/api/countyx/',{zhid: this.zhi_id})
                    .then(response=>{this.listNum=response.data});
            }},

	}
</script>

