<!-- 这是31模块独有的设计，这个模块里能查询所有用户的信息，但因为全部用户数据量较大和保护用户隐私的考虑，所以并不罗列出所有用户的信息，
只罗列出最新注册的用户（最新注册且已经上传了头像的用户）。
当用户搜索相关关键词的时候，后台查询后返回。
-->
<template>
	<div id="xh31">
            <el-row class="font18px">
                <span v-if="zongshu">全站共有{{this.zongshu}}名用户，</span>
                <span v-if="zongshu===0">全站共有<i class="el-icon-loading"></i>名用户，</span>
                <span v-show="show_xhk31===false">优先展示最新10名。</span>
                <span v-show="show_xhk31" style="color:blue"><i class="el-icon-finished"></i>{{this.listNumk}}个结果。</span>
                &nbsp;
				<a v-show="show_zhankai" @click="zhankaijian" class="a_black">-展开-</a> 
                <span v-show="show_chazhaolan">
                        <input type="text" class="input_jian font18px" size="mini" v-model="keyword" placeholder="在全部用户中查找">
                        <a @click="chazhaojian(keyword)" class="a_black"><i class="el-icon-search"></i>查找</a>   
                        &nbsp;
                        <span style="color:orange" v-show="show_chazhaokong"><i class="el-icon-warning"></i>关键词不能为空！</span>
                        <a v-show="show_shuaxin" @click="shuaxinjian" class="a_black"><i class="el-icon-refresh"></i>刷新</a>
                        &nbsp;
                        <a v-show="show_huanyuan" @click="huanyuanjian" class="a_black"><i class="el-icon-refresh-left"></i>还原</a>
                </span>
            </el-row>
               
            <div v-show="show_xh31">
                <div v-if="show_loading===false">
                    <el-row class="br10px17px" v-for="list in lists" :key="list.pk">
                            <el-row>
                                    <router-link class="a_black" target="_blank" :to="{name:'yonghuye',params:{id:list.pk}}">
                                        <b>{{list.fields.yonghu_name}}</b>
                                    </router-link>
                                    <!-- <span v-if="list.fields.yonghu_type==='yh5'" style="color:grey"><el-divider direction="vertical"></el-divider>公众人物</span> -->
                                    <!-- <span v-if="list.fields.yonghu_type==='yh6'" style="color:grey"><el-divider direction="vertical"></el-divider>历史名人</span> -->
                            </el-row>
                            <el-row>
                                <span>
                                    <span v-if="list.fields.yonghu_area">{{list.fields.yonghu_area}}</span><span v-else><font style="color:grey">地区:暂无</font></span>
                                    <el-divider direction="vertical"></el-divider>
                                    <span v-if="list.fields.yonghu_job">{{list.fields.yonghu_job}}</span><span v-else><font style="color:grey">职业:暂无</font></span>
                                    <el-divider direction="vertical"></el-divider>
                                    <span v-if="list.fields.yonghu_remark"><font style="color:grey">签名:</font>{{list.fields.yonghu_remark}}</span><span v-else><font style="color:grey">签名:无</font></span>
                                </span>
                            </el-row>
                            <el-row :span="24"><el-divider style="margin:0px;"></el-divider></el-row>
                    </el-row>
                </div>
                <div v-if="show_loading">
                    <div style="font-size:30px;color:grey;"><i class="el-icon-loading"></i>正在加载...</div>
                </div>
            </div>
        
            <div v-show="show_xhk31">
                <div v-if="show_kloading===false">
                    <el-row class="br10px17px" v-for="list in listks" :key="list.pk">
                            <el-row>
                                    <router-link class="a_black" target="_blank" :to="{name:'yonghuye',params:{id:list.pk}}">
                                        <b><span v-html="gaoliangk(list.fields.yonghu_name, keyword)" ></span></b>
                                    </router-link>
                                    <span v-if="list.fields.yonghu_type==='yh5'" style="color:grey"><el-divider direction="vertical"></el-divider>公众人物</span>
                                    <span v-if="list.fields.yonghu_type==='yh6'" style="color:grey"><el-divider direction="vertical"></el-divider>历史名人</span>
                                    <!-- <span style="color:grey"><i class="el-icon-view"></i>关注</span> -->
                            </el-row>
                            <el-row>
                                <span>
                                    <span v-if="list.fields.yonghu_area">{{list.fields.yonghu_area}}</span><span v-else><font style="color:grey">地区:暂无</font></span>
                                    <el-divider direction="vertical"></el-divider>
                                    <span v-if="list.fields.yonghu_job">{{list.fields.yonghu_job}}</span><span v-else><font style="color:grey">职业:暂无</font></span>
                                    <el-divider direction="vertical"></el-divider>
                                    <span v-if="list.fields.yonghu_remark">{{list.fields.yonghu_remark}}</span><span v-else><font style="color:grey">签名:无</font></span>
                                </span>
                            </el-row>
                        <el-col :span="24"><el-divider style="margin:0px;"></el-divider></el-col>
                    </el-row>     
                    <!-- 下面的div是用来显示筛选后的分页条 -->
                    <el-pagination  v-if="listNumk>10" style="text-align:right;"
                                    background
                                    :page-size=10
                                    :total="listNumk"
                                    :current-page.sync="currentPagek"
                                    layout="total, prev, pager, next">
                    </el-pagination>
                </div>
                <div v-if="show_kloading">
                    <div style="font-size:30px;color:grey;"><i class="el-icon-loading"></i>正在加载...</div>
                </div>
                <div style="text-align:center;font-size:30px;color:grey" v-if="listNumk===0 && show_kloading===false">
                    <br><br><i class="el-icon-warning">查询无结果</i><br><br>
                </div>
            </div>
    </div>


</template>

<script>
import tj0shanchu from '../tijiao/tj_shanchu';
import tj0huifu from '../tijiao/tj_huifu';

export default {
    name:'xh31',
    components: {tj0shanchu,tj0huifu},
    
	data() {return {
        currentPage: 1,//当前分页的数值
        listNum:0,//分页总条数
        currentPagek: 1,//查找后，当前分页的数值
        listNumk:0,//查找后，分页总条数
        show_xh31:false,
        show_xhk31:false,
        xh31s:[],
        xh31ks:[],

        keyword:'',

        show_chazhaokong:false,
        show_shuaxin:true,
        show_huanyuan:false,
        show_chazhaolan:false,
        show_zhankai:true,
        zongshu:0,
        show_loading:false,
        show_kloading:false,
    }},


	computed: {
            lists(){
                let pages=Math.ceil(this.listNum/10);//
                let newList=[];
                for(let i=0;i<pages;i++){
                let sonList=[];
                sonList=this.xh31s.slice(i*10,i*10+10);//
                newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },

            listks(){
                let pages=Math.ceil(this.listNumk/10);//
                let newList=[];
                for(let i=0;i<pages;i++){
                let sonList=[];
                sonList=this.xh31ks.slice(i*10,i*10+10);//
                newList.push(sonList)
                }
                return newList[this.currentPagek-1]
            },
    },
    
	methods:{
        zhankaijian:function(){
                this.show_zhankai=false;
                this.show_chazhaolan=true;
                this.show_loading=false;
                this.show_loading=true;
                this.$axios.get('http://www.zhishiren.info/api/xunhuan31/').then(response=>{
                    this.xh31s=JSON.parse(response.data);
                    this.listNum=this.xh31s.length;
                    this.show_loading=false;
                    });
                this.show_xh31=true;                
        },

        huanyuanjian(){
                this.show_xh31=true;
                this.show_xhk31=false;
                this.show_chazhaokong=false;
                this.keyword='';
                this.show_shuaxin=true;
                this.show_huanyuan=false;
        },

        shuaxinjian(){
                this.show_loading=false;
                this.show_loading=true;
                this.$axios.get('http://www.zhishiren.info/api/xunhuan31/').then(response=>{
                    this.xh31s=JSON.parse(response.data);
                    this.listNum=this.xh31s.length;
                    this.show_loading=false;
                    });
        },

        chazhaojian:function(keyword){
            if(keyword==''){
                // 这是说明刚展开的阶段，这是输入空值后的表现
                this.show_chazhaokong=true;
                this.show_huanyuan=false;
                this.show_shuaxin=true;
            }else{
                this.show_huanyuan=true;
                this.show_shuaxin=false;
                this.show_chazhaokong=false;
                this.show_xhk31=true;
                this.show_xh31=false;
                this.show_kloading=false;
                this.show_kloading=true;
                
                // 这个动作是用于展开之后，显示多少条记录
                this.$axios
                    .post('http://www.zhishiren.info/api/xunhuan31_sou/', {k: this.keyword})
                    .then(response=>{
                        this.xh31ks=JSON.parse(response.data);
                        this.listNumk=this.xh31ks.length;
                        this.currentPagek=1;
                        this.show_kloading=false;
                        });
            }
        },
    },	

    created: function () {
            this.$axios
                .post('http://www.zhishiren.info/api/count31/', {userid:this.$cookies.get('userid')})
                .then(response=>{this.zongshu=response.data;});
	}

};
</script>




