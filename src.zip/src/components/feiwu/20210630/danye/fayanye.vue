<template>
<div id="fayanye"  @click="turnfresh()">
	<toubu0></toubu0>
		<el-container>
			<el-aside width="120px" class="bgcolor_FF"></el-aside>
			<el-main v-if="fy_info.fy_status==='s0'" class="bgcolor_FC font18px">
				<el-card v-if="fy_info.fy_id" class="box-card">
					<el-row >
						<span style="color:grey">{{formatDate_ymdhm(this.fy_info.fy_createtime)}}</span>
						<el-divider direction="vertical"></el-divider>
						<router-link class="a_black" target="_blank" :to="{name:'yonghuye',params:{id:fy_info.fy_createrid}}">
							<span class="a_black">{{this.fy_info.fy_creatername}}</span>
						</router-link>
						<span style="color:grey">发言说</span>
						
						<b>:</b>
						<el-col :span="24"  class="font21px">
							<font style="font-size:25px;"><b>“</b></font>
							<span v-html="this.fy_info.fy_content" style="color:brown;"></span>
							<font style="font-size:25px;"><b>”</b></font>
						</el-col>
					</el-row>
					<zu0fujianfutu v-if="this.fy_info.fy_fu!==0" :zhid="fy_info.fy_id"></zu0fujianfutu>
					<el-row>
						<span><b>属性<i class="el-icon-caret-right"></i></b></span>
						<span>发言ID:{{this.fy_info.fy_id}}<el-divider direction="vertical"></el-divider></span>
						<span style="color:red;" v-if="fy_info.fy_att==='紧急重要'">{{fy_info.fy_att}}<el-divider direction="vertical"></el-divider></span>
						<span>{{this.fy_info.fy_type}}<el-divider direction="vertical"></el-divider></span>
						<span style="color:red;" v-if="fy_info.fy_status==='s4'">{{daibiaoma(this.fy_info.fy_status)}}<el-divider direction="vertical"></el-divider></span>
						<span v-if="fy_info.fy_status!=='s4'">{{daibiaoma(this.fy_info.fy_status)}}<el-divider direction="vertical"></el-divider></span>
						<showfanwei :qz_id="fy_info.fy_fanwei"></showfanwei>
						<zu0tongjishu :dj="fy_tongji.dianji" :gz="fy_tongji.guanzhu" :fx="fy_tongji.fenxiang"></zu0tongjishu>
					</el-row>
				</el-card>
				<el-card v-else>
					<br>
						<div style="text-align:center;font-size:30px;"><i class="el-icon-loading"></i>正在加载</div>
					<br>
				</el-card>
			</el-main>
			<el-main v-if="fy_info.fy_status!=='s0'">
				<el-card>
					<i class="el-icon-lock"></i>
					<span>此内容</span>
					<span v-if="fy_info.fy_zishu===0">
						<span v-if="fy_info.fy_status==='s4'">已被删除</span>
						<span v-if="fy_info.fy_status==='s5'">拒绝退回</span>
						<span v-if="fy_info.fy_status==='s9'">正在审核</span>
					</span>
					<span v-if="fy_info.fy_zishu!==0">是密文，无法显示</span>

				</el-card>
			</el-main>
		</el-container>

		<el-container  v-if="fy_info.fy_status==='s0'">
			<el-aside width="120px">
				<el-menu default-active="12" class="el-menu-vertical-demo bgcolor_menu_FC" @open="handleOpen" @close="handleClose">
			      <el-menu-item @click="daohang11" index="11" class="font18px">
			        <span slot="title">发言全集</span>
			      </el-menu-item>
				  <el-menu-item @click="daohang12" index="12" class="font18px">
			        <span slot="title">关注分享</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang13" index="13" class="font18px">
			        <span slot="title">评论</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang14" index="14" class="font18px">
			        <span slot="title">关联知识</span>
			      </el-menu-item>
			      <!-- <el-menu-item @click="daohang15" index="15" class="font18px">
			        <span slot="title">推荐阅读</span>
			      </el-menu-item>
				  <el-menu-item @click="daohang16" index="16" class="font18px">
			        <span slot="title">内容管理</span>
			      </el-menu-item>				       -->
			    </el-menu>
			</el-aside>
			<el-main v-show="dh12" class="section_xh">
				<tj0fenxiang @fxadd1="add1(1)" :zhid="fy_info.fy_id" zhitype="fayanye" :zhititle="fy_info.fy_content+'｜来自'+fy_info.fy_creatername" :createrid="fy_info.fy_createrid" :zhitype1="fy_info.fy_type" :fanwei="fy_info.fy_fanwei"></tj0fenxiang>
				<tj0guanzhu @gzadd1="add1(2)" @gzminus1="minus1(2)" :zhid="fy_info.fy_id" :zhititle="fy_info.fy_content+'｜来自'+fy_info.fy_creatername" zhitype="fayanye" bq_fanwei=0></tj0guanzhu>
				<!-- <tj0jiucuo zhitype="fayanye" :zhid="fy_info.fy_id" :zhititle="fy_info.fy_content"></tj0jiucuo> -->
				<tj0jiabiaoqian zhitype="fayanye" :zhid="fy_info.fy_id" :zhititle="fy_info.fy_content+'｜来自'+fy_info.fy_creatername"></tj0jiabiaoqian>
			</el-main>
			<el-main v-show="dh13" class="section_xh">
            <tj0pinglun :zhid="fy_info.fy_id" zhitype="fayanye" :zhititle="fy_info.fy_content+'｜来自'+fy_info.fy_creatername" :fanwei="fy_info.fy_fanwei"></tj0pinglun>
			</el-main>
			<el-main v-show="dh14" class="section_xh">
             <tj0guanlian  zhitype="fayanye" :zhid="fy_info.fy_id" :zhititle="fy_info.fy_content+'｜来自'+fy_info.fy_creatername" :fanwei="fy_info.fy_fanwei"></tj0guanlian>
			</el-main>
			<el-main v-show="dh15" class="section_xh">
            <tj0tuijian></tj0tuijian>
			</el-main>
			<el-main v-show="dh11" class="section_xh">
             <tj1fayan :userid="fy_info.fy_createrid" :username="fy_info.fy_creatername"></tj1fayan>
			</el-main>
			<el-main v-show="dh16" class="section_xh">
			<bdg2></bdg2>
			</el-main>

			<el-aside width="120px" class="bgcolor_FC"></el-aside>


		</el-container>
	</div>

</template>

<script>
import tj0fenxiang from '../tijiao/tj_fenxiang';
import tj0guanzhu from '../tijiao/tj_guanzhu';
import tj0jiabiaoqian from '../tijiao/tj_jiabiaoqian';
import tj1fayan from '../tijiao/tj1fayan';
import tj0jiucuo from '../tijiao/tj_jiucuo';
import tj0pinglun from '../tijiao/tj_pinglun';
import tj0guanlian from '../tijiao/tj_guanlian';
import tj0tuijian from '../tijiao/tj_tuijian';

import bdg2 from '../biaodan/bdg2';
import xiazaiyuanwen from '../fujian/xiazaiyuanwen';
import toubu0 from '../fujian/toubu0';
import showfanwei from '../fujian/showfanwei';
import zu0tongjishu from '../fujian/zu0tongjishu';
import zu0fujianfutu from '../fujian/zu0fujianfutu';

export default {
        name:'fayanye',
		components: {zu0fujianfutu,zu0tongjishu,showfanwei,tj0tuijian,toubu0,tj0guanzhu,tj0fenxiang,tj0jiabiaoqian,tj0pinglun,tj0guanlian,tj0jiucuo,tj1fayan,bdg2,xiazaiyuanwen},
        methods:{
                    daohang11(){this.dh11=true;this.dh12=false;this.dh13=false;this.dh14=false;this.dh15=false;this.dh16=false;},
                    daohang12(){this.dh12=true;this.dh11=false;this.dh13=false;this.dh14=false;this.dh15=false;this.dh16=false;},
                    daohang13(){this.dh13=true;this.dh11=false;this.dh12=false;this.dh14=false;this.dh15=false;this.dh16=false;},
                    daohang14(){this.dh14=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh15=false;this.dh16=false;},
                    daohang15(){this.dh15=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh14=false;this.dh16=false;},
					daohang16(){this.dh16=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh14=false;this.dh15=false;},
					//这里的k值指的是关注这种类型，以后可能会加入其他类型
					add1(k){
						if(k==1){this.fy_tongji.fenxiang++;}
						if(k==2){this.fy_tongji.guanzhu++;}
					},
					minus1(k){
						if(k==2){this.fy_tongji.guanzhu--;}
					},
			
        },
        data() {
			return {dh15:false,dh11:false,dh13:false,dh14:false,dh12:true,dh16:false,
			fayan_id:0,
			fy_info:[],
			fy_tongji:[],
			fulist:[],
			fucount:0,
			futuid:100000210
			}
        },
        created() {
				this.fayan_id = this.$route.params.id;//获取上个页面传递的id,在下面获取数据的时候先提交id,这里的id不用加前缀
				var _this= this;
				_this.axios
				.post('http://www.zhishiren.info/api/show_fayanye/', {fayan_id:_this.fayan_id})
				.then(function (response) {
					_this.fy_info=response.data;
					_this.fy_tongji=JSON.parse(response.data.fy_tongji);
				});
		},
		computed: {
				welcomename(){return this.$cookies.get('username')},
		},
};

</script>

<style scoped>

</style>




