// 这个评论栏是用在每个知识点页面之下的评论功能，他有异议和匿名两个多选框
<template>
	<div id="tj_pinglun"  class="font18px">
				    <!-- <el-button @click="pinglunjian" type="text" style="padding:0px;" class="font18px">
                        <i class="el-icon-plus"></i>添加...
                    </el-button>
                    <span style="color:green;" v-show="ok_msg==1"><i class="el-icon-success"></i>发布成功!</span>
                    <span style="color:red;" v-show="ok_msg==3"><i class="el-icon-error"></i>操作失败!</span> -->
                    你共有{{this.listNum}}条动态。
                    <zhankai0 ref="zhankai0" @get_list="zhankaijian" @shuaxin="shuaxinjian"></zhankai0>
					<!-- <a @click="shuaxinjian" class="a_black"><i class="el-icon-refresh"></i>刷新</a> -->

        <div v-show="show_xhpl" >
                <el-row class="br10px17px" v-for="list in lists" :key="list.fields.act_createrid">
                            <el-row  :class="blinkyellow" v-if="list.pk==return_id">
                                {{list.fields.act_creatername}}:
                                <span style="color:grey">
                                    <!-- <span style="color:red;">(异议)</span> -->
                                    <span v-html="list.fields.act_fuyan"></span>
                                </span>
                                <tj0huifu @shanchuok="shanok()" :creater_id="list.fields.act_createrid" :comment_id="list.pk" actype=2 :zhid="list.fields.item0_id" :create_time="list.fields.act_createtime"></tj0huifu>
                            </el-row>
                            <el-row v-if="list.pk!==return_id">
                                {{list.fields.act_creatername}}:
                                <span style="color:grey">
                                    <!-- <span style="color:red;">(异议)</span> -->
                                    <span v-html="list.fields.act_fuyan"></span>
                                </span>
                                <tj0huifu@shanchuok="shanok()" :creater_id="list.fields.act_createrid" :comment_id="list.pk" actype=2 :zhid="list.fields.item0_id" :create_time="list.fields.act_createtime"></tj0huifu>
                            </el-row>
                            <el-row><el-divider style="margin:0px;"></el-divider></el-row>
                </el-row>
<br>
                <el-pagination v-if="listNum>10" style="text-align:right;"
                                background
                                :page-size=10
                                :total="listNum"
                                :current-page.sync="currentPage"
                                layout="total, prev, pager, next">
                </el-pagination>
        </div>

	</div>
</template>

<script>
import tj0huifu from '../tijiao/tj_huifu';
import fanwei from '../fujian/fanwei';
import tixing from '../fujian/tixing';
import zhankai0 from '../fujian/zhankai0';

	export default {
		name: 'tj_pinglun',
        components: {tj0huifu,fanwei,tixing,zhankai0},
        props:['zhid','listNum','zhititle','zhitype'],
		data () {
			return {
                return_id:0,//这个return_id是用户添加评论成功之后，
                show_dialog:false,   
                show_xhpl:false,
                blinkyellow:'',
                xhpls:[],
                currentPage: 1,//当前分页的数值
                listNum:0,//分页总条数
                zhitype:'',
                ok_msg:9,
				att_value:'-无态度-',
                niming:'fy6',
                zhi_id:1,
                radio: '1'
			}
        },
        
        computed: {
            lists(){
                let pages=Math.ceil(this.listNum/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                    let sonList=[];
                    sonList=this.xhpls.slice(i*10,i*10+10);//10为每页设置数量
                    newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
            
        },

		methods: {
            f_blod() {document.execCommand ( 'bold', false );},
            
            onPaste: function(e) {
                    e.preventDefault()
                    e.stopPropagation()
                    let pasteValue = (e.clipboardData || window.clipboardData).getData('text/plain')
                    console.log(pasteValue)
                    var re = /<[^>]+>/gi;
                    pasteValue = pasteValue.replace(re, '').replace(/\s+|[\r\n]/g,"");
                    e.target.textContent += pasteValue
                },
            fabujian() {
                // 这里需要判断，
                var that = this;
                        if(that.$refs.contents.innerHTML==='请输入你要评论的内容。'){
                            that.ok_msg=2;
                            setTimeout(function(){that.ok_msg=0;}, 2000);
                        }
                        else{
                                that.axios
                                .post('http://www.zhishiren.info/api/oopinglun/',{
                                    userid: that.$cookies.get('userid'),
                                    username:that.$cookies.get('username'),
                                    pl_content:that.$refs.contents.innerHTML,
                                    pl_att:that.att_value,
                                    pl_niming:that.niming,
                                    zhid:that.zhid,
                                    zhititle:that.zhititle,
                                    zhitype:that.zhitype,
                                    })
                                .then(function (response) {
                                    if (response.data.ok_id === 1){
                                        that.ok_msg=1;
                                        that.return_id = response.data.rrid;
                                        setTimeout(function(){that.ok_msg=0;}, 2000);
                                        that.$refs.contents.innerHTML='请输入你要评论的内容。';
                                        that.show_xhpl=true;
                                        that.show_dialog=false;
                                        that.$refs.zhankai0.addnew();
                                        that.$nextTick(() => {
                                            that.$axios
                                                .post('http://www.zhishiren.info/api/xunhuanpl/',{zhid: that.zhid})
                                                .then(response=>{
                                                                that.xhpls=JSON.parse(response.data);
                                                                that.listNum=that.xhpls.length;                                                                
                                                                that.currentPage=1;
                                                                that.blinkyellow='blinkyellow';
                                                                setTimeout(function(){that.blinkyellow='';}, 2000);
                                                });
                                        });
          
                                    }
                                    if (response.data.ok_id === 3){
                                        that.ok_msg=3;
                                        setTimeout(function(){that.ok_msg=0;}, 2000);
                                        that.$refs.contents.innerHTML='请输入你要评论的内容。';
                                    }
                                });
                        }
                
            },

			f_blod() {
                document.execCommand ( 'bold', false );
                // document.execCommand ( 'backColor', false, 'yellow' );
			},

			pinglunjian(){
				this.show_dialog=true;
            },

            zhankaijian(){
                this.show_xhpl=true;
                this.$axios
                .post('http://www.zhishiren.info/api/xunhuanpl/',{zhid: this.zhid})
                .then(response=>{
                    this.xhpls=JSON.parse(response.data);
                    this.listNum=this.xhpls.length;});
            },

            shuaxinjian(){
                this.$nextTick(() => {
                this.$axios
                .post('http://www.zhishiren.info/api/xunhuanpl/',{zhid: this.zhid})
                .then(response=>{
                    this.xhpls=JSON.parse(response.data);
                    this.listNum=this.xhpls.length;});
                });
            },

            shanok(){
                this.$nextTick(() => {
                this.$axios
                .post('http://www.zhishiren.info/api/xunhuanpl/',{zhid: this.zhid})
                .then(response=>{
                    this.xhpls=JSON.parse(response.data);
                    this.listNum=this.xhpls.length;});
                });

            }
            
        },
        // 由于created不能收到props的传值，所以只能用watch的方法。
        // watch: {
        //     zhid: function(newVal,oldVal){
        //         this.zhi_id = newVal;  
        //         this.$axios
        //         .post('http://www.zhishiren.info/api/xunhuanpl/',{zhid: this.zhi_id})
        //         .then(response=>{
        //             this.xhpls=JSON.parse(response.data);
        //             this.listNum=this.xhpls.length;});
        //          }
        // },

        // created: function () {
        //     this.$axios
        //         .post('http://www.zhishiren.info/api/xunhuanpl/',{zhid: this.zhid})
        //         .then(response=>{
        //             this.xhpls=JSON.parse(response.data);
        //             this.listNum=this.xhpls.length;});
        // }
	}
</script>

