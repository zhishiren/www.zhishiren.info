// 这是在用户动态中每一条记录下面的回复内容。
<template>
<span>
                <span style="color:grey;">
                    <!-- <span v-show="yonghuid!==createrid && huifu_loading===false">
                        <span v-show="show_huifulan===false"><a @click="huifujian()" class="a_grey"><i class="el-icon-caret-left"></i>回复</a></span>
                        <span v-show="show_huifulan===true"  style="font-size:16px;background:grey;color:white;right:0px;position: absolute;">
                            <i class="el-icon-caret-left"></i><input :placeholder="huifuid" v-model="hf_content1" type="text" class="input_jian" style="font-size:15px;background:grey;color:white;width:200px;padding:0px;border-bottom:1px solid white;" >
                            <el-dropdown style="font-size:16px;"  @command="choose_taidu">
                                <span class="el-dropdown-link a_white"><i class="el-icon-arrow-down el-icon--right"></i>态度</span>
                                <el-dropdown-menu slot="dropdown">
                                    <el-dropdown-item command="支持">点赞支持</el-dropdown-item>
									<el-dropdown-item command="反对">反对异议</el-dropdown-item>
									<el-dropdown-item command="疑问">疑惑不解</el-dropdown-item>
                                </el-dropdown-menu>
                            </el-dropdown>·
                            <span><a @click="quedingjian()" class="a_white"><i class="el-icon-chat-dot-round"></i>明发</a>·</span>
                            <span><a @click="quedingjian()" class="a_white"><i class="el-icon-s-comment"></i>密发</a>·</span>
                            <span><a @click="huanyuanjian()" class="a_white"><i class="el-icon-refresh-left"></i>取消</a></span>
							<span v-if="rmsg!==''">{{this.rmsg}}</span>
                            <span v-if="show_kong" style="color:orange">:输入不能空</span>
                            <span v-if="show_error" style="color:orange">:操作失败！</span>
                            <span v-if="show_addok" style="color:orange">:添加成功！</span>
                        </span>
                    </span>
					<span v-if="huifu_loading"><i class="el-icon-loading"></i>正在发布...</span> -->

                    <span v-show="yonghuid===createrid">
                        <a v-if="shan_loading===false" @click="hf_shan(comm_id)" class="a_grey"><i class="el-icon-close"></i>删</a>
                        <span style="color:orange" v-if="shan_error">:删除失败</span>
                        <span v-if="shan_loading"><i class="el-icon-loading"></i>正在删除...</span>
                    </span> 

                </span>

                <!-- <span v-if="yonghuid===hf.fields.act_createrid" style="color:black;right:0px;position: absolute;">
					<i class="el-icon-caret-left"></i><input placeholder="" v-model="hf_content1" type="text" class="input_jian" style="background:grey;color:white;width:200px;font-size:16px;padding:0px;" >
					<span>
						<el-dropdown>
							<span class="el-dropdown-link a_grey" style="font-size:17px;color:black;"><i class="el-icon-arrow-down el-icon--right"></i>态度</span>
							<el-dropdown-menu slot="dropdown">
								<el-dropdown-item>支持</el-dropdown-item>
								<el-dropdown-item>反对</el-dropdown-item>
								<el-dropdown-item>疑问</el-dropdown-item>
							</el-dropdown-menu>
						</el-dropdown>·</span>
					<span><a @click="quedingjian()"><i class="el-icon-chat-dot-round"></i>明发</a>·</span>
					<span><a @click="quedingjian()" class="a_grey"><i class="el-icon-s-comment"></i>密发</a>·</span>
					<span><a @click="huanyuanjian()" class="a_grey"><i class="el-icon-refresh-left"></i>取消</a></span>
					
					<span v-if="show_kong" style="color:orange">:输入不能空</span>
					<span v-if="show_error" style="color:orange">:操作失败！</span>
					<span v-if="show_addok" style="color:orange">:添加成功！</span>
				</span> -->
</span>
                
</template>

<script>
export default {
	data() {return {
        show_huifulan:false,
		hf_content1:'',
		shan_error:false,
		shan_loading:false,
		huifu_loading:false,
		rmsg:'',
		taidu:''
    }},
	props:['creater_id','creater_name','comm_id'],
    computed: {
            huifuid(){return "...回复"+this.creater_name},
			yonghuid(){return parseInt(this.$cookies.get('userid'))},
			createrid(){return parseInt(this.creater_id)},
    },
	methods:{
		choose_taidu(taidu_value){this.taidu=taidu_value;},
		        huifujian:function(){
					this.show_huifulan=true;
					this.huifu_loading=true;
					var that=this;
					that.$nextTick(() => {
						that.$axios
						.post('http://www.zhishiren.info/api/huifu_list/',{act_id: that.act_id})
						.then(response=>{
							that.hflist=JSON.parse(response.data);
							that.hfshu=JSON.parse(response.data).length;
							that.huifu_loading=false;

						});
					});
				},
				huanyuanjian(){
					this.show_huifulan=false;
					this.hf_content1='';
				},



		hf_shan(kkk){
					this.$alert('确认删除本条回复内容？', '确认删除这条回复内容？', {
						confirmButtonText: '确定',
						callback: action => {
							if (action === 'confirm') {
								this.shan_loading=true;
								var that=this;
								that.$axios
								.post('http://www.zhishiren.info/api/hf_shan/',{act_id: kkk})
								.then(response=>{
									if(response.data.shan_ok==0){
											// var that=this;
											// that.$nextTick(() => {
											// 	that.$axios
											// 	.post('http://www.zhishiren.info/api/huifu_list/',{act_id: that.act_id})
											// 	.then(response=>{
											// 		that.hflist=JSON.parse(response.data);
											// 		that.hfshu=JSON.parse(response.data).length;
											// 		that.shan_loading=false;
											// 	});
											// });
											that.$emit('hf_shan_ok');
											that.notok=false;
										}
									else{
											that.notok=true;
											setTimeout(function(){that.notok=false;}, 2000);
											that.shan_loading=false;
										}
								})
							}
						}
					});
		},

				
	},
};

</script>

<style scoped>
input::-webkit-input-placeholder, textarea::-webkit-input-placeholder {
  color: white;
  font-size: 16px;
}

input:-moz-placeholder, textarea:-moz-placeholder {
  color: white;
  font-size: 16px;
}

input::-moz-placeholder, textarea::-moz-placeholder {
  color: white;
  font-size: 16px;
}

input:-ms-input-placeholder, textarea:-ms-input-placeholder {
  color: white;
  font-size: 16px;
}



</style>

