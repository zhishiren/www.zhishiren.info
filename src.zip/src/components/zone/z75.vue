<template>
    <div id="z72">
				<el-row style="height:270px">
					<el-col :span="24">
						<img src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/aboutus51.jpg" class="bg_image" style="height:270px;width:100%;" alt="">
						<div class="huanhang font22px juzhong" style="color:white;">
							本网站特色功能的操作说明
						</div>
					</el-col>
				</el-row>
                
        <el-row>
			<el-col :span="24">
				<div class="huanhang font18px">
                   	本版块将介绍“密文评论”，“片段化阅读”，“关联知识展示”，“专题标签”等特色功能。
                </div>
			</el-col>
		</el-row>
		<br>
		<el-row>
			<el-col :span="10">
					<el-image
					    style="border:1px solid grey"
						src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/z75a.gif"
						:fit="fill">
					</el-image>
			</el-col>
			<el-col :span="14">
				<div class="huanhang">
					<b class="font20px">加密发送言论信息</b>
					<br>	
					所有言论可以选择“明发”和“密发”两种发布形式。
					<br>
					“明发”的内容需要管理员审核，不能有涉及契丹当代时政内容。
					<br>
					“密发”的内容<b>不需要</b>管理员审核，默认加密和解密密码均为八个1。你可以在“我的主页-发言密码‘处修改你的发言密码，然后通过一对一的通信方式分享你的解密密码。

					<br>
				</div>

			</el-col>
		</el-row>
		<br>
		<el-row>
			<el-col :span="14">
				<div class="huanhang">
					<b class="font20px">查看全站文章+片段化阅读</b>		
					<br>
					点击主页右侧“搜”的按键，可以看见全站文集汇总。
					<br>
					本站所有的文章均是以原文自然段落拆分为片段，用户可以对这些片段进行关注、分享、评论和关联知识等操作。
					<br>
					用户可以通过ID号关联两个相关的知识片段。
				</div>
			</el-col>
			<el-col :span="10">
					<el-image
						style="border:1px solid grey"
						src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/z75b.gif"
						:fit="fill">
					</el-image>
			</el-col>
		</el-row>
		<br>
		<el-row>
			<el-col :span="10">
					<el-image
					    style="border:1px solid grey"
						src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/z75c.jpg"
						:fit="fill">
					</el-image>
			</el-col>
			<el-col :span="14">
				<div class="huanhang">
					<b class="font20px">专题观点标签</b>	
					<br>
					本站建立了多个专题观点标签，例如“阅读难点求解”、“与某派对线专用资料包”，用户均可以添加相关知识片段到这些标签里，这样所有的用户都可以共享和协作。
		</div>

			</el-col>
		</el-row>

    </div>

</template>

<script>
    export default {
        name:'z72',
        props:['k'],//k是区分
        data() {return {

        }},
        computed:{

        },
        methods:{
            
            
        },
    };
</script>



