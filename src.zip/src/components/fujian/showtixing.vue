<template>
<div id="showtixing" style="display:inline-block;color:red;">
<span style="color:black" v-if="this.qz_id==80000000">无提醒</span>
<span v-if="this.qz_id>80000000 && this.qz_id<89999999">
    提醒<router-link class="a_black" target="_blank" :to="{name:'qunzuye',params:{id:this.qz_id}}">{{this.qz_id}}</router-link>看
</span>
<span v-if="this.qz_id==90000000">提醒所有人看</span>
</div>

</template>

<script>
  export default {
      name:'showtixing',
    props:['qz_id'],
    data() {
      return {
      }
    },

    methods:{


    }

  }
</script>