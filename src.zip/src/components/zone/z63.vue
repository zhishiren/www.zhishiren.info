<template>
    <div id="z63">
        <el-row style="color:red;" class="font20px">仅供展示相关理念,没有实物</el-row>
		<el-row>
			<el-col :span="10">
					<el-image
						src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/z63a.jpg"
						:fit="fill">
					</el-image>
			</el-col>
			<el-col :span="14">
				<div class="huanhang">
					<b class="font20px">单人宿舍、共享社区</b>	
				</div>
			</el-col>
		</el-row>
		<br>
		<el-row>
			<el-col :span="14">
				<div class="huanhang">
					<b class="font20px">青年旅社</b>		
					<br>
				</div>
			</el-col>
			<el-col :span="10">
					<el-image
						src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/z63b.jpg"
						:fit="fill">
					</el-image>
			</el-col>
		</el-row>
    </div>
</template>

<script>
    export default {
        name:'z63',
        props:[],
        data() {return {

        }},
        computed:{

        },
        methods:{
            
        },
    };
</script>



