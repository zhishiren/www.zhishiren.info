// 这个评论栏是用在每个知识点页面之下的评论功能，他有异议和匿名两个多选框
<template>
	<div id="tj_jiabiaoqian"  class="font18px">
				    <el-button @click="jiabiaoqianjian" type="text" style="padding-bottom:0px;" class="font18px">
                        <i class="el-icon-plus"></i>标签...
                    </el-button>
                    <span style="color:green;" v-show="ok_msg==1"><i class="el-icon-success"></i>添加成功!</span>
                    <span style="color:red;" v-show="ok_msg==3"><i class="el-icon-error"></i>操作失败!</span>
                    <span>
                        <span v-if="zhitype==='yonghuye'">此用户信息</span>
                        <span v-if="zhitype==='wenduanye'">此文段信息</span>
                        <span v-if="zhitype==='wenjiye'">此文辑信息</span>
                        <span v-if="zhitype==='qunzuye'">此群组信息</span>
                        <span v-if="zhitype==='fayanye'">此段言论</span>
                        <span v-if="zhitype==='biaoqianye'">此标签信息</span>
                        <span>已有了{{this.c1+this.c2}}条标签，其中{{this.c2}}条仅你本人可见。</span>      
                    </span>
                    <zhankai0 ref="zhankai0" @get_list="zhankaijian" @shuaxin="shuaxinjian"></zhankai0>
					<!-- <a @click="shuaxinjian" class="a_black"><i class="el-icon-refresh"></i>刷新</a> -->

		<el-dialog title="标签附言..." width="400px" :visible.sync="show_dialog">
            <el-row>
                <el-col :span="7" class="font18px" style="padding-top:10px;">
                    选择标签：
                </el-col>
                <el-col :span="17">
                    <el-select @focus="show_bqlist" v-model="bq_id" placeholder="在我创建或关注的标签中选择"  style="width:100%;">
                        <el-option
                            v-for="item in bqlists"
                            :key="item.bq_id"
                            :label="item.bq_title"
                            :value="item.bq_id+item.bq_title+item.bq_fanwei">
                        </el-option>
                    </el-select> 
                </el-col>
            </el-row>
            <br>
            <el-row>
                <div contenteditable ref="contents" @paste="onPaste" class="pinglunlan">请输入标签附言。</div>
            </el-row>
            <el-row>
                <el-col :span="7">
                    <a class="a_black font18px" href="javascript:;" @click="f_blod">
                        <b>所选加粗</b>
                    </a>
                </el-col>
                <el-col class="font18px" :span="11">
                    <span style="color:red;" v-show="ok_msg==5"><i class="el-icon-warning-outline"></i>重复添加标签!</span>
                    <span style="color:orange;" v-show="ok_msg==4"><i class="el-icon-warning-outline"></i>无标签供选择!</span>

                </el-col>
                <el-col :span="6" style="text-align:right">
                    <a @click="fabujian" class="font20px a_black" >发布</a>
                </el-col>
            </el-row>
        </el-dialog>

        <div v-show="show_xhjbq" >
                <el-row class="br10px17px" v-for="list in lists" :key="list.fields.act_createrid">
                            <el-row  :class="blinkyellow" v-if="list.pk==return_id">
                                <span>
                                    <span v-if="list.fields.act_createrid===user_id">你</span>
                                    <router-link v-if="list.fields.act_createrid!==user_id" target="_blank" class="a_black" :to="{name:'yonghuye',params:{id:list.fields.act_createrid}}" >
                                        <span>{{list.fields.act_creatername}}</span>
                                    </router-link>
                                    <span style="color:grey;">添加到标签</span>
                                    <router-link target="_blank" class="a_black" :to="{name:'biaoqianye',params:{id:list.fields.item0_id}}" >
                                        <span>{{list.fields.item0_title}}</span>
                                    </router-link>
                                </span>
                                <span style="color:grey">附言:<span v-html="list.fields.act_fuyan"></span>
                                </span>
                            </el-row>
                            <el-row v-if="list.pk!==return_id">
                                <span>
                                    <span v-if="list.fields.act_createrid===user_id">你</span>
                                    <router-link  v-if="list.fields.act_createrid!==user_id" target="_blank" class="a_black" :to="{name:'yonghuye',params:{id:list.fields.act_createrid}}" >
                                        <span>{{list.fields.act_creatername}}</span>
                                    </router-link>
                                    <span style="color:grey;">添加到标签</span>
                                    <router-link target="_blank" class="a_black" :to="{name:'biaoqianye',params:{id:list.fields.item0_id}}" >
                                        <span>{{list.fields.item0_title}}</span>
                                    </router-link>
                                </span>
                                <span style="color:grey">附言:<span v-html="list.fields.act_fuyan"></span>
                                </span>
                            </el-row>
                            <tj0huifu :shuaxinid="shuaxinyn" timek=0 news_yn=0 @shanchuok="shanok()" :act_id="list.pk" :create_time="list.fields.act_createtime" :it_att="list.fields.act_att" :creater_id="list.fields.act_createrid" :fanwei_id="list.fields.act_fanwei" :item1title="'你关联了:'+zhititle+'&&&'+list.fields.item1_title+'>>>附言:'+list.fields.act_fuyan"></tj0huifu>
                            <el-row><el-divider style="margin:0px;"></el-divider></el-row>
                </el-row>
                <!-- 下面的div是用来显示原始的未筛选的分页条 -->
                <el-pagination v-if="listNum>10" style="text-align:right;"
                                background
:page-size=10
                                :total="listNum"
                                :current-page.sync="currentPage"
                                layout="total, prev, pager, next">
                </el-pagination>
        </div>

	</div>
</template>

<script>
import tj0huifu from '../tijiao/tj_huifu';
import fanwei from '../fujian/fanwei';
import zhankai0 from '../fujian/zhankai0';

	export default {
		name: 'tj_jiabiaoqian',
        components: {tj0huifu,fanwei,zhankai0},
        props:['zhid','zhititle','zhitype'],
		data () {
			return {
                return_id:0,//这个return_id是用户操作成功之后
                show_dialog:false,   
                show_xhjbq:false,
                blinkyellow:'',
                xhjbqs:[],
                currentPage: 1,//当前分页的数值
                listNum:0,//分页总条数
                ok_msg:9,
                bqlists: [],
                bq_id:'',
                freshqzlist:true,
                c1:0,
                c2:0,
                fuyan:'',
                shuaxinyn:0

			}
        },
        
        computed: {
            lists(){
                let pages=Math.ceil(this.listNum/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                    let sonList=[];
                    sonList=this.xhjbqs.slice(i*10,i*10+10);//10为每页设置数量
                    newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
            user_id(){return parseInt(this.$cookies.get('userid'))},
        },

		methods: {
            f_blod() {document.execCommand ( 'bold', false );},
            
            onPaste: function(e) {
                    e.preventDefault()
                    e.stopPropagation()
                    let pasteValue = (e.clipboardData || window.clipboardData).getData('text/plain')
                    console.log(pasteValue)
                    var re = /<[^>]+>/gi;
                    pasteValue = pasteValue.replace(re, '').replace(/\s+|[\r\n]/g,"");
                    e.target.textContent += pasteValue
                },
            fabujian() {
                // 这里需要判断，
                var that = this;
                        if(that.$refs.contents.innerHTML==='请输入标签附言。'){that.fuyan='无'}
                        else{that.fuyan=that.$refs.contents.innerHTML}

                        if(that.bq_id===''){
                            that.ok_msg=4;
                            setTimeout(function(){that.ok_msg=0;}, 2000);
                        }
                        else{
                                that.axios
                                .post('http://www.zhishiren.info/api/oojiabiaoqian/',{
                                    userid: that.$cookies.get('userid'),
                                    username:that.$cookies.get('username'),
                                    jbq_content:that.fuyan,
                                    bq_id:that.bq_id,
                                    zhid:that.zhid,
                                    zhititle:that.zhititle,
                                    zhitype:that.zhitype,
                                    })
                                .then(function (response) {
                                    if (response.data.ok_id === 0){
                                        
                                        that.ok_msg=1;
                                        that.return_id = response.data.rrid;
                                        setTimeout(function(){that.ok_msg=0;}, 2000);
                                        that.$refs.contents.innerHTML='请输入标签附言。';
                                        that.show_dialog=false;
                                        that.show_xhjbq=true;
                                        that.$refs.zhankai0.addnew();
                                        that.$nextTick(() => {
                                            that.$axios
                                                .post('http://www.zhishiren.info/api/xunhuanjbq/',{zhid: that.zhid,userid: that.$cookies.get('userid')})
                                                .then(response=>{
                                                                that.xhjbqs=JSON.parse(response.data.l0);
                                                                that.c1=JSON.parse(response.data.l1).length;
                                                                that.c2=JSON.parse(response.data.l2).length;
                                                                that.listNum=that.xhjbqs.length;
                                                                that.show_xhjbq=true;
                                                                that.currentPage=1;
                                                                that.blinkyellow='blinkyellow';
                                                                setTimeout(function(){that.blinkyellow='';}, 2000);
                                                });
                                        });
                                    }
                                    if (response.data.ok_id === 1){
                                        that.ok_msg=5;
                                        setTimeout(function(){that.ok_msg=0;}, 2000);
                                        that.$refs.contents.innerHTML='请输入标签附言。';
                                    }
                                    if (response.data.ok_id === 2){
                                        that.ok_msg=3;
                                        setTimeout(function(){that.ok_msg=0;}, 2000);
                                        that.$refs.contents.innerHTML='请输入标签附言。';
                                    }
                                });
                        }
                
            },

			f_blod() {
                document.execCommand ( 'bold', false );
                document.execCommand ( 'backColor', false, 'yellow' );
			},

			jiabiaoqianjian(){
                this.show_dialog=true;

            },

            show_bqlist(){
                var that = this;
                that.axios
                .post('http://www.zhishiren.info/api/listmybiaoqian/', {userid: that.$cookies.get('userid')})
                .then(response=>{that.bqlists=response.data;})
            },

            zhankaijian(){
                this.show_xhjbq=true;
                this.$axios
                .post('http://www.zhishiren.info/api/xunhuanjbq/',{zhid: this.zhid,userid: this.$cookies.get('userid')})
                .then(response=>{
                    this.xhjbqs=JSON.parse(response.data.l0);
                    this.c1=JSON.parse(response.data.l1).length;
                    this.c2=JSON.parse(response.data.l2).length;
                    this.listNum=this.xhjbqs.length;});
                
            },

            shuaxinjian(){
                this.$nextTick(() => {
                this.shuaxinyn=1;
                this.$axios
                .post('http://www.zhishiren.info/api/xunhuanjbq/',{zhid: this.zhid,userid: this.$cookies.get('userid')})
                .then(response=>{
                    this.shuaxinyn=0;
                    this.xhjbqs=JSON.parse(response.data.l0);
                    this.c1=JSON.parse(response.data.l1).length;
                    this.c2=JSON.parse(response.data.l2).length;
                    this.listNum=this.xhjbqs.length;});
                });
            },
            shanok(){
                this.$nextTick(() => {
                this.$axios
                .post('http://www.zhishiren.info/api/xunhuanjbq/',{zhid: this.zhid,userid: this.$cookies.get('userid')})
                .then(response=>{
                    this.xhjbqs=JSON.parse(response.data.l0);
                    this.c1=JSON.parse(response.data.l1).length;
                    this.c2=JSON.parse(response.data.l2).length;
                    this.listNum=this.xhjbqs.length;});
                });

            }

        },

        watch: {
                zhid: function(newVal,oldVal){
                this.zhi_id = newVal;
                var that = this;
                that.axios
                .post('http://www.zhishiren.info/api/countbq/', {userid: that.$cookies.get('userid'),zhid:that.zhi_id})
                .then(response=>{that.c1=response.data.c1;
                                 that.c2=response.data.c2;});
                },
        },

	}
</script>

