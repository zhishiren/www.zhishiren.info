<template>
<div id="zhutiye" @click="turnfresh()">
		<div class="logo">知识人
			<span class="font18px" >welcome,<span v-if="this.welcomename">{{welcomename}},</span>{{getNowFormatDate(nowTime)}}</span>
			<span class="font19px_tuichu">
			<!-- <router-link to="/" class="a_noline"> -->
				<a v-if="this.welcomename" class="a_noline a_white" @click="tuichu">退出</a>
			<!-- </router-link> -->
			</span>
		</div>

		<el-container>
			<el-aside width="120px" class="bgcolor_FF"></el-aside>
			<el-menu :default-active="tab_active" class="el-menu-demo" mode="horizontal" @select="handleSelect" >
			<!-- <el-menu :default-active="tab_active" class="el-menu-demo" mode="horizontal" @select="handleSelect" > -->
					  <el-menu-item @click="daohang1" index="1" class="font20px" >今日动态</el-menu-item>
					  <el-menu-item @click="daohang2" index="2" class="font20px" >关注收藏</el-menu-item>
					  <el-menu-item @click="daohang3" index="3" class="font20px" >用户与群</el-menu-item>
					  <el-menu-item @click="daohang4" index="4" class="font20px" ref="active4">我的主页</el-menu-item>
					  <!-- <el-menu-item @click="daohang5" index="5" class="font20px" >知识地图</el-menu-item> -->
					  <el-menu-item @click="daohang6" index="6" class="font20px" >工团产品</el-menu-item>
					  <el-menu-item @click="daohang7" index="7" class="font20px" >关于本站</el-menu-item>
					</el-menu>
		</el-container>

		<el-container v-show="dh1">
			<el-aside width="120px">
				<el-menu default-active="11" class="el-menu-vertical-demo bgcolor_menu_FC height_x00px" @open="handleOpen" @close="handleClose">
			      <el-menu-item @click="daohang11" index="11" class="font18px">
			        <span slot="title">用户动态</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang12" index="12" class="font18px">
			        <span slot="title">内容动态</span>
			      </el-menu-item>
			      <!-- <el-menu-item @click="daohang13" index="13" class="font18px">
			        <span slot="title">变更信息</span>
			      </el-menu-item> -->
				  <el-menu-item @click="daohang14" index="14" class="font18px">
			        <span slot="title">用户互动</span>
			      </el-menu-item>	
			      <!-- <el-menu-item @click="daohang15" index="15" class="font18px">
			        <span slot="title">历史记录</span>
			      </el-menu-item>						       -->
			    </el-menu>
			</el-aside>
			<el-main v-show="dh11" class="section_xh">
				<xh11></xh11>
                                
			</el-main>
			<el-main v-show="dh12" class="section_xh">
				<xh12></xh12>
			</el-main>
			<!-- <el-main v-show="dh13" class="section_xh">
			</el-main> -->
			<el-main v-show="dh14" class="section_xh">
				<xh14></xh14>
			</el-main>
			<!-- <el-main v-show="dh15" class="section_xh">
				选择时间段；7天内；30天内；180内
			</el-main> -->

			<el-aside width="120px">
				
			</el-aside>
		</el-container>

		<el-container v-show="dh2">
			<el-aside width="120px">
				<el-menu default-active="21" class="el-menu-vertical-demo bgcolor_menu_FC height_x00px" @open="handleOpen" @close="handleClose">
			      <el-menu-item @click="daohang21" index="21" class="font18px">
			    	<span slot="title">标签</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang22" index="22" class="font18px">
			        <span slot="title">文辑</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang23" index="23" class="font18px">
			        <span slot="title">段落</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang24" index="24" class="font18px">
			        <span slot="title">言论</span>
			      </el-menu-item>	
			      <!-- <el-menu-item @click="daohang25" index="25" class="font18px">
			        <span slot="title">数集</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang26" index="26" class="font18px">
			        <span slot="title">数据</span>
			      </el-menu-item> -->
			      <el-menu-item @click="daohang27" index="27" class="font18px">
			        <span slot="title">用户</span>
			      </el-menu-item>
					      
			    </el-menu>
			</el-aside>
			<el-main v-show="dh21" class="section_xh">
				<xh21></xh21>
			</el-main>
			<el-main v-show="dh22" class="section_xh">
             	<xh22></xh22>
			</el-main>
			<el-main v-show="dh23" class="section_xh">
             	<xh23></xh23>
			</el-main>
			<el-main v-show="dh24" class="section_xh">
             	<xh24></xh24>
			</el-main>
			<el-main v-show="dh25" class="section_xh">
             25
			</el-main>
			<el-main v-show="dh26" class="section_xh">
             26
			</el-main>
			<el-main v-show="dh27" class="section_xh">
            	<xh27></xh27>
			</el-main>
			<el-aside width="120px">

			</el-aside>
		</el-container>


		<el-container v-show="dh3">
			<el-aside width="120px">
				<el-menu default-active="31" class="el-menu-vertical-demo bgcolor_menu_FC height_x00px" @open="handleOpen" @close="handleClose">

			      <el-menu-item @click="daohang31" index="31" class="font18px">
			        <span slot="title">所有用户</span>
			      </el-menu-item>
				  <el-menu-item @click="daohang36" index="36" class="font18px">
			        <span slot="title">名人名片</span>
			      </el-menu-item>
				  <el-menu-item @click="daohang37" index="37" class="font18px">
			        <span slot="title">工团组织</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang32" index="32" class="font18px">
			        <span slot="title">我关注的</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang33" index="33" class="font18px">
			        <span slot="title">关注我的</span>
			      </el-menu-item>	
				  <el-menu-item @click="daohang34" index="34" class="font18px">
			        <span slot="title">所有群组</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang35" index="35" class="font18px">
			        <span slot="title">我的群组</span>
			      </el-menu-item>


			    </el-menu>
			</el-aside>
			<el-main v-show="dh31" class="section_xh">
             <xh31></xh31>
			</el-main>
			<el-main v-show="dh32" class="section_xh">
            <xh32></xh32>
			</el-main>
			<el-main v-show="dh33" class="section_xh">
             <xh33></xh33>
			</el-main>
			<el-main v-show="dh34" class="section_xh">
             <xh34></xh34>
			</el-main>
			<el-main v-show="dh35" class="section_xh">
             <xh35></xh35>
			</el-main>
			<el-main v-show="dh36" class="section_xh">
             <xh36></xh36>
			</el-main>
			<el-main v-show="dh37" class="section_xh">
             <xh37></xh37>
			</el-main>
			<el-aside width="120px">

			</el-aside>
		</el-container>


		<el-container v-show="dh4">
			<el-aside width="120px">
				<el-menu default-active="41" class="el-menu-vertical-demo bgcolor_menu_FC height_x00px" @open="handleOpen" @close="handleClose">
			      <el-menu-item @click="daohang41" index="41" class="font18px">
			    	<span slot="title">我的信息</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang42" index="42" class="font18px">
			        <span slot="title">公告动态</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang43" index="43" class="font18px">
			        <span slot="title">对我印象</span>
			      </el-menu-item>
			      <!-- <el-menu-item @click="daohang44" index="44" class="font18px">
			        <span slot="title">与我相关</span>
			      </el-menu-item>	 -->
			      <!-- <el-menu-item @click="daohang45" index="45" class="font18px">
			        <span slot="title">我的相册</span>
			      </el-menu-item>	 -->

			    </el-menu>
			</el-aside>
			<el-main v-show="dh41" class="section_xh">
				<el-row  style="height:270px;">
					<el-card class="box-card">
						<el-col v-if="userinfo.yonghu_touxiang===1" :span="5" style="text-align:center;background-size:100% 100%;height:260px;">
								<div v-if="show_touxiang1===false" style="padding-top:100px;" class="a_grey font18px">
									<a @click="showtouxiang1()">
										<i class="el-icon-s-custom" style="font-size:30px;"></i>
										<br>
										查看头像
									</a>
								</div>
								<img v-if="show_touxiang1===true" alt="" :src="timestamp('https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/touxiang/'+this.userid+'.jpg')" style="width:100%;height:250px;">
								<!-- <div style="position:absolute;z-index:0;left:10px;top:10px;">lll</div> -->
						</el-col>

						<!-- <el-col v-if="userinfo.yonghu_touxiang===0" :span="5" style="background-repeat:no-repeat;background-size:100% 100%;height:250px;background-image:url(https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/touxiang/90000000.jpg);">
						</el-col> -->
						<el-col v-if="userinfo.yonghu_touxiang===0" :span="5" style="background-size:100% 100%;height:250px;text-align:center;padding-top:100px;">
							<i class="el-icon-user" style="font-size:30px;"></i>
							<br>
							尚无头像
						</el-col>
						<el-col :span="19">
							<!-- 这里要在mongodb里面设计一个集合，用于记录各种数据信息，如用户这个信息，应该有用户最近登陆时间，用户被关注，留言的数据。在每次退出登陆之后，括号里的数据被清零 -->
							<div v-if="!userinfo.yonghu_id" class="font18px_gray" style="height:250px;padding-left:10px;">
								<br>
								<br>
								<br>
								<div style="text-align:center;font-size:50px;color:grey;"><i class="el-icon-loading"></i>正在加载...</div>
							</div>
							<div v-if="userinfo.yonghu_type==='普通用户' || userinfo.yonghu_type==='内容整理'" class="font18px_gray section_userinfo">
								用户名称：<span class="font18px_black">{{this.userinfo.yonghu_name}}</span><br>
								<!-- 用户类型：<span class="font18px_black">{{this.userinfo.yonghu_type}}</span><a class="el-icon-thumb a_grey">升级</a><br> -->
								用户类型：<span class="font18px_black">{{this.userinfo.yonghu_type}}</span><br>
								用户ID号：<span class="font18px_black">{{this.userinfo.yonghu_id}}</span><br>
								注册时间：<span class="font18px_black">{{getNowFormatDate(this.userinfo.yonghu_borntime)}}</span><br>
								<!-- 上次登录：<span class="font18px_black">{{getNowFormatDate(this.userinfo.yonghu_updatetime)}}</span><br> -->
								行业岗位：<bianji0userinfo @freshinfo="freshinfo" :inputzhi0="userinfo.yonghu_job" :id="userid" length=20 type="1" inputzhi1="请输入你所属的行业岗位，如金融-银行-内审" ></bianji0userinfo>
								<br>
								国家地区：<bianji0userinfo @freshinfo="freshinfo" :inputzhi0="userinfo.yonghu_area" :id="userid" length=15 type="2" inputzhi1="请输入你所属的地区，如江苏-南京" ></bianji0userinfo>
								<br>
								联系方式：<bianji0userinfo @freshinfo="freshinfo" :inputzhi0="userinfo.yonghu_contact" :id="userid" length=17 type="3" inputzhi1="请输入你的联系方式，如邮箱或微信号" ></bianji0userinfo>
								<br>
								爱好特长：<bianji0userinfo @freshinfo="freshinfo" :inputzhi0="userinfo.yonghu_hobby" :id="userid" length=9 type="4" inputzhi1="请输入你的兴趣爱好" ></bianji0userinfo>
								<br>
								个人签名：<bianji0userinfo @freshinfo="freshinfo" :inputzhi0="userinfo.yonghu_remark" :id="userid" length=14 type="5" inputzhi1="请输入你的个人签名，限20个字" ></bianji0userinfo>
								<br>
								数据统计：<span class="font18px" style="color:green">
									<span>来访主页{{this.userjishu.dianji}}<el-divider direction="vertical"></el-divider></span>
									<span>关注我{{this.userjishu.guanzhu}}<el-divider direction="vertical"></el-divider></span>
									<span>分享我{{this.userjishu.fenxiang}}</span>
								</span>						
							</div>

							<div v-if="userinfo.yonghu_type==='历史人物'"  class="font18px_gray section_userinfo">
								名称类型：<span class="font18px_black">{{this.userinfo.yonghu_name}}<el-divider direction="vertical"></el-divider>{{this.userinfo.yonghu_type}}</span><br>
								用户ID号：<span class="font18px_black">{{this.userinfo.yonghu_id}}</span><br>
								生卒年月：<span class="font18px_black">{{this.userinfo.yonghu_born}}<el-divider direction="vertical"></el-divider>{{this.userinfo.yonghu_dead}}</span><br>
								职业身份：<bianji0userinfo @freshinfo="freshinfo" :inputzhi0="userinfo.yonghu_job" :id="userid" length=20 type="1" inputzhi1="请输入你所属的行业岗位，如金融-银行-内审" ></bianji0userinfo>
								<br>
								国家地区：<bianji0userinfo @freshinfo="freshinfo" :inputzhi0="userinfo.yonghu_area" :id="userid" length=15 type="2" inputzhi1="请输入你所属的地区，如江苏-南京" ></bianji0userinfo>
								<br>
								人物名言：<bianji0userinfo @freshinfo="freshinfo" :inputzhi0="userinfo.yonghu_remark" :id="userid" length=14 type="5" inputzhi1="请输入你的个人签名，限20个字" ></bianji0userinfo>
								<br>
								数据统计：<span class="font18px" style="color:green">
									<span>来访主页{{this.userjishu.dianji}}<el-divider direction="vertical"></el-divider></span>
									<span>关注我{{this.userjishu.guanzhu}}<el-divider direction="vertical"></el-divider></span>
									<span>分享我{{this.userjishu.fenxiang}}</span>
								</span>	
								<br>
								生平事迹：<bianji0userinfo @freshinfo="freshinfo" :inputzhi0="userinfo.yonghu_life" :id="userid" length=15 type="6" inputzhi1="请输入生平事迹，限120字" ></bianji0userinfo>		
							</div>

							<div v-else-if="userinfo.yonghu_type==='当代人物'" class="font18px_gray" style="height:250px;padding-left:10px;">
								&nbsp;人物名称：<span class="font18px_black">{{this.userinfo.yonghu_name}}<el-divider direction="vertical"></el-divider><span>{{this.userinfo.yonghu_type}}</span>
											</span><br>
								&nbsp;用户ID号：<span class="font18px_black">{{this.userinfo.yonghu_id}}</span><span style="color:grey">
											</span><br>
								&nbsp;生日地区：<span class="font18px_black">{{this.userinfo.yonghu_born}}<span style="color:grey">-</span>{{this.userinfo.yonghu_area}}</span><br>
								<!-- &nbsp;生卒年月：<span class="font18px_black">{{this.userinfo.yonghu_born}}<el-divider direction="vertical"></el-divider>{{this.userinfo.yonghu_dead}}</span><br> -->
								&nbsp;联系方式：<span class="font18px_black">{{this.userinfo.yonghu_contact}}</span><br>
								&nbsp;人物名言：<span class="font18px" style="color:brown;">{{this.userinfo.yonghu_remark}}</span><br>
								&nbsp;数据统计：<span class="font18px" style="color:green">
													<span>访问他{{this.userjishu.dianji}}<el-divider direction="vertical"></el-divider></span>
													<span>关注他{{this.userjishu.guanzhu}}<el-divider direction="vertical"></el-divider></span>
													<span>分享他{{this.userjishu.fenxiang}}</span>
											</span>
								<br>
								生平事迹：<span>{{this.userinfo.yonghu_life}}职业生涯+目前状态</span>
							</div>
							<div v-else-if="userinfo.yonghu_type==='安人组织'" class="font18px_gray" style="height:250px;padding-left:10px;">
								&nbsp;组织名称：<span class="font18px_black">{{this.userinfo.yonghu_name}}<el-divider direction="vertical"></el-divider><span>{{this.userinfo.yonghu_type}}</span>
											</span><br>
								&nbsp;用户ID号：<span class="font18px_black">{{this.userinfo.yonghu_id}}</span><span style="color:grey">
											</span><br>
								&nbsp;地区行业：<span class="font18px_black">{{this.userinfo.yonghu_area}}</span><br>
								&nbsp;联系方式：<span class="font18px" style="color:brown;">{{this.userinfo.yonghu_contact}}</span><br>
								&nbsp;数据统计：<span class="font18px" style="color:green">
													<span>访问它{{this.userjishu.dianji}}<el-divider direction="vertical"></el-divider></span>
													<span>关注它{{this.userjishu.guanzhu}}<el-divider direction="vertical"></el-divider></span>
													<span>分享它{{this.userjishu.fenxiang}}</span>
											</span>
								<br>
								组织介绍：<span>{{this.userinfo.yonghu_life}}</span>
							</div>

						</el-col>
					</el-card>
				</el-row>
				<br>
				<el-row>
						    <el-upload
								name="touxiang"
								class="upload-demo"
								action="http://www.zhishiren.info/api/shangchuan1/"
								Access-Control-Request-Headers: ContentType
								:data={user_id:this.userid}
								:on-preview="handlePreview"
								:on-remove="handleRemove"
								:on-success="shuaxintouxiang"
								:before-remove="beforeRemove"
								:on-change="onchange"
								:limit="1"
								:file-list="fileList"
								>
								<el-button v-if="ceshi_id===0" class="font18px" type="text">
									更改头像...
								</el-button>
								<el-button v-if="ceshi_id===1" disabled class="font18px" type="text">
									更改头像...
								</el-button>
								<span v-if="ceshi_id===1">
									<i class="el-icon-loading"></i>正在上传，请等待...
								</span>
								<span v-show="ceshi_id===0 && chuantouxiang_okmsg===9" class="font18px">
									仅限jpg/jpeg格式
								</span>
								<span v-show="chuantouxiang_okmsg===0" class="font18px" style="color:red">
									上传失败
								</span>
							</el-upload>
				</el-row>

				<el-row>
					<el-button type="text" class="font18px" disabled>个性设置...</el-button>
					<span class="font18px">
						选择你的历史动态公开的时间段。</span>
				</el-row>
				<!-- <el-row  class="font18px">
					<el-button type="text" style="padding-bottom:0px;" class="font18px">
                    	我要发言...
					</el-button>
                    我共有1条发言。-展开- 
				</el-row> -->
				<!-- <el-row>
					<el-button type="text" class="font18px" disabled >升级用户...</el-button>
					<span class="font18px">
						你可以依次升级为实名用户和高级用户。</span>
				</el-row> -->
				<el-row>
					<el-button @click="denglumima()" type="text" class="font18px">登陆密码...</el-button>
					<span v-if="dlmmok!==true" class="font18px">
						此为你登陆网站的密码。</span>
					<span v-if="dlmmok===true" style="color:red;font-size:18px;">修改成功！</span>
					<el-dialog title="修改你的登陆密码..." width="400px" :visible.sync="show_denglumima_dialog">
						<el-row>
							<el-col :span="7" class="font18px" style="padding-top:10px;">
								修改密码：
							</el-col>
							<el-col :span="17">
								<el-input v-model="denglumima0" placeholder="请输入你的登陆密码" style="width:90%;">
								</el-input>
							</el-col>
						</el-row>
						<br>
						<el-row>
							<el-col :span="7" class="font18px" style="padding-top:10px;">
								再次确认：
							</el-col>
							<el-col :span="17">
								<el-input v-model="denglumima1" placeholder="请再次确认..." style="width:90%;">
								</el-input>
							</el-col>
						</el-row>
						<br>
						<el-row style="text-align:center;">
							<span style="color:red;font-size:18px;">{{this.dlmm_kong}}</span>
							<span style="color:red;font-size:18px;">{{this.errormsg_dlmm}}</span>
						</el-row>
						<el-row style="text-align:center;">
							<a @click="commit_denglumima()" class="font20px a_black">确定</a>
						</el-row>
					</el-dialog>

				</el-row>

				<el-row>
					<el-button @click="fayanmima()" type="text" class="font18px">发言密码...</el-button>
					<span class="font18px">
						<span>
							此为你发布密文的密码。</span>
						<span class="a_black" v-show="show_zhankai_fayanmima" @click="zhankai_fayanmima()">-展开-</span>
						<span class="a_black" v-show="show_shuaxin_fayanmima" @click="shuaxin_fayanmima()"><i class="el-icon-refresh"></i>刷新</span>
						<span style="color:red" v-show="show_fayanmima_kong===true">
							:你尚未设置发言密码...</span>
					</span>
					<br>
					<!-- <div v-show="show_fayanmima_list"  class="font18px" style="color:grey;"> -->
					<div v-show="show_fayanmima_list && show_loading_fayanmima===false" v-for="(l_fymm,index) in fayanmima_list" :key="l_fymm.fields.mi_hint" class="font18px" style="color:grey;">
						设置时间:{{l_fymm.fields.mi_createtime}}<el-divider direction="vertical"></el-divider>
						提示信息: <span style="color:brown;">{{l_fymm.fields.mi_hint}}</span><el-divider direction="vertical"></el-divider>
						<span style="color:red;" v-if="index===0">正在使用</span>
						<el-row><el-divider style="margin:0px;"></el-divider></el-row>
					</div>
					<br>
					<el-pagination v-if="countfymm>10" style="text-align:right;"
										background
										:page-size=10
										:total="countfymm"
										:current-page.sync="currentPage"
										layout="total, prev, pager, next">
						</el-pagination>
					<el-dialog title="设置你的发言密码..." width="400px" :visible.sync="show_fayanmima_dialog">
						<el-row>
							<el-col :span="7" class="font18px" style="padding-top:10px;">
								提示信息：
							</el-col>
							<el-col :span="17">
								<el-input v-model="fayanmima_tips" placeholder="请留下密码提示信息，限10字" style="width:90%;">
								</el-input>
							</el-col>
						</el-row>
						<br>
						<el-row>
							<el-col :span="7" class="font18px" style="padding-top:10px;">
								发言密码：
							</el-col>
							<el-col :span="17">
								<el-input v-model="fayanmima_code" placeholder="请输入发言密码，限8位数字" style="width:90%;">
								</el-input>
							</el-col>
						</el-row>
						<br>
						<el-row style="text-align:center;">
							<a @click="commit_fayanmima()" class="font20px a_black">确定</a>
							<span style="color:red;font-size:18px;">{{this.fymm_kong}}</span>
							<span style="color:red;font-size:18px;">{{this.errormsg_fymm}}</span>
						</el-row>
					</el-dialog>
					<div v-if="show_loading_fayanmima===true">
                    	<div style="font-size:30px;color:grey;"><i class="el-icon-loading"></i>正在加载...</div>
                	</div>
				</el-row>


			</el-main>
			<el-main v-show="dh42" class="section_xh">
					<el-row style="text-align:center;color:white;background-repeat:no-repeat;background-size:100% 100%;height:280px;background-image:url(https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/bg_gonggao0.jpg);">
					<el-row>
						<el-rol :span="8"></el-rol>
						<el-rol :span="8" style="font-size:30px;">我的公告栏</el-rol>
						<el-rol :span="8"></el-rol>
					</el-row>
					<div style="height:170px;font-size:20px;text-align:center;">
						<div v-if="show_editgonggaolan===false" style="width:500px;text-align:center;margin:0 auto;">
							<div v-if="mygonggao.gg_mizi===0">{{this.mygonggao.gg}}</div>
							<div v-if="mygonggao.gg_mizi!==0">
								<span>一段{{this.mygonggao.gg_mizi}}个字的密文</span>
								<input v-if="mygonggao.gg!==''" style="width:1px;border-color:green;border:0px;background-color:green;" type="text" v-model="mygonggao.gg.slice(2,-1)" id="gonggao">                                   
								<a class="a_brown" @click="kcopy_gg()"><i class="el-icon-document-copy"></i>点击复制密文</a>
                            </div>
						</div>
						<textarea placeholder="请输入你想发布的公告内容，限100字。" v-if="show_editgonggaolan" v-model="gonggaoneirong" cols="30" rows="7"  style="width:500px;text-align:center;margin:0 auto;font-size:19px;opacity: 0.5;"></textarea>
					</div>
					<el-row v-if="show_editgonggaolan===false">
						<el-rol :span="8">
						</el-rol>
						<el-rol :span="8" style="font-size:20px;text-align:center;">
							<i @click="edit_gonggao()" class="el-icon-edit-outline a_white">撰写公告</i>
						</el-rol>
						<el-rol :span="8">
						</el-rol>
					</el-row>
					<el-row v-if="show_editgonggaolan && edit_gonggao_loading===false">
						<span v-if="gonggao_msg==='' && edit_gonggao_loading!==true" >
							<i @click="quxiao_gonggao()" class="el-icon-close a_white"  style="font-size:20px;">取消</i>
							<span style="font-size:18px;color:yellow;"><el-divider direction="vertical"></el-divider></span>
							<i @click="commit_gonggao()" class="el-icon-chat-square a_white"  style="font-size:20px;">明发</i>
							<span style="font-size:18px;color:yellow;"><el-divider direction="vertical"></el-divider></span>
							<i @click="commit_gonggao_mi()" class="el-icon-chat-line-square a_white"  style="font-size:20px;">密发</i>
						</span>	
							<span v-if="gonggao_msg!==''" style="font-size:18px;color:yellow;"><i class="el-icon-info"></i>{{this.gonggao_msg}}</span>
							<span v-if="edit_gonggao_loading" style="font-size:18px;color:yellow;"><i class="el-icon-loading"></i>正在发布...</span>

					</el-row>
					<el-row v-if="show_editgonggaolan && edit_gonggao_loading" style="font-size:18px;">
						<i class="el-icon-loading"></i>正在发布...
					</el-row>
					
				</el-row>
			<xh42></xh42>
			</el-main>
			<el-main v-show="dh43" class="section_xh">
				<!-- 这里要有个词云。 -->
            <xh43></xh43>
			</el-main>
			<el-main v-show="dh44" class="section_xh">
            共有1条与我相关的关联知识。-展开-
			</el-main>
			<el-main v-show="dh45" class="section_xh">
            我共上传了5幅照片。-展开-
			</el-main>
			<el-aside width="120px">
				
			</el-aside>
		</el-container>

		<el-container v-show="dh5">
			<el-aside width="120px">
				<el-menu default-active="51" class="el-menu-vertical-demo bgcolor_menu_FC height_x00px" @open="handleOpen" @close="handleClose">
			      <el-menu-item @click="daohang51" index="51" class="font18px">
			    	<span slot="title">学科分类</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang52" index="52" class="font18px">
			        <span slot="title">地区分类</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang53" index="53" class="font18px">
			        <span slot="title">时间分类</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang54" index="54" class="font18px">
			        <span slot="title">预测趋势</span>
			      </el-menu-item>		
			    </el-menu>
			</el-aside>
			<el-main v-show="dh51" class="section_xh">
             1
			</el-main>
			<el-main v-show="dh52" class="section_xh">
             2
			</el-main>
			<el-main v-show="dh53" class="section_xh">
             3
			</el-main>
			<el-main v-show="dh54" class="section_xh">
             4
			</el-main>
			<el-aside width="120px">
				
			</el-aside>
		</el-container>

		<el-container v-show="dh6">
			<el-aside width="120px">
				<el-menu default-active="61" class="el-menu-vertical-demo bgcolor_menu_FC height_x00px" style="text-align:center;" @open="handleOpen" @close="handleClose">
			      <el-menu-item @click="daohang61" index="61" class="font18px">
			    	<span slot="title">衣</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang62" index="62" class="font18px">
			        <span slot="title">食</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang63" index="63" class="font18px">
			        <span slot="title">住</span>
			      </el-menu-item>

			      <el-menu-item @click="daohang64" index="64" class="font18px">
			        <span slot="title">书</span>
			      </el-menu-item>	
				<el-menu-item @click="daohang65" index="65" class="font18px">
			        <span slot="title">医/药</span>
			      </el-menu-item>	
				 <el-menu-item @click="daohang66" index="66" class="font18px">
			        <span slot="title">互助金融</span>
			      </el-menu-item>	
				 <el-menu-item @click="daohang67" index="67" class="font18px">
			        <span slot="title">自由软件</span>
			      </el-menu-item>	

			    </el-menu>
			</el-aside>
			<el-main v-show="dh61" class="section_xh">
			</el-main>
			<el-main v-show="dh62" class="section_xh">
			</el-main>
			<el-main v-show="dh63" class="section_xh">
             3
			</el-main>
			<el-main v-show="dh64" class="section_xh">
             4
			</el-main>
			<el-main v-show="dh65" class="section_xh">
             5
			</el-main>
			<el-main v-show="dh66" class="section_xh">
             5
			</el-main>
			<el-main v-show="dh67" class="section_xh">
             5
			</el-main>
			<el-aside width="120px">
				
			</el-aside>
		</el-container>

		<el-container v-show="dh7">
			<el-aside width="120px">
				<el-menu default-active="71" class="el-menu-vertical-demo bgcolor_menu_FC height_x00px" @open="handleOpen" @close="handleClose">
			      <el-menu-item @click="daohang71" index="71" class="font18px">
			    	<span slot="title">知识共享</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang72" index="72" class="font18px">
			        <span slot="title">宗旨精神</span>
			      </el-menu-item>
				  <el-menu-item @click="daohang74" index="74" class="font18px">
			        <span slot="title">劳动实践</span>
			      </el-menu-item>	
			      <el-menu-item @click="daohang73" index="73" class="font18px">
			        <span slot="title">加入我们</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang75" index="75" class="font18px">
			        <span slot="title">公益互助</span>
			      </el-menu-item>	

			    </el-menu>
			</el-aside>
			<el-main v-show="dh71" class="section_xh">


				<el-row style="height:270px">
					<el-col :span="24">
						<img src="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/aboutus11.jpg" class="bg_image" style="height:270px;" alt="">
						<div class="huanhang font22px juzhong">
							一种全新的知识库设计
							<br>片段化阅读+隐性知识挖掘+内容精准推荐
						</div>
					</el-col>
				</el-row>
				<el-row>
					<el-col :span="24">
						<div class="huanhang">
							这是一个信息过载的时代。我们都将挣扎在知识和信息的混沌之海中，我们拼命翻腾，才不会被浪涛淹没头顶。<b>长篇和空洞的报告文体，已经成为新一代“祭司”和“贵族”装神弄鬼的马戏。劳动者是没时间看长篇大论的。劳动者需要一种快捷高效的分享劳动经验的工具。</b>各类知识太多，哪些是最重要的？常用的？与我劳动岗位最相关的？这些问题日夜困扰着我，而一种灵感渐渐在我眼前明晰，那就是设计一种知识库，以段落(知识片段)的形式呈现文章内容、关注收藏、分享评论，展示关联知识、用户行为数据、历史变迁版本，智能推荐。这种想法基于以下三个假设前提：片段化阅读、隐性知识挖掘、内容精准推荐。						
						</div>
					</el-col>
				</el-row>

				<br>
				
				<el-row>
					<el-col :span="10">
							<el-image
								src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/aboutus_8.jpg"
								:fit="fill">
							</el-image>
					</el-col>
					<el-col :span="14">
						<div class="huanhang">
							<b class="font20px">这是一个繁巨的基础工程，一场深刻的社会实验<br></b>	
					<b>劳动经验，是劳动者的宝贵财富。</b>截止目前，全世界范围存在的数以千万计的行业标准、学术论文、优秀案例、经验分享，指标数据，这些都是大众常用的公共信息。整理这些信息，是一个繁巨的公共信息基础工程，也是建设一个“人民互助”世界的社会实验，公众参与如同核裂变一样的链式反应，它产生的能量和成果让全民共治共有共享，从而打破垄断资本、官僚集团的知识霸权和话语霸权，协助人民自我组织和自我管理，提高社会管理效率，减少社会运行成本。					</div>
					</el-col>
				</el-row>
				<br>


				<el-row>

					<el-col :span="14">
						<div class="huanhang">
							<b class="font20px">片段化阅读：当我们在阅读公文时，我们真正在读什么？</b>		
							<br>
							现代心理学认为，<b>人类注意力的最佳范围是150字之内</b>，所以在写作时人脑潜意识里就会把一个小主题凝结成一个相对独立的、150字左右的段落。尤其是对于法律法规类的公文，我们寻找的、关注的、记住的是某些段落，而不是整篇文章。只有把精度细化到文章中的那些段落之上，用户的收藏、评论等动作才有意义，才是真正对知识进行管理。
						</div>
					</el-col>
					<el-col :span="10">
							<el-image
								src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/aboutus_1.jpg"
								:fit="fill">
							</el-image>
					</el-col>
				</el-row>
				<br>

				<el-row>
					<el-col :span="10">
							<el-image
								src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/aboutus_2.jpg"
								:fit="fill">
							</el-image>
					</el-col>
					<el-col :span="14">
						<div class="huanhang">
							<b class="font20px">隐形知识：水面下的冰山<br></b>	
							显性知识是知识片段的表面文字信息。隐形知识是知识片段背后的用户行为：点击量和关注量、评论和解释、支持或反对的意见、用户归类标签，知识片段之间关系（相互矛盾还是互为补充），语句中的强调关键词。这些隐形知识都是组织内员工多次试错后慢慢积累的，极具价值但很难被记录、传播和继承。在本网站中，知识片段的各种隐形知识均被挖掘和展示。
						</div>
					</el-col>

				</el-row>
				<br>

				<el-row>

					<el-col :span="14">
						<div class="huanhang">	
							<b class="font20px">内容精准推荐：将信息推送给合适的用户<br></b>	
							推荐系统是信息过载时代下信息过滤的重要手段，基于内容文本相似度和用户画像相似度的推荐系统，将相应的“知识片段”推送给合适的用户。内容文本相似度：根据用户的关注列表，分析其中的高频关键词和语法结构，查找库内相似度高的“知识片段”推荐给用户。用户画像相似度：分析用户的岗位、地域、爱好、历史行为等用户画像，查找库内相似度高的用户群类，将该用户群类的交集信息推送给用户。
						</div>
					</el-col>
					<el-col :span="10">
							<el-image
								src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/aboutus_3.jpg"
								:fit="fill">
							</el-image>
					</el-col>
				</el-row>
				<br>

				<el-row>
					<el-col :span="10">
							<el-image
								src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/aboutus_4.jpg"
								:fit="fill">
							</el-image>
					</el-col>
					<el-col :span="14">
						<div class="huanhang">
							<b class="font20px">烂笔头的时代已经过去，我们需要更快捷的知识归纳方式<br></b>	
							手写摘抄到纸面之上，这种“烂笔头”方式已经完全不适合现今信息流，我们需要更快捷的知识归纳方式。在本网站中，用户只需轻点按钮，就可以把知识片段收入到自己的关注列表中，为相关的知识片段建立归纳标签。
						</div>
					</el-col>

				</el-row>
				<br>

				<el-row>

					<el-col :span="14">
						<div class="huanhang">	
							<b class="font20px">利用六度空间理论，提高组织内信息传播效率<br></b>	
							传统的科层金字塔体制的信息是自上而下单链分发，这种模式相对封闭、路径长、速度慢、容易产生中断、阻塞和死角。六度空间是指信息通过多层熟人关系就能到达任何用户。利用此理论设计的信息发布平台，每个用户都是一个转发源，更高效传播给相近岗位用户。
						</div>
					</el-col>
					<el-col :span="10">
							<el-image
								src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/aboutus_5.jpg"
								:fit="fill">
							</el-image>
					</el-col>
				</el-row>
				<br>

				<el-row>
					<el-col :span="10">
							<el-image
								src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/aboutus_6.jpg"
								:fit="fill">
							</el-image>
					</el-col>
					<el-col :span="14">
						<div class="huanhang">
							<b class="font20px">构建每个岗位角色的知识图谱，加强组织内的知识传承<br></b>	
					每个用户都代表着组织内的某一个岗位角色，用户日常关注和评论等历史行为，都是某个岗位角色的知识图谱，这是组织内的极为重要但常被忽视的隐形知识。在传统的组织内岗位的管理水平严重依赖个人的历史经验和认知水平，人员流动就会造成一段时期的业务混乱。本知识库可以记录用户的历史行为，形成对岗位角色的知识图谱，可以有效加强组织内各个岗位角色的知识传承。
						</div>
					</el-col>

				</el-row>
				<br>


				<el-row>
					<el-col :span="14">
						<div class="huanhang">	
							<b class="font20px">劳动经验的共享，促成劳动者的全面发展<br></b>	
							传统组织过度依靠人工重复劳动，将整体工作划分部门和岗位各司其职，只能依靠增加部门和人力来应对业务变化，造成了组织内人力架构的僵化和膨胀，也造成人的单向度化。在组织内利用这种知识库系统，员工更高效的适应多个岗位的知识，促成人的全面发展。
						</div>
					</el-col>
					<el-col :span="10">
							<el-image
								src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/aboutus_7.jpg"
								:fit="fill">
							</el-image>
					</el-col>

				</el-row>
				<br>


			</el-main>
			<el-main v-show="dh72" class="section_xh">
				<el-row style="height:270px">
					<el-col :span="24">
						<img src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/aboutus21.jpg" class="bg_image" style="height:270px;" alt="">
						<div class="huanhang font22px">
							如果代码是音符，那我就是那首《国际歌》
							阳光之下，我们联合。
							劳动者要有自己的文化的，解放
						</div>
					</el-col>
				</el-row>
				ce
			</el-main>
			<el-main v-show="dh73" class="section_xh">
				<el-row style="height:270px">
					<el-col :span="24">
						<img src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/aboutus31.jpg" class="bg_image" style="height:270px;" alt="">
						<div class="huanhang font22px juzhong">
							<!-- 站长一个人太难了，期待您的各种参与... -->
							期待您的参与...
						</div>
					</el-col>
				</el-row>
             		<!-- 不分主客，皆为同志！践行自由和互助的理念，摒弃中心化领导的旧思维。 源代码公开，遵守gnu协议，任意使用.宣传到微信朋友圈，内容编辑，写代码，联系我们微信号，关注微信公众号，贴吧，知乎，今日头条，github.捐助(资金将全部用于购买服务器资源) -->
					让我们践行自由和互助的理念，贡献您特有的专业能力，共建一个“共有共享共治”的知识库平台，联系我们：
					<!-- 让我们践行自由和互助的理念，贡献您特有的专业能力，共建一个“共有共享共治”的知识库平台，我们需要以下志愿者： -->
					介绍各种共建企业，和产品。

				<!-- <el-row>
					<el-col :span="10">
							<el-image
								src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/aboutus73_a.jpg"
								:fit="fill">
							</el-image>
					</el-col>
					<el-col :span="14">
						<div class="huanhang">	
							<b class="font20px">计算机程序设计人员<br></b>	
							网站设计：参与本站基础功能的开发与优化。<br>
							文本挖掘：对本站内含的文本信息进行分析挖掘。<br>
							推荐系统开发：根据用户行为设计推荐系统。<br>
							AI设计：设计AI增强网站功能。<br>
							区块链项目设计：设计可匿名防篡改的网站功能。<br>
						</div>
					</el-col>
				</el-row>
				<br> -->


				<!-- <el-row>
					<el-col :span="14">
						<div class="huanhang">
							<b class="font20px">这是一个繁巨的基础工程，也是一场有着深刻意义的社会实验<br></b>	
					截止2020年，我国的法律法规已达15万篇，更有数以千万计的行业标准、学术论文、优秀案例、经验分享，指标数据，这些都是大众常用的公共信息。整理这些信息，是一个繁巨的公共信息基础工程，也是建设一个“人民互助”世界的社会实验，公众参与如同核裂变一样的链式反应，它产生的能量和成果让全民共治共有共享，从而打破垄断资本、官僚集团的知识霸权和话语霸权，协助人民自我组织和自我管理，提高社会管理效率，减少社会运行成本。					</div>
					</el-col>
					<el-col :span="10">
							<el-image
								src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/aboutus_8.jpg"
								:fit="fill">
							</el-image>
					</el-col>
				</el-row>
				<br> -->


				<el-row>
					<el-col style="text-align:center;" :span="24">
						<div class="huanhang">	
							<b class="font20px">欢迎添加“知识人”微信公众号和站长微信号<br></b>	
						</div>
					</el-col>
					<el-col style="text-align:center;" :span="12">
							<el-image 
								src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/aboutus73_1.jpg"
								:fit="fill">
							</el-image>
					</el-col>
					<el-col style="text-align:center;" :span="12">
							<el-image 
								src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/aboutus73_2.jpg"
								:fit="fill">
							</el-image>
					</el-col>
				</el-row>
				<br>


				




			</el-main>
			<el-main v-show="dh74" class="section_xh">
				<el-row style="height:270px">
					<el-col :span="24">
						<img src="	https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/aboutwebsite/11112.jpg" class="bg_image" style="height:270px;" alt="">
						<div class="huanhang font22px juzhong" style="color:white;">
							值得您关注的特色功能...
						</div>
					</el-col>
				</el-row>

           		这里面要加入未来规划的特色功能
			</el-main>
			<el-main v-show="dh75" class="section_xh">
             这里有各种问题，民主投票，各类型的常见的问题等。共检产品，设计之初就是有利于公用，耐用，极简
			</el-main>
			<el-aside width="120px">

			</el-aside>


		</el-container>

		<div class="youcelan">
			<router-link  class="square_right a_grey" to="/fuye_sou" target="_blank">
				搜
			</router-link>
<br>
			<router-link  class="square_right a_grey" to="/fuye_zeng" target="_blank">
				增
			</router-link>
<br>
			<a href="http://tool.chacuo.net/cryptdes/" class="square_right a_grey"  target="_blank">
			密
			</a>

<br>
			<router-link  class="square_right a_grey" to="/fuye_shen" target="_blank">
				审
			</router-link>
			<!-- <router-link  class="square_right a_grey" href="http://tool.chacuo.net/cryptdes/" target="_blank">
				密
			</router-link> -->
<!-- <br>




			<router-link  class="square_right a_grey" to="/fuye_liao" target="_blank">
				聊
			</router-link>
<br>
			<router-link  class="square_right a_grey" to="/fuye_bang" target="_blank">
				帮
			</router-link>
<br>
			<router-link  class="square_right a_grey" to="/fuye_ji" target="_blank">
				记
			</router-link>
<br>
			<router-link  class="square_right a_grey" to="/fuye_ce" target="_blank">
				测
			</router-link>

<br>

			<router-link  class="square_right a_grey" to="/fuye_wen" target="_blank">
				问
			</router-link>



<br>

			<router-link  class="square_right a_grey" to="/fuye_wen" target="_blank">
				玩
			</router-link>
<br>
			<router-link  class="square_right a_grey" to="/fuye_kan" target="_blank">
				看
			</router-link>
<br>
			<router-link  class="square_right a_grey" to="/fuye_kan" target="_blank">
				听
			</router-link> -->
		</div>
	</div>

</template>

<script>
import bianji0userinfo from './fujian/bianji_userinfo';
import tj1mydongtai from './tijiao/tj_mydongtai';
import xh11 from './xunhuan/xh11';
import xh21 from './xunhuan/xh21';
import xh22 from './xunhuan/xh22';
import xh23 from './xunhuan/xh23';
import xh24 from './xunhuan/xh24';
import xh27 from './xunhuan/xh27';
import xh31 from './xunhuan/xh31';
import xh32 from './xunhuan/xh32';
import xh33 from './xunhuan/xh33';
import xh34 from './xunhuan/xh34';
import xh35 from './xunhuan/xh35';
import xh36 from './xunhuan/xh36';
// import xh37 from './xunhuan/xh37';
import xh43 from './xunhuan/xh43';
import xh42 from './xunhuan/xh42';
import xh12 from './xunhuan/xh12';
// import xh13 from './xunhuan/xh13';
import xh14 from './xunhuan/xh14';


export default {
        name:'zhutiye',
		components: {bianji0userinfo,
		xh21,xh22,xh23,xh24,xh27,
		xh11,xh12,xh14,
		xh31,xh32,xh33,xh34,xh35,xh36,
		xh43,xh42,
		tj1mydongtai},

        methods:{
                    daohang1(){this.dh1=true;this.dh2=this.dh3=this.dh4=this.dh5=this.dh6=this.dh7=false;this.show_touxiang1=false},
                    daohang2(){this.dh2=true;this.dh1=this.dh3=this.dh4=this.dh5=this.dh6=this.dh7=false;this.show_touxiang1=false},
                    daohang3(){this.dh3=true;this.dh1=this.dh2=this.dh4=this.dh5=this.dh6=this.dh7=false;this.show_touxiang1=false},
                    daohang4(){this.dh4=true;this.dh1=this.dh2=this.dh3=this.dh5=this.dh6=this.dh7=false;},
                    daohang5(){this.dh5=true;this.dh1=this.dh2=this.dh3=this.dh4=this.dh6=this.dh7=false;this.show_touxiang1=false},
                    daohang6(){this.dh6=true;this.dh1=this.dh2=this.dh3=this.dh4=this.dh5=this.dh7=false;this.show_touxiang1=false},
                    daohang7(){this.dh7=true;this.dh1=this.dh2=this.dh3=this.dh4=this.dh6=this.dh5=false;this.show_touxiang1=false},

                    daohang11(){this.dh11=true;this.dh12=false;this.dh13=false;this.dh14=false;this.dh15=false;},
                    daohang12(){this.dh12=true;this.dh11=false;this.dh13=false;this.dh14=false;this.dh15=false;},
                    daohang13(){this.dh13=true;this.dh11=false;this.dh12=false;this.dh14=false;this.dh15=false;},
                    daohang14(){this.dh14=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh15=false;},
                    daohang15(){this.dh15=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh14=false;},

                    daohang21(){this.dh21=true;this.dh22=this.dh23=this.dh24=this.dh25=this.dh26=this.dh27=false;},
                    daohang22(){this.dh22=true;this.dh21=this.dh23=this.dh24=this.dh25=this.dh26=this.dh27=false;},
                    daohang23(){this.dh23=true;this.dh21=this.dh22=this.dh24=this.dh25=this.dh26=this.dh27=false;},
                    daohang24(){this.dh24=true;this.dh21=this.dh22=this.dh23=this.dh25=this.dh26=this.dh27=false;},
                    daohang25(){this.dh25=true;this.dh21=this.dh23=this.dh24=this.dh22=this.dh26=this.dh27=false;},
                    daohang26(){this.dh26=true;this.dh21=this.dh23=this.dh24=this.dh25=this.dh22=this.dh27=false;},
                    daohang27(){this.dh27=true;this.dh21=this.dh23=this.dh24=this.dh25=this.dh26=this.dh22=false;},

                    daohang31(){this.dh31=true;this.dh32=this.dh33=this.dh34=this.dh35=this.dh36=this.dh37=false;},
                    daohang32(){this.dh32=true;this.dh31=this.dh33=this.dh34=this.dh35=this.dh36=this.dh37=false;},
                    daohang33(){this.dh33=true;this.dh31=this.dh32=this.dh34=this.dh35=this.dh36=this.dh37=false;},
                    daohang34(){this.dh34=true;this.dh31=this.dh32=this.dh33=this.dh35=this.dh36=this.dh37=false;},
                    daohang35(){this.dh35=true;this.dh31=this.dh32=this.dh33=this.dh34=this.dh36=this.dh37=false;},
                    daohang36(){this.dh36=true;this.dh31=this.dh32=this.dh33=this.dh34=this.dh35=this.dh37=false;},
                    daohang37(){this.dh37=true;this.dh31=this.dh32=this.dh33=this.dh34=this.dh35=this.dh36=false;},

                    daohang41(){this.dh41=true;this.dh42=this.dh43=this.dh44=this.dh45=false;this.show_touxiang1=false},
                    daohang42(){this.dh42=true;this.dh41=this.dh43=this.dh44=this.dh45=false;this.show_touxiang1=false},
                    daohang43(){this.dh43=true;this.dh41=this.dh42=this.dh44=this.dh45=false;this.show_touxiang1=false},
                    daohang44(){this.dh44=true;this.dh41=this.dh42=this.dh43=this.dh45=false;},
                    daohang45(){this.dh45=true;this.dh41=this.dh42=this.dh43=this.dh44=false;},

                    daohang51(){this.dh51=true;this.dh52=this.dh53=this.dh54=this.dh55=false;},
                    daohang52(){this.dh52=true;this.dh51=this.dh53=this.dh54=this.dh55=false;},
                    daohang53(){this.dh53=true;this.dh51=this.dh52=this.dh54=this.dh55=false;},
                    daohang54(){this.dh54=true;this.dh51=this.dh52=this.dh53=this.dh55=false;},
                    daohang55(){this.dh55=true;this.dh51=this.dh52=this.dh53=this.dh54=false;},

                    daohang61(){this.dh61=true;this.dh62=this.dh63=this.dh64=this.dh65=this.dh66=this.dh67=this.dh68=false;},
                    daohang62(){this.dh62=true;this.dh61=this.dh63=this.dh64=this.dh65=this.dh66=this.dh67=this.dh68=false;},
                    daohang63(){this.dh63=true;this.dh61=this.dh62=this.dh64=this.dh65=this.dh66=this.dh67=this.dh68=false;},
                    daohang64(){this.dh64=true;this.dh61=this.dh62=this.dh63=this.dh65=this.dh66=this.dh67=this.dh68=false;},
                    daohang65(){this.dh65=true;this.dh61=this.dh62=this.dh63=this.dh64=this.dh66=this.dh67=this.dh68=false;},
                    daohang66(){this.dh66=true;this.dh61=this.dh62=this.dh63=this.dh64=this.dh65=this.dh67=this.dh68=false;},
                    daohang67(){this.dh67=true;this.dh61=this.dh62=this.dh63=this.dh64=this.dh65=this.dh66=this.dh68=false;},
                    daohang68(){this.dh68=true;this.dh61=this.dh62=this.dh63=this.dh64=this.dh65=this.dh66=this.dh67=false;},

                    daohang71(){this.dh71=true;this.dh72=this.dh73=this.dh74=this.dh75=false;},
                    daohang72(){this.dh72=true;this.dh71=this.dh73=this.dh74=this.dh75=false;},
                    daohang73(){this.dh73=true;this.dh71=this.dh72=this.dh74=this.dh75=false;},
                    daohang74(){this.dh74=true;this.dh71=this.dh72=this.dh73=this.dh75=false;},
					daohang75(){this.dh75=true;this.dh71=this.dh72=this.dh73=this.dh74=false;},

					tuichu(){
								// this.$alert('确认退出页面？', '确认退出？', {
								// 	confirmButtonText: '确认',
								// 	callback: action => {
								// 							var _this= this;
								// 							_this.$cookies.remove('username');
								// 							_this.$cookies.remove('userid');
								// 							_this.$cookies.remove('status');
								// 							// location.href = '/';
								// 							_this.$router.push({path: '/'});
								// 	}
								// });

							this.$confirm('', '确认退出登陆？',{
								confirmButtonText: '确定',
								cancelButtonText: '取消',
								}).then(() => {
															var _this= this;
															_this.$cookies.remove('username');
															_this.$cookies.remove('userid');
															_this.$cookies.remove('status');
															// location.href = '/';
															_this.$router.push({path: '/'});
								}).catch(() => {
								this.$message({
									type: 'info',
									message: '已取消'
								});          
							});

						// this.$axios.get('http://www.zhishiren.info/api/tuichu/').then(function(response){
						// 	if (response.data.tuichu_ok === 0){
						// 	_this.$cookies.remove('username');
						// 	_this.$cookies.remove('userid');
						// 	}
						// })
					},
					shuaxintouxiang(response, file, fileList) {
							if(response===0){
								this.chuantouxiang_okmsg=0;
								setTimeout(function(){this.chuantouxiang_okmsg=9;}, 2000);
							}
							if(response===1){
								this.$router.go(0);
								// this.$refs.upload.clearFiles();
									// this.chuantouxiang_okmsg=9;
									// this.ceshi_id=0;
									// this.show_touxiang0=true;
							}
					},
						kcopy_gg(){
							let copycode = document.getElementById("gonggao");
							copycode.select(); // 选择对象
							document.execCommand("Copy"); // 执行浏览器复制命令
							alert("密文已经复制到你的粘贴板，请到首页右侧‘密’功能栏解密。");
							// alert(copycode.value);
						},

					handleExceed(files, fileList) {
						this.$message.warning(`每次操作只能上传一个文件！`);
					},
					beforeRemove(file, fileList) {
						return this.$confirm(`确定移除 ${ file.name }？`);
					},
					handleRemove(file, fileList) {
						console.log(file, fileList);
					},
					handlePreview(file) {
						console.log(file);
					},
					onchange(file, fileList){
						this.ceshi_id=1;

					},
					freshinfo(){
						var _this= this;
						_this.axios
						.post('http://www.zhishiren.info/api/show_mypage/', {userid:_this.$cookies.get('userid')})
						.then(function (response) {
							_this.userinfo=response.data;
							_this.userjishu=JSON.parse(response.data.yh_tongji)
						});
					},

					showtouxiang1(){
						this.show_touxiang1=false;
						this.show_touxiang1=true;
					},
					fayanmima(){
						this.show_fayanmima_dialog=true;
						this.fymm_kong='';

					},
					zhankai_fayanmima(){
						this.show_fayanmima_list=true;
						this.show_shuaxin_fayanmima=true;
						this.show_zhankai_fayanmima=false;
						this.show_loading_fayanmima=true;
						var _this= this;
						_this.axios
						.post('http://www.zhishiren.info/api/show_fayanmima_list/', {userid:_this.$cookies.get('userid')})
						.then(function (response) {
							_this.fayanmima_list=JSON.parse(response.data);
							_this.countfymm=_this.fayanmima_list.length;
							if(_this.countfymm===0){_this.show_fayanmima_kong=true;};
							_this.show_loading_fayanmima=false;
						});
					},

					shuaxin_fayanmima(){
						this.show_shuaxin_fayanmima=true;
						this.show_zhankai_fayanmima=false;
						this.show_loading_fayanmima=true;
						var _this= this;
						_this.axios
						.post('http://www.zhishiren.info/api/show_fayanmima_list/', {userid:_this.$cookies.get('userid')})
						.then(function (response) {
							_this.fayanmima_list=JSON.parse(response.data);
							_this.countfymm=_this.fayanmima_list.length;
							if(_this.countfymm===0){_this.show_fayanmima_kong=true;};
							_this.show_loading_fayanmima=false;
						});
					},

					commit_fayanmima(){
						var _this= this;
						if(_this.fayanmima_tips===''||_this.fayanmima_code===''){
							_this.fymm_kong='内容不能为空！';
							setTimeout(function(){_this.fymm_kong='';}, 1500);
							}
						else{
								_this.axios
								.post('http://www.zhishiren.info/api/set_fayanmima/', {userid:_this.$cookies.get('userid'),fymmtips: _this.fayanmima_tips,fymmcode:_this.fayanmima_code})
								.then(function (response) {
									if (response.data.setfymmok === 1){
										_this.errormsgfymm='操作失败';
									}
									if (response.data.setfymmok === 0){
										_this.show_fayanmima_dialog=false;
										_this.show_shuaxin_fayanmima=true;
										_this.show_zhankai_fayanmima=false;
										_this.show_fayanmima_list=true;
										_this.shuaxin_fayanmima();
										
									}
								})
						}
					},

					denglumima(){
						this.show_denglumima_dialog=true;
					},

					edit_gonggao(){
						this.show_editgonggaolan=true;

						
					},

					commit_gonggao(){
						var _this= this;
							if(_this.gonggaoneirong===''){
								_this.gonggao_msg='输入不能为空';
								setTimeout(function(){_this.gonggao_msg='';}, 1500);
							}
							else{
								_this.edit_gonggao_loading=true;
								_this.axios
								.post('http://www.zhishiren.info/api/commit_gonggao/', {userid:_this.$cookies.get('userid'),gonggaoneirong: _this.gonggaoneirong})
								.then(function (response) {
									if (response.data.okmsg === 1){
										_this.gonggao_msg="操作失败";
									}
									if (response.data.okmsg === 0){
										_this.show_editgonggaolan=false;
										_this.edit_gonggao_loading=false;
										_this.$nextTick(() => {
											_this.axios
											.post('http://www.zhishiren.info/api/show_mygonggao/', {userid:_this.$cookies.get('userid')})
											.then(function (response) {
												_this.mygonggao=response.data;
											});
										});
									}
								})
							}
					},
					commit_gonggao_mi(){
						var _this= this;
							if(_this.gonggaoneirong===''){
								_this.gonggao_msg='输入不能为空';
								setTimeout(function(){_this.gonggao_msg='';}, 1500);
							}
							else{
								_this.edit_gonggao_loading=true;
								_this.axios
								.post('http://www.zhishiren.info/api/commit_gonggao_mi/', {userid:_this.$cookies.get('userid'),gonggaoneirong: _this.gonggaoneirong})
								.then(function (response) {
									if (response.data.okmsg === 1){
										_this.gonggao_msg="操作失败";
									}
									if (response.data.okmsg === 0){
										_this.show_editgonggaolan=false;
										_this.edit_gonggao_loading=false;
										_this.$nextTick(() => {
											_this.axios
											.post('http://www.zhishiren.info/api/show_mygonggao/', {userid:_this.$cookies.get('userid')})
											.then(function (response) {
												_this.mygonggao=response.data;
											});
										});
									}
								})
							}
					},


					quxiao_gonggao(){
						this.show_editgonggaolan=false;
					},


					commit_denglumima(){
						var _this= this;
						if(_this.denglumima0===''||_this.denglumima1===''){
							_this.dlmm_kong='输入不能为空！';
							setTimeout(function(){_this.dlmm_kong='';}, 1500);
						}
						else{
							if(_this.denglumima0!==_this.denglumima1){
								_this.dlmm_kong='两次输入不一致！';
								setTimeout(function(){_this.dlmm_kong='';}, 1500);
							}
							else{
								_this.axios
								.post('http://www.zhishiren.info/api/reset_denglumima/', {userid:_this.$cookies.get('userid'),dlmm0: _this.denglumima0})
								.then(function (response) {
									if (response.data.resetmm === 1){
										_this.errormsg_dlmm='操作失败';
									}
									if (response.data.resetmm === 0){
										_this.show_denglumima_dialog=false;
										_this.dlmmok=true;
										setTimeout(function(){_this.dlmmok='';}, 1500);
									}
								})
							}
						}
					},
        },
        data(){
            return {
                dh1:false,dh2:false,dh3:false,dh7:false,dh5:false,dh6:false,dh4:true,
                dh11:true,dh12:false,dh13:false,dh14:false,dh15:false,
                dh21:true,dh22:false,dh23:false,dh24:false,dh25:false,dh26:false,dh27:false,
                dh31:true,dh32:false,dh33:false,dh34:false,dh35:false,dh36:false,dh37:false,
                dh41:true,dh42:false,dh43:false,dh44:false,dh45:false,
                dh51:true,dh52:false,dh53:false,dh54:false,dh55:false,
                dh61:true,dh62:false,dh63:false,dh64:false,dh65:false,dh66:false,dh67:false,dh68:false,
				dh71:true,dh72:false,dh73:false,dh74:false,dh75:false,
				nowTime: new Date(), // 当前时间
				userinfo:[],
				userjishu:[],
				fileList:[],
				ceshi_id:0,
				kkk:999,
				chuantouxiang_okmsg:9,
				tab_active:"4",
				// show_touxiang0:true,
				show_touxiang1:false,
				show_fayanmima_dialog:false,
				show_fayanmima_list:false,
				fayanmima_tips:'',
				fayanmima_code:'',
				show_shuaxin_fayanmima:false,
				show_zhankai_fayanmima:true,
				show_loading_fayanmima:false,
				fayanmima_list:[],
				countfymm:0,
				show_fayanmima_kong:false,
				okmsg_fymm:'',
				errormsg_fymm:'',

				show_denglumima_dialog:false,
				dlmm_kong:'',
				errormsg_dlmm:'',
				fymm_kong:'',
				dlmmok:false,
				denglumima0:'',
				denglumima1:'',

				show_editgonggaolan:false,
				gonggaoneirong:'',
				gonggao_msg:'',
				edit_gonggao_loading:false,
				mygonggao:''

			}
		},

		computed:{
			welcomename(){return this.$cookies.get('username')},
			userid(){return this.$cookies.get('userid')},
			// user_img(){return 'http://www.zhishiren.info/api/'+this.$cookies.get('userid')+'.jpg'},
			user_img(){return 'https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/futu1/90000001.jpg'},
		},

// 这里需要写入加载这个页面时所有的初始数据，包括用户信息，各类汇总统计数据，
		created: function () {
			// this.kkk = this.$route.params.k;
			// 这kkk是用来表示用户是不是第一次注册还是再次登陆。
			// if(this.welcomename){
				// if(this.kkk==="4"){this.tab_active="4";};
				// this.tab_active="7";
				var _this= this;
				_this.axios
				.post('http://www.zhishiren.info/api/show_mypage/', {userid:_this.$cookies.get('userid')})
				.then(function (response) {
					_this.userinfo=response.data;
					_this.userjishu=JSON.parse(response.data.yh_tongji);
				});
				_this.axios
				.post('http://www.zhishiren.info/api/show_mygonggao/', {userid:_this.$cookies.get('userid')})
				.then(function (response) {
					_this.mygonggao=response.data;
				});

		},

};
</script>
<style>

</style>


