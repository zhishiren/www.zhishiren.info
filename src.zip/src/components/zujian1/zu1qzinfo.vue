
// 这是用于“用户与群”的用户信息
<template>
    <div id="zu1qzinfo">
        <el-row>
            <router-link class="a_black" target="_blank" :to="{name:'qunzuye',params:{id:list.pk}}">
                <span v-html="gaoliangk(list.fields.qz_title, kkk)" ></span>
            </router-link>
            <span style="color:red;" v-if="list.fields.qz_status==='失效已删'">失效已删</span>
            <span style="color:orange;" v-if="list.fields.qz_status==='正在审核'">正在审核</span>
        </el-row>
        <el-row>
            <span style="color:grey">创建时间:</span><span>{{qian_date(list.fields.qz_createtime)}}<el-divider direction="vertical"></el-divider></span>
            <span style="color:grey">群组说明:</span><span v-html="gaoliangk(list.fields.qz_remark, kkk)" ></span>
        </el-row>
        <el-col :span="24"><el-divider style="margin:0px;"></el-divider></el-col>
    </div>
</template>

<script>
  export default {
    name:'zu1qzinfo',
    data() {
      return {

      }
    },

    props:['list','kkk'],

    methods:{
        

    }

  }
</script>





