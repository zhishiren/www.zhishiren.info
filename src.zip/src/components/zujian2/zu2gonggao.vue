<template>
    <div id="zu2gonggao">
		<el-row style="text-align:center;color:white;background-repeat:no-repeat;background-size:100% 100%;height:250px;background-image:url(https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/bg_gonggao0.jpg);">
			<el-row>
				<el-rol :span="8"></el-rol>
				<el-rol :span="8" style="font-size:30px;">
					<span v-if="my_yn!=='0'">TA</span>
					<span v-if="my_yn==='0'">我</span>
					<span>的公告栏</span>
				</el-rol>
				<el-rol :span="8"></el-rol>
			</el-row>
			<div v-if="show_editgonggaolan===false" style="width:400px;text-align:center;margin:0 auto;">{{qian_date(this.mygonggao.gg_time)}}</div>
			<div style="height:150px;font-size:20px;text-align:center;">
				<div v-if="show_editgonggaolan===false" style="width:500px;text-align:center;margin:0 auto;">
					<div style="color:orange;"  v-if="mygonggao.gg_mizi===0 && mygonggao.gg_status==='正常有效'">{{this.mygonggao.gg}}</div>
					<div style="color:yellow;" v-if="mygonggao.gg_mizi===0 && mygonggao.gg_status==='正在审核'">正在审核公告内容...</div>
					<div v-if="mygonggao.gg_mizi!==0">
						<span>一段{{this.mygonggao.gg_mizi}}个字的密文</span>
						<input v-if="mygonggao.gg!==''" style="width:1px;border-color:green;border:0px;background-color:green;" type="text" v-model="gonggao_content" id="gonggao">                                   
						<a class="a_brown" @click="kcopy_gg()"><i class="el-icon-document-copy"></i>点击复制密文</a>
					</div>
				</div>
				<textarea placeholder="请输入你想发布的公告内容，限100字。" v-if="show_editgonggaolan" v-model="gonggaoneirong" cols="20" rows="6"  style="width:500px;text-align:center;margin:0 auto;font-size:19px;opacity: 0.5;"></textarea>
			</div>
			<el-row v-if="show_editgonggaolan===false && my_yn==='0'">
				<el-rol :span="8"></el-rol>
				<el-rol :span="8" style="font-size:20px;text-align:center;">
					<i @click="edit_gonggao()" class="el-icon-edit-outline a_white">撰写公告</i>
				</el-rol>
				<el-rol :span="8"></el-rol>
			</el-row>
			<el-row v-if="show_editgonggaolan && edit_gonggao_loading===false && my_yn==='0'">
				<span v-if="gonggao_msg==='' && edit_gonggao_loading!==true" >
					<i @click="quxiao_gonggao()" class="el-icon-close a_white"  style="font-size:20px;">取消</i>
					<span style="font-size:18px;color:yellow;"><el-divider direction="vertical"></el-divider></span>
					<i @click="fabujian(0)" class="el-icon-chat-square a_white"  style="font-size:20px;">明发</i>
					<span style="font-size:18px;color:yellow;"><el-divider direction="vertical"></el-divider></span>
					<i @click="fabujian(1)" class="el-icon-chat-line-square a_white"  style="font-size:20px;">密发</i>
				</span>	
					<span v-if="gonggao_msg!==''" style="font-size:18px;color:yellow;"><i class="el-icon-info"></i>{{this.gonggao_msg}}</span>
					<span v-if="edit_gonggao_loading" style="font-size:18px;color:yellow;"><i class="el-icon-loading"></i>正在发布...</span>
			</el-row>
			<el-row v-if="show_editgonggaolan && edit_gonggao_loading" style="font-size:18px;">
				<i class="el-icon-loading"></i>正在发布...
			</el-row>
			
		</el-row>
    </div>
</template>

<script>
    export default {
        name:'zu2gonggao',
        props:['my_yn','yonghuid'],//k是区分
        data() {return {
			show_editgonggaolan:false,
			gonggaoneirong:'',
			gonggao_msg:'',
			edit_gonggao_loading:false,
			mygonggao:'',
        }},
        computed:{
            gonggao_content(){return this.mygonggao.gg.slice(2,-1)},
		},
        methods:{
			kcopy_gg(){
				let copycode = document.getElementById("gonggao");
				copycode.select(); // 选择对象
				document.execCommand("Copy"); // 执行浏览器复制命令
				// alert("密文已经复制到你的粘贴板，请到首页右侧‘密’功能栏解密。");
				const h = this.$createElement;
				this.$notify({
					title: '密文已经复制到你的粘贴板',
					type: 'success',
					message: h('i', { style: 'color: teal;font-size:19px;'}, '请到‘密’功能栏解密。')
				});
				
				// alert(copycode.value);
			},
            
			edit_gonggao(){
				this.show_editgonggaolan=true;
			},

			fabujian(mi){
				var _this= this;
				if(_this.gonggaoneirong===''){
					_this.gonggao_msg='输入不能为空';
					setTimeout(function(){_this.gonggao_msg='';}, 1500);
				}
				else{
					_this.edit_gonggao_loading=true;
					_this.axios
					.post('http://www.zhishiren.info/api/to_caozuo/', {
						uid:_this.yonghuid,
						fy: _this.gonggaoneirong,
						fymi:mi,
						cztype:'公告',
						fymm:_this.$cookies.get('fayanmima'),
						})
					.then(function (response) {
						if (response.data.msg === 1){
							_this.show_editgonggaolan=false;
							_this.edit_gonggao_loading=false;
							_this.$nextTick(() => {
								_this.axios
								.post('http://www.zhishiren.info/api/show_mygonggao/', {userid:_this.yonghuid})
								.then(function (response) {
									_this.mygonggao=response.data;
								});
							});
						}else{
							_this.gonggao_msg="操作失败";
						}
						
					})
				}
			},


			quxiao_gonggao(){
				this.show_editgonggaolan=false;
			},
            
        },

		// created: function () {
		// 	var _this= this;
		// 	_this.axios
		// 	.post('http://www.zhishiren.info/api/show_mygonggao/', {userid:_this.yonghuid})
		// 	.then(function (response) {
		// 		_this.mygonggao=response.data;
		// 	});
		// },

		 watch: {
            yonghuid: function(newVal,oldVal){
				var _this= this;
				_this.yonghu_id = newVal;
				_this.axios
					.post('http://www.zhishiren.info/api/show_mygonggao/', {userid:_this.yonghu_id})
					.then(response=>{
						_this.mygonggao=response.data;
			    });

            },
        },


    };
</script>



