
import Vue from 'vue';
import Element from 'element-ui';
import './plugins/element.js'
import 'element-ui/lib/theme-chalk/index.css';
import App from './App.vue';
import router from './router/index.js';
import axios from 'axios';
import VueAxios from 'vue-axios';
import './assets/css/zcss.css';
import VueCookies from 'vue-cookies';
import store from './store';

import zu2logo from "@/components/zujian2/zu2logo.vue";
import zu2z41myinfo from "@/components/zujian2/zu2z41myinfo.vue";
import zu2gonggao from "@/components/zujian2/zu2gonggao.vue";
import zu2youcelan from "@/components/zujian2/zu2youcelan.vue";
import zu2errorpage from "@/components/zujian2/zu2errorpage.vue";
import zu2liaolist from "@/components/zujian2/zu2liaolist.vue";

import zengwenji from "@/components/zone/zengwenji.vue";
import zengbiaoqian from "@/components/zone/zengbiaoqian.vue";
import zengqunzu from "@/components/zone/zengqunzu.vue";
import zengfayan from "@/components/zone/zengfayan.vue";

import zu1caozuojishu from "@/components/zujian1/zu1caozuojishu.vue";
import zu1yuansu from "@/components/zujian1/zu1yuansu.vue";
import zu1huifulan from "@/components/zujian1/zu1huifulan.vue";
import zu1fabujian from "@/components/zujian1/zu1fabujian.vue";
import zu1wenda from "@/components/zujian1/zu1wenda.vue";

import zu0fy from "@/components/zujian0/zu0fy.vue";
import zu0niming from "@/components/zujian0/zu0niming.vue";
import zu0z41edituserinfo from "@/components/zujian0/zu0z41edituserinfo.vue";
import zu0setfanwei from "@/components/zujian0/zu0setfanwei.vue";
import zu0showfanwei from "@/components/zujian0/zu0showfanwei.vue";
import zu0uploadfu from "@/components/zujian0/zu0uploadfu.vue";
import zu0uploadyuanwen from "@/components/zujian0/zu0uploadyuanwen.vue";
import zu0zengshanchu from "@/components/zujian0/zu0zengshanchu.vue";
import zu0fujianfutu from "@/components/zujian0/zu0fujianfutu.vue";
import zu0tongjishu from "@/components/zujian0/zu0tongjishu.vue";
import zu0editshu from "@/components/zujian0/zu0editshu.vue";

import xhcaozuo from "@/components/xunhuan/xhcaozuo.vue";
import xhduanluo from "@/components/xunhuan/xhduanluo.vue";
import xhzuyuan from "@/components/xunhuan/xhzuyuan.vue";
import xhqznei from "@/components/xunhuan/xhqznei.vue";
import xhchanged from "@/components/xunhuan/xhchanged.vue";
// import zu1editfy from "@/components/zujian1/zu1editfy.vue";这个组件在局部注册


Vue.config.productionTip = false;
Vue.use(Element);
Vue.use(router);
Vue.use(require('vue-cookies'));
Vue.use(VueCookies);
Vue.use(VueAxios,axios);
Vue.prototype.$axios = axios;


Vue.component("zu2logo", zu2logo);
Vue.component("zu2z41myinfo", zu2z41myinfo);
Vue.component("zu2youcelan", zu2youcelan);
Vue.component("zu2gonggao", zu2gonggao);
Vue.component("zu2errorpage", zu2errorpage);
Vue.component("zu2liaolist", zu2liaolist);


Vue.component("zengwenji", zengwenji);
Vue.component("zengbiaoqian", zengbiaoqian);
Vue.component("zengqunzu", zengqunzu);
Vue.component("zengfayan", zengfayan);

Vue.component("zu1caozuojishu", zu1caozuojishu);
Vue.component("zu1yuansu", zu1yuansu);
Vue.component("zu1huifulan", zu1huifulan);
Vue.component("zu1fabujian", zu1fabujian);
Vue.component("zu1wenda", zu1wenda);

Vue.component("xhcaozuo", xhcaozuo);
Vue.component("xhduanluo", xhduanluo);
Vue.component("xhzuyuan", xhzuyuan);
Vue.component("xhqznei", xhqznei);
Vue.component("xhchanged", xhchanged);

Vue.component("zu0niming", zu0niming);
Vue.component("zu0fy", zu0fy);
Vue.component("zu0setfanwei", zu0setfanwei);
Vue.component("zu0showfanwei", zu0showfanwei);
Vue.component("zu0uploadfu", zu0uploadfu);
Vue.component("zu0uploadyuanwen", zu0uploadyuanwen);
Vue.component("zu0zengshanchu", zu0zengshanchu);
Vue.component("zu0fujianfutu", zu0fujianfutu);
Vue.component("zu0tongjishu", zu0tongjishu);
Vue.component("zu0editshu", zu0editshu);
Vue.component("zu0z41edituserinfo", zu0z41edituserinfo);

//以下两个函数是用于在数据库返回数组中查询并高亮关键字,indexOf()方法可以判断字符串中是否包含写字符串，原函数写在methed中。
Vue.prototype.gaoliangk = function(val, keyword){
  val = val + '';
  if (val.indexOf(keyword) !== -1) {return val.replace(keyword, '<b><font color="orange">' + keyword + '</font></b>')}
  else{return val}
};

Vue.prototype.turnfresh = function () {
  var cooname = this.$cookies.get('username');
  if (cooname == undefined || cooname == "") {
    this.$alert('你上次登陆信息已失效，请重新登陆...', '登陆过期', {
      confirmButtonText: '回到登陆页',
      callback: action => {
        this.$router.push({ path: '/' });
      }
    });
  }
};

Vue.prototype.errorid_transfer = function (zhifanwei) {
  // zhifanwei是知识点的公开范围，需要判断是否在用户的群组id串中
  var kkk = this.$cookies.get('chuan');
      if (kkk.indexOf(zhifanwei) === -1) { return zhifanwei; }//此代码的意思是用户没有该知识点的群组权限
      else{return 0;}
};


// Vue.prototype.search = function(keyword,list){
// 	　　　　　　　　var newList = [];
// 	　　　　　　　　list.forEach(xh_k_11=>{if(xh_k_11.news_comm.indexOf(keyword) !==-1||xh_k_11.news_item1title.indexOf(keyword) !==-1){newList.push(xh_k_11)}});
// 				       this.$store.state.COUNT_XHK11 = newList.length;
// 	　　　　　　   return newList;
// };

// Vue.prototype.jishu_chuan = function(chuan,type0){
//     var chuan1=chuan.split('_');
//     var jishu=1;
//     if (type0 == 'bq') { 
//       for (let i = 0; i < chuan1.length; i++) {
//         if (chuan1[i] > 30000000 && chuan1[i]<40000000){
//           jishu=jishu+1;
//         }else{
//         }
        
//       }
//     }

// };
Vue.prototype.jishu_chuan = function (chuan, type0) {
  var chuan1 = chuan.split('_');
  var jishu = 0;
  if (type0 == 'bq') {
    for (let i = 0; i < chuan1.length; i++) {
      var chuankkk = chuan1[i];
      if (chuankkk > 30000000 && chuankkk < 40000000) {
        jishu = jishu + 1;
      }
    }
  }
  if (type0 == 'yh') {
    for (let i = 0; i < chuan1.length; i++) {
      var chuankkk = chuan1[i];
      if (chuankkk > 90000000 && chuankkk < 100000000) {
        jishu = jishu + 1;
      }
    }
  }
  if (type0 == 'wj') {
    for (let i = 0; i < chuan1.length; i++) {
      var chuankkk = chuan1[i];
      if (chuankkk > 10000000 && chuankkk < 20000000) {
        jishu = jishu + 1;
      }
    }
  }
  if (type0 == 'wd') {
    for (let i = 0; i < chuan1.length; i++) {
      var chuankkk = chuan1[i];
      if (chuankkk > 20000000 && chuankkk < 30000000) {
        jishu = jishu + 1;
      }
    }
  }
  if (type0 == 'qz') {
    for (let i = 0; i < chuan1.length; i++) {
      var chuankkk = chuan1[i];
      if (chuankkk > 80000000 && chuankkk < 90000000) {
        jishu = jishu + 1;
      }
    }
  }
  if (type0 == 'fay') {
    for (let i = 0; i < chuan1.length; i++) {
      var chuankkk = chuan1[i];
      if (chuankkk > 100000000) {
        jishu = jishu + 1;
      }
    }
  }
  ;
  return jishu;
};


Vue.prototype.timestamp = function(url) {return url + "?timestamp=" + new Date().getTime();};

Vue.prototype.daibiaoma = function(key) {
  if (key=='yh0') {return '普通用户';}
  if (key=='yh1') {return '实名用户';}
  if (key=='yh2') {return '高级用户';}
  if (key=='yh3') {return '内容管理员';}
  if (key=='yh4') {return '超级管理员';}
  if (key=='yh5') {return '公众人物';}
  if (key=='yh6') {return '历史人物';}
  if (key=='yh7') {return '团体组织';}

  if (key=='wj0') {return '知识百科';}
  if (key=='wj1') {return '国家法规';}
  if (key=='wj2') {return '行业标准';}
  if (key=='wj3') {return '公司制度';}
  if (key=='wj4') {return '学术著作';}
  if (key=='wj5') {return '新闻简讯';}
  if (key=='wj6') {return '公告通知';}
  if (key == 'wj7') { return '经验分享'; }
  if (key == 'wj8') { return '独立文段'; }
  if (key == 'wj9') { return '无类型'; }

  if (key == 'fy0') { return '暂无类型'; }
  if (key=='fy1') {return '求助询问';}
  if (key=='fy2') {return '新闻简讯';}
  if (key=='fy3') {return '公告通知';}
  if (key=='fy4') {return '感悟思考';}
  if (key == 'fy5') { return '名人名言'; }
  if (key == 'fy6') { return '公开言论'; }

  if (key=='wd1') {return '自然段落';}
  if (key=='wd2') {return '独立段落';}

  if (key=='sji0') {return '不定期';}
  if (key=='sji1') {return '每日';}
  if (key=='sji7') {return '每周';}
  if (key=='sji30') {return '每月';}
  if (key=='sji120') {return '每季度';}
  if (key=='sji180') {return '每半年';}
  if (key=='sji365') {return '每年';}
  
  if (key=='qz0') {return '兴趣小组';}
  if (key=='qz1') {return '内部团队';}
  if (key=='qz2') {return '企业社团';}

  if (key=='qz_j0') {return '不需申请';}
  if (key=='qz_j1') {return '需要申请';}

  if (key=='a01') {return '关注';}         //不放入news
  if (key=='a02') {return '分享';}         //放入-------“关注用户”
  if (key=='a03') {return '添加入标签';}    //放入“关注内容”
  if (key=='a04') {return '评论';}         //放入“关注内容”
  if (key=='a05') {return '发言说';}          //放入-------“关注用户”
  if (key=='a06') {return '回复';}            //放入--“互动消息”
  if (key=='a07') {return '顶';}              //放入--“互动消息”
  if (key=='a08') {return '踩';}              //放入--“互动消息”
  if (key=='a09') {return '新增';}            //群组消息
  if (key=='a10') {return '修改了知识点信息';}   //。。。计划放入“关注内容”
  if (key=='a11') {return '加入了群组';}        //变动
  if (key=='a12') {return '退出了群组';}        //变动
  if (key=='a13') {return '收到了邀请';}        //放入--“互动消息”
  if (key=='a14') {return '申请被拒';}          //放入--“互动消息”
  if (key=='a15') {return '申请加入群组';}      //放入--“互动消息”
  if (key=='a16') {return '修改了个人签名';}    //放入-------“关注用户”
  if (key=='a17') {return '修改了个人信息';}    //不放入news
  if (key=='a18') {return '关联';}            //放入“关注内容”
  if (key == 'a19') { return '留言'; }            //放入“互动消息”
  if (key=='a20') {return '提问';}            //放入“互动消息”
  if (key == 'a21') { return '悬赏提问'; }            //放入“互动消息”
  if (key == 'a22') { return '悬赏任务'; }            //放入“互动消息”
  if (key == 'a23') { return '加入群组'; }            //放入“关注用户”
  if (key == 'a24') { return '用户关注'; }            //放入“互动消息”
  if (key == 'a25') { return '纠错'; }            //放入“互动消息”


  if (key=='s0') {return '正常有效';}
  if (key=='s1') {return '过期失效';}
  if (key == 's2') { return '正在审核'; }
  if (key=='s3') {return '禁用停用';}
  if (key == 's4') { return '失效已删'; }
  if (key=='s5') {return '审核被拒';}

  if (key==80000000) {return '仅本人可见';}
  if (key >80000000 && key < 89999999) {return '限小组'+key+'可见';}
  if (key==90000000) {return '所有人可见';}

  if (key=='att0') {return '无关系无态度';}
  if (key=='att1') {return '相互矛盾';}
  if (key=='att2') {return '互补';}
  if (key=='att3') {return '更细化';}
  if (key=='att4') {return '吐槽异议';}
  if (key=='att5') {return '点赞支持';}
  if (key=='att6') {return '疑惑不解';}
  if (key=='att7') {return '申请置顶';}
};


Vue.prototype.formatDate_ymdhm = function (value) {
  let date = new Date(value);
  let y = date.getFullYear();
  let MM = date.getMonth() + 1;
  MM = MM < 10 ? ('0' + MM) : MM;
  let d = date.getDate();
  d = d < 10 ? ('0' + d) : d;
  let h = date.getHours();
  h = h < 10 ? ('0' + h) : h;
  let m = date.getMinutes();
  m = m < 10 ? ('0' + m) : m;
  let s = date.getSeconds();
  s = s < 10 ? ('0' + s) : s;
  return y + '-' + MM + '-' + d + ' ' + h + ':' + m ;
};


//这个函数是用于把13位的时间戳转换为各种时间格式，例如此例的小时:分钟格式，减28800000就是调整八小时的毫秒数
//43200000是12小时的毫秒数
Vue.prototype.formatDate_hm_8 = function(value){
        let date0 = Date.parse(new Date()) - 43200000;
        let date = new Date(value-28800000);
        if (date < date0) { return '12小时前';}
        else{
          let y = date.getFullYear();
          let MM = date.getMonth() + 1;
          MM = MM < 10 ? ('0' + MM) : MM;
          let d = date.getDate();
          d = d < 10 ? ('0' + d) : d;
          let h = date.getHours();
          h = h < 10 ? ('0' + h) : h;
          let m = date.getMinutes();
          m = m < 10 ? ('0' + m) : m;
          let s = date.getSeconds();
          s = s < 10 ? ('0' + s) : s;
          // return y + '-' + MM + '-' + d + ' ' + h + ':' + m + ':' + s;
          return h + ':' + m;
        }
        
};



// Vue.prototype.formatDate_hm = function (value) {
//   let date = new Date(value);
//   let y = date.getFullYear();
//   let MM = date.getMonth() + 1;
//   MM = MM < 10 ? ('0' + MM) : MM;
//   let d = date.getDate();
//   d = d < 10 ? ('0' + d) : d;
//   let h = date.getHours();
//   h = h < 10 ? ('0' + h) : h;
//   let m = date.getMinutes();
//   m = m < 10 ? ('0' + m) : m;
//   let s = date.getSeconds();
//   s = s < 10 ? ('0' + s) : s;
//   // return y + '-' + MM + '-' + d + ' ' + h + ':' + m + ':' + s;
//   return h + ':' + m;
// };



Vue.prototype.formatDate_hm = function (value) {
  let date = new Date(value);
  let y = date.getFullYear();
  let MM = date.getMonth() + 1;
  MM = MM < 10 ? ('0' + MM) : MM;
  let d = date.getDate();
  d = d < 10 ? ('0' + d) : d;
  let h = date.getHours();
  h = h < 10 ? ('0' + h) : h;
  let m = date.getMinutes();
  m = m < 10 ? ('0' + m) : m;
  let s = date.getSeconds();
  s = s < 10 ? ('0' + s) : s;
  // return y + '-' + MM + '-' + d + ' ' + h + ':' + m + ':' + s;
  return h + ':' + m;
};


// 例如此例的月份：日期格式
Vue.prototype.formatDate_ymd_8 = function(value){
  let date = new Date(value-28800000);
  let y = date.getFullYear();
  let MM = date.getMonth() + 1;
  MM = MM < 10 ? ('0' + MM) : MM;
  let d = date.getDate();
  d = d < 10 ? ('0' + d) : d;
  let h = date.getHours();
  h = h < 10 ? ('0' + h) : h;
  let m = date.getMinutes();
  m = m < 10 ? ('0' + m) : m;
  let s = date.getSeconds();
  s = s < 10 ? ('0' + s) : s;
  // return y + '-' + MM + '-' + d + ' ' + h + ':' + m + ':' + s;
  return y + '-' + MM+ '-'+ d;
};

// 例如此例的月份：日期格式
Vue.prototype.formatDate_ymd = function (value) {
  let date = new Date(value);
  let y = date.getFullYear();
  let MM = date.getMonth() + 1;
  MM = MM < 10 ? ('0' + MM) : MM;
  let d = date.getDate();
  d = d < 10 ? ('0' + d) : d;
  let h = date.getHours();
  h = h < 10 ? ('0' + h) : h;
  let m = date.getMinutes();
  m = m < 10 ? ('0' + m) : m;
  let s = date.getSeconds();
  s = s < 10 ? ('0' + s) : s;
  // return y + '-' + MM + '-' + d + ' ' + h + ':' + m + ':' + s;
  return y + '-' + MM + '-' + d;
};


Vue.prototype.qian_date_8 = function (timeStamp) {
  timeStamp = timeStamp-28800000;
  if (timeStamp === null) { return '无效时间' }
  var dateTime = new Date(timeStamp);
  var no1new = dateTime.valueOf();
  var year = dateTime.getFullYear();
  var month = dateTime.getMonth() + 1;
  var day = dateTime.getDate();
  var hour = dateTime.getHours();
  var minute = dateTime.getMinutes();
  var second = dateTime.getSeconds();
  var now = new Date();
  var now_new = now.valueOf();
  var milliseconds = 0;
  var timeSpanStr;

  milliseconds = now_new - no1new;

  if (milliseconds <= 1000 * 60 * 1) {
    timeSpanStr = '刚刚';
  } else if (1000 * 60 * 1 < milliseconds && milliseconds <= 1000 * 60 * 60) {
    timeSpanStr = Math.round((milliseconds / (1000 * 60))) + '分钟前';
  } else if (1000 * 60 * 60 * 1 < milliseconds && milliseconds <= 1000 * 60 * 60 * 24) {
    timeSpanStr = Math.round(milliseconds / (1000 * 60 * 60)) + '小时前';
  } else if (1000 * 60 * 60 * 24 < milliseconds && milliseconds <= 1000 * 60 * 60 * 24 * 15) {
    timeSpanStr = Math.round(milliseconds / (1000 * 60 * 60 * 24)) + '天前';
  } else if (milliseconds > 1000 * 60 * 60 * 24 * 15 && year == now.getFullYear()) {
    // timeSpanStr = year + '-' + month + '-' + day + ' ' + hour + ':' + minute + ':' + second;
    timeSpanStr = year + '-' + month + '-' + day
  } else {
    // timeSpanStr = year + '-' + month + '-' + day + ' ' + hour + ':' + minute + ':' + second;
    timeSpanStr = year + '-' + month + '-' + day
  }

  return timeSpanStr;
}



Vue.prototype.later24h = function (timeStamp) {
  var dayu24h;
  var date = new Date(timeStamp);
  // var time1 = date.getTime();
  // var time2 = date.valueOf();
  var time3 = Date.parse(date);
  // console.log(time1);//1398250549123
  // console.log(time2);//1398250549123
  // console.log(time3);//1398250549000

  let nowtime = Date.parse(new Date());
  if (time3+86400000 < nowtime) { dayu24h = true;}
  else { dayu24h = false;}
  return dayu24h;
  }




Vue.prototype.qian_date = function (timeStamp) {
  if(timeStamp===null){return '无效时间'}
  var dateTime = new Date(timeStamp);
  var no1new = dateTime.valueOf();
  var year = dateTime.getFullYear();
  var month = dateTime.getMonth() + 1;
  var day = dateTime.getDate();
  var hour = dateTime.getHours();
  var minute = dateTime.getMinutes();
  var second = dateTime.getSeconds();
  var now = new Date();
  var now_new = now.valueOf();
  var milliseconds = 0;
  var timeSpanStr;

  milliseconds = now_new - no1new;

  if (milliseconds <= 1000 * 60 * 1) {
    timeSpanStr = '刚刚';
  } else if (1000 * 60 * 1 < milliseconds && milliseconds <= 1000 * 60 * 60) {
    timeSpanStr = Math.round((milliseconds / (1000 * 60))) + '分钟前';
  } else if (1000 * 60 * 60 * 1 < milliseconds && milliseconds <= 1000 * 60 * 60 * 24) {
    timeSpanStr = Math.round(milliseconds / (1000 * 60 * 60)) + '小时前';
  } else if (1000 * 60 * 60 * 24 < milliseconds && milliseconds <= 1000 * 60 * 60 * 24 * 15) {
    timeSpanStr = Math.round(milliseconds / (1000 * 60 * 60 * 24)) + '天前';
  } else if (milliseconds > 1000 * 60 * 60 * 24 * 15 && year == now.getFullYear()) {
    // timeSpanStr = year + '-' + month + '-' + day + ' ' + hour + ':' + minute + ':' + second;
    timeSpanStr = year + '-' + month + '-' + day
  } else {
    // timeSpanStr = year + '-' + month + '-' + day + ' ' + hour + ':' + minute + ':' + second;
    timeSpanStr = year + '-' + month + '-' + day
  }

  return timeSpanStr;
}






/**
 * 这是页面上部调用当前时间，格式为YYYY-MM-DD
 */
Vue.prototype.getNowFormatDate = function(value) {
  var date = new Date(value);
  var seperator1 = "-";
  var year = date.getFullYear();
  var month = date.getMonth() + 1;
  var strDate = date.getDate();
  var strHours = date.getHours();
  var strMinutes = date.getMinutes();
  if (month >= 1 && month <= 9) {
    month = "0" + month;
  }
  if (strDate >= 0 && strDate <= 9) {
    strDate = "0" + strDate;
  }
  var currentdate = year + seperator1 + month + seperator1 + strDate;
  return currentdate;
};


/**
 * 这是页面上部调用当前时间，格式为YYYY-MM-DD
 */
Vue.prototype.getNowFormatDatetime = function (value) {
  var date = new Date(value);
  var seperator1 = "-";
  var year = date.getFullYear();
  var month = date.getMonth() + 1;
  var strDate = date.getDate();
  var strHours = date.getHours();
  var strMinutes = date.getMinutes();
  if (month >= 1 && month <= 9) {
    month = "0" + month;
  }
  if (strDate >= 0 && strDate <= 9) {
    strDate = "0" + strDate;
  }
  var currentdate = year  + month  + strDate  + strHours  + strMinutes;
  return currentdate;
};



/**
 * 这是更新用户所属的群组集的函数，当用户新增/删除一个群组，加入/退出一个群组时，都会更新这个群组集。
 * 不需要当时就查询数组，而是直接在字符串里改
 */
Vue.prototype.update_qunzu = function (value) {
  var date = new Date(value);
  var seperator1 = "-";
  var year = date.getFullYear();
  var month = date.getMonth() + 1;
  var strDate = date.getDate();
  if (month >= 1 && month <= 9) {
    month = "0" + month;
  }
  if (strDate >= 0 && strDate <= 9) {
    strDate = "0" + strDate;
  }
  var currentdate = year + seperator1 + month + seperator1 + strDate;
  return currentdate;
};



new Vue({
  el:'#app',
  template: '<App/>',
  components: { App },
  store,
  router,
  render: h => h(App),
}).$mount('#app')
