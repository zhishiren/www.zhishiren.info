
<template>
    <span id="zu0zengshanchu" style="float:right">
        <span v-if="yishan_yn!=='失效已删'">
            <a @click="shanchujian()"><i class="el-icon-close a_grey">删</i></a>
        </span>
        <span style="color:orange" v-if="notok">删除失败</span>
        <span v-if="yishan_yn==='失效已删'" style="color:grey">已删</span>
        <span><el-divider direction="vertical"></el-divider></span>
        <span style="color:grey">{{qian_date(time)}}</span>
	</span>
</template>

<script>
export default {
    name:'zu0zengshanchu',
	data() {return {notok:false}},
	props:['zhid','leixing','yishan_yn','time'],
	methods:{
		shanchujian:function(){
            this.$alert('确认删除本条记录？', '确认删除？', {
                confirmButtonText: '确认',
                callback: action => {
                    if (action === 'confirm') {
                        var that = this;
                        that.axios
                        .post('http://www.zhishiren.info/api/shanchu/', {zhid:that.zhid,leixing:that.leixing,userid:that.$cookies.get('userid')})
                        .then(response=>{
                            if(response.data.changed_ok==0){
                                that.$emit('shanchuok');
                                that.notok=false;
                                that.yishan_yn="失效已删";
                            }
                            else{
                                that.notok=true;
                            }
                        });
                    }
                }
            });
		},
	},
};

</script>

