<template>
    <div id="zu1fabujian">
		<el-row >
                <el-col :span="2" >
                    <span class="font16px">备注说明：</span>
                </el-col>
                <el-col :span="20" >
                    <div contenteditable ref="contents" @paste="onPaste" class="pinglunlan" style="font-size:16px;width:100%;">请输入备注或说明的内容。</div>
                </el-col>
                <el-col :span="2">
                    <a class="a_black" href="javascript:;" @click="f_blod">
                        <b>所选加粗</b>
                    </a>
                </el-col>
        </el-row>
        <el-row style="text-align:center;line-height: 40px;">
                <span v-show="faloading!==true">
            		<a @click="fabu()" class="font20px a_black">发布</a>
				</span>
                <span v-if="faloading"  style="font-size:18px;"><i class="el-icon-loading"></i>正在发布...</span>
                <span v-if="return_msg" style="color:orange;font-size:18px;">:{{this.return_msg}}</span>
        </el-row>
    </div>
</template>

<script>
    export default {
        name:'zu1fabujian',
        props:['faloading','return_msg'],//k是区分
        data() {return {}},
        computed:{},
        methods:{
			f_blod() {document.execCommand ( 'bold', false );},
        
        	onPaste: function(e) {
                e.preventDefault()
                e.stopPropagation()
                let pasteValue = (e.clipboardData || window.clipboardData).getData('text/plain')
                console.log(pasteValue)
                var re = /<[^>]+>/gi;
                pasteValue = pasteValue.replace(re, '').replace(/\s+|[\r\n]/g,"");
                e.target.textContent += pasteValue
            },

			fabu(){
				var that=this;
                that.faloading=true;
				let data = {k: that.$refs.contents.innerHTML,};
                that.$emit('fabujian',data);
                that.$refs.contents.innerHTML='请输入备注或说明的内容。';
			}

        },
    };
</script>



