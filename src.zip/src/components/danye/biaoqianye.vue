<template>
<div id="biaoqianye"  @click="turnfresh()">
	<zu2logo k=1></zu2logo>
	<zu2errorpage v-if="errorid!==0" :errorid="errorid"></zu2errorpage>
	<el-container v-if="errorid===0">
		<el-aside width="120px" class="bgcolor_FF"></el-aside>
		<el-main class="bgcolor_FC font18px">
			<el-card v-if="bq_info.bq_id"  class="box-card">
				<el-row>
					<span class="font21px" style="float:left;">{{this.bq_info.bq_title}}</span>
				</el-row>
				<el-row>
					<span><b>属性<i class="el-icon-caret-right"></i></b></span>
					<span>标签ID:{{this.bq_info.bq_id}}<el-divider direction="vertical"></el-divider></span>
					<span>{{this.bq_info.bq_status}}<el-divider direction="vertical"></el-divider></span>
					<span><zu0showfanwei :qz_id="bq_info.bq_fanwei"></zu0showfanwei><el-divider direction="vertical"></el-divider></span>
					<span>管理人:
						<router-link class="a_black" target="_blank" :to="{name:'yonghuye',params:{id:bq_info.bq_manager}}">
							{{this.bq_info.bq_manager}}
						</router-link>
					</span>
					<zu0tongjishu :dj="bq_tongji.dianji" :gz="bq_tongji.guanzhu" :fx="bq_tongji.fenxiang"></zu0tongjishu>
				</el-row>
				<el-row>
					<b>说明<i class="el-icon-caret-right"></i></b><span v-html="bq_info.bq_remark"></span>
				</el-row>
				<zu0fujianfutu v-if="this.bq_info.fu!==0" :zhid="bq_info.bq_id"></zu0fujianfutu>
			</el-card>
			<el-card v-else>
				<br><div style="text-align:center;font-size:30px;"><i class="el-icon-loading"></i>正在加载</div><br>
			</el-card>
		</el-main>
		<el-aside width="120px" class="bgcolor_FC"></el-aside>

	</el-container>

	<el-container v-if="errorid===0">
		<el-aside width="120px">
			<el-menu default-active="11" class="el-menu-vertical-demo bgcolor_menu_FC" @open="handleOpen" @close="handleClose">
				<el-menu-item @click="daohang11" index="11" class="font18px">
				<span slot="title">包含内容</span>
				</el-menu-item>
				<el-menu-item @click="daohang12" index="12" class="font18px">
				<span slot="title">关注分享</span>
				</el-menu-item>
				<el-menu-item @click="daohang13" index="13" class="font18px">
				<span slot="title">评论</span>
				</el-menu-item>
				<!-- <el-menu-item @click="daohang14" index="14" class="font18px">
				<span slot="title">关联知识</span>
				</el-menu-item> -->
				<el-menu-item @click="daohang15" index="15" class="font18px">
				<span slot="title">标签管理</span>
				</el-menu-item>
			</el-menu>
		</el-aside>
		<el-main v-show="dh12" class="section_xh">
			<zu1caozuojishu zone_id="分享" :zhid="bq_info.bq_id" type0="biaoqianye" :title0="bq_info.bq_title" :fanwei="bq_info.bq_fanwei"></zu1caozuojishu>
			<br>
			<zu1caozuojishu zone_id="关注" :zhid="bq_info.bq_id" type0="biaoqianye" :title0="bq_info.bq_title"></zu1caozuojishu>
			<br>
			<zu1caozuojishu zone_id="纠错" :zhid="bq_info.bq_id" type0="biaoqianye" :title0="bq_info.bq_title"></zu1caozuojishu>
			<br>
		</el-main>
		<el-main v-show="dh13" class="section_xh">
			<xhcaozuo zoneid="评论" :zhid="bq_info.bq_id" :title0="bq_info.bq_title" type0="biaoqianye" :fanwei="bq_info.bq_fanwei" :listNum="bq_tongji.pinglun"></xhcaozuo>
		</el-main>
		<el-main v-show="dh14" class="section_xh"></el-main>
		<el-main v-show="dh15" class="section_xh">
			<xhchanged :zhid="bq_info.bq_id" zhitype="biaoqianye" :list='bq_info' :managerid="bq_info.bq_manager" :zhicontent="bq_info.bq_content" :fanwei="bq_info.bq_fanwei" :listNum="bq_tongji.xiugai"></xhchanged>
		</el-main>
		<el-main v-show="dh11" class="section_xh">
			<xhbqnei zoneid="标签里加入" :zhid="bq_info.bq_id" :title0="bq_info.bq_title" type0="biaoqianye" :manager="bq_info.bq_manager" :listNum="bq_tongji.neihan"></xhbqnei>
		</el-main>
		<el-aside width="120px" class="bgcolor_FC"></el-aside>
	</el-container>
</div>

</template>

<script>

import xhbqnei from '../xunhuan/xhbqnei';

export default {
        name:'biaoqianye',
		components: {xhbqnei,},
        methods:{
                    daohang11(){this.dh11=true;this.dh12=false;this.dh13=false;this.dh14=false;this.dh15=false;this.dh16=false;},
                    daohang12(){this.dh12=true;this.dh11=false;this.dh13=false;this.dh14=false;this.dh15=false;this.dh16=false;},
                    daohang13(){this.dh13=true;this.dh11=false;this.dh12=false;this.dh14=false;this.dh15=false;this.dh16=false;},
					daohang14(){this.dh14=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh15=false;this.dh16=false;},
                    daohang15(){this.dh15=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh14=false;this.dh16=false;},
                    daohang16(){this.dh16=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh14=false;this.dh15=false;},
					//这里的k值指的是关注数或分享数等等
					add1(k){
						if(k==1){this.bq_tongji.fenxiang++;}
						if(k==2){this.bq_tongji.guanzhu++;}
					},
					minus1(k){
						if(k==2){this.bq_tongji.guanzhu--;}
					},
				
		},
        data() {
			return {
				dh11:true,dh12:false,dh13:false,dh14:false,dh15:false,dh16:false,
				biaoqian_id:0,
				bq_info:[],
				bq_tongji:[],
				errorid:0,
				// showloading1:true,
			}
        },
        created() {
				
				this.biaoqian_id = this.$route.params.id;//获取上个页面传递的id,在下面获取数据的时候先提交id,这里的id不用加前缀
				var _this= this;
				_this.axios
					.post('http://www.zhishiren.info/api/show_biaoqianye/', {biaoqian_id:_this.biaoqian_id})
					.then(function (response) {
						_this.bq_info=response.data;
						_this.bq_tongji=JSON.parse(response.data.bq_tongji);
						_this.errorid=errorid_transfer(_this.bq_info.bq_fanwei);
				});

		},
		computed: {
				welcomename(){return this.$cookies.get('username')},
		},
};

</script>

<style scoped>

</style>




