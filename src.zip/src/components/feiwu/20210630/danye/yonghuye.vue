<template>
<div id="yonghuye"  @click="turnfresh()">
	<toubu0></toubu0>

		<el-container>
			<el-aside width="120px" class="bgcolor_FF"></el-aside>
			<el-main class="bgcolor_FC font18px">
            <el-row style="height:270px;">
				<el-card class="box-card">
					<el-col v-if="userinfo.yonghu_touxiang===1" :span="5" style="background-repeat:no-repeat;background-size:100% 100%;height:260px;text-align:center;">
						<div style="padding-top:100px;" class="a_grey font18px" v-if="show_touxiang===false">
							<a @click="showtouxiang()">
								<i class="el-icon-s-custom font20px"></i>
								<br>
								查看头像
							</a>
						</div>
						<img v-if="show_touxiang" alt="" :src="timestamp('https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/touxiang/'+this.yonghuid+'.jpg')" style="width:100%;height:250px;"> 
					</el-col>
					<el-col v-if="userinfo.yonghu_touxiang===0" :span="5" >
						<div v-if="userinfo.yonghu_type!=='工团企业'" style="background-repeat:no-repeat;background-size:100% 100%;height:255px;background-image:url(https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/touxiang/90000000.jpg);"></div>
						<div v-if="userinfo.yonghu_type==='工团企业'" style="background-repeat:no-repeat;background-size:100% 100%;height:255px;background-image:url(https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/touxiang/qiyelogo0.jpg);"></div>
					<!-- <el-col v-if="userinfo.yonghu_touxiang===0 && userinfo.yonghu_type==='工团企业'" :span="5" style="background-repeat:no-repeat;background-size:100% 100%;height:255px;background-image:url(https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/touxiang/qiyelogo.jpg);"> -->
					</el-col>
					<el-col :span="19">
						<div v-if="!userinfo.yonghu_id" style="height:250px;padding-left:10px;">
							<br><br><br><div style="text-align:center;font-size:50px;color:grey;"><i class="el-icon-loading"></i>正在加载</div>
						</div>
						<div v-if="userinfo.yonghu_type==='普通用户' || userinfo.yonghu_type==='内容整理'" class="font18px_gray" style="height:250px;padding-left:10px;">
							&nbsp;名称类型：<span class="font18px_black">{{this.userinfo.yonghu_name}}<el-divider direction="vertical"></el-divider><span>{{this.userinfo.yonghu_type}}</span>
												<!-- <a @click="xiugai_type"><i v-if="xiaozhi_id===90000106" class="el-icon-edit"></i></a>
												<input v-if="show_queding"  v-model="changed_type" type="text" class="font18px" style="width:80px;" >
												<a v-if="show_queding" @click="queding" class="font18px"><i class="el-icon-check"></i>确定</a> 
												<a v-if="show_queding" @click="huanyuan" class="font18px"><i class="el-icon-refresh-left"></i>还原</a> -->
										</span><br>
							&nbsp;用户ID号：<span class="font18px_black">{{this.userinfo.yonghu_id}}</span><span style="color:grey">
											<!-- <i class="el-icon-chat-dot-round"></i>聊天 -->
										</span><br>
							&nbsp;注册时间：<span class="font18px_black">{{getNowFormatDate(this.userinfo.yonghu_borntime)}}</span><br>
							&nbsp;最近登录：<span class="font18px_black">{{getNowFormatDate(this.userinfo.yonghu_updatetime)}}</span><br>
							&nbsp;行业岗位：<span class="font18px_black">{{this.userinfo.yonghu_job}}</span><br>
							&nbsp;国家地区：<span class="font18px_black">{{this.userinfo.yonghu_area}}</span><br>
							&nbsp;联系方式：<span class="font18px_black">{{this.userinfo.yonghu_contact}}</span><br>
							&nbsp;爱好特长：<span class="font18px_black">{{this.userinfo.yonghu_hobby}}</span><br>
							&nbsp;个人签名：<span class="font18px" style="color:brown;">{{this.userinfo.yonghu_remark}}</span><br>
							&nbsp;数据统计：<span class="font18px" style="color:green">
												<span>访问他{{this.userjishu.dianji}}<el-divider direction="vertical"></el-divider></span>
												<span>关注他{{this.userjishu.guanzhu}}<el-divider direction="vertical"></el-divider></span>
												<span>分享他{{this.userjishu.fenxiang}}</span><el-divider direction="vertical"></el-divider></span>
												<span style="color:black">屏蔽他{{this.userjishu.fenxiang}}</span>
										</span>
						</div>
						<div v-else-if="userinfo.yonghu_type==='历史人物'" class="font18px_gray" style="height:250px;padding-left:10px;">
							&nbsp;名称类型：<span class="font18px_black">{{this.userinfo.yonghu_name}}<el-divider direction="vertical"></el-divider><span>{{this.userinfo.yonghu_type}}</span>
										</span><br>
							&nbsp;用户ID号：<span class="font18px_black">{{this.userinfo.yonghu_id}}</span><span style="color:grey">
										</span><br>
							&nbsp;生卒年月：<span class="font18px_black">{{this.userinfo.yonghu_born}}<span style="color:grey">-</span>{{this.userinfo.yonghu_dead}}</span><br>
							<!-- &nbsp;生卒年月：<span class="font18px_black">{{this.userinfo.yonghu_born}}<el-divider direction="vertical"></el-divider>{{this.userinfo.yonghu_dead}}</span><br> -->
							&nbsp;职业身份：<span class="font18px_black">{{this.userinfo.yonghu_job}}</span><br>
							&nbsp;国家地区：<span class="font18px_black">{{this.userinfo.yonghu_area}}</span><br>
							&nbsp;人物名言：<span class="font18px" style="color:brown;">{{this.userinfo.yonghu_remark}}</span><br>
							&nbsp;数据统计：<span class="font18px" style="color:green">
												<span>访问他{{this.userjishu.dianji}}<el-divider direction="vertical"></el-divider></span>
												<span>关注他{{this.userjishu.guanzhu}}<el-divider direction="vertical"></el-divider></span>
												<span>分享他{{this.userjishu.fenxiang}}</span>
										</span>
							<br>
							生平事迹：<span>{{this.userinfo.yonghu_life}}</span>
						</div>
						<div v-else-if="userinfo.yonghu_type==='当代人物'" class="font18px_gray" style="height:250px;padding-left:10px;">
							&nbsp;人物名称：<span class="font18px_black">{{this.userinfo.yonghu_name}}<el-divider direction="vertical"></el-divider><span>{{this.userinfo.yonghu_type}}</span>
										</span><br>
							&nbsp;用户ID号：<span class="font18px_black">{{this.userinfo.yonghu_id}}</span><span style="color:grey">
										</span><br>
							&nbsp;生日地区：<span class="font18px_black">{{this.userinfo.yonghu_born}}<span style="color:grey">-</span>{{this.userinfo.yonghu_area}}</span><br>
							<!-- &nbsp;生卒年月：<span class="font18px_black">{{this.userinfo.yonghu_born}}<el-divider direction="vertical"></el-divider>{{this.userinfo.yonghu_dead}}</span><br> -->
							&nbsp;联系方式：<span class="font18px_black">{{this.userinfo.yonghu_contact}}</span><br>
							&nbsp;人物名言：<span class="font18px" style="color:brown;">{{this.userinfo.yonghu_remark}}</span><br>
							&nbsp;数据统计：<span class="font18px" style="color:green">
												<span>访问他{{this.userjishu.dianji}}<el-divider direction="vertical"></el-divider></span>
												<span>关注他{{this.userjishu.guanzhu}}<el-divider direction="vertical"></el-divider></span>
												<span>分享他{{this.userjishu.fenxiang}}</span>
										</span>
							<br>
							生平事迹：<span>{{this.userinfo.yonghu_life}}职业生涯+目前状态</span>
						</div>
						<div v-else-if="userinfo.yonghu_type==='工团企业'" class="font18px_gray" style="height:250px;padding-left:10px;">
							&nbsp;企业名称：<span class="font18px_black">{{this.userinfo.yonghu_name}}<el-divider direction="vertical"></el-divider><span>{{this.userinfo.yonghu_type}}</span>
										</span><br>
							&nbsp;企业ID号：<span class="font18px_black">{{this.userinfo.yonghu_id}}</span><span style="color:grey">
										</span><br>
							&nbsp;地区行业：<span class="font18px_black">{{this.userinfo.yonghu_area}}</span><br>
							&nbsp;联系方式：<span class="font18px" style="color:brown;">{{this.userinfo.yonghu_contact}}</span><br>
							&nbsp;数据统计：<span class="font18px" style="color:green">
												<span>访问它{{this.userjishu.dianji}}<el-divider direction="vertical"></el-divider></span>
												<span>关注它{{this.userjishu.guanzhu}}<el-divider direction="vertical"></el-divider></span>
												<span>分享它{{this.userjishu.fenxiang}}</span>
										</span>
							<br>
						    组织介绍：<span>{{this.userinfo.yonghu_life}}</span>
						</div>
					</el-col>
				</el-card>
				</el-row>

			</el-main>
		</el-container>

		<el-container>
			<el-aside width="120px">
				<el-menu default-active="12" class="el-menu-vertical-demo bgcolor_menu_FC" @open="handleOpen" @close="handleClose">
			      <el-menu-item @click="daohang11" index="11" class="font18px">
			        <span slot="title">公告动态</span>
			      </el-menu-item>
				  <el-menu-item @click="daohang12" index="12" class="font18px">
			        <span slot="title">关注分享</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang13" index="13" class="font18px">
			        <span slot="title">大家印象</span>
			      </el-menu-item>
			      <!-- <el-menu-item @click="daohang14" index="14" class="font18px">
			        <span slot="title">与他相关</span>
			      </el-menu-item> -->
                  <!-- <el-menu-item @click="daohang15" index="15" class="font18px">
			        <span slot="title">推荐阅读</span>
			      </el-menu-item>		       -->
			    </el-menu>
			</el-aside>
			<el-main v-show="dh12" class="section_xh">
						<tj0fenxiang @fxadd1="add1(1)" :zhid="userinfo.yonghu_id" zhitype="yonghuye" :zhititle="userinfo.yonghu_name" :zhitype1="userinfo.yonghu_type"></tj0fenxiang>
						<tj0guanzhu @gzadd1="add1(2)" @gzminus1="minus1(2)" :zhid="userinfo.yonghu_id" :zhititle="userinfo.yonghu_name" zhitype="yonghuye" bq_fanwei=0></tj0guanzhu>
						<tj0jiabiaoqian zhitype="yonghuye" :zhititle="userinfo.yonghu_name" :zhid="userinfo.yonghu_id"></tj0jiabiaoqian>
			</el-main>
			<el-main v-show="dh13" class="section_xh">
				<tj0yinxiang zhitype="yonghuye" :zhititle="userinfo.yonghu_name" :zhid="userinfo.yonghu_id"></tj0yinxiang>
			</el-main>
			<!-- <el-main v-show="dh14" class="section_xh">
			    该用户共有3条与他相关的知识。-展开-
			</el-main> -->
			<!-- <el-main v-show="dh15" class="section_xh">
            	<tj0tuijian></tj0tuijian>
			</el-main> -->
			<el-main v-show="dh11" class="section_xh">
				<zu2gonggao></zu2gonggao>

				<xhyhy11 :userid="userinfo.yonghu_id"></xhyhy11>
			</el-main>
			<el-aside width="120px" class="bgcolor_FC"></el-aside>

		</el-container>



	</div>

</template>

<script>



import tj0fenxiang from '../tijiao/tj_fenxiang';
import tj0guanzhu from '../tijiao/tj_guanzhu';
import tj0jiabiaoqian from '../tijiao/tj_jiabiaoqian';
import tj0jiucuo from '../tijiao/tj_jiucuo';
import tj0pinglun from '../tijiao/tj_pinglun';
import tj0guanlian from '../tijiao/tj_guanlian';
import tj0tuijian from '../tijiao/tj_tuijian';
import tj0yinxiang from '../tijiao/tj_yinxiang';

import bdg5 from '../biaodan/bdg5';
import xiazaishuji from '../fujian/xiazaishuji';
import toubu0 from '../fujian/toubu0';
import xhyhy11 from '../xunhuan/xhyhy11';

export default {
        name:'yonghuye',
		components: {xhyhy11,tj0yinxiang,tj0tuijian,toubu0,tj0guanzhu,tj0fenxiang,tj0jiabiaoqian,tj0pinglun,tj0guanlian,tj0jiucuo,bdg5,xiazaishuji},
        methods:{

                    daohang11(){this.dh11=true;this.dh12=false;this.dh13=false;this.dh14=false;this.dh15=false;this.dh16=false;},
                    daohang12(){this.dh12=true;this.dh11=false;this.dh13=false;this.dh14=false;this.dh15=false;this.dh16=false;},
                    daohang13(){this.dh13=true;this.dh11=false;this.dh12=false;this.dh14=false;this.dh15=false;this.dh16=false;},
                    daohang14(){this.dh14=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh15=false;this.dh16=false;},
                    daohang15(){this.dh15=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh14=false;this.dh16=false;},
					daohang16(){this.dh16=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh14=false;this.dh15=false;},
					//这里的k值指的是关注数或分享数等等
					add1(k){
						if(k==1){this.userjishu.fenxiang++;}
						if(k==2){this.userjishu.guanzhu++;}
					},
					minus1(k){
						if(k==2){this.userjishu.guanzhu--;}
					},
		
					showtouxiang(){
						this.show_touxiang=false;
						this.show_touxiang=true;
					},
					
				// xiugai_type(){
        		// 	this.show_queding=true;
				// },
				// queding(){
                //     var _this= this;
                //     if(this.changed_zhi==''){this.show_kongzhi=true}
                //     else{
                //         this.$axios
                //         .post('http://www.zhishiren.info/api/edit_mypage/', {userid: this.id,zhi:this.changed_zhi,zhi_type:this.type})
                //         .then(function(response){
                //             if (response.data.changed_ok === 0){
                //             _this.inputzhi0=_this.changed_zhi;
				// 			_this.show_queding=false;
							
                //             }
                //         })
                //     }
       			// },
				// huanyuan(){
				// this.show_queding=false;
				// },
		},
        data() {
			return {dh15:false,dh11:false,dh13:false,dh14:false,dh12:true,dh16:false,
			yonghuid:0,
			userinfo:[],
			userjishu:[],
			show_touxiang:false,mygonggao:''
			}
		},
		
		computed:{
			welcomename(){return this.$cookies.get('username')},
            xiaozhi_id(){return parseInt(this.$cookies.get('userid'))},

		},
        created() {
				this.yonghuid = this.$route.params.id;//获取上个页面传递的id,在下面获取数据的时候先提交id,这里的id不用加前缀
				var _this= this;
				_this.axios
					.post('http://www.zhishiren.info/api/show_yonghuye/',{userid:_this.yonghuid})
					.then(function (response) {
						_this.userinfo=response.data;
						_this.userjishu=JSON.parse(response.data.yh_tongji);
				});
				_this.axios
				.post('http://www.zhishiren.info/api/show_mygonggao/', {userid:_this.yonghuid})
				.then(function (response) {
					_this.mygonggao=response.data;
				});
        },
};






</script>






