<template>
    <div id="zu1caozuojishu" class="font18px" >
        <el-button @click="caozuo()" type="text" class="font18px" style="padding:0px;">
            <span v-if="zone_id==='分享'"><i class="el-icon-share"></i>分享...</span>
            <span v-if="zone_id==='关注'&&focused_yn===0"><i class="el-icon-view"></i>关注...</span>
            <span v-if="zone_id==='加入群组'&&focused_yn===0"><i class="el-icon-plus"></i>加入...</span>
            <span v-if="zone_id==='纠错'"><i class="el-icon-document-delete"></i>纠错...</span>
            <span v-if="zone_id==='发言密码'">发言密码...</span>

            <span v-if="zone_id==='邀请' && parseInt(this.managerid)===this.yonghuid"><i class="el-icon-thumb"></i>邀请...</span>
            <span v-if="zone_id==='评论'"><i class="el-icon-s-comment"></i>评论...</span>
            <span v-if="zone_id==='解答'"><i class="el-icon-microphone"></i>解答...</span>
            <span v-if="zone_id==='关联'"><i class="el-icon-connection"></i>关联...</span>
            <span v-if="zone_id==='加入标签'"><i class="el-icon-plus"></i>标签...</span>
            <span v-if="zone_id==='评价' && parseInt(this.zhid)!==yonghuid"><i class="el-icon-s-comment"></i>评价...</span>
            <span v-if="zone_id==='发言'"><i class="el-icon-microphone"></i>发言...</span>
            <span v-if="zone_id==='提问'"><i class="el-icon-microphone"></i>提问...</span>
            <span v-if="zone_id==='群发言'"><i class="el-icon-microphone"></i>发言...</span>
            <span v-if="zone_id==='发言列表' && parseInt(this.createrid)===yonghuid"><i class="el-icon-microphone"></i>发言...</span>
            <span v-if="zone_id==='提问列表' && parseInt(this.createrid)===yonghuid"><i class="el-icon-microphone"></i>提问...</span>

            <span v-if="zone_id==='标签里加入' && parseInt(this.managerid)===this.yonghuid">添加内容...</span>
            <span v-if="zone_id==='添加段落' && parseInt(this.managerid)===this.yonghuid"><i class="el-icon-plus"></i>段落...</span>
        </el-button>
		<span v-show="zone_id==='关注'&&focused_yn!==0" style="color:blue;">
			<el-button @click="quguanjian()" type="text" class="font18px" style="padding:0px;"><i class="el-icon-close"></i>取关...</el-button>
			<span>你已经关注了。</span>
		</span>
		<span v-show="zone_id==='加入群组'&&focused_yn!==0" style="color:blue;">
			<el-button @click="quguanjian()" type="text" class="font18px" style="padding:0px;"><i class="el-icon-close"></i>退出...</el-button>
			<span>你已经加入这个群组了。</span>
		</span>

		<span v-if="yonghuid===parseInt(zhid) && zone_id==='关注' && type0==='yonghuye'">你不能关注你自己。</span>

        <span v-if="zone_id==='分享'"><span class="msg_ok" v-if="msg===1">分享成功！</span>分享后将在“今日动态”中显示。</span>
        <span v-if="zone_id==='关注'&&focused_yn===0"><span class="msg_ok" v-if="msg===1">关注成功！</span>关注后将在“关注收藏”中显示。</span>
        <span v-if="zone_id==='加入群组'&&focused_yn===0"><span class="msg_ok" v-if="msg===1">加群成功！</span>加入群组后将在“用户与群”中显示。</span>
        <span v-if="zone_id==='纠错'"><span class="msg_ok" v-if="msg===1">发送成功！</span>纠错信息将反馈给后台管理员。</span>
        <span v-if="zone_id==='邀请'"><span class="msg_ok" v-if="msg===1">操作成功！</span></span>

        <span>
            <span v-if="zone_id==='11'">你和关注用户共有</span>
            <span v-if="zone_id==='12'">你关注的知识点共有</span>
            <span v-if="zone_id==='13'">你共有</span>
            <span v-if="zone_id==='14'">你共有</span>
            <span v-if="zone_id==='21'">你共关注了</span>
            <span v-if="zone_id==='22'">你共关注了</span>
            <span v-if="zone_id==='23'">你共关注了</span>
            <span v-if="zone_id==='24'">你共关注了</span>
            <span v-if="zone_id==='27'">你共关注了</span>

            <span v-if="zone_id==='32'">你共关注了</span>
            <span v-if="zone_id==='31'">全站共有</span>
            <span v-if="zone_id==='36'">全站共有</span>
            <span v-if="zone_id==='37'">全站共有</span>
            <span v-if="zone_id==='33'">你被</span>
            <span v-if="zone_id==='34'">全站共有</span>
            <span v-if="zone_id==='35'">你共加入了</span>

            <span v-if="zone_id==='43'">我共收到</span>
            
            <span v-if="zone_id==='souwenji'">全站共计</span>
            <span v-if="zone_id==='souwenduan'">全站共计</span>
            <span v-if="zone_id==='soubiaoqian'">全站共计</span>
            <span v-if="zone_id==='soufayan'">全站共计</span>
            <span v-if="zone_id==='soufuyan'">全站共计</span>
            <span v-if="zone_id==='shenfayan'">等待审核的用户发言。</span>
            <span v-if="zone_id==='shenfuyan'">等待审核的用户附言。</span>
            <span v-if="zone_id==='fyrejected'">已经拒绝的用户发言和附言。</span>
            <span v-if="zone_id==='fypassed'">已经通过的用户发言和附言。</span>
            <span v-if="zone_id==='shenyh0'">等待审核的用户申请。</span>
            <span v-if="zone_id==='shenyh1'">用户最近修改的身份信息。</span>
            <span v-if="zone_id==='xzwj'">你共曾新增</span>
            <span v-if="zone_id==='xzqz'">你共曾新增</span>
            <span v-if="zone_id==='xzfy'">你共曾有</span>
            <span v-if="zone_id==='wen1'">你共曾有</span>
            <span v-if="zone_id==='xzbq'">你共曾新增</span>
            <span v-if="zone_id==='wen2'">你提问的问题共收到</span>
            <span v-if="zone_id==='wen3'">本站共有</span>
            <span v-if="zone_id==='评论'">
                <span v-if="type0==='wenjiye'">该文辑</span>
                <span v-if="type0==='yonghuye'">该用户</span>
                <span v-if="type0==='wenduanye'">该段落</span>
                <span v-if="type0==='qunzuye'">该群组</span>
                <span v-if="type0==='biaoqianye'">该标签</span>
                <span v-if="type0==='fayanye'">该发言</span>
                <span>共有</span>
            </span>
            <span v-if="zone_id==='解答'">
                <span v-if="type0==='fayanye'">该提问</span>
                <span>共有</span>
            </span>
            <span v-if="zone_id==='评价'">{{parseInt(this.zhid)===yonghuid?'我':'该用户'}}共收到</span>
            <span v-if="zone_id==='加入标签'">
                <span v-if="type0==='wenjiye'">该文辑</span>
                <span v-if="type0==='yonghuye'">该用户</span>
                <span v-if="type0==='wenduanye'">该段落</span>
                <span v-if="type0==='qunzuye'">该群组</span>
                <span>共有</span>
            </span>
            <span v-if="zone_id==='发言密码'">你曾经设置的发言密码。</span>
            <span v-if="zone_id==='添加段落'">此文辑已有</span>
            <span v-if="zone_id==='邀请'">此群组已有</span>
            <span v-if="zone_id==='关联'">
                <span v-if="type0==='wenjiye'">该文辑</span>
                <!-- <span v-if="type0==='yonghuye'">该用户</span> -->
                <span v-if="type0==='wenduanye'">该段落</span>
                <!-- <span v-if="type0==='qunzuye'">该群组</span> -->
                <span>已有</span>
            </span>
            <span v-if="zone_id==='标签里加入'">该标签共包含</span>
            <span v-if="zone_id==='发言列表'">该用户共有</span>
            <span v-if="zone_id==='提问列表'">该用户共有</span>
            <span v-if="zone_id==='发言'">我共有</span>
            <span v-if="zone_id==='群发言'">这个群里共有</span>
            <span v-if="zone_id==='TA动态'">TA共有</span>
            
            <span v-if="jishu!==undefined">
                <span v-if="showloading1===false">{{this.jishu}}</span>
                <span v-if="showloading1"><i class="el-icon-loading"></i></span>
            </span>

            <span v-if="zone_id==='11'">条动态。</span>
            <span v-if="zone_id==='12'">条动态。</span>
            <span v-if="zone_id==='13'">条互动信息。</span>
            <span v-if="zone_id==='14'">条系统通知。</span>
            <span v-if="zone_id==='21'">条标签。</span>
            <span v-if="zone_id==='22'">条书辑。</span>
            <span v-if="zone_id==='23'">条段落。</span>
            <span v-if="zone_id==='24'">条发言提问。</span>
            <span v-if="zone_id==='27'">名用户。</span>
            
            <span v-if="zone_id==='32'">名用户。</span>
            <span v-if="zone_id==='34'">个群组。</span>
            <span v-if="zone_id==='35'">个群组。</span>
            <span v-if="zone_id==='31'">名用户，优先展示最新10名。</span>
            <span v-if="zone_id==='36'">名历史人物名片。</span>
            <span v-if="zone_id==='37'">个左翼组织名片。</span>
            <span v-if="zone_id==='33'">名用户关注。</span>

            <span v-if="zone_id==='43'">条评价。</span>

            <span v-if="zone_id==='souwenji'">部文集。</span>
            <span v-if="zone_id==='souwenduan'">条文段，为你推荐最新的10条。</span>
            <span v-if="zone_id==='soubiaoqian'">条标签，为你推荐最新的10条。</span>
            <span v-if="zone_id==='soufayan'">条用户发言，为你推荐最新的10条。</span>
            <span v-if="zone_id==='soufuyan'">条附言，为你推荐最新的10条。</span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span v-if="zone_id==='xzwj'">部文集。</span>
            <span v-if="zone_id==='xzqz'">个群组。</span>
            <span v-if="zone_id==='xzfy'">条发言。</span>
            <span v-if="zone_id==='wen1'">条提问。</span>
            <span v-if="zone_id==='xzbq'">条标签。</span>
            <span v-if="zone_id==='wen2'">
                <span>条解答。</span>
                <!-- <span v-if="jishu===0">。</span> -->
                <!-- <span v-if="jishu!==0">,最新解答是{{qian_date(this.lastjiedatime)}}。</span> -->
            </span>
            <span v-if="zone_id==='wen3'">条提问。</span>
            <span v-if="zone_id==='评论'">条评论。</span>
            <span v-if="zone_id==='评价'">条评价。</span>
            <span v-if="zone_id==='解答'">条解答。</span>
            <span v-if="zone_id==='加入标签'">条标签。</span>
            <span v-if="zone_id==='添加段落'">条段落。</span>
            <span v-if="zone_id==='邀请'">名组员。</span>
            <span v-if="zone_id==='关联'">条关联知识。</span>
            <span v-if="zone_id==='标签里加入'">条内容。</span>
            <span v-if="zone_id==='发言列表'">条发言。</span>
            <span v-if="zone_id==='提问列表'">条问题。</span>
            <span v-if="zone_id==='发言'">条动态。</span>
            <span v-if="zone_id==='群发言'">条动态。</span>
            <span v-if="zone_id==='TA动态'">条动态。</span>

            <!-- <span v-if="jishu1">
                <span>，其中</span>
                <span v-if="showloading1===false">{{this.jishu1}}</span>
                <span v-if="showloading1"><i class="el-icon-loading"></i></span>
                <span>条正在审核</span>            
            </span> -->

        </span>
        <span v-if="zone_id!=='分享'&&zone_id!=='关注'&&zone_id!=='加入群组'&&zone_id!=='纠错'">
            <a class="a_black" v-show="show_zhankai" @click="zhankaijian()">-展开-</a> 
            <transition name="el-zoom-in-center">
                <span v-if="parseInt(zone_id)<20 || parseInt(zone_id)>40 
                    || zone_id==='发言密码' || zone_id==='评论' || zone_id==='解答' ||zone_id==='评价' || zone_id==='加入标签'|| zone_id==='关联' || zone_id==='标签里加入' 
                    ||zone_id==='发言'||zone_id==='发言列表' ||zone_id==='提问列表' ||zone_id==='群发言' 
                    || zone_id==='xzfy' || zone_id==='xzbq' || zone_id==='xzwd' || zone_id==='xzwj' || zone_id==='xzqz' 
                    || zone_id==='souwenji' || zone_id==='souwenduan' || zone_id==='soubiaoqian' || zone_id==='soufuyan' || zone_id==='soufayan' 
                    ||zone_id==='TA动态' || zone_id==='wen1'|| zone_id==='wen2'|| zone_id==='wen3'
                    ||zone_id==='shenfuyan'||zone_id==='shenfayan'||zone_id==='fyrejected'||zone_id==='fypassed'||zone_id==='shenyh0'||zone_id==='shenyh1'">
                    <a v-if="show_zhankai===false" class="a_black" @click="shuaxinjian()"><i class="el-icon-refresh"></i>刷新</a>
                </span>
            </transition>
            <transition name="el-zoom-in-center">
                <span v-if="(parseInt(zone_id)>20 && parseInt(zone_id)<40 && show_zhankai===false) || (zone_id==='添加段落' && show_zhankai===false) || (zone_id==='邀请' && show_zhankai===false)">
                    <input type="text" class="input_jian font18px" size="mini" v-model="keyword" placeholder="在以下结果中查找">
                    <a class="a_black" @click="chazhaojian(keyword)"><i class="el-icon-search"></i>查找</a>
                    <span style="color:orange" v-show="show_chazhaokong"><i class="el-icon-warning"></i>关键词不能为空!</span>
                    <span style="color:blue" v-show="show_huanyuan"><i class="el-icon-finished"></i>{{this.listNumk}}个结果</span>
                    <a class="a_black" @click="huanyuanjian()"  v-show="show_huanyuan"><i class="el-icon-refresh-left"></i>还原</a>
                    <a class="a_black" @click="shuaxinjian()"   v-show="show_huanyuan===false"><i class="el-icon-refresh"></i>刷新</a>
                </span>
            </transition>
        </span>
        <br>
        <div v-if="listNumk===0 && show_huanyuan" style="font-size:30px;color:grey;text-align:center;">
            <i class="el-icon-info"></i>查询无结果
        </div>
        <div v-if="showloading2" style="font-size:30px;color:grey;">
            <i class="el-icon-loading"></i>正在加载...
        </div>

		<el-dialog :title="zone_id+'的设置...'" width="400px" :visible.sync="show_dialog">
            <br>
            <el-row v-if="zone_id==='发言'||zone_id==='群发言'||zone_id==='发言列表'" class="font18px" >
                <el-col :span="7" style="padding-top:10px;">
                    <span>发言类型：</span>
                </el-col>
                <el-col :span="17">
                    <el-select v-model="fytype" placeholder="请选择发言的类型" style="width:90%;">
                            <el-option value="求助询问" key="求助询问" label="求助询问"></el-option>
                            <el-option value="新闻简讯" key="新闻简讯" label="新闻简讯"></el-option>
                            <el-option value="公告通知" key="公告通知" label="公告通知"></el-option>
                            <el-option value="感悟思考" key="感悟思考" label="感悟思考"></el-option>
                            <el-option value="名人名言" key="名人名言" label="名人名言"></el-option>
                            <el-option value="公开言论" key="公开言论" label="公开言论"></el-option>
                    </el-select>
                </el-col>
            </el-row>
            <el-row v-if="zone_id==='发言'||zone_id==='群发言'||zone_id==='发言列表'"><br></el-row>

            <el-row v-if="zone_id==='评价' || zone_id==='评论'">
                <el-col :span="7" class="font18px" style="padding-top:10px;">
                    是否匿名：
                </el-col>
                <el-col :span="17">
                    <el-select v-model="niming" placeholder="请选择发言的类型" style="width:90%;">
                        <el-option value="不匿名" key="不匿名" label="不匿名"></el-option>
                        <el-option value="匿名" key="匿名" label="匿名"></el-option>
                    </el-select>
                </el-col>
            </el-row>
            <el-row v-if="zone_id==='评价' || zone_id==='评论'"><br></el-row>

            <el-row v-if="zone_id==='关联'||zone_id==='加入群组'||zone_id==='邀请'||zone_id==='标签里加入'||zone_id==='发言密码'||zone_id==='添加段落'" class="font18px">
                <el-col :span="7" class="font18px" style="padding-top:10px;">
                    <span v-if="zone_id==='标签里加入'">知识ID号：</span>
                    <span v-if="zone_id==='关联'">关联ID号：</span>
                    <span v-if="zone_id==='加入群组'">八位密码：</span>
                    <span v-if="zone_id==='发言密码'">八位密码：</span>
                    <span v-if="zone_id==='邀请'">用户ID号：</span>
                    <span v-if="zone_id==='添加段落'">段落标题：</span>
                </el-col>
                <el-col :span="17">
                    <el-input v-if="zone_id!=='添加段落'" v-model="id1" style="width:90%" placeholder="请输入数字格式"></el-input>
                    <el-input v-if="zone_id==='添加段落'" v-model="id1" style="width:90%" placeholder="请输入段落标题"></el-input> 
                </el-col>
            </el-row>
            <el-row v-if="zone_id==='关联'||zone_id==='加入群组'||zone_id==='邀请'||zone_id==='标签里加入'||zone_id==='发言密码'||zone_id==='添加段落'"><br></el-row>

            <el-row v-if="zone_id==='发言' || zone_id==='分享' || zone_id==='评论' || zone_id==='关联'|| zone_id==='评价'||zone_id==='群发言'||zone_id==='发言列表'"  class="font18px" >
                <el-col :span="7" style="padding-top:10px;" >
                    <span v-if="zone_id!=='群发言'&&zone_id!=='发言列表'">{{this.zone_id}}态度：</span>
                    <span v-if="zone_id==='群发言'">发言态度：</span>
                    <span v-if="zone_id==='发言列表'">发言态度：</span>
                </el-col>
                <el-col :span="17" >
                    <el-select v-model="fyatt" placeholder="请选择态度" style="width:90%;">
                        <el-option value="无态度" key="无态度" label="无态度"></el-option>
					    <el-option v-if="zone_id==='发言'||zone_id==='群发言'||zone_id==='发言列表'" value="紧急重要" key="紧急重要" label="紧急重要"></el-option>
						<el-option v-if="zone_id==='分享'" value="强烈推荐" key="强烈推荐" label="强烈推荐"></el-option>
                        <span v-if="zone_id==='评论'">
                            <el-option value="反对异议" key="反对异议" label="反对异议"></el-option>
                            <el-option value="点赞支持" key="点赞支持" label="点赞支持"></el-option>
                            <el-option value="疑惑不解" key="疑惑不解" label="疑惑不解"></el-option>
                        </span>
                        <span v-if="zone_id==='评价'">
                            <el-option value="聪明绝顶" key="聪明绝顶" label="聪明绝顶"></el-option>
                            <el-option value="古道心肠" key="古道心肠" label="古道心肠"></el-option>
                            <el-option value="一言九鼎" key="一言九鼎" label="一言九鼎"></el-option>
                            <el-option value="言论怪异" key="言论怪异" label="言论怪异"></el-option>
                            <el-option value="让人困惑" key="让人困惑" label="让人困惑"></el-option>
                            <el-option value="胡说八道" key="胡说八道" label="胡说八道"></el-option>
                        </span>
                        <span v-if="zone_id==='关联'">
                            <el-option value="矛盾" key="矛盾" label="矛盾"></el-option>
                            <el-option value="互补" key="互补" label="互补"></el-option>
                            <el-option value="更细化" key="更细化" label="更细化"></el-option>
                        </span>
                    </el-select>                
                </el-col>
            </el-row>
            <el-row v-if="zone_id==='发言' ||zone_id==='发言列表' || zone_id==='分享' || zone_id==='评论' || zone_id==='关联'|| zone_id==='评价'||zone_id==='群发言'" ><br></el-row>

            <el-row v-if="zone_id==='发言'||zone_id==='发言列表'"  class="font18px">
                <el-col :span="7" style="padding-top:10px;" >
                    <span>公开范围：</span>
                </el-col>
                <el-col :span="17" >
                    <zu0setfanwei ref="huanyuan" @set_fanwei="set_gongkaifanwei" style="width:90%;"></zu0setfanwei>
                </el-col>
            </el-row>
            <el-row v-if="zone_id==='发言'||zone_id==='发言列表'"><br></el-row>

            <el-row v-if="zone_id==='分享'"  class="font18px">
				<el-col :span="7" class="font18px" style="padding-top:10px;">
					公开范围：
				</el-col>
				<el-col :span="17">
					<el-select v-if="fanweizhi===0 || fanweizhi===1" v-model="qz_id" @focus="show_qzlist" placeholder="请选择"  style="width:90%;">
						<el-option
						v-for="item in lists"
						:key="item.qz_id"
						:label="item.qz_title"
						:value="item.qz_id">
						</el-option>
					</el-select> 
					<el-select v-if="fanweizhi===8" :placeholder="'仅'+this.fanwei+'可见'" disabled style="width:90%;"></el-select>
				</el-col>
			</el-row>
            <el-row  v-if="zone_id==='分享'"><br></el-row>


            <el-row v-if="zone_id==='加入标签'" class="font18px">
                <el-col :span="7" class="font18px" style="padding-top:10px;">
                    选择标签：
                </el-col>
                <el-col :span="17">
                    <el-select @focus="show_bqlist" v-model="bq_id" placeholder="在我创建或关注的标签中选择"  style="width:90%;">
                        <el-option
                            v-for="item in bqlists"
                            :key="item.bq_id"
                            :label="item.bq_title"
                            :value="item.bq_id+item.bq_title+item.bq_fanwei">
                        </el-option>
                    </el-select> 
                </el-col>
            </el-row>
            <el-row v-if="zone_id==='加入标签'"><br></el-row>

            <el-row >
                <div  v-if="zone_id!=='发言密码' && zone_id!=='添加段落'" contenteditable ref="contents" @paste="onPaste" class="pinglunlan">请输入发言/附言的内容。</div>
                <div  v-if="zone_id==='发言密码'" contenteditable ref="contents" @paste="onPaste" class="pinglunlan">请输入用于回忆密码的提示信息。</div>
                <div  v-if="zone_id==='添加段落'" contenteditable ref="contents" @paste="onPaste" class="pinglunlan">请输入段落内容。</div>
            </el-row>

            <el-row class="font18px">
                <el-col :span="7">
                    <a v-if="zone_id!=='发言密码'" class="a_black" href="javascript:;" @click="f_blod">
                        <b>所选加粗</b>
                    </a>
                </el-col>
                <el-col :span="7">
                </el-col>
                <el-col :span="10" style="text-align:right" class="font20px">
                    <span v-if="faloading===false">
                        <span v-if="zone_id==='分享'||zone_id==='评论'||zone_id==='解答'||zone_id==='关联'||zone_id==='加入标签'||zone_id==='评价'||zone_id==='发言'||zone_id==='标签里加入'||zone_id==='群发言'||zone_id==='发言列表'">
                            <a class="a_black" @click="fabujian(0)">明发</a>
                            <el-divider direction="vertical"></el-divider>
                            <a class="a_black" @click="fabujian(1)">密发</a>
                        </span>
                        <span  v-if="zone_id==='关注'||zone_id==='纠错'||zone_id==='邀请'||zone_id==='加入群组'">
                            <a class="a_black" @click="fabujian(0)">确定</a>
                        </span>
                        <span  v-if="zone_id==='发言密码'||zone_id==='添加段落'">
                            <a class="a_black" @click="fabujian(2)">确定</a>
                        </span>
                    </span>
                    <span v-if="faloading"><i class="el-icon-loading"></i>正在发布...</span>
                </el-col>
            </el-row>
			<el-row class="msg_orange" v-show="fanweizhi===8 && zone_id==='分享'"><i class="el-icon-info"></i>你只能分享给指定的群组{{this.fanwei}}</el-row>
            <el-row class="msg_orange" v-show="fanweizhi===1 && zone_id==='分享'"><i class="el-icon-info"></i>原知识点的公开范围<b>并非</b>所有人</el-row>
            <el-row class="msg_red" v-if="msg===2"><i class="el-icon-info"></i>操作失败！</el-row>
            <el-row class="msg_red" v-if="msg===5"><i class="el-icon-info"></i>评论内容不能为空！</el-row>
            <el-row class="msg_red" v-if="msg===7"><i class="el-icon-info"></i>不可以重复操作！</el-row>
            <el-row class="msg_red" v-if="msg===9"><i class="el-icon-info"></i>须在10000000和99999999之间！</el-row>
        </el-dialog>

    </div>
</template>

<script>
    export default {
        name:'zu1caozuojishu',
        props:['zone_id','jishu','showloading1','showloading2',
        'listNumk',//这是用于判断查找后结果为零的情况
        'zhid','title0','type0',//这个type0是用于判断是否为用户页或群组的
        'fanwei',//只在分享，关联，评论，标签，标签内加入，等处才能用到
        // 'fytype',
        'createrid','creatername',//这个creatername用来录入被操作的原始人员
        'managerid',//仅用于群组页面，用来判断是不是群组管理员
        //一般只需要zhid,title0,type0,fanwei,只有在fayanye中才需要createrid和name
        // 'lastjiedatime',//这仅用于wen2组件里
        ],
        
        data() {return {
            show_zhankai:true,
            keyword:'',
            show_chazhaokong:false,
            show_huanyuan:false,

            show_dialog:false,
            fytype:'',
            fyatt:'',
            id1:null,
            lists: [{qz_id:90000000,qz_title:"--所有人--"}],
		    qz_id:90000000,
            bq_id:null,
            fyfanwei:90000000,
            faloading:false,
            msg:0,
            focused_yn:0,
            bqlists:[],
            niming:'不匿名',
            fy:''
        }},
        computed:{
			fanweizhi(){
                    var cid=parseInt(this.createrid);
                    var coid=parseInt(this.$cookies.get('userid'));
                    var fanwei_zhi=parseInt(this.fanwei);
                    if(this.type0==='yonghuye' || this.type0==='qunzuye' || fanwei_zhi===90000000){return 0}
                    else{
                        if(cid===coid){return 1}//这说明分享者是创建者本人
                        else{
                            if(this.fanwei_zhi===80000000){return 2}//这代表分享者不是创建人且原知识点的范围仅为本人
                            else{return 8}//这代表分享者不是创建人且原知识点的范围为某群组
                        }
                    }
                },
            yonghuid(){return parseInt(this.$cookies.get('userid'))},
            watchObj () {
                let {zhid,zone_id} = this;
                return {zhid,zone_id}
            },
            
        },
        methods:{
            zhankaijian(){
                this.show_zhankai=false;
                this.$emit('zhankai');
            },

            shuaxinjian(){
                this.show_zhankai=false;
                this.$emit('shuaxin');
            },

            shuaxinjian_duanluo1(){
                //这是用于"增添新的段落"后,让段落列表逆序形式展示最新的增加段落。
                this.show_zhankai=false;
                this.$emit('shuaxinduanluo1');
            },

			chazhaojian(keyword){
                var _this= this;
                if(keyword==''){
                    // 这是说明刚展开的阶段，这是输入空值后的表现
                    _this.show_chazhaokong=true;
                    setTimeout(function(){_this.show_chazhaokong=false;}, 1500);
                }else{
                    _this.show_huanyuan=false;
                    _this.show_huanyuan=true;
                    _this.show_chazhaokong=false;
                    let data = {k: keyword};
                    this.$emit('send_searchword',data);
                    _this.keyword='';
                }
            },

            huanyuanjian(){
                this.show_huanyuan=false;
                this.keyword='';
                this.$emit('huanyuan');
            },


            caozuo(){this.show_dialog=true;},

            set_gongkaifanwei(data){this.fyfanwei = data.qz_id;},

            show_qzlist(){
                var that = this;
                that.axios
                .post('http://www.zhishiren.info/api/listmyqunzu/', {userid: that.$cookies.get('userid'),cztype:that.zone_id})
                .then(response=>{that.lists=response.data;});
            },

            show_bqlist(){
                var that = this;
                that.axios
                .post('http://www.zhishiren.info/api/listmybiaoqian/', {userid: that.$cookies.get('userid')})
                .then(response=>{that.bqlists=response.data;})
            },

            f_blod() {document.execCommand ( 'bold', false );},
            
            onPaste: function(e) {
                    e.preventDefault()
                    e.stopPropagation()
                    let pasteValue = (e.clipboardData || window.clipboardData).getData('text/plain')
                    console.log(pasteValue)
                    var re = /<[^>]+>/gi;
                    pasteValue = pasteValue.replace(re, '').replace(/\s+|[\r\n]/g,"");
                    e.target.textContent += pasteValue
            },

            quguanjian(){
                this.axios
                    .post('http://www.zhishiren.info/api/change_caozuo/',{
                        czid:this.focused_yn,
                        czxxx:"失效已删"
                    })
                    .then(response=>{
                        if (response.data.msg === 1){
                            // this.$emit("gzminus1");
                            this.focused_yn=0;
                            let chuan=this.$cookies.get('chuan');
                            let id_=this.zhid+'_';
                            chuan=chuan.replace(id_,"");
                            this.$cookies.set('chuan',chuan,'8h');

                        }else{
                            that.msg=2;
                            setTimeout(function(){that.msg=0;}, 2000);
                        }
                        }
                    );
            },

            fabujian(mi){
                var that = this;
                that.faloading=true;
                if(that.zone_id==='群发言'){that.fyfanwei=that.fanwei;};
                if(that.$refs.contents.innerHTML==='请输入发言/附言的内容。' && (that.zone_id==='评论'||that.zone_id==='发言'||that.zone_id==='群发言')){
                    that.msg=5;
                    setTimeout(function(){that.msg=0;}, 2000);
                    that.faloading=false;
                }
                else if(that.$refs.contents.innerHTML==='请输入用于回忆密码的提示信息。' && that.zone_id==='发言密码'){
                    that.msg=5;
                    setTimeout(function(){that.msg=0;}, 2000);
                    that.faloading=false;
                }
                else if(that.$refs.contents.innerHTML==='请输入段落内容。' && that.zone_id==='添加段落'){
                    that.msg=5;
                    setTimeout(function(){that.msg=0;}, 2000);
                    that.faloading=false;
                }
                else if (that.zone_id==='发言密码' && (that.id1.replace(/\D/g, '')<10000000 || that.id1.replace(/\D/g, '')>99999999)){
                    // var idmima=that.id1.replace(/\D/g, '');
                    // if(idmima<10000000 || idmima>99999999){
                        that.msg=9;
                        setTimeout(function(){that.msg=0;}, 2000);
                        that.faloading=false;
                    // }
                }
                else{
                    if(that.$refs.contents.innerHTML==='请输入发言/附言的内容。'||that.$refs.contents.innerHTML===''){that.fy='无';};
                    if(that.$refs.contents.innerHTML!=='请输入发言/附言的内容。'&&that.$refs.contents.innerHTML!==''){
                        that.fy=that.$refs.contents.innerHTML;
                    };
                    if(that.fanweizhi===8){
                        that.qz_id=that.fanwei;
                    };
                    that.axios
                    .post('http://www.zhishiren.info/api/to_caozuo/',{
                        cztype:that.zone_id,
                        fy:that.fy,
                        fymm:that.$cookies.get('fayanmima'),

                        fytype:that.fytype,
                        fyatt:that.fyatt,
                        fymi:mi,
                        fyniming:that.niming,
                        fyfanwei_fx:that.qz_id,
                        fyfanwei:that.fyfanwei,
                        bq_id:that.bq_id,
                        fyhui:that.fyhui,

                        id0:that.zhid,
                        title0:that.title0,
                        type0:that.type0,
                        id1:that.id1,

                        uid: that.$cookies.get('userid'),
                        uname:that.$cookies.get('username'),
                        })
                    .then(function (response) {
                        if (response.data.msg === 1){
                            that.msg=response.data.msg;
                            that.$refs.contents.innerHTML='请输入发言/附言的内容。';
                            that.show_dialog=false;
                            that.qz_id=90000000;
                            that.lists=[{qz_id:90000000,qz_title:"--所有人--"}];
                            that.bq_id=null;
                            if(that.zone_id==="关注"||that.zone_id==="加入群组"){
                                that.focused_yn=response.data.focused_id;
                                let chuan=that.$cookies.get('chuan');
                                chuan=chuan+that.zhid+'_';
                                that.$cookies.set('chuan',chuan,'8h');
                                };
                            that.faloading=false;
                            setTimeout(function(){that.msg=0;}, 2000);
                            // that.$emit('shuaxin');
                            if(that.zone_id==="添加段落"){that.shuaxinjian_duanluo1()}else{that.shuaxinjian();};
                            // that.$emit('add1');
                            if(that.zone_id==='发言密码'){that.$cookies.set('fayanmima',that.id1,'8h');};
                        }
                        else if(response.data.msg === 7){
                            that.msg=response.data.msg;
                            setTimeout(function(){that.msg=0;}, 2000);
                            that.faloading=false;
                        }
                        else{
                                that.msg=response.data.msg;
                                setTimeout(function(){that.msg=0;}, 2000);
                                that.$refs.contents.innerHTML='请输入发言/附言的内容。';
                                // that.show_dialog=false;
                                that.faloading=false;
                        }
                    });
                }
            },
        },
        watch: {
            // watchObj: function(newVal,oldVal){
			// 	this.zhi_id = newVal;
			// 	this.axios
			// 		.post('http://www.zhishiren.info/api/check_focused/',{
			// 			zhi_id:this.zhi_id,
			// 			userid:this.$cookies.get('userid'),
			// 		})
			// 		.then(response=>{
			// 			this.focused_yn=response.data.focused_id;
			//     });
            // },

            //以下是两个变量的watch,zone_id先行判断是不是关注，从而再进行查询，节省查询次数
            watchObj:{
                handler(newVal, oldVal){
                    if(newVal.zone_id==='关注'||newVal.zone_id==='加入群组'){
                    	this.axios
                    		.post('http://www.zhishiren.info/api/check_focused/',{
                    			zhi_id:newVal.zhid,
                    			userid:this.$cookies.get('userid'),
                    		})
                    		.then(response=>{
                    			this.focused_yn=response.data.focused_id;
                        });
                    }
                },
                deep: true,
                immediate: true
            }
        },
    };
</script>

<style scoped>
	 .msg_ok{font-size:18px;color:green;text-align: center;} 
	 .msg_orange{font-size:18px;color:orange;text-align: center;} 
	 .msg_red{font-size:18px;color:red;text-align: center;} 
</style>



