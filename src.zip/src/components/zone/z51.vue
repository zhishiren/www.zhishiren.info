<template>
    <div id="z51" style="font-size:20px;">
        <el-row>感谢某吧某群的同志们的整理搜集，点击链接以预览和下载。</el-row>	
        <br>
        <el-divider>安主义著作</el-divider>
        <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/AnarchistFAQ%E8%8B%B1%E6%96%87%E7%89%88V15.rar" download  target="_blank">
            AnarchistFAQ(安人问答)英文版V15</a>
            <span style="color:grey">-8MB-置顶</span>
        </el-row>
        <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/AnarchistFAQ%E9%83%A8%E5%88%86%E4%B8%AD%E6%96%87%E7%BF%BB%E8%AF%91.docx" download  target="_blank">
            AnarchistFAQ(安人问答)部分中文翻译</a>
            <span style="color:grey">-170KB-置顶</span>
        </el-row>

                <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/20220102/Interviews%20and%20Essays%20by%20Bookchin.pdf" download  target="_blank">
            Interviews and Essays by Bookchin</a>
            <span style="color:grey">-9MB</span>
        </el-row>

                <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/20220102/%E4%B8%80%E4%B8%AA%E6%97%A0%E6%94%BF%E5%BA%9C%E4%B8%BB%E4%B9%89%E8%80%85%E7%9A%84%E7%B2%BE%E7%A5%9E%E4%B9%8B%E6%97%85.pdf" download  target="_blank">
            一个安人的精神之旅</a>
            <span style="color:grey">-2MB</span>
        </el-row>

                <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/20220102/%E4%B8%BA%E6%97%A0%E6%94%BF%E5%BA%9C%E4%B8%BB%E4%B9%89%E7%94%B3%E8%BE%A9_%E6%B2%83%E5%B0%94%E5%A4%AB.pdf" download  target="_blank">
            为安主义申辩_沃尔夫</a>
            <span style="color:grey">-6MB</span>
        </el-row>


                                <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/20220102/%E5%8F%A4%E5%85%B8%E6%97%A0%E6%94%BF%E5%BA%9C%E4%B8%BB%E4%B9%89%E8%91%9B%E8%92%B2%E5%B7%B4%E9%87%91%E7%9A%84%E6%94%BF%E6%B2%BB%E6%80%9D%E6%83%B3.pdf" download  target="_blank">
            古典安主义-葛蒲巴金的政治思想</a>
            <span style="color:grey">-6MB</span>
        </el-row>

                                        <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/20220102/%E5%90%8E%E7%BB%93%E6%9E%84%E4%B8%BB%E4%B9%89%E7%9A%84%E5%AE%89%E9%82%A3%E5%85%B6%E6%94%BF%E6%B2%BB%E5%93%B2%E5%AD%A6.pdf" download  target="_blank">
            后结构主义的安那其政治哲学</a>
            <span style="color:grey">-800kB</span>
        </el-row>

                                        <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/20220102/%E5%92%96%E5%95%A1%E5%BA%97%E8%B0%88%E8%AF%9D.pdf" download  target="_blank">
            咖啡店谈话</a>
            <span style="color:grey">-6MB</span>
        </el-row>

                                        <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/20220102/%E5%B7%B4%E6%9E%AF%E5%AE%81%E4%BC%A01985.pdf" download  target="_blank">
            巴枯宁传1985</a>
            <span style="color:grey">-17MB</span>
        </el-row>

                                        <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/20220102/%E5%B7%B4%E6%9E%AF%E5%AE%81%E7%9A%84%E4%B8%89%E6%BC%94%E8%AE%B2.pdf" download  target="_blank">
            巴枯宁的三演讲</a>
            <span style="color:grey">-2MB</span>
        </el-row>



                                        <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/20220102/%E5%B7%B4%E9%87%91%E3%80%8A%E5%85%8B%E9%B2%81%E6%B3%A1%E7%89%B9%E9%87%91%E3%80%8B.pdf" download  target="_blank">
            《克鲁泡特金》巴金译</a>
            <span style="color:grey">-1.6MB</span>
        </el-row>

                                        <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/20220102/%E5%B7%B4%E9%87%91%E8%AF%91%E6%96%87%E5%85%A8%E9%9B%86%E7%AC%AC10%E5%8D%B7_%E4%BC%A6%E7%90%86%E5%AD%A6%E7%9A%84%E8%B5%B7%E6%BA%90%E5%92%8C%E5%8F%91%E5%B1%95_%E5%91%8A%E9%9D%92%E5%B9%B4_%E7%A4%BE%E4%BC%9A%E5%8F%98%E9%9D%A9%E4%B8%8E%E7%BB%8F%E6%B5%8E%E7%9A%84%E6%94%B9%E9%80%A0.pdf" download  target="_blank">
            《伦理学的起源和发展_告青年_社会变革与经济的改造》巴金译</a>
            <span style="color:grey">-19MB</span>
        </el-row>

                                        <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/20220102/%E5%BD%93%E4%BB%A3%E5%AE%89%E9%82%A3%E5%85%B6%E7%8A%B6%E5%86%B5.pdf" download  target="_blank">
            当代安那其状况</a>
            <span style="color:grey">-2MB</span>
        </el-row>

        <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/20220102/%E6%97%A0%E6%94%BF%E5%BA%9C%E4%B8%BB%E4%B9%89%E5%8F%B2_%E4%B8%8D%E5%8F%AF%E8%83%BD%E6%80%A7.docx" download  target="_blank">
            安主义史_不可能性</a>
            <span style="color:grey">-1MB</span>
        </el-row>

        <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/20220102/%E6%97%A0%E6%94%BF%E5%BA%9C%E4%B8%BB%E4%B9%89%EF%BC%9A%E6%A6%82%E5%BF%B5%E6%96%B9%E6%B3%95.pdf" download  target="_blank">
            安主义：概念方法</a>
            <span style="color:grey">-2MB</span>
        </el-row>

                <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/20220102/%E7%8B%97%E5%B1%81%E5%B7%A5%E4%BD%9C_%E7%B9%81%E4%B8%AD.pdf" download  target="_blank">
            狗屁工作_繁中</a>
            <span style="color:grey">-9MB</span>
        </el-row>

                <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/20220102/%E7%8B%97%E5%B1%81%E5%B7%A5%E4%BD%9C_%E8%8B%B1%E6%96%87.pdf" download  target="_blank">
            狗屁工作_英文</a>
            <span style="color:grey">-2MB</span>
        </el-row>

                <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/20220102/%E7%94%B0%E5%9B%AD%E5%B7%A5%E5%8E%82%E6%89%8B%E5%B7%A5%E5%9C%BA.pdf" download  target="_blank">
            田园工厂手工场</a>
            <span style="color:grey">-13MB</span>
        </el-row>

                <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/20220102/%E8%A5%BF%E7%8F%AD%E7%89%99%E9%9D%A9%E5%91%BD%E4%B8%AD%E7%9A%84%E5%8A%B3%E5%8A%A8%E8%80%85%E8%87%AA%E4%B8%BB%E7%AE%A1%E7%90%86.pdf" download  target="_blank">
            西班牙革命中的劳动者自主管理.pdf</a>
            <span style="color:grey">-13MB</span>
        </el-row>

                <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/20220102/%E8%AE%B0%E5%BF%86%E4%B8%AD%E7%9A%84%E9%A9%AC%E8%B5%AB%E8%AF%BA.pdf" download  target="_blank">
            记忆中的马赫诺</a>
            <span style="color:grey">-2MB</span>
        </el-row>

<!-- 
                <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/20220102/%E9%A9%AC%E5%85%8B%E6%80%9D%E5%92%8C%E8%92%B2%E9%B2%81%E4%B8%9C.pdf" download  target="_blank">
            马克思和蒲鲁东</a>
            <span style="color:grey">-80MB</span>
        </el-row>


                <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/20220102/%E9%A9%AC%E8%B5%AB%E8%AF%BA_%E4%B9%8C%E5%85%8B%E5%85%B0%E7%9A%84%E5%86%9C%E6%B0%91%E8%BF%90%E5%8A%A8.pdf" download  target="_blank">
            马赫诺_乌克兰的农民运动</a>
            <span style="color:grey">-30MB</span>
        </el-row>


                <el-row>
            <a href="" download  target="_blank">
            </a>
            <span style="color:grey">-MB</span>
        </el-row>


                <el-row>
            <a href="" download  target="_blank">
            </a>
            <span style="color:grey">-MB</span>
        </el-row> -->

                <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/bakuning.pdf" download  target="_blank">
            法国杂志发表关于巴枯宁的新史料</a>
            <span style="color:grey">-1MB</span>
        </el-row>

                       <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/%E5%AF%B9%E8%AF%9D%E5%BD%951.pdf" download  target="_blank">福柯乔姆斯基对话录</a>
            <span style="color:grey">-8MB</span>
        </el-row>

                                <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/%E5%BE%B7%E5%8B%92%E5%85%B9%E4%B8%8E%E5%AE%89%E9%82%A3%E5%85%B6.pdf" download  target="_blank">
            德勒兹与安那其</a>
            <span style="color:grey">-5MB</span>
        </el-row>
        <br>
        <el-divider>哲学社科类</el-divider>

        <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/ceshi18mb.pdf" download  target="_blank">黑格尔导论-自由真理和历史</a>
            <span style="color:grey">-20MB</span>
        </el-row>



        <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/%E3%80%8A%E5%8F%A4%E4%BB%A3%E7%A4%BE%E4%BC%9A%E3%80%8B%E8%8E%AB%E5%B0%94%E6%A0%B9%E8%91%97.pdf" download  target="_blank">古代社会-莫尔根</a>
            <span style="color:grey">-16MB</span>
        </el-row>

        <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/%E5%8D%A2%E6%A2%AD%E3%80%8A%E7%A4%BE%E4%BC%9A%E5%A5%91%E7%BA%A6%E8%AE%BA%E3%80%8B%E5%95%86%E5%8A%A1%E5%8D%B0%E4%B9%A6%E9%A6%86.pdf" download  target="_blank">社会契约论</a>
            <span style="color:grey">-7MB</span>
        </el-row>

        <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/%E5%A4%96%E5%9B%BD%E5%93%B2%E5%AD%A6%E5%A4%A7%E8%BE%9E%E5%85%B8%2B%E4%B8%8A%E6%B5%B7%E8%BE%9E%E4%B9%A6%E5%87%BA%E7%89%88%E7%A4%BEnew.pdf" download  target="_blank">外国哲学大辞典</a>
            <span style="color:grey">-59MB</span>
        </el-row>


        <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/%E5%BE%B7%E5%8B%92%E5%85%B9%E5%8F%8A%E5%85%B6%E5%93%B2%E5%AD%A6%E5%88%9B%E9%80%A0_%E6%A0%BE%E6%A0%8B.pdf" download  target="_blank">德勒兹及其哲学创造</a>
            <span style="color:grey">-1MB</span>
        </el-row>

        <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/%E9%BB%91%E6%A0%BC%E5%B0%94%E4%BC%A0.pdf" download  target="_blank">黑格尔传</a>
            <span style="color:grey">-11MB</span>
        </el-row>

                <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/%E5%BD%93%E4%BB%A3%E8%A5%BF%E6%96%B9%E5%93%B2%E5%AD%A6%E6%96%B0%E8%AF%8D%E5%85%B8.pdf" download  target="_blank">当代西方哲学新词典</a>
            <span style="color:grey">-6MB</span>
        </el-row>

                <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/%E8%A5%BF%E6%96%B9%E5%93%B2%E5%AD%A6%E5%8F%B2%E8%80%83%E7%A0%94%E7%AC%94%E8%AE%B0.doc" download  target="_blank">西方哲学史考研笔记</a>
            <span style="color:grey">-240kB</span>
        </el-row>

                <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/%E9%BB%91%E6%A0%BC%E5%B0%94%E6%96%B0%E9%87%8A_%E5%88%98%E5%88%9B%E9%A6%A5.zip" download  target="_blank">黑格尔新释(刘创馥)</a>
            <span style="color:grey">-12MB</span>
        </el-row>

                <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/%E4%B8%AD%E5%9B%BD%E7%99%BE%E7%A7%91%E5%A4%A7%E8%BE%9E%E5%85%B8%E5%93%B2%E5%AD%A6.pdf" download  target="_blank">中国百科大辞典哲学</a>
            <span style="color:grey">-2MB</span>
        </el-row>

                <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/%E6%89%B9%E8%AF%84%E7%9A%84%E8%A5%BF%E6%96%B9%E5%93%B2%E5%AD%A6%E5%8F%B2.pdf" download  target="_blank">批评的西方哲学史</a>
            <span style="color:grey">-62MB</span>
        </el-row>

                <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/%E5%A4%A7%E9%97%AE%E9%A2%98-%E9%97%B4%E6%98%8E%E5%93%B2%E5%AD%A6%E5%AF%BC%E8%AE%BA.pdf" download  target="_blank">大问题-间明哲学导论</a>
            <span style="color:grey">-32MB</span>
        </el-row>

 

 

                        <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/%E8%A5%BF%E6%96%B9%E5%93%B2%E5%AD%A6%E8%AF%8D%E5%85%B8-%E8%B0%AD%E9%91%AB%E7%94%B0%E7%AD%89%E4%B8%BB%E7%BC%961992.pdf" download  target="_blank">西方哲学词典-谭鑫田等主编1992</a>
            <span style="color:grey">-42MB</span>
        </el-row>



                                <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/%E5%A5%BD%E7%94%A8%E7%9A%84%E5%93%B2%E5%AD%A6.pdf" download  target="_blank">好用的哲学</a>
            <span style="color:grey">-45MB</span>
        </el-row>

                                <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/%E5%81%9A%E5%93%B2%E5%AD%A6_88%E4%B8%AA%E6%80%9D%E6%83%B3%E5%AE%9E%E9%AA%8C%E4%B8%AD%E7%9A%84%E5%93%B2%E5%AD%A6%E5%AF%BC%E8%AE%BA.pdf" download  target="_blank">做哲学_88个思想实验中的哲学导论</a>
            <span style="color:grey">-34MB</span>
        </el-row>

                                <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/%E5%AE%8C%E5%85%A8%E8%A7%A3%E8%AF%BB%E5%93%B2%E5%AD%A6%E7%94%A8%E8%AF%AD%E4%BA%8B%E5%85%B8-%E5%B0%8F%E5%B7%9D%E4%BB%81%E5%BF%97.pdf" download  target="_blank">	完全解读哲学用语事典-小川仁志</a>
            <span style="color:grey">-28MB</span>
        </el-row>

                                <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/%E6%BC%AB%E8%AF%9D%E5%93%B2%E5%AD%A6.pdf" download  target="_blank">漫画哲学</a>
            <span style="color:grey">-72MB</span>
        </el-row>

                <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/20220102%E5%93%B2%E5%AD%A6/%E4%BA%8C%E5%8D%81%E4%B8%96%E7%BA%AA%E5%8D%8E%E5%8C%97%E5%86%9C%E6%9D%91%E7%A4%BE%E4%BC%9A%E7%BB%8F%E6%B5%8E%E7%A0%94%E7%A9%B6.pdf" download  target="_blank">
            二十世纪华北农村社会经济研究</a>
            <span style="color:grey">-11MB</span>
        </el-row>


                <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/20220102%E5%93%B2%E5%AD%A6/%E5%89%96%E6%9E%90%E4%B8%96%E7%95%8C2000%E5%AE%B6%E5%A4%A7%E4%BC%81%E4%B8%9A.pdf" download  target="_blank">
            剖析世界2000家大企业</a>
            <span style="color:grey">-2MB</span>
        </el-row>


                <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/20220102%E5%93%B2%E5%AD%A6/%E5%B8%B8%E8%AF%86-%E6%BD%98%E6%81%A9.pdf" download  target="_blank">
            常识-潘恩</a>
            <span style="color:grey">-9MB</span>
        </el-row>


                <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/20220102%E5%93%B2%E5%AD%A6/%E5%BF%85%E9%A1%BB%E4%BF%9D%E5%8D%AB%E7%A4%BE%E4%BC%9A.pdf" download  target="_blank">
            必须保卫社会-福柯</a>
            <span style="color:grey">-11MB</span>
        </el-row>


                <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/20220102%E5%93%B2%E5%AD%A6/%E7%A6%8F%E6%9F%AF%E6%80%9D%E6%83%B3%E8%BE%9E%E5%85%B8.pdf" download  target="_blank">
            福柯思想辞典</a>
            <span style="color:grey">-33MB</span>
        </el-row>


                <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/20220102%E5%93%B2%E5%AD%A6/%E8%A2%AB%E5%8E%8B%E8%BF%AB%E8%80%85%E6%95%99%E8%82%B2%E5%AD%A6.pdf" download  target="_blank">
            被压迫者教育学</a>
            <span style="color:grey">-14MB</span>
        </el-row>


                <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/20220102%E5%93%B2%E5%AD%A6/%E8%A5%BF%E6%96%B9%E5%93%B2%E5%AD%A6%E5%8F%B2%E8%80%83%E7%A0%94%E7%AC%94%E8%AE%B0.doc" download  target="_blank">
            西方哲学史考研笔记</a>
            <span style="color:grey">-1MB</span>
        </el-row>


                <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/20220102%E5%93%B2%E5%AD%A6/%E8%B5%84%E6%9C%AC%E4%B8%BB%E4%B9%89%E7%9A%84%E5%8E%86%E5%8F%B2500%E5%B9%B4.pdf" download  target="_blank">
            资本主义的历史500年</a>
            <span style="color:grey">-23MB</span>
        </el-row>

                <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/20220102%E5%85%B1/%E4%B8%96%E7%95%8C%E4%BD%93%E7%B3%BB_500%E5%B9%B4%E8%BF%98%E6%98%AF5000%E5%B9%B4.pdf" download  target="_blank">世界体系_500年还是5000年</a>
            <span style="color:grey">-19MB</span>
        </el-row>


        <br>
        <el-divider>社会主义相关</el-divider>
                       <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/%E7%A4%BE%E4%BC%9A%E4%B8%BB%E4%B9%89%281%29.pdf" download  target="_blank">马克斯韦伯论社会主义</a>
            <span style="color:grey">-3MB</span>
        </el-row>



                <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/20220102%E5%85%B1/%E4%BB%80%E4%B9%88%E6%98%AF%E5%87%AF%E6%81%A9%E6%96%AF%E4%B8%BB%E4%B9%89.pdf" download  target="_blank">什么是凯恩斯主义</a>
            <span style="color:grey">-5MB</span>
        </el-row>

                <!-- <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/20220102%E5%85%B1/%E5%85%B1%E4%BA%A7%E4%B8%BB%E4%B9%89%E7%9A%84%E6%8E%98%E5%A2%93%E4%BA%BA.pdf" download  target="_blank">共产主义的掘墓人</a>
            <span style="color:grey">-12MB</span>
        </el-row> -->

                <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/20220102%E5%85%B1/%E6%88%91%E4%BB%AC%E6%97%B6%E4%BB%A3%E9%9D%A9%E5%91%BD%E7%9A%84%E6%96%B0%E5%8F%8D%E6%80%9D%20.pdf" download  target="_blank">我们时代革命的新反思</a>
            <span style="color:grey">-11MB</span>
        </el-row>
        <br>


        
        <el-divider>其他</el-divider>
        <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/20220102%E5%85%B1/%E4%B8%87%E7%89%A9%E8%A7%A3%E9%87%8A%E8%80%85_%E5%A4%8D%E6%9D%82%E4%BA%8B%E7%89%A9%E7%9A%84%E6%9E%81%E7%AE%80%E8%AF%B4%E6%98%8E%E4%B9%A6.pdf" download  target="_blank">万物解释者_复杂事物的极简说明书</a>
            <span style="color:grey">-25MB</span>
        </el-row>

                <!-- <el-row>
            <a href="https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/20220102%E5%85%B1/%E9%99%88%E7%BA%AF_%E8%AE%BA%E5%B0%8F%E7%B2%89%E7%BA%A21.pdf" download  target="_blank">陈纯_论小粉红</a>
            <span style="color:grey">-1MB</span>
        </el-row>
        <br> -->





        

    </div>
</template>

<script>
    export default {
        name:'z51',
        props:[],
        data() {return {

        }},
        computed:{

        },
        methods:{
            
        },
    };
</script>



