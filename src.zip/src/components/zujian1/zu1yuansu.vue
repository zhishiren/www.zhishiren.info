//这是用于xh11的功能
<template>
<span id="zu1yuansu">
    <span v-if="list.fields.cztype==='发言'||list.fields.cztype==='提问'">
        <span v-if="list.fields.fy==='正在审核' && list.fields.type0==='fayanye' && list.fields.fymi===0" style="color:white;background-color:grey;">{{this.list.fields.fy}}</span>
        <router-link v-if="list.fields.fy!=='正在审核' && list.fields.type0==='fayanye' && list.fields.fymi===0" class="a_black" target="_blank" :to="{name:'fayanye',params:{id:list.pk}}">          
            <span style="color:brown;"><font style="font-size:20px;"><b>“</b></font><span v-html="list.fields.fy" ></span><font style="font-size:20px;"><b>”</b></font></span>
        </router-link>
        <span v-if="list.fields.fy!=='正在审核'&&list.fields.type0==='fayanye'&&list.fields.fymi!==0" style="color:grey;">
            <span>{{this.list.fields.fymi}}字密文</span>
            <input style="width:1px;border-color:white;border:0px;" type="text" v-model="list.fields.fy.slice(2,-1)" :id="list.pk">
            <a class="a_brown" @click="kcopy(list.pk)" style="color:blue;"><i class="el-icon-document-copy"></i>复制</a>
        </span>
    </span>

    <span v-if="onlyid1!=='1' 
        && (list.fields.cztype==='评论' || list.fields.cztype==='分享' || list.fields.cztype==='加入标签'|| list.fields.cztype==='关联'|| list.fields.cztype==='标签里加入')">
        <router-link v-if="list.fields.type0!=='fayanye'" class="a_black" target="_blank" :to="{name:list.fields.type0,params:{id:list.fields.id0}}">          
            <span><i v-if="list.fields.type0==='yonghuye'" class="el-icon-s-custom"></i>{{list.fields.title0}}</span>
        </router-link>
        <span v-if="list.fields.type0==='wenduanye'||list.fields.type0==='yonghuye'">，</span>
        <router-link v-if="list.fields.type0==='fayanye'" class="a_black" target="_blank" :to="{name:'fayanye',params:{id:list.fields.id0}}">          
            <span style="color:brown;"><font style="font-size:20px;"><b>“</b></font><span v-html="list.fields.title0" ></span><font style="font-size:20px;"><b>”</b></font></span>
        </router-link>
    </span>
    
    <span v-if="onlyid1!=='0' 
        && list.fields.cztype==='关联'">
        <!-- <span style="font-size:17px;color:grey;">和</span> -->
        <router-link v-if="list.fields.type1!=='fayanye'" class="a_black" target="_blank" :to="{name:list.fields.type1,params:{id:list.fields.id1}}">          
            <span><i v-if="list.fields.type1==='yonghuye'" class="el-icon-s-custom"></i>{{list.fields.title1}}</span>
        </router-link>
        <router-link v-if="list.fields.type1==='fayanye'" class="a_black" target="_blank" :to="{name:'fayanye',params:{id:list.fields.id1}}">          
            <span style="color:brown;"><font style="font-size:20px;"><b>“</b></font><span v-html="list.fields.title1" ></span><font style="font-size:20px;"><b>”</b></font></span>
        </router-link>
    </span>

    <span v-if="onlyid1!=='0' 
        && list.fields.cztype==='加入标签'">
        <span style="font-size:17px;color:grey;">到标签</span>
        <router-link class="a_black" target="_blank" :to="{name:'biaoqianye',params:{id:list.fields.id1}}">
            <span>{{list.fields.title1}}</span>
        </router-link>
    </span>
</span>

</template>

<script>
export default {
    name:'zu1yuansu',
    props:['list','onlyid1'],
    // onlyid1是区别id0和id1时用的，
    // onlyid1===1时，是用来隐藏id0等相关信息的，用在某个知识点信息页，
    // onlyid1===0时，是用来隐藏“到标签[xx]”等相关信息，是用于标签信息页中标签内含的页面，

	data() {return {}},
    methods:{
        kcopy(a){
        let copycode = document.getElementById(a);
            copycode.select(); // 选择对象
            document.execCommand("Copy"); // 执行浏览器复制命令
            // alert("密文已经复制到你的粘贴板，请到首页右侧‘密’功能栏解密。");
            const h = this.$createElement;
            this.$notify({
                title: '密文已经复制到你的粘贴板',
                type: 'success',
				message: h('i', { style: 'color: teal;font-size:19px;'}, '请到‘密’功能栏解密。')
            });
        },
    },
};

</script>



