<template>
<div id="wenjiye"  @click="turnfresh()">
	<zu2logo k=1></zu2logo>
	<zu2errorpage v-if="errorid!==0" :errorid="errorid"></zu2errorpage>
	<el-container v-if="errorid===0">
		<el-aside width="120px" class="bgcolor_FF"></el-aside>
		<el-main class="bgcolor_FC font18px">
			<el-card v-if="wj_info.wj_id" class="box-card">
				<el-row >
					<el-col :span="20" >
						<p class="font21px">{{this.wj_info.wj_title}}</p>
					</el-col>
					<el-col :span="4" >
						<el-upload v-if="wj_info.wj_yuanwen===0 && wj_info.wj_manager===yonghuid"
							name="yuanwen"
							class="upload-demo"
							ref="upload"
							:data={id:this.wj_info.wj_id}
							action='http://www.zhishiren.info/api/shangchuan_yuanwen/'
							Access-Control-Request-Headers: ContentType
							style="text-align:40px;display:inline;float:right;"
							:on-preview="handlePreview"
							:on-remove="handleRemove"
							:before-remove="beforeRemove"
							:on-exceed="handleExceed"
							:on-success="onsuccess"
							:file-list="fileList" 
							>
							<a class="a_grey" type="primary" style="font-size:20px;" slot="trigger" size="small"><i class="el-icon-upload2"></i>上传原文</a>
						</el-upload>
						<!-- <a v-if="wj_info.wj_yuanwen!==0" style="font-size:20px;float:right;" class="a_grey" 
							:href="'https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/yuanwen1/'+wj_info.wj_id+'.doc'" 
							:download="wj_info.wj_id+''+wj_info.wj_title+'.doc'">
							<i class="el-icon-download"></i>下载原文
						</a> -->
					</el-col>
				</el-row>

				<el-row>
					<span><b>属性<i class="el-icon-caret-right"></i></b></span>
					<span>文辑ID:{{this.wj_info.wj_id}}<el-divider direction="vertical"></el-divider></span>
					<span style="color:red;" v-if="wj_info.wj_status==='失效已删'">{{this.wj_info.wj_status}}<el-divider direction="vertical"></el-divider></span>
					<span v-if="wj_info.wj_status!=='失效已删'">{{this.wj_info.wj_status}}<el-divider direction="vertical"></el-divider></span>
					<span>{{this.wj_info.wj_type}}<el-divider direction="vertical"></el-divider></span>
					<span><zu0showfanwei :qz_id="wj_info.wj_fanwei"></zu0showfanwei><el-divider direction="vertical"></el-divider></span>
					<span>生效:<span style="color:grey" v-show="wj_info.wj_borntime===null">缺少信息</span><span v-show="wj_info.wj_borntime!==null">{{getNowFormatDate(this.wj_info.wj_borntime)}}</span><el-divider direction="vertical"></el-divider></span>
					<span>失效:<span style="color:grey" v-show="wj_info.wj_deadtime===null">缺少信息</span><span v-show="wj_info.wj_deadtime!==null">{{getNowFormatDate(this.wj_info.wj_deadtime)}}</span><el-divider direction="vertical"></el-divider></span>
					<span>行业:<span style="color:grey" v-show="wj_info.wj_hangye===''">缺少信息</span><span v-show="wj_info.wj_hangye!==''">{{this.wj_info.wj_hangye}}</span><el-divider direction="vertical"></el-divider></span>
					<span>地区:<span style="color:grey" v-show="wj_info.wj_area===''">缺少信息</span><span v-show="wj_info.wj_area!==''">{{this.wj_info.wj_area}}</span><el-divider direction="vertical"></el-divider></span>
					<span>发文:<span style="color:grey" v-show="wj_info.wj_publisher===''">缺少信息</span><span v-show="wj_info.wj_publisher!==''">{{this.wj_info.wj_publisher}}</span><el-divider direction="vertical"></el-divider></span>
					<span>管理人:
						<router-link class="a_black" target="_blank" :to="{name:'yonghuye',params:{id:wj_info.wj_manager}}">{{this.wj_info.wj_manager}}</router-link>
					</span>
					<zu0tongjishu :dj="wj_tongji.dianji" :gz="wj_tongji.guanzhu" :fx="wj_tongji.fenxiang"></zu0tongjishu>
				</el-row>
				<el-row>
					<b>说明<i class="el-icon-caret-right"></i></b><span v-html="wj_info.wj_remark"></span>
				</el-row>
				<zu0fujianfutu v-if="wj_info.fujianshu!==0" :zhid="wj_info.wj_id"></zu0fujianfutu>
		</el-card>
			<el-card  v-if="!wj_info.wj_id">
				<br>
					<div style="text-align:center;font-size:30px;"><i class="el-icon-loading"></i>正在加载...</div>
				<br>
			</el-card>
		</el-main>
		<el-aside width="120px" class="bgcolor_FC"></el-aside>
	</el-container>

	<el-container v-if="errorid===0">
		<el-aside width="120px">
			<el-menu default-active="11" class="el-menu-vertical-demo bgcolor_menu_FC" @open="handleOpen" @close="handleClose">
				<el-menu-item @click="daohang11" index="11" class="font18px">
				<span slot="title">段落列表</span>
				</el-menu-item>
				<el-menu-item @click="daohang12" index="12" class="font18px">
				<span slot="title">关注分享</span>
				</el-menu-item>
				<el-menu-item @click="daohang13" index="13" class="font18px">
				<span slot="title">评论</span>
				</el-menu-item>
				<el-menu-item @click="daohang14" index="14" class="font18px">
				<span slot="title">关联知识</span>
				</el-menu-item>
				<!-- <el-menu-item @click="daohang15" index="15" class="font18px">
				<span slot="title">推荐阅读</span>
				</el-menu-item>-->
				<el-menu-item @click="daohang16" index="16" class="font18px">
					<span slot="title">内容管理</span>
				</el-menu-item>
			</el-menu>
		</el-aside>
		<el-main v-show="dh12" class="section_xh">
			<zu1caozuojishu zone_id="分享" :zhid="wj_info.wj_id" type0="wenjiye" :title0="wj_info.wj_title" :fanwei="wj_info.wj_fanwei"></zu1caozuojishu>
			<br>
			<zu1caozuojishu zone_id="关注" :zhid="wj_info.wj_id" type0="wenjiye" :title0="wj_info.wj_title"></zu1caozuojishu>
			<br>
			<zu1caozuojishu zone_id="纠错" :zhid="wj_info.wj_id" type0="wenjiye" :title0="wj_info.wj_title"></zu1caozuojishu>
			<br>
			<xhcaozuo zoneid="加入标签" :zhid="wj_info.wj_id" :title0="wj_info.wj_title" type0="wenjiye" :fanwei="wj_info.wj_fanwei" :listNum="wj_tongji.biaoqian"></xhcaozuo>
		</el-main>
		<el-main v-show="dh13" class="section_xh">
			<xhcaozuo zoneid="评论" :zhid="wj_info.wj_id" :title0="wj_info.wj_title" type0="wenjiye" :listNum="wj_tongji.pinglun"  :fanwei="wj_info.wj_fanwei"></xhcaozuo>
		</el-main>
		<el-main v-show="dh14" class="section_xh">
			<xhcaozuo zoneid="关联" :zhid="wj_info.wj_id" :title0="wj_info.wj_title" type0="wenjiye" :listNum="wj_tongji.guanlian"  :fanwei="wj_info.wj_fanwei"></xhcaozuo>
		</el-main>
		<!-- <el-main v-show="dh15" class="section_xh">
			<tj0tuijian :id="wj_info.wj_id" ></tj0tuijian>
		</el-main> -->
		<el-main v-show="dh11" class="section_xh">
			<xhduanluo :zhid="wj_info.wj_id" :listNum="wj_info.wj_wdshu" :managerid="wj_info.wj_manager"></xhduanluo>
		</el-main>
		<el-main v-show="dh16" class="section_xh">
			<xhchanged :zhid="wj_info.wj_id" zhitype='wenjiye' :list='wj_info' :managerid="wj_info.wj_manager" :zhicontent="wj_info.wj_remark" :fanwei="wj_info.wj_fanwei" :listNum="wj_tongji.xiugai"></xhchanged>
		</el-main>
		<el-aside width="120px" class="bgcolor_FC"></el-aside>
	</el-container>
	</div>

</template>

<script>
import Xhchanged from '../xunhuan/xhchanged.vue';
import Xhduanluo from '../xunhuan/xhduanluo.vue';

export default {
	name:'wenjiye',
	components: {Xhduanluo,Xhchanged},
	methods:{
		daohang11(){this.dh11=true;this.dh12=false;this.dh13=false;this.dh14=false;this.dh15=false;this.dh16=false;},
		daohang12(){this.dh12=true;this.dh11=false;this.dh13=false;this.dh14=false;this.dh15=false;this.dh16=false;},
		daohang13(){this.dh13=true;this.dh11=false;this.dh12=false;this.dh14=false;this.dh15=false;this.dh16=false;},
		daohang14(){this.dh14=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh15=false;this.dh16=false;},
		// daohang15(){this.dh15=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh14=false;this.dh16=false;},
		daohang16(){this.dh16=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh14=false;this.dh15=false;},
		//这里的k值指的是关注数或分享数等等
		add1(k){
			if(k==1){this.wj_tongji.fenxiang++;}
			if(k==2){this.wj_tongji.guanzhu++;}
		},
		minus1(k){
			if(k==2){this.wj_tongji.guanzhu--;}
		},
		
		//以下是上传文件原文的功能
		handleRemove(file, fileList) {console.log(file, fileList);},
		handlePreview(file) {console.log(file);},
		onsuccess(response, file, fileList) {this.$refs.upload.clearFiles();this.wj_info.wj_yuanwen=1;},
		handleExceed(files, fileList) {this.$message.warning(`每次操作只能上传一个文件！`);},
		beforeRemove(file, fileList) {return this.$confirm(`确定移除 ${ file.name }？`);},
		handleRemove(file, fileList) {console.log(file, fileList);},
		handlePreview(file) {console.log(file,fileList);},
	},
	data() {
		return {
			dh15:false,dh12:false,dh13:false,dh14:false,dh11:true,dh16:false,
			wj_id:0,wj_info:[],wj_tongji:[],fulist:[],
			showloading1:true,errorid:0
		}
	},
	computed: {
		yonghuid(){return parseInt(this.$cookies.get('userid'))},
		welcomename(){return this.$cookies.get('username')},
	},
	created() {
		
		this.wj_id = this.$route.params.id;//获取上个页面传递的id,在下面获取数据的时候先提交id,这里的id不用加前缀
		var _this= this;
		_this.axios
		.post('http://www.zhishiren.info/api/show_wenjiye/', {wj_id:_this.wj_id})
		.then(function (response) {
			_this.wj_info=response.data;
			_this.wj_tongji=JSON.parse(response.data.wj_tongji);
			_this.errorid=errorid_transfer(_this.wj_info.wj_fanwei);
			_this.showloading1=false;
		});
	},
};
</script>

<style scoped>

</style>




