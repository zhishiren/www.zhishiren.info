<template>
<div id="yonghuye"  @click="turnfresh()">
		<zu2logo k=1></zu2logo>
		<el-container>
			<el-aside width="120px" class="bgcolor_FF"></el-aside>
			<el-main class="bgcolor_FC font18px">
				<el-card class="box-card"  v-if="!userinfo" style="height:270px;font-size:40px;text-align:center;">
					<br><i class="el-icon-loading"></i>正在加载...
				</el-card>
				<zu2usercard v-if="userinfo" :userinfo="userinfo" :userjishu="userjishu"></zu2usercard>
			</el-main>
			<el-aside width="120px" class="bgcolor_FC"></el-aside>
		</el-container>

		<el-container>
			<el-aside width="120px">
				<el-menu default-active="12" class="el-menu-vertical-demo bgcolor_menu_FC" @open="handleOpen" @close="handleClose">
			      <el-menu-item @click="daohang11" index="11" class="font18px">
			        <span slot="title">公告动态</span>
			      </el-menu-item>
				  <el-menu-item @click="daohang12" index="12" class="font18px">
			        <span slot="title">关注分享</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang13" index="13" class="font18px">
			        <span slot="title">大家印象</span>
			      </el-menu-item>
			      <!-- <el-menu-item @click="daohang14" index="14" class="font18px">
			        <span slot="title">与他相关</span>
			      </el-menu-item> -->
                  <!-- <el-menu-item @click="daohang15" index="15" class="font18px">
			        <span slot="title">推荐阅读</span>
			      </el-menu-item>		       -->
			    </el-menu>
			</el-aside>
			<el-main v-show="dh12" class="section_xh">
				<zu1caozuojishu zone_id="分享" :zhid="userinfo.yonghu_id" :title0="userinfo.yonghu_name" type0="yonghuye"></zu1caozuojishu> 
				<br> 
				<zu1caozuojishu zone_id="关注" :zhid="userinfo.yonghu_id" :title0="userinfo.yonghu_name" type0="yonghuye"></zu1caozuojishu> 
				<br>
				<xhcaozuo zoneid="加入标签" :zhid="userinfo.yonghu_id" :title0="userinfo.yonghu_name" type0="yonghuye" :listNum="userjishu.biaoqian"></xhcaozuo>
			</el-main>
			<el-main v-show="dh13" class="section_xh">
				<xhcaozuo zoneid="评价" :zhid="userinfo.yonghu_id" :title0="userinfo.yonghu_name" type0="yonghuye"  :listNum="userjishu.pinglun"></xhcaozuo>
			</el-main>
			<!-- <el-main v-show="dh14" class="section_xh">
			    该用户共有3条与他相关的知识。-展开-
			</el-main> -->
			<!-- <el-main v-show="dh15" class="section_xh">
            	<tj0tuijian></tj0tuijian>
			</el-main> -->
			<el-main v-show="dh11" class="section_xh">
				<zu2gonggao :yonghuid="userinfo.yonghu_id"></zu2gonggao>
				<!-- <xhyhy11 :userid="userinfo.yonghu_id"></xhyhy11> -->
				<xhqznei :yonghuid="userinfo.yonghu_id" dongtaitype="TA" :listNum="userjishu.zengfenxiang+userjishu.zengfayan"></xhqznei>
			</el-main>
			<el-aside width="120px" class="bgcolor_FC"></el-aside>
		</el-container>
	</div>

</template>

<script>
import zu2usercard from '../zujian2/zu2usercard';
import bdg5 from '../biaodan/bdg5';
import xiazaishuji from '../fujian/xiazaishuji';
import Xhcaozuo from '../xunhuan/xhcaozuo.vue';
import xhqznei from '../xunhuan/xhqznei.vue';


export default {
        name:'yonghuye',
		components: {bdg5,xiazaishuji,Xhcaozuo,Xhcaozuo,zu2usercard,xhqznei},
        methods:{
			daohang11(){this.dh11=true;this.dh12=false;this.dh13=false;this.dh14=false;this.dh15=false;this.dh16=false;},
			daohang12(){this.dh12=true;this.dh11=false;this.dh13=false;this.dh14=false;this.dh15=false;this.dh16=false;},
			daohang13(){this.dh13=true;this.dh11=false;this.dh12=false;this.dh14=false;this.dh15=false;this.dh16=false;},
			daohang14(){this.dh14=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh15=false;this.dh16=false;},
			daohang15(){this.dh15=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh14=false;this.dh16=false;},
			daohang16(){this.dh16=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh14=false;this.dh15=false;},
			//这里的k值指的是关注数或分享数等等
			// add1(k){
			// 	if(k==1){this.userjishu.fenxiang++;}
			// 	if(k==2){this.userjishu.guanzhu++;}
			// },
			// minus1(k){
			// 	if(k==2){this.userjishu.guanzhu--;}
			// },

		},
        data() {
			return {dh15:false,dh11:false,dh13:false,dh14:false,dh12:true,dh16:false,
			yonghuid:0,
			userinfo:[],
			userjishu:[],
			show_touxiang:false,mygonggao:''
			}
		},
		
		computed:{
			welcomename(){return this.$cookies.get('username')},
            xiaozhi_id(){return parseInt(this.$cookies.get('userid'))},
			// mypage_yn(){return parseInt(this.$cookies.get('userid'))===this.userinfo.yonghu_id}
		},
        created() {
			var _this= this;
			_this.yonghuid = _this.$route.params.id;//获取上个页面传递的id,在下面获取数据的时候先提交id,这里的id不用加前缀
			_this.axios
				.post('http://www.zhishiren.info/api/show_yonghuye/',{
					userid:_this.yonghuid,
					kkk:true})
				.then(function (response) {
					_this.userinfo=response.data;
					_this.userjishu=JSON.parse(response.data.yh_tongji);
			});
        },
};






</script>






