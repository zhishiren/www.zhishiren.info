<template>
<div id="wen"  @click="turnfresh()">
		<zu2logo k=1></zu2logo>
		<el-container>
			<el-aside width="120px" class="bgcolor_FF"></el-aside>
			<el-main class="bgcolor_FC font18px">
				<i class="el-icon-info">所有用户均可在“今日动态”看见你的提问</i>
				<br>
				<i v-if="wened_yn===false" class="el-icon-info">每天只能提问一次，你还没有提问过。</i>
				<i v-if="wened_yn===true" class="el-icon-info">每天只能提问一次，你上次提问是<b>{{this.lastwentime}}</b></i>
				<br>
				<i class="el-icon-info"><b>明发</b>需要被审核，<b>密发</b>不被审核</i>,使用方法见主页面-关于本站-操作说明
				<br>
			</el-main>
		</el-container>

		<el-container>
			<el-aside width="120px">
				<el-menu default-active="11" class="el-menu-vertical-demo bgcolor_menu_FC height_x00px" @open="handleOpen" @close="handleClose">
			      <el-menu-item @click="daohang11" index="11" class="font18px">
			        <span slot="title">马上提问</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang12" index="12" class="font18px">
			        <span slot="title">回答我的</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang13" index="13" class="font18px">
			        <span slot="title">所有问答</span>
			      </el-menu-item>

			    </el-menu>
			</el-aside>
			<el-main v-show="dh11" class="section_xh">
				<xhwen1 :listNum0='weninfo.mywen'></xhwen1>
			</el-main>
			<el-main v-show="dh12" class="section_xh">
				<xhwen2></xhwen2>
			</el-main>
			<el-main v-show="dh13" class="section_xh">
				<xhwen3 :listNum0='weninfo.allwen'></xhwen3>
			</el-main>
			<el-aside width="120px" class="bgcolor_FC"></el-aside>
		</el-container>
	</div>

</template>

<script>

import xhwen1 from '../xunhuan/xhwen1';
import xhwen2 from '../xunhuan/xhwen2';
import xhwen3 from '../xunhuan/xhwen3';
// import qtiwen from '../zone/qtiwen';



export default {
		name:'wen',
		components: {xhwen1,xhwen2,xhwen3},
        methods:{
                    daohang11(){this.dh11=true;this.dh12=false;this.dh13=false;this.dh14=false;},
                    daohang12(){this.dh12=true;this.dh11=false;this.dh13=false;this.dh14=false;},
                    daohang13(){this.dh13=true;this.dh11=false;this.dh12=false;this.dh14=false;},
                    daohang14(){this.dh14=true;this.dh11=false;this.dh12=false;this.dh13=false;},
        },
        data() {
			return {dh11:true,dh12:false,dh13:false,dh14:false,show_sousuohou:false,show_sousuokong:false,sou_keyword:'',
			divcontent:'',ceshi1:201,created_ok:[],fnametest:'',ceshi_upload:"",
			weninfo:[],
			lastwen:0,
			}
		},

		computed:{
			lastwentime(){return this.$cookies.get('lastwentime')},
			wened_yn(){
				if(this.$cookies.get('lastwentime')==="2020-01-01T00:00:00"){
					return false;
				}else{return true;}},
		},

		created: function () {
			var _this= this;
			_this.axios
				.post('http://www.zhishiren.info/api/show_wenpage/', {userid:_this.$cookies.get('userid')})
				.then(function (response) {
					_this.weninfo=response.data;
					_this.lastwentime=response.data.lastwentime;
					_this.$cookies.set('lastwentime',response.data.lastwentime,'8h');
					// _this.userjishu=JSON.parse(response.data.yh_tongji);
					// _this.alljishu=JSON.parse(response.data.alljishu);
				});
		}


};






</script>






