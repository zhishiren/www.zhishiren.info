<template>
<div id="fuye_ce"  @click="turnfresh()">
		<toubu0>mm</toubu0>
		<el-container>
			<el-aside width="120px" class="bgcolor_FF"></el-aside>
			<el-main class="bgcolor_FC">
ceshiye		
			</el-main>
		</el-container>

		<el-container>
			<el-aside width="120px">
				<el-menu :default-active="kk" class="el-menu-vertical-demo bgcolor_menu_FC height_x00px" @open="handleOpen" @close="handleClose">
			      <el-menu-item @click="daohang11" index="11" class="font18px">
			        <span slot="title">文章标题</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang12" index="12" class="font18px" ref="d12">
			        <span slot="title">段落内容</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang13" index="13" class="font18px">
			        <span slot="title">标签</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang14" index="14" class="font18px">
			        <span slot="title">数集</span>
			      </el-menu-item>						      
			    </el-menu>
			</el-aside>
			<el-main v-show="dh11" class="section_xh">


<zu0fujianfutu :zhid="Number(100000210)"></zu0fujianfutu>

				<i style="font-size:50px" class="el-icon-lock"></i>该知识点的公开范围仅为创建者本人。

				<br>
				<br>
				<br>
<a @click="ceshinews">ceshinews</a>
---------------
{{this.newslist}}
------------

				<br>
				<br>
				<br>






				<tj0fenxiang zhititle='wenjiye' fanwei=80000001 createrid=90000050></tj0fenxiang>


			</el-main>
			<el-main v-show="dh12" class="section_xh">
             	<ceshi :ceshishuzu="ceshilist"></ceshi>
            	<tj0pinglun zhitype="wenjiye" zhid=10000011 listNum=1></tj0pinglun>

				<br>
				<tj0huifu act_id=11111111 act_yan="ceshidewenben"  it_type="fy4" it_att="紧急重要" fanwei_id=80000000 creater_id=90000064 timek=1 create_time="2010-01-01" ></tj0huifu>
                <el-row><el-divider style="margin:0px;"></el-divider></el-row>

			


			</el-main>
			<el-main v-show="dh13" class="section_xh">
             dh13-小组新闻
			</el-main>
			<el-main v-show="dh14" class="section_xh">
             dh14-历史新闻
			</el-main>


			<el-aside width="120px" class="bgcolor_FC"></el-aside>


		</el-container>



	</div>

</template>

<script>

import zu0fujianfutu from '../fujian/zu0fujianfutu';
import toubu0 from '../fujian/toubu0';
import ceshi from '../fujian/ceshi';
import bianji0userinfo from '../fujian/bianji_userinfo';
import tj0pinglun from '../tijiao/tj_pinglun';
import tj0huifu from '../tijiao/tj_huifu';
import tj0fenxiang from '../tijiao/tj_fenxiang';


export default {
		name:'fuye_ce',
		components: {toubu0,bianji0userinfo,ceshi,tj0pinglun,tj0huifu,tj0fenxiang,zu0fujianfutu},
        methods:{
                    daohang11(){this.dh11=true;this.dh12=false;this.dh13=false;this.dh14=false;},
                    daohang12(){this.dh12=true;this.dh11=false;this.dh13=false;this.dh14=false;},
                    daohang13(){this.dh13=true;this.dh11=false;this.dh12=false;this.dh14=false;},
                    daohang14(){this.dh14=true;this.dh11=false;this.dh12=false;this.dh13=false;},
                    sousuojian:function(sou_keyword){
                        if(sou_keyword==''){
                            this.show_sousuokong=true;
                            this.show_sousuohou=false;
                            }
                        else{
                            this.show_sousuohou=true;
                            this.show_sousuokong=false;
						}

					},

ceshinews(){
	this.$axios.post("http://www.zhishiren.info/api/ceshinews/").then(response=>{this.newslist=response.data});
},


			
				filenameok() {this.$axios.post("http://www.zhishiren.info/api/ceshi_upload/").then(response=>{this.ceshi_upload=response.msg111});},

        },
        data() {
			return {dh11:true,dh12:false,dh13:false,dh14:false,show_sousuohou:false,show_sousuokong:false,sou_keyword:'',
			divcontent:'',ceshi1:201,created_ok:[],fnametest:'',ceshi_upload:"",
			ks:[111,222,333,444],fisrtstyle:'',blinkyellow:'',kk:"11",
			ceshilist:[1,2,3],
			newslist:[]
			}
		},

		computed:{welcomename(){return this.$cookies.get('username')}},

        created() {

			var that = this;
			that.kk="12";
			that.daohang12();
			// that.fisrtstyle='background-color:yellow';
			that.blinkyellow='blinkyellow';
			setTimeout(function(){
			// that.fisrtstyle='';
			that.blinkyellow='';
			}, 2000);




        },

// vue的跳转路由改变导航的:default-active

};

</script>



<style scoped>

@keyframes blink{
  0%{opacity: 1;}
  100%{opacity: 0;} 
}
/* 添加兼容性前缀 */
@-webkit-keyframes blink {
    0% { opacity: 1; }
    100% { opacity: 0; }
}
@-moz-keyframes blink {
    0% { opacity: 1; }
    100% { opacity: 0; }
}
@-ms-keyframes blink {
    0% {opacity: 1; } 
    100% { opacity: 0;}
}
@-o-keyframes blink {
    0% { opacity: 1; }
    100% { opacity: 0; }
}
.blinkyellow{
    background-color: yellow;
    animation: blink 1s linear infinite;
    /* 其它浏览器兼容性前缀 */
    -webkit-animation: blink 1s linear infinite;
    -moz-animation: blink 1s linear infinite;
    -ms-animation: blink 1s linear infinite;
    -o-animation: blink 1s linear infinite;
}

</style>