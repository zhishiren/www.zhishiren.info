<!-- 
// 以下是审核的原则：
// 1.内容有无谬误，
// 2.内容是否有意义
// 3.内容是否优质
// 4.内容是否含有禁止词
-->

<template>
<div id="shen" @click="turnfresh()">
		<zu2logo k=1></zu2logo>
		<el-container>
			<el-aside width="120px" class="bgcolor_FF"></el-aside>
			<el-menu default-active="6" class="el-menu-demo" mode="horizontal" @select="handleSelect" >
				<el-menu-item @click="daohang6" index="6" class="font20px" >网站数据</el-menu-item>
				<el-menu-item @click="daohang1" index="1" class="font20px" :disabled="disabled_yn">新增名片</el-menu-item>
				<el-menu-item @click="daohang2" index="2" class="font20px" :disabled="disabled_yn">言论管理</el-menu-item>
				<el-menu-item @click="daohang3" index="3" class="font20px" :disabled="disabled_yn">用户管理</el-menu-item>
				<!-- <el-menu-item @click="daohang4" index="4" class="font20px" :disabled="disabled_yn">知识管理</el-menu-item> -->
				<!-- <el-menu-item @click="daohang5" index="5" class="font20px" :disabled="disabled_yn">群组管理</el-menu-item> -->
				<!-- <el-menu-item @click="daohang7" index="7" class="font20px" >关于本站</el-menu-item> -->
		</el-menu>
		</el-container>

		<el-container v-show="dh1">
			<el-aside width="120px">
				<el-menu default-active="11" class="el-menu-vertical-demo bgcolor_menu_FC height_x00px" @open="handleOpen" @close="handleClose">
			      <el-menu-item @click="daohang11" index="11" class="font18px">
			        <span slot="title">人物名片</span>
			      </el-menu-item>
			      <!-- <el-menu-item @click="daohang12" index="12" class="font18px">
			        <span slot="title">公众名人</span>
			      </el-menu-item> -->
			      <!-- <el-menu-item @click="daohang13" index="13" class="font18px">
			        <span slot="title">变更信息</span>
			      </el-menu-item> -->
				  <el-menu-item @click="daohang14" index="14" class="font18px">
			        <span slot="title">工团组织</span>
			      </el-menu-item>	
			      <!-- <el-menu-item @click="daohang15" index="15" class="font18px">
			        <span slot="title">历史记录</span>
			      </el-menu-item>						       -->
			    </el-menu>
			</el-aside>
			<el-main v-show="dh11" class="section_xh">
				<el-card class="box-card">
					<el-row style="line-height: 40px;" >
						<el-col :span="2" style="text-align:right;">名称：</el-col>
						<el-col :span="6" >
							<el-input v-model="name1" placeholder="请输入人物名称"  style="width:100%;"></el-input>
						</el-col>
						<el-col :span="2" style="text-align:right;">职业：</el-col>
						<el-col :span="6" >
							<el-input v-model="jobs1" placeholder="请输入职业和身份"  style="width:100%;"></el-input>
						</el-col>
						<el-col :span="2" style="text-align:right;">地区：</el-col>
						<el-col :span="6" >
							<el-input v-model="area1" placeholder="请输入所在地区"  style="width:100%;"></el-input>
						</el-col>
					</el-row>
					<br>
					<el-row style="line-height: 40px;" >
						<el-col :span="2" style="text-align:right;">生卒：</el-col>
						<el-col :span="6" >
							<el-input v-model="date1" placeholder="请输入人物的生卒年月"  style="width:100%;"></el-input>
						</el-col>
						<el-col :span="2" style="text-align:right;">名言：</el-col>
						<el-col :span="14" >
							<el-input v-model="remark1" placeholder="请输入人物的名言"  style="width:100%;"></el-input>
						</el-col>
					</el-row>
					<br>
					<el-row style="line-height: 40px;" >
						<el-col :span="2" style="text-align:right;">事迹：</el-col>
						<el-col :span="22"><input v-model="lifeinfo1" placeholder="请输入人物的生平事迹" type="text" class="input_jian"  style="color:grey;font-size:20px;width:100%;" ></el-col>
					</el-row>
					<el-row style="text-align:center;line-height: 40px;">
						<el-col :span="10" style="text-align:left;">
						</el-col>
						<el-col :span="4" style="text-align:right;"><el-button style="font-size:20px" @click="zenginfo1('人物名片')" type="text">提交</el-button></el-col>
						<el-col :span="10" style="text-align:left;color:green;">{{this.okmsg}}</el-col>
					</el-row>
					<el-row>
						
						<el-upload
							name="touxiang"
							class="upload-demo"
							style=""
							action="http://www.zhishiren.info/api/shangchuan1/"
							Access-Control-Request-Headers: ContentType
							:data={user_id:this.id_touxiang}
							:on-preview="handlePreview"
							:on-remove="handleRemove"
							:on-success="shuaxintouxiang"
							:before-remove="beforeRemove"
							:on-change="onchange"
							:limit="1"
							:file-list="fileList"
							>
							<el-button class="font18px" type="text">更改头像...</el-button>
							<span class="font18px">-请输入用户id号：</span>
							<input v-model="id_touxiang"  type="text" class="input_jian"  style="color:grey;font-size:18px;width:200px;" >
						</el-upload>
				
					</el-row>
				</el-card>

			</el-main>
			<el-main v-show="dh14" class="section_xh">
				<el-card class="box-card">
					<el-row style="line-height: 40px;" >
						<el-col :span="2" style="text-align:right;">名称：</el-col>
						<el-col :span="6" >
							<el-input v-model="name2" placeholder="请输入组织的名称"  style="width:100%;"></el-input>
						</el-col>
						<el-col :span="2" style="text-align:right;">联系：</el-col>
						<el-col :span="6" >
							<el-input v-model="contact2" placeholder="请输入组织的联系方式"  style="width:100%;"></el-input>
						</el-col>
						<el-col :span="2" style="text-align:right;">地区：</el-col>
						<el-col :span="6" >
							<el-input v-model="area2" placeholder="请输入所在地区"  style="width:100%;"></el-input>
						</el-col>
					</el-row>
					<br>
					<el-row style="line-height: 40px;" >
						<el-col :span="2" style="text-align:right;">介绍：</el-col>
						<el-col :span="22"><input v-model="lifeinfo2" placeholder="请输入组织的介绍" type="text" class="input_jian"  style="color:grey;font-size:20px;width:100%;" ></el-col>
					</el-row>
					<el-row style="text-align:center;line-height: 40px;">
						<el-col :span="12" style="text-align:right;"><el-button style="font-size:20px" @click="zenginfo2('左翼组织')" type="text">提交</el-button></el-col>
						<el-col :span="12" style="text-align:left;color:green;">{{this.okmsg}}</el-col>
					</el-row>
				</el-card>
			</el-main>
			<el-aside width="120px">
			</el-aside>
		</el-container>

		<el-container v-show="dh2">
			<el-aside width="120px">
				<el-menu default-active="21" class="el-menu-vertical-demo bgcolor_menu_FC height_x00px" @open="handleOpen" @close="handleClose">
			      <el-menu-item @click="daohang21" index="21" class="font18px">
			        <span slot="title">待审发言</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang24" index="24" class="font18px">
			        <span slot="title">待审附言</span>
			      </el-menu-item>			      
				  <!-- <el-menu-item @click="daohang22" index="22" class="font18px">
			        <span slot="title">已拒绝</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang23" index="23" class="font18px">
			        <span slot="title">已通过</span>
			      </el-menu-item>		       -->
			    </el-menu>
			</el-aside>

			<el-main v-show="dh21" class="section_xh">
				<zu1caozuojishu zone_id="shenfayan" :showloading2="showloading2" @zhankai="zhankai_fy_daishen('fa')" @shuaxin="zhankai_fy_daishen('fa')"></zu1caozuojishu>
				<div v-if="show_shenfayan" class="zborder" style="height:auto;line-height:40px;" v-for="list in list_daishen" :key="list.pk" >
					<router-link class="a_brown" target="_blank" :to="{name:'yonghuye',params:{id:list.fields.uid1}}">{{list.fields.uname}}</router-link>
					<el-divider direction="vertical"></el-divider>
					<span class="a_black" @click="shen_fay_edit(list.pk,list.fields.fyshen)">{{list.fields.fyshen}}</span>
					<span style="float:right;"><a class="a_black" @click="shen_fy_pass(list.pk,'fa')">pass</a><el-divider direction="vertical"></el-divider><a class="a_black" @click="shen_fy_reject(list.pk)">reject</a></span>
					<div v-if="show_dialog_fay&&list.pk===editfyid" style="color:grey;">
						<el-input type="textarea" :autosize="{ minRows: 1,maxRows: 15}" v-model="to_edit_fayinfo" class="font18px" style="width:800px;" ></el-input>
						<span>
							<a class="a_grey" @click="editfayinfo()">提交</a>
							<el-divider direction="vertical"></el-divider>
							<a class="a_grey" @click="xxeditfayinfo()">取消</a>
						</span>
					</div>
				</div>
			</el-main>
			<el-main v-show="dh24" class="section_xh">
				<zu1caozuojishu zone_id="shenfuyan" :showloading2="showloading2" @zhankai="zhankai_fy_daishen('fu')" @shuaxin="zhankai_fy_daishen('fu')"></zu1caozuojishu>
				<div v-if="show_shenfuyan" class="zborder" style="height:auto;line-height:40px;"  v-for="list in list_daishen" :key="list.pk" >
					<router-link class="a_brown" target="_blank" :to="{name:'yonghuye',params:{id:list.fields.uid1}}">{{list.fields.uname}}</router-link>
					<el-divider direction="vertical"></el-divider>
					<span style="color:grey;">
						{{list.fields.cztype}}:
						<router-link class="a_grey" target="_blank" :to="{name:list.fields.type0,params:{id:list.fields.id0}}">          
							<span>{{list.fields.title0}}</span>
						</router-link>
					</span>
					<el-divider direction="vertical"></el-divider>
					<span class="a_black" @click="shen_fuy_edit(list.pk,list.fields.fyshen)">{{list.fields.fyshen}}</span>
					<span style="float:right;"><a class="a_black" @click="shen_fy_pass(list.pk,'fu')">pass</a><el-divider direction="vertical"></el-divider><a class="a_black" @click="shen_fy_reject(list.pk)">reject</a></span>
					<div v-if="show_dialog_fuy&&list.pk===editfyid" style="color:grey;">
						<el-input type="textarea" :autosize="{ minRows: 1,maxRows: 15}" v-model="to_edit_fuyinfo" class="font18px" style="width:800px;" ></el-input>
						<span>
							<a class="a_grey" @click="editfuyinfo()">提交</a>
							<el-divider direction="vertical"></el-divider>
							<a class="a_grey" @click="xxeditfuyinfo()">取消</a>
						</span>
					</div>
				</div>
			</el-main>
			<el-main v-show="dh22" class="section_xh">
				<!-- <a class="a_black" @click="zhankai_yijujue('已被拒绝')">--展开--</a> -->
			</el-main>
			<el-main v-show="dh23" class="section_xh">
				<!-- <a class="a_black" @click="zhankai_yishen('正常有效')">--展开--</a> -->
			</el-main>
			<el-aside width="120px"></el-aside>
		</el-container>

		<el-container v-show="dh3">
			<el-aside width="120px">
				<el-menu default-active="31" class="el-menu-vertical-demo bgcolor_menu_FC height_x00px" @open="handleOpen" @close="handleClose">
			      <el-menu-item @click="daohang31" index="31" class="font18px">
			        <span slot="title">注册待审</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang32" index="32" class="font18px">
			        <span slot="title">用户信息</span>
			      </el-menu-item>
			    </el-menu>
			</el-aside>
			<el-main v-show="dh31" class="section_xh">
				<zu1caozuojishu zone_id="shenyh0" :showloading2="showloading2" @zhankai="zhankai_yh_daishen('正在审核')" @shuaxin="zhankai_yh_daishen('正在审核')"></zu1caozuojishu>
				<el-row  class="huanhang zborder" v-if="show_shenzhuce" v-for="list in list1" :key="list.pk" >
					<span>{{list.fields.yonghu_name}}<el-divider direction="vertical"></el-divider>{{list.fields.yonghu_remark}}</span>
					<span style="float:right;">
						{{list.fields.yonghu_borntime}}
						<el-divider direction="vertical"></el-divider>
						<a class="a_black" @click="shen_yh_pass(list.pk)">pass</a>
						<el-divider direction="vertical"></el-divider>
						<a class="a_black" @click="shen_yh_reject(list.pk)">reject</a>
					</span>
				</el-row>
			</el-main>
			<el-main v-show="dh32" class="section_xh">
				<zu1caozuojishu zone_id="shenyh1" :showloading2="showloading2" @zhankai="zhankai_yh_daishen('正常有效')" @shuaxin="zhankai_yh_daishen('正常有效')"></zu1caozuojishu>
				<el-row class="huanhang zborder" v-if="show_sheninfo" v-for="list in list2" :key="list.pk" >
					<span>{{list.fields.yonghu_name}}<el-divider direction="vertical"></el-divider></span>
					<span style="color:blue" v-if="list.fields.yonghu_touxiang===1">
						<router-link class="a_brown" target="_blank" :to="{name:'yonghuye',params:{id:list.pk}}">头像</router-link>
						<el-divider direction="vertical"></el-divider>
					</span>
					<span class="a_black" @click="shen_yh_edit('2',list.pk)">{{list.fields.yonghu_area}}<el-divider direction="vertical"></el-divider></span>
					<span class="a_black" @click="shen_yh_edit('1',list.pk)">{{list.fields.yonghu_job}}<el-divider direction="vertical"></el-divider></span>
					<span class="a_black" @click="shen_yh_edit('3',list.pk)">{{list.fields.yonghu_contact}}<el-divider direction="vertical"></el-divider></span>
					<span class="a_black" @click="shen_yh_edit('4',list.pk)">{{list.fields.yonghu_hobby}}<el-divider direction="vertical"></el-divider></span>
					<span class="a_black" @click="shen_yh_edit('5',list.pk)">{{list.fields.yonghu_remark}}<el-divider direction="vertical"></el-divider></span>
					<span class="a_black" @click="shen_yh_edit('6',list.pk)">{{list.fields.yonghu_life}}</span>
					<span style="color:red;float:right;">{{qian_date(list.fields.yonghu_fresh)}}</span>
					
					<div v-if="show_dialog&&list.pk===edityhid" style="color:grey;">
						<input v-model="to_edit_info" type="text" class="input_jian font18px" style="width:200px;" >
						<a class="a_grey" @click="edityhinfo()">提交</a>
						<el-divider direction="vertical"></el-divider>
						<a class="a_grey" @click="xxedityhinfo()">取消</a>
					</div>
				</el-row>

			</el-main>
			<el-aside width="120px"></el-aside>
		</el-container>


		<el-container v-show="dh4">
			<el-aside width="120px"></el-aside>
		</el-container>

		<el-container v-show="dh5">
			<el-aside width="120px"></el-aside>
		</el-container>

		<el-container v-show="dh6">
			<el-aside width="120px">
				<el-menu default-active="65" class="el-menu-vertical-demo bgcolor_menu_FC height_x00px" @open="handleOpen" @close="handleClose">
			     <el-menu-item @click="daohang61" index="61" class="font18px">
			        <span slot="title">例外处理</span>
			      </el-menu-item>
				  <!-- <el-menu-item @click="daohang62" index="62" class="font18px">
			        <span slot="title">书名标题</span>
			      </el-menu-item>

			      <el-menu-item @click="daohang63" index="63" class="font18px">
			        <span slot="title">标签</span>
			      </el-menu-item>
				  <el-menu-item @click="daohang64" index="64" class="font18px">
			        <span slot="title">群组</span>
			      </el-menu-item>	 -->
			      <el-menu-item @click="daohang65" index="65" class="font18px">
			        <span slot="title">全站数据</span>
			      </el-menu-item>
				  <el-menu-item @click="daohang66" index="66" class="font18px">
			        <span slot="title">登陆数据</span>
			      </el-menu-item>							      
			    </el-menu>
			</el-aside>
			<el-main v-show="dh61" class="section_xh">
				<a class="a_black" @click="ceshi()">例外操作</a>
			</el-main>
			<el-main v-show="dh62" class="section_xh">
			</el-main>
			<el-main v-show="dh63" class="section_xh">
			</el-main>
			<el-main v-show="dh64" class="section_xh">
			</el-main>
			<el-main v-show="dh65" class="section_xh">
				<el-row>
					<el-col style="text-align:center;" :span="10">
						<span class="font20px">全站数据</span>
						<el-card>
							<zu0editshu jitype="yonghu" :jishu="zongshu_yonghu" zhid=999></zu0editshu>
							<zu0editshu jitype="yonghu1" :jishu="zongshu_yonghu1" zhid=999></zu0editshu>
							<zu0editshu jitype="yonghu2" :jishu="zongshu_yonghu2" zhid=999></zu0editshu>
							<zu0editshu jitype="biaoqian" :jishu="zongshu_biaoqian" zhid=999></zu0editshu>
							<zu0editshu jitype="qunzu" :jishu="zongshu_qunzu" zhid=999></zu0editshu>
							<zu0editshu jitype="wenji" :jishu="zongshu_wenji" zhid=999></zu0editshu>
							<zu0editshu jitype="fayan" :jishu="zongshu_fayan" zhid=999></zu0editshu>
							<zu0editshu jitype="fuyan" :jishu="zongshu_fuyan" zhid=999></zu0editshu>
							<zu0editshu jitype="wenduan" :jishu="zongshu_wenduan" zhid=999></zu0editshu>					
						</el-card>
					</el-col>
					<el-col :span="2"></el-col>
					<el-col  style="text-align:center;" :span="10">
						<el-row>
							<el-col :span="4"></el-col>
							<el-col :span="16">
								<span class="font20px">某点数据:</span>
								<input v-model="shuju001" type="text" placeholder="知识点ID" class="input_jian font18px" style="width:100px;" >
								<!-- <i class="el-icon-search" @click="searchid"> -->
								<i @click="searchjishu()" class="el-icon-search font20px a_black">查</i>
							</el-col>
							<el-col :span="4"></el-col>
						</el-row>
						<el-card>
							<zu0editshu jitype="dianji" :jishu="jishu_dianji" :zhid="shuju001"></zu0editshu>					
							<zu0editshu jitype="guanzhu" :jishu="jishu_guanzhu" :zhid="shuju001"></zu0editshu>					
							<zu0editshu jitype="fenxiang" :jishu="jishu_fenxiang" :zhid="shuju001"></zu0editshu>					
							<zu0editshu jitype="biaoqian" :jishu="jishu_biaoqian" :zhid="shuju001"></zu0editshu>					
							<zu0editshu jitype="pinglun" :jishu="jishu_pinglun" :zhid="shuju001"></zu0editshu>					
							<zu0editshu jitype="guanlian" :jishu="jishu_guanlian" :zhid="shuju001"></zu0editshu>					
							<zu0editshu jitype="xiugai" :jishu="jishu_xiugai" :zhid="shuju001"></zu0editshu>					
							<zu0editshu jitype="neihan" :jishu="jishu_neihan" :zhid="shuju001"></zu0editshu>					
							<zu0editshu jitype="zengwenji" :jishu="jishu_zengwenji" :zhid="shuju001"></zu0editshu>					
							<zu0editshu jitype="zengbiaoqian" :jishu="jishu_zengbiaoqian" :zhid="shuju001"></zu0editshu>					
							<zu0editshu jitype="zengqunzu" :jishu="jishu_zengqunzu" :zhid="shuju001"></zu0editshu>					
							<zu0editshu jitype="zengfayan" :jishu="jishu_zengfayan" :zhid="shuju001"></zu0editshu>					
							<zu0editshu jitype="shenfayan" :jishu="jishu_shenfayan" :zhid="shuju001"></zu0editshu>					
							<zu0editshu jitype="zengfenxiang" :jishu="jishu_zengfenxiang" :zhid="shuju001"></zu0editshu>					
						</el-card>
					</el-col>
				</el-row>
			</el-main>
			<el-main v-show="dh66" class="section_xh">
				
				<el-row class="huanhang zborder" v-for="list in denglu_jishu" :key="list.tjid" >
						<router-link class="a_brown" target="_blank" :to="{name:'yonghuye',params:{id:list.tjid}}">{{list.tjid}}</router-link>
						<el-divider direction="vertical"></el-divider>
						{{formatDate_hm_8(list.updatetime.$date)}}
				</el-row>

			</el-main>
			<el-aside width="120px"></el-aside>
		</el-container>

		<el-container v-show="dh7">
			<el-aside width="120px"></el-aside>
		</el-container>

		<div class="youcelan"></div>
	</div>

</template>

<script>
export default {
        name:'shen',
		components: {},
        methods:{
                    daohang1(){this.dh1=true;this.dh2=this.dh3=this.dh4=this.dh5=this.dh6=this.dh7=false;},
                    daohang2(){this.dh2=true;this.dh1=this.dh3=this.dh4=this.dh5=this.dh6=this.dh7=false;},
                    daohang3(){this.dh3=true;this.dh1=this.dh2=this.dh4=this.dh5=this.dh6=this.dh7=false;},
                    daohang4(){this.dh4=true;this.dh1=this.dh2=this.dh3=this.dh5=this.dh6=this.dh7=false;},
                    daohang5(){this.dh5=true;this.dh1=this.dh2=this.dh3=this.dh4=this.dh6=this.dh7=false;},
                    daohang6(){this.dh6=true;this.dh1=this.dh2=this.dh3=this.dh4=this.dh5=this.dh7=false;},
                    daohang7(){this.dh7=true;this.dh1=this.dh2=this.dh3=this.dh4=this.dh6=this.dh5=false;},

                    daohang11(){this.dh11=true;this.dh12=false;this.dh13=false;this.dh14=false;this.dh15=false;},
                    daohang12(){this.dh12=true;this.dh11=false;this.dh13=false;this.dh14=false;this.dh15=false;},
                    daohang13(){this.dh13=true;this.dh11=false;this.dh12=false;this.dh14=false;this.dh15=false;},
                    daohang14(){this.dh14=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh15=false;},
                    daohang15(){this.dh15=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh14=false;},

                    daohang21(){this.dh21=true;this.dh22=this.dh23=this.dh24=this.dh25=this.dh26=this.dh27=false;},
                    daohang22(){this.dh22=true;this.dh21=this.dh23=this.dh24=this.dh25=this.dh26=this.dh27=false;},
                    daohang23(){this.dh23=true;this.dh21=this.dh22=this.dh24=this.dh25=this.dh26=this.dh27=false;},
                    daohang24(){this.dh24=true;this.dh21=this.dh22=this.dh23=this.dh25=this.dh26=this.dh27=false;},
                    daohang25(){this.dh25=true;this.dh21=this.dh23=this.dh24=this.dh22=this.dh26=this.dh27=false;},
                    daohang26(){this.dh26=true;this.dh21=this.dh23=this.dh24=this.dh25=this.dh22=this.dh27=false;},
                    daohang27(){this.dh27=true;this.dh21=this.dh23=this.dh24=this.dh25=this.dh26=this.dh22=false;},

                    daohang31(){this.dh31=true;this.dh32=this.dh33=this.dh34=this.dh35=this.dh36=this.dh37=false;},
                    daohang32(){this.dh32=true;this.dh31=this.dh33=this.dh34=this.dh35=this.dh36=this.dh37=false;},
                    daohang33(){this.dh33=true;this.dh31=this.dh32=this.dh34=this.dh35=this.dh36=this.dh37=false;},
                    daohang34(){this.dh34=true;this.dh31=this.dh32=this.dh33=this.dh35=this.dh36=this.dh37=false;},
                    daohang35(){this.dh35=true;this.dh31=this.dh32=this.dh33=this.dh34=this.dh36=this.dh37=false;},
                    daohang36(){this.dh36=true;this.dh31=this.dh32=this.dh33=this.dh34=this.dh35=this.dh37=false;},
                    daohang37(){this.dh37=true;this.dh31=this.dh32=this.dh33=this.dh34=this.dh35=this.dh36=false;},

                    daohang41(){this.dh41=true;this.dh42=this.dh43=this.dh44=this.dh45=false;},
                    daohang42(){this.dh42=true;this.dh41=this.dh43=this.dh44=this.dh45=false;},
                    daohang43(){this.dh43=true;this.dh41=this.dh42=this.dh44=this.dh45=false;},
                    daohang44(){this.dh44=true;this.dh41=this.dh42=this.dh43=this.dh45=false;},
                    daohang45(){this.dh45=true;this.dh41=this.dh42=this.dh43=this.dh44=false;},


                    daohang51(){this.dh51=true;this.dh52=this.dh53=this.dh54=this.dh55=false;},
                    daohang52(){this.dh52=true;this.dh51=this.dh53=this.dh54=this.dh55=false;},
                    daohang53(){this.dh53=true;this.dh51=this.dh52=this.dh54=this.dh55=false;},
                    daohang54(){this.dh54=true;this.dh51=this.dh52=this.dh53=this.dh55=false;},
                    daohang55(){this.dh55=true;this.dh51=this.dh52=this.dh53=this.dh54=false;},

                    daohang61(){this.dh61=true;this.dh62=this.dh63=this.dh64=this.dh65=this.dh66=this.dh67=this.dh68=false;},
                    daohang62(){this.dh62=true;this.dh61=this.dh63=this.dh64=this.dh65=this.dh66=this.dh67=this.dh68=false;},
                    daohang63(){this.dh63=true;this.dh61=this.dh62=this.dh64=this.dh65=this.dh66=this.dh67=this.dh68=false;},
                    daohang64(){this.dh64=true;this.dh61=this.dh62=this.dh63=this.dh65=this.dh66=this.dh67=this.dh68=false;},
                    daohang65(){this.dh65=true;this.dh61=this.dh62=this.dh63=this.dh64=this.dh66=this.dh67=this.dh68=false;},
                    daohang66(){this.dh66=true;this.dh61=this.dh62=this.dh63=this.dh64=this.dh65=this.dh67=this.dh68=false;},
                    daohang67(){this.dh67=true;this.dh61=this.dh62=this.dh63=this.dh64=this.dh65=this.dh66=this.dh68=false;},
                    daohang68(){this.dh68=true;this.dh61=this.dh62=this.dh63=this.dh64=this.dh65=this.dh66=this.dh67=false;},

                    daohang71(){this.dh71=true;this.dh72=this.dh73=this.dh74=this.dh75=false;},
                    daohang72(){this.dh72=true;this.dh71=this.dh73=this.dh74=this.dh75=false;},
                    daohang73(){this.dh73=true;this.dh71=this.dh72=this.dh74=this.dh75=false;},
                    daohang74(){this.dh74=true;this.dh71=this.dh72=this.dh73=this.dh75=false;},
					daohang75(){this.dh75=true;this.dh71=this.dh72=this.dh73=this.dh74=false;},

					ceshi(){
						var _this= this;
						_this.axios
						.post('http://www.zhishiren.info/api/deletemongoid/', {
								kkk: "1"
							})
						.then(function (response) {
								alert(response.data);
						})
					},
				
					zenginfo1(aaa){
						var _this= this;
						if(_this.name1!==''){
							_this.axios
							.post('http://www.zhishiren.info/api/zenginfo1/', {
									yonghu_name: _this.name1,
									yonghu_pswd: 1111,
									yonghu_type :aaa,
									yonghu_area :_this.area1,
									yonghu_job : _this.jobs1,
									yonghu_remark : _this.remark1,
									yonghu_borntime :_this.date1,
									yonghu_life :_this.lifeinfo1,
								})
							.then(function (response) {
								if (response.data.okmsg === 0){
									_this.okmsg='注册成功！等待管理员审核...';
									setTimeout(function(){_this.okmsg='';}, 2000);
									_this.name1='';
									_this.area1='';
									_this.job1='';
									_this.remark1='';
									_this.date1='';
									_this.lifeinfo1='';
								}
								else{
									_this.okmsg='注册失败，联系管理员'
								}
							})
						}else{
							_this.okmsg='用户名不得为空！'
						}
						
					},
					zenginfo2(aaa){
						var _this= this;
						if(_this.name2!==''){
							_this.axios
							.post('http://www.zhishiren.info/api/zenginfo2/', {
									yonghu_name: _this.name2,
									yonghu_pswd: 1111,
									yonghu_type :aaa,
									yonghu_area :_this.area2,
									yonghu_contact:_this.contact2,
									yonghu_life :_this.lifeinfo2,
								})
							.then(function (response) {
								if (response.data.okmsg === 0){
									_this.okmsg='注册成功！等待管理员审核...';
									setTimeout(function(){_this.okmsg='';}, 2000);
									_this.name2='';
									_this.area2='';
									_this.contact2='';
									_this.lifeinfo2='';
								}
								else{
									_this.okmsg='注册失败，联系管理员'
								}
							})
						}else{
							_this.okmsg='用户名不得为空！'
						}
					},
					
					zhankai_fy_daishen(aaa){
						this.show_shenfayan=false;
						this.show_shenfuyan=false;
						this.showloading2=true;
						var _this= this;
						_this.axios
						.post('http://www.zhishiren.info/api/show_fy_daishen/', {
								type_: aaa
							})
						.then(function (response) {
							_this.list_daishen=JSON.parse(response.data);
							if(aaa==='fa'){_this.show_shenfayan=true;_this.show_shenfuyan=false;};
							if(aaa==='fu'){_this.show_shenfuyan=true;_this.show_shenfayan=false;};
							_this.showloading2=false;
						});
						_this.to_edit_fuyinfo='';
						_this.to_edit_fayinfo='';
						_this.editfyid=0;
						_this.show_dialog_fuy=false;
						_this.show_dialog_fay=false;
					},


					shen_fy_pass(kkk,fff){
						var _this= this;
						_this.axios
						.post('http://www.zhishiren.info/api/shen_fy_pass/', {
								kkk: kkk
							})
						.then(function (response) {
							if(response.data.msg===0){
								if(fff==='fa'){_this.zhankai_fy_daishen('fa');}
								if(fff==='fu'){_this.zhankai_fy_daishen('fu');}
							}
						})
					},
					shen_fy_reject(kkk,fff){
						var _this= this;
						_this.axios
						.post('http://www.zhishiren.info/api/shen_fy_reject/', {
								kkk: kkk
							})
						.then(function (response) {
							if(response.data.msg===0){
								if(fff==='fa'){_this.zhankai_fy_daishen('fa');}
								if(fff==='fu'){_this.zhankai_fy_daishen('fu');}
							}
						})
					},

					shen_yh_pass(kkk){
						var _this= this;
						_this.axios
						.post('http://www.zhishiren.info/api/shen_yh_pass/', {
								kkk: kkk
							})
						.then(function (response) {
							if(response.data.msg===0){
								_this.zhankai_yh_daishen('正在审核');
							}
						})
					},

					shen_yh_reject(kkk){
						var _this= this;
						_this.axios
						.post('http://www.zhishiren.info/api/shen_yh_reject/', {
								kkk: kkk
							})
						.then(function (response) {
							if(response.data.msg===0){
								_this.zhankai_yh_daishen('正在审核');
							}
						})
					},

					zhankai_yh_daishen(aaa){
						this.show_shenzhuce=false;
						this.show_sheninfo=false;
						this.showloading2=true;
						var _this= this;
						_this.axios
						.post('http://www.zhishiren.info/api/show_yh_daishen/', {
								status_: aaa
							})
						.then(function (response) {
							_this.list1=JSON.parse(response.data.list1);
							_this.list2=JSON.parse(response.data.list2);
							if(aaa==='正在审核'){_this.show_shenzhuce=true;_this.show_sheninfo=false;};
							if(aaa==='正常有效'){_this.show_sheninfo=true;_this.show_shenzhuce=false;};
							_this.showloading2=false;
						})
					},

					shen_yh_edit(kkk,yhid){
						this.show_dialog=true;
						this.infotype=kkk;
						this.edityhid=yhid;
					},

					shen_fay_edit(fyid,yyy){
						this.show_dialog_fay=false;
						this.to_edit_fayinfo='';
						this.editfyid=0;
						this.show_dialog_fay=true;
						this.editfyid=fyid;
						this.to_edit_fayinfo=yyy;
					},
					shen_fuy_edit(fyid,yyy){
						this.show_dialog_fuy=false;
						this.to_edit_fuyinfo='';
						this.editfyid=0;
						this.show_dialog_fuy=true;
						this.editfyid=fyid;
						this.to_edit_fuyinfo=yyy;
					},

					editfuyinfo(){
						var _this= this;
						_this.axios
						.post('http://www.zhishiren.info/api/edit_fyshen/', {
								fuyan:_this.to_edit_fuyinfo,
								fuid:_this.editfyid,
							})
						.then(function (response) {
							_this.to_edit_fuyinfo='';
							_this.editfyid=0;
							_this.show_dialog_fuy=false;
							_this.zhankai_fy_daishen('fu');

						});
					},

					editfayinfo(){
						var _this= this;
						_this.axios
						.post('http://www.zhishiren.info/api/edit_fyshen/', {
								fuyan:_this.to_edit_fayinfo,
								fuid:_this.editfyid,
							})
						.then(function (response) {
							_this.to_edit_fayinfo='';
							_this.editfyid=0;
							_this.show_dialog_fay=false;
							_this.zhankai_fy_daishen('fa');
						});
					},

					xxeditfayinfo(){
						var _this= this;
						_this.to_edit_fayinfo='';
						_this.editfyid=0;
						_this.show_dialog_fay=false;
					},

					editfuyinfo(){
						var _this= this;
						_this.axios
						.post('http://www.zhishiren.info/api/edit_fyshen/', {
								fuyan:_this.to_edit_fuyinfo,
								fuid:_this.editfyid,
							})
						.then(function (response) {
							_this.to_edit_fuyinfo='';
							_this.editfyid=0;
							_this.show_dialog_fuy=false;
							_this.zhankai_fy_daishen('fu');
						});
					},

					xxeditfuyinfo(){
						var _this= this;
						_this.to_edit_fuyinfo='';
						_this.editfyid=0;
						_this.show_dialog_fuy=false;
					},

					edityhinfo(){
						var _this= this;
						_this.axios
						.post('http://www.zhishiren.info/api/edit_mypage/', {
								zhi_type: _this.infotype,
								zhi:_this.to_edit_info,
								userid:_this.edityhid,
								shen_yn:1,
							})
						.then(function (response) {
							_this.zhankai_yh_daishen('正常有效');
							_this.infotype='';
							_this.to_edit_info='';
							_this.edityhid=0;
							_this.show_dialog=false;
						});
					},

					xxedityhinfo(){
						var _this= this;
						_this.infotype='';
						_this.to_edit_info='';
						_this.edityhid=0;
						_this.show_dialog=false;
					},

					searchjishu(){
						var _this= this;
						_this.showloading1=true;
						_this.axios
						.post('http://www.zhishiren.info/api/showxxjishu/', {k:_this.shuju001})
						.then(function (response) {
							_this.jishu=JSON.parse(response.data);
							_this.jishu_dianji=_this.jishu.dianji;
							_this.jishu_guanzhu=_this.jishu.guanzhu;
							_this.jishu_fenxiang=_this.jishu.fenxiang;
							_this.jishu_biaoqian=_this.jishu.biaoqian;
							_this.jishu_pinglun=_this.jishu.pinglun;
							_this.jishu_guanlian=_this.jishu.guanlian;
							_this.jishu_xiugai=_this.jishu.xiugai;
							_this.jishu_neihan=_this.jishu.neihan;
							_this.jishu_updatetime=_this.jishu.updatetime;
							_this.jishu_zengwenji=_this.jishu.zengwenji;
							_this.jishu_zengbiaoqian=_this.jishu.zengbiaoqian;
							_this.jishu_zengqunzu=_this.jishu.zengqunzu;
							_this.jishu_zengfayan=_this.jishu.zengfayan;
							_this.jishu_shenfayan=_this.jishu.shenfayan;
							_this.jishu_zengfenxiang=_this.jishu.zengfenxiang;
							});
					},
					shuaxintouxiang(response, file, fileList) {
						
							this.$router.go(0);
							// this.ceshi2=false;
							// this.ceshi2=true;
							// this.$refs.upload.clearFiles();
							// this.chuantouxiang_okmsg=9;
							// this.ceshi_id=0;
						
					},

					handleExceed(files, fileList) {this.$message.warning(`每次操作只能上传一个文件！`);},
					beforeRemove(file, fileList) {return this.$confirm(`确定移除 ${ file.name }？`);},
					handleRemove(file, fileList) {console.log(file, fileList);},
					handlePreview(file) {console.log(file);},
					onchange(file, fileList){this.ceshi_id=1;},

        },
        data(){
            return {
                dh1:false,dh2:false,dh3:false,dh7:false,dh5:false,dh6:true,dh4:false,
                dh11:true,dh12:false,dh13:false,dh14:false,dh15:false,
                dh21:true,dh22:false,dh23:false,dh24:false,dh25:false,dh26:false,dh27:false,
                dh31:true,dh32:false,dh33:false,dh34:false,dh35:false,dh36:false,dh37:false,
                dh41:true,dh42:false,dh43:false,dh44:false,dh45:false,
                dh51:true,dh52:false,dh53:false,dh54:false,dh55:false,
                dh65:true,dh62:false,dh63:false,dh64:false,dh61:false,dh66:false,dh67:false,dh68:false,
				dh71:true,dh72:false,dh73:false,dh74:false,dh75:false,
				name1:'',date1:'',jobs1:'',area1:'',remark1:'',lifeinfo1:'',
				name2:'',area2:'',contact2:'',lifeinfo2:'',
				list_daishen:[],
				list_yijujue:[],
				list1:[],list2:[],
				okmsg:'',
				show_shenfayan:false,show_shenfuyan:false,
				showloading2:false,
				show_shenzhuce:false,show_sheninfo:false,
				show_dialog:false,show_dialog_fay:false,show_dialog_fuy:false,
				to_edit_info:'',to_edit_fayinfo:'',to_edit_fuyinfo:'',
				infotype:'',
				edityhid:0,
				show_touxiang1:false,
				shuju001:'',
				id_touxiang:0,

				ceshi_id:0,

				zongshu_yonghu:0,
				zongshu_yonghu1:0,
				zongshu_yonghu2:0,
				zongshu_biaoqian:0,
				zongshu_qunzu:0,
				zongshu_wenji:0,
				zongshu_fayan:0,
				zongshu_fuyan:0,
				zongshu_wenduan:0,

				jishu_dianji:0,
				jishu_guanzhu:0,
				jishu_fenxiang:0,
				jishu_biaoqian:0,
				jishu_pinglun:0,
				jishu_guanlian:0,
				jishu_xiugai:0,
				jishu_neihan:0,
				jishu_updatetime:0,
				jishu_zengwenji:0,
				jishu_zengbiaoqian:0,
				jishu_zengqunzu:0,
				jishu_zengfayan:0,
				jishu_shenfayan:0,
				jishu_zengfenxiang:0,

				denglu_jishu:[]
			
			}
		},
		computed:{
			disabled_yn(){return this.$cookies.get('usertype')==='内容整理'?false:true}

		},
		created: function () {
			var _this= this;
			_this.showloading1=true;
			_this.axios
			.post('http://www.zhishiren.info/api/showalldata/', {k:'kkk'})
			.then(function (response) {
				_this.jishu=JSON.parse(response.data);
				_this.zongshu_yonghu=_this.jishu.yonghu;
				_this.zongshu_yonghu1=_this.jishu.yonghu1;
				_this.zongshu_yonghu2=_this.jishu.yonghu2;
				_this.zongshu_biaoqian=_this.jishu.biaoqian;
				_this.zongshu_qunzu=_this.jishu.qunzu;
				_this.zongshu_wenji=_this.jishu.wenji;
				_this.zongshu_fayan=_this.jishu.fayan;
				_this.zongshu_fuyan=_this.jishu.fuyan;
				_this.zongshu_wenduan=_this.jishu.wenduan;
				});
			_this.axios
			.post('http://www.zhishiren.info/api/show_users_denglu/', {k:'kkk'})
			.then(function (response) {
				_this.denglu_jishu=JSON.parse(response.data);
				});
		},

};
</script>
<style>

.zborder{box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04)}
</style>



