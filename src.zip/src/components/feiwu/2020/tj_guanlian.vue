// 这个评论栏是用在每个知识点页面之下的关联其他知识点的组件，非常通用
<template>
	<div id="tj_guanlian" class="font16px">
		<el-row class="font18px">
			<el-button @click="to_guanlian" type="text" class="font18px" style="padding-bottom:0px;">
				<i class="el-icon-connection"></i>关联...</el-button>
			共有7条关联知识。-展开-
		</el-row>

		<el-dialog title="关联附言..." width="400px" :visible.sync="show_dialog">
            <el-row>
                <el-col :span="7" class="font18px" style="padding-top:10px;">
                    关联ID号：
                </el-col>
                <el-col :span="17">
                    <el-input style="width:100%" placeholder="请在你所关注的标签中选择">
                    </el-input> 
                </el-col>
            </el-row>
            <br>

			<el-row>
                <el-col :span="7" class="font18px" style="padding-top:10px;">
                    两者关系：
                </el-col>
                <el-col :span="17">
                    <el-select style="width:100%" placeholder="请在你所关注的标签中选择">
                    </el-select> 
                </el-col>
            </el-row>
            <br>
            <el-row>
                <!-- 这里的格式要注意，“请输入分享附言，限100字。”与上下文的标签不能有换行等。 -->
                <div contenteditable ref="contents" @paste="onPaste" class="pinglunlan">请输入标签附言，限100字。</div>
            </el-row>
            <el-row>
                <el-col :span="7">
                    <a class="a_black font18px" href="javascript:;" @click="f_blod">
                        <b>所选加粗</b>
                    </a>
                </el-col>
                <el-col class="font18px" :span="11">
                    <span style="color:green;"><i class="el-icon-success"></i>发布成功!</span>
                    <span style="color:orange;" v-show="ok_msg==2"><i class="el-icon-warning-outline"></i>标签不能为空!</span>
                    <span style="color:red;" v-show="ok_msg==3"><i class="el-icon-error"></i>数据库写入失败!</span>
                </el-col>
                <el-col :span="6" style="text-align:right">
                    <a @click="fabujian" class="font20px a_black" >发布</a>
                </el-col>
            </el-row>
        </el-dialog>



		<el-row class="br10px17px" >
			<el-row>
				zhao关联了《测试的文件》
				<span style="color:grey">附言:
					<span style="color:red;">(相互矛盾)</span>注意自主支付的金额，试测试,一二三四五六七八九十一二三四五六七八九十一二三四五六七八九十一二三四五六七八九十。</span>
				<tj0huifu></tj0huifu>
			</el-row>
            <el-row><el-divider style="margin:0px;"></el-divider></el-row>
		</el-row>

		<el-row class="br10px17px" >
			<el-row>
				zhao关联了《测试的文件》
				<span style="color:grey">附言:
					<span style="color:red;">(相互矛盾)</span>注意自主支付的金额，试测试,一二三四五六七八九十一二三四五六七八九十一二三四五六七八九十一二三四五六七八九十。</span>
				<tj0huifu></tj0huifu>
			</el-row>
            <el-row><el-divider style="margin:0px;"></el-divider></el-row>
		</el-row>


	</div>
</template>


<script type="text/javascript">
import fanwei from '../fujian/fanwei';
import tj0huifu from '../tijiao/tj_huifu';


	export default {
		name: 'tj_guanlian',
		components: {fanwei,tj0huifu},
		data () {
			return {
				show_dialog:false,
				show_xunhuan:true,

				ok_msg:9,
                qunzu_id:1,

				att_value:'att0',

			}
		},
		methods: {

			fabujian:function(){
					var that = this;
					if(that.$refs.contents.innerHTML==='请输入关联附言，限100字。'){that.fuyan=''}
					else{that.fuyan=that.$refs.contents.innerHTML};
					that.axios
						.post('http://www.zhishiren.info/api/oofenxiang/',{zhi_id:that.zhi_id,zhi_title:that.zhi_title,userid: that.$cookies.get('userid'),username:that.$cookies.get('username'),zhi_leixing:that.zhi_type,divcontent:that.fuyan})
						.then(function (response) {
									if (response.data.ok_msg === 0){
										that.ok_msg=response.data.ok_msg;
										that.$refs.contents.innerHTML='请输入关联附言，限100字。';
										that.show_dialog=false;
									}
					})
			},

			f_blod() {
                document.execCommand ( 'bold', false );
			},

			to_guanlian(){
				this.show_dialog=true;
			},


		}
	}
</script>

