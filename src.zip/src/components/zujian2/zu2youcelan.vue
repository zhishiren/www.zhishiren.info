<template>
    <div id="zu2youcelan">
        <router-link  class="square_right a_grey" to="/sou" target="_blank">搜</router-link><br>
		<router-link  class="square_right a_grey" to="/zeng" target="_blank">增</router-link><br>
		<router-link  class="square_right a_grey" to="/wen" target="_blank">问</router-link><br>
		<!-- <router-link  class="square_right a_grey" to="/liao" target="_blank">聊</router-link><br> -->
		<a href="http://tool.chacuo.net/cryptdes/" class="square_right a_grey"  target="_blank">密</a><br>
		<router-link class="square_right a_grey" target="_blank" :to="{name:'liao',params:{id:1}}">          
            <span>聊</span>
        </router-link>
        <br>
		<router-link v-if="disabled_yn===false" class="square_right a_grey" to="/shen" target="_blank">审</router-link><br>

        <!-- <router-link  class="square_right a_grey" to="/fuye_liao" target="_blank">
			聊帮记问玩看听
		</router-link> -->
    </div>
</template>

<script>
    export default {
        name:'zu2youcelan',
        props:[],//k是区分
        data() {return {

        }},
        computed:{
            disabled_yn(){return this.$cookies.get('usertype')==='内容整理'?false:true}


        },
        methods:{
        },
    };
</script>



