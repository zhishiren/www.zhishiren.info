//作废，用editfuyan代替。

<template>
<span>
    <span v-if="show_edit===false" v-html="beizhu" ></span>
    <span v-if="manager===yonghuid">
        <a v-if="show_edit===false" @click="bianji" class="a_grey font16px"><i class="el-icon-edit">编辑</i></a>
        <span v-if="edit_loading===false">
            <input v-if="show_edit" placeholder="请输入用户的备注..." v-model="changed_beizhu" type="text" class="input_jian font16px" style="color:grey" >
            <a v-if="show_edit" @click="queding" class="a_grey font16px"><i class="el-icon-check"></i>确定</a> 
            <a v-if="show_edit" @click="huanyuan" class="a_grey font16px"><i class="el-icon-refresh-left"></i>还原</a>
            <span v-if="show_kong" style="color:orange"><i class="el-icon-warning"></i>输入不能为空！</span>
            <span v-if="show_error" style="color:red"><i class="el-icon-warning"></i>修改失败！</span>
        </span>
        <span v-if="edit_loading===true">
            <i style="el-icon-loading"></i>
        </span>
        
    </span>
    
</span>

</template>

<script>
  export default {
    data() {
      return {
                show_edit:false,
                show_kong:false,
                changed_beizhu:'',
                show_error:false,
                edit_loading:false,
      }
    },

    props:['qz_yh_id','beizhu','manager'],

    computed: {

            yonghuid(){return parseInt(this.$cookies.get('userid'))},
            
    },

    methods:{
        bianji(){
        this.show_edit=true;
        },

        queding(){
            this.edit_loading=true;
                    var _this= this;
                    if(_this.changed_beizhu==''){_this.show_kong=true}
                    else{
                        _this.$axios
                        .post('http://www.zhishiren.info/api/edit_beizhu/', {qz_yh_id: _this.qz_yh_id,beizhu:_this.changed_beizhu})
                        .then(function(response){
                            if (response.data.changed_ok === 0){
                                _this.beizhu=_this.changed_beizhu;
                                _this.show_edit=false;
                                _this.show_kong=false;
                                _this.edit_loading=false;
                            }
                            else{
                                _this.show_error=true,
                                _this.edit_loading=false;
                                setTimeout(function(){
                                    _this.show_error=false;
                                    _this.show_edit=false;
                                    _this.show_kong=false;
                                }, 2000);

                            }
                        })
                    }
        },


        huanyuan(){
        this.show_edit=false;
        this.show_kong=false;
        },
    }

  }
</script>





