<template>
<div id="biaoqianye"  @click="turnfresh()">
		<zu2logo k=1></zu2logo>
		<el-container>
			<el-aside width="120px" class="bgcolor_FF"></el-aside>
			<el-main class="bgcolor_FC font18px">
				<el-card  v-if="qz_info.qz_id"  class="box-card">
					<el-row class="font21px">{{this.qz_info.qz_title}}</el-row>
					<el-row>
						<span><b>属性<i class="el-icon-caret-right"></i></b></span>
						<span>群组ID:{{this.qz_info.qz_id}}<el-divider direction="vertical"></el-divider></span>
						<span v-if="qz_info.qz_status==='失效已删'" style="color:red;">{{this.qz_info.qz_status}}<el-divider direction="vertical"></el-divider></span>
						<span v-if="qz_info.qz_status!=='正常有效'">{{this.qz_info.qz_status}}<el-divider direction="vertical"></el-divider></span>
						<span>{{this.qz_info.qz_type}}<el-divider direction="vertical"></el-divider></span>
						<span>管理人:
							<router-link v-if="qz_info.qz_manager!==this.userid" class="a_black" target="_blank" :to="{name:'yonghuye',params:{id:qz_info.qz_manager}}">
								{{this.qz_info.qz_manager}}
							</router-link>
							<span v-if="qz_info.qz_manager===this.userid">你</span>
						</span>
						<zu0tongjishu :dj="qz_tongji.dianji" :gz="qz_tongji.neihan" :fx="qz_tongji.fenxiang" qz_yn='1'></zu0tongjishu>
					</el-row>
					<el-row v-if="qz_info.qz_remark!==null">
						<b>说明<i class="el-icon-caret-right"></i></b><span v-html="qz_info.qz_remark"></span>
					</el-row>
					<zu0fujianfutu v-if="this.qz_info.fu!==0" :zhid="qz_info.qz_id"></zu0fujianfutu>
				</el-card>
				<el-card v-else>
					<br>
						<div style="text-align:center;font-size:30px;"><i class="el-icon-loading"></i>正在加载</div>
					<br>
				</el-card>
			</el-main>
			<el-aside width="120px" class="bgcolor_FC"></el-aside>
		</el-container>

		<el-container>
			<el-aside width="120px">
				<el-menu default-active="12" class="el-menu-vertical-demo bgcolor_menu_FC" @open="handleOpen" @close="handleClose">
			      <el-menu-item @click="daohang11" index="11" class="font18px">
			        <span slot="title">组员列表</span>
			      </el-menu-item>
				  <el-menu-item @click="daohang12" index="12" class="font18px">
			        <span slot="title">关注分享</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang13" index="13" class="font18px">
			        <span slot="title">评论</span>
			      </el-menu-item>
			      <!-- <el-menu-item @click="daohang14" index="14" class="font18px">
			        <span slot="title">关联知识</span>
			      </el-menu-item> -->
				  <el-menu-item @click="daohang15" index="15" class="font18px">
			        <span slot="title">群内动态</span>
			      </el-menu-item>
                  <!-- <el-menu-item @click="daohang16" index="16" class="font18px">
			        <span slot="title">群组管理</span>
			      </el-menu-item> -->
			    </el-menu>
			</el-aside>
			<el-main v-show="dh12" class="section_xh">
				<el-row>
					<zu1caozuojishu zone_id="分享" :zhid="qz_info.qz_id" type0="qunzuye" :title0="qz_info.qz_title" :fanwei="qz_info.qz_fanwei"></zu1caozuojishu>
					<br>
					<zu1caozuojishu zone_id="加入群组" :zhid="qz_info.qz_id" type0="qunzuye" :title0="qz_info.qz_title"></zu1caozuojishu>
					<br>
					<zu1caozuojishu zone_id="纠错" :zhid="qz_info.qz_id" type0="qunzuye" :title0="qz_info.qz_title"></zu1caozuojishu>
					<br>
					<xhcaozuo zoneid="加入标签" :zhid="qz_info.qz_id" :title0="qz_info.qz_title" type0="qunzuye" :fanwei="qz_info.qz_fanwei" :listNum="qz_tongji.biaoqian"></xhcaozuo>
				</el-row>
			</el-main>
			<el-main v-show="dh13" class="section_xh">	
				<xhcaozuo zoneid="评论" :zhid="qz_info.qz_id" :title0="qz_info.qz_title" type0="qunzuye" :fanwei="qz_info.qz_fanwei" :listNum="qz_tongji.pinglun"></xhcaozuo>
			</el-main>
			<!-- <el-main v-show="dh14" class="section_xh"></el-main> -->
			<el-main v-show="dh15" class="section_xh">
				<xhqznei :qzid="qz_info.qz_id" dongtaitype="群"></xhqznei>
			</el-main>
            <el-main v-show="dh16" class="section_xh">
				<xhchanged :zhid="qz_info.qz_id" zhitype="qunzuye" :list='qz_info' :managerid="qz_info.qz_manager" :zhicontent="qz_info.qz_remark" :fanwei="qz_info.qz_fanwei" :listNum="qz_tongji.xiugai"></xhchanged>
			</el-main>
			<el-main v-show="dh11" class="section_xh">
        		<xhzuyuan :qzid="qz_info.qz_id" :managerid="qz_info.qz_manager" :qztitle="qz_info.qz_title"  :listNum="qz_tongji.neihan"></xhzuyuan>
			</el-main>
			<el-aside width="120px" class="bgcolor_FC"></el-aside>
		</el-container>
	</div>

</template>

<script>

import Xhqznei from '../xunhuan/xhqznei.vue';

export default {
        name:'biaoqianye',
		components: {Xhqznei,},
        methods:{
                    daohang11(){this.dh11=true;this.dh12=false;this.dh13=false;this.dh14=false;this.dh15=false;this.dh16=false;},
                    daohang12(){this.dh12=true;this.dh11=false;this.dh13=false;this.dh14=false;this.dh15=false;this.dh16=false;},
                    daohang13(){this.dh13=true;this.dh11=false;this.dh12=false;this.dh14=false;this.dh15=false;this.dh16=false;},
					daohang14(){this.dh14=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh15=false;this.dh16=false;},
                    daohang15(){this.dh15=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh14=false;this.dh16=false;},
					daohang16(){this.dh16=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh14=false;this.dh15=false;},
					//这里的k值指的是关注数或分享数等等，这里的关注是加入群组的意思
					add1(k){
						if(k==1){this.qz_tongji.fenxiang++;}
						if(k==2){this.qz_tongji.guanzhu++;}
					},
					minus1(k){
						if(k==2){this.qz_tongji.guanzhu--;}
					},

        },
        data() {
			return {dh12:true,dh11:false,dh13:false,dh14:false,dh15:false,dh16:false,
			qunzu_id:0,
			qz_info:[],
			qz_tongji:[],
			focused_yn:0,
			kkk:0}
        },
        created() {
				this.qunzu_id = this.$route.params.id;//获取上个页面传递的id,在下面获取数据的时候先提交id,这里的id不用加前缀
				var _this= this;
				_this.axios
				.post('http://www.zhishiren.info/api/show_qunzuye/', {qunzu_id:this.qunzu_id})
				.then(function (response) {
					_this.qz_info=response.data;
					_this.qz_tongji=JSON.parse(response.data.qz_tongji);
				});
		},
		computed: {
				welcomename(){return this.$cookies.get('username')},
				userid(){return parseInt(this.$cookies.get('userid'))},
		},
};

</script>

<style scoped>

    
</style>




