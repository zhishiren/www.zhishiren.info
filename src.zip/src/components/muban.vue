<template>
    <div id="zu2logo" class="logo">知识人


    </div>
</template>

<script>
    export default {
        name:'zu2logo',
        props:['k'],//k是区分
        data() {return {

        }},
        computed:{

        },
        methods:{
            
            
        },
    };
</script>



