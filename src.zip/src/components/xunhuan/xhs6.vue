
<template>
	<div id="xhs6">
        <zu1caozuojishu zone_id='soufuyan' :jishu="count_fuyan" :showloading1="showloading1" :showloading2="xhs6_loading" @zhankai="zhankaijian" @shuaxin="shuaxinjian"></zu1caozuojishu>  
        <div v-if="fuyan1 && xhs6_loading===false">
            <el-row v-for="l in fuyan1" :key="l.pk" class="br10px17px">
                <zu0niming :uname="l.fields.uname" :uid1="l.fields.uid1" :uid0="l.fields.uid0"></zu0niming>
                <span v-if="l.fields.cztype==='加入标签'">添加了</span>
                <span v-if="l.fields.cztype==='关联'">关联了</span>
                <span v-if="l.fields.cztype==='分享'">分享了</span>
                <span v-if="l.fields.cztype==='评论'">评论了</span>
                <zu1yuansu :list="l"></zu1yuansu>
                <span style="color:grey;">:<span v-html="l.fields.fy" ></span></span>
                <zu1huifulan :list='l' @shanchuok="shuaxinjian()"></zu1huifulan>
                <el-row><el-divider style="margin:0px;"></el-divider></el-row>
            </el-row>
        </div>
    </div>
</template>
<script>

export default {
    name:'xhs6',
    components: {},
    props:['count_fuyan',,'showloading1'],
	data() {return {
        fuyan1:[],
        xhs6_loading:false,
    }},

	methods:{
            zhankaijian(){this.shuaxinjian();},
            shuaxinjian(){
                this.xhs6_loading=true;
                this.$axios
                    .get('http://www.zhishiren.info/api/xunhuans6/')
                    .then(response=>{
                        this.fuyan1=JSON.parse(response.data);
                        this.xhs6_loading=false;
                });
            },

    },	
};
</script>

                        <!-- <span v-if="l.fields.act_type==='a04'">
                            <span style="color:grey;">评论了</span>
                            <router-link class="a_black" target="_blank" :to="{name:l.fields.item0_type,params:{id:l.fields.item0_id}}">
                                <span><i v-if="l.fields.item0_type==='yonghuye'" class="el-icon-s-custom"></i>{{l.fields.item0_title}}</span>
                            </router-link>
                        </span>
                        <span v-if="l.fields.act_type==='a03'">
                            <span style="color:grey;">添加了</span>
                            <router-link class="a_black" target="_blank" :to="{name:l.fields.item1_type,params:{id:l.fields.item1_id}}">
                                <span><i v-if="l.fields.item1_type==='yonghuye'" class="el-icon-s-custom"></i>{{l.fields.item1_title}}</span>
                            </router-link>
                            <span style="color:grey;">到标签</span>
                            <router-link class="a_black" target="_blank" :to="{name:l.fields.item0_type,params:{id:l.fields.item0_id}}">
                                <span>{{l.fields.item0_title}}</span>
                            </router-link>
                        </span>
                        <span v-if="l.fields.act_type==='a18'">
                            <span style="color:grey;">关联了</span>
                            <router-link class="a_black" target="_blank" :to="{name:l.fields.item0_type,params:{id:l.fields.item0_id}}">
                                <span>{{l.fields.item0_title}}</span>
                            </router-link>
                            <span style="color:grey;">和</span>
                            <router-link class="a_black" target="_blank" :to="{name:l.fields.item1_type,params:{id:l.fields.item1_id}}">
                                <span><i v-if="l.fields.item1_type==='yonghuye'" class="el-icon-s-custom"></i>{{l.fields.item1_title}}</span>
                            </router-link>
                        </span> -->
