<!-- 这是通用的模版-->
<template>
	<div id="xhyhy11">
            <el-row class="font18px">
                <span>该用户共有{{this.listNum}}条动态。</span>
                <zhankai0 ref="zhankai0" @get_list="get_list" @shuaxin="shuaxin"></zhankai0>
            </el-row>
            <div v-if="show_xhyhy11">
                <el-row class="br10px17px" v-for="list in lists" :key="list.createrid" >
                    <div v-if="list.news_type==='a02'">
                            <el-row>
                                <span>他</span><span>分享了</span>
                                <router-link class="a_black" target="_blank" :to="{name:list.item0_type,params:{id:list.item0_id}}">          
                                    <span v-if="list.item0_type==='fayanye'" style="color:brown;">
                                        <font style="font-size:20px;"><b>“</b></font><span v-html="list.item0_title" ></span><font style="font-size:20px;"><b>”</b></font>
                                    </span>
                                    <span v-if="list.item0_type!=='fayanye'">
                                        <i v-if="list.item0_type==='yonghuye'" class="el-icon-s-custom"></i>{{list.item0_title}}
                                    </span>
                                </router-link>
                                <span v-if="list.news_comm_content!=='无'" style="color:grey;">
                                    附言:<span v-html="list.news_comm_content" ></span>
                                </span>
                            </el-row>
                            <tj0huifu :shuaxinid="shuaxinyn" timek=0 news_yn=1 @shanchuok="shanok()" :act_id="list.news_comm_id" :act_yan="list.news_comm_content" :create_time="list.create_time.$date" :fanwei_id="list.news_fanwei" :it_type="list.item1_type" :it_att="list.news_attitude" :creater_id="list.createrid"  :item1title="'你分享了:'+list.item0_title+'>>>附言:'+list.news_comm_content"></tj0huifu>
                    </div>
                    <div v-if="list.news_type==='a05'">
                            <el-row>
                                    <span  v-if="list.news_zishu===0">他发言说
                                        <router-link class="a_black" target="_blank" :to="{name:'fayanye',params:{id:list.item0_id}}">          
                                            <span style="color:brown;">
                                                <font style="font-size:20px;"><b>“</b></font><span v-html="list.news_comm_content" ></span><font style="font-size:20px;"><b>”</b></font>
                                            </span>
                                        </router-link>
                                    </span>
                                    <span v-if="list.news_zishu!==0" class="font18px" style="color:grey;">你发布了一段{{list.news_zishu}}字的密文:
                                        <input style="width:1px;border-color:white;border:0px;" type="text" v-model="list.news_comm_content" :id="list.news_comm_id">                                            
                                        <a class="a_brown" @click="kcopy(list.news_comm_id)">点击复制密文</a>
                                    </span>
                            </el-row>
                            <el-row>
                                <zu0zu0fujianfutu v-if="list.fujian!==0" :zhid="list.item0_id" :futujian="list.fujian"></zu0zu0fujianfutu>
                            </el-row>
                            <tj0huifu :shuaxinid="shuaxinyn" timek=0 news_yn=1 @shanchuok="shanok()" :act_id="list.news_comm_id" :act_yan="list.news_comm_content" :create_time="list.create_time.$date" :fanwei_id="list.news_fanwei" :it_type="list.item0_type" :it_att="list.news_attitude" :creater_id="list.createrid"  :item1title="'你发表了言论:'+list.news_comm_content"></tj0huifu>
                    </div>
                    <el-row><el-divider style="margin:0px;"></el-divider></el-row>
                </el-row>
                <br>
                <el-pagination v-if="listNum>10" style="text-align:right;"
                                background
                                :page-size=10
                                :total="listNum"
                                :current-page.sync="currentPage"
                                layout="total, prev, pager, next">
                </el-pagination>
            </div>
            
    </div>
</template>

<script>
import zu0zu0fujianfutu from '../fujian/zu0zu0fujianfutu';
import tj0huifu from '../tijiao/tj_huifu';
import zhankai0 from '../fujian/zhankai0';


export default {
    name:'xhyhy11',
    components: {zu0zu0fujianfutu,tj0huifu,zhankai0},
	props:['userid'],
    
	data() {return {
        currentPage: 1,//当前分页的数值
        listNum:0,//分页总条数
        
        show_xhyhy11:false,
        xhyhy11s:[],

        shuaxinyn:0

    }},

	computed: {
            lists(){
                let pages=Math.ceil(this.listNum/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                let sonList=[];
                sonList=this.xhyhy11s.slice(i*10,i*10+10);//10为每页设置数量
                newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },

    },
    
	methods:{
      shanok(){this.shuaxin();},
        kcopy(a){
            let copycode = document.getElementById(a);
            copycode.select(); // 选择对象
            document.execCommand("Copy"); // 执行浏览器复制命令
            alert("密文已经复制到你的粘贴板，请到首页右侧‘密’功能栏解密。");
            // alert(copycode.value);
        },

      get_list(){
        this.$axios
        .post('http://www.zhishiren.info/api/xunhuanyhy11/', {userid:this.userid})
        .then(response=>{
            this.xhyhy11s=JSON.parse(response.data);
            this.listNum=this.xhyhy11s.length;
            this.show_xhyhy11=false;
            this.show_xhyhy11=true;
        });
      },

        shuaxin(){
                this.shuaxinyn=1;
                this.$nextTick(() => {
                    this.$axios
                        .post('http://www.zhishiren.info/api/xunhuanyhy11/', {userid:this.userid})
                        .then(response=>{
                            this.xhyhy11s=JSON.parse(response.data);
                            this.listNum=this.xhyhy11s.length;
                            this.show_xhyhy11=false;
                            this.show_xhyhy11=true;
                            this.shuaxinyn=0;
                            this.currentPage=1;
                        });
                });   
        },

    },	
            watch: {
                userid: function(newVal,oldVal){
                    this.user_id = newVal;
                    var that = this;
                    that.axios
                    .post('http://www.zhishiren.info/api/countyhy11/', {userid: that.user_id})
                    .then(response=>{that.listNum=response.data;});
                },
            },
};
</script>




