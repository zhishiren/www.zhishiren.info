<template>
<div id="fuye0">
		<div class="logo">知识人
			<span class="font_yahei_17px" >hello,zhaoxiaofei,2018.1.21,07:12</span>
			<span class="font_yahei_17px_tuichu">
			<a class="a_noline" target="_blank" href="/#/fuye">关闭</a>
	        <router-link to="/">返回</router-link>
			</span>
		</div>

		<el-container>
			<el-aside width="120px" class="bgcolor_FF"></el-aside>
			<el-main class="bgcolor_FC">
			</el-main>
		</el-container>

		<el-container>
			<el-aside width="120px" class="height_x00px">
				<el-menu default-active="11" class="el-menu-vertical-demo bgcolor_menu_FC height_x00px" @open="handleOpen" @close="handleClose">
			      <el-menu-item @click="daohang11" index="11" class="font_yaoti_18px">
			        <span slot="title">1111</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang12" index="12" class="font_yaoti_18px">
			        <span slot="title">2222</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang13" index="13" class="font_yaoti_18px">
			        <span slot="title">3333</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang14" index="14" class="font_yaoti_18px">
			        <span slot="title">4444</span>
			      </el-menu-item>						      
			    </el-menu>
			</el-aside>
			<el-main v-show="dh11" class="section_xh">

        <el-row style="line-height: 40px;" >
            <el-col :span="16" >
            </el-col>

            <el-col :span="8" >
            </el-col>
 
        </el-row>

        <el-row style="line-height: 40px;" >
            <el-col :span="8" >
				ceshi
            </el-col>
            <el-col :span="8" >

            </el-col>
            <el-col :span="8" >
            </el-col>
 
        </el-row>



			</el-main>
			<el-main v-show="dh12" class="section_xh">
             dh12-特别关注
			</el-main>
			<el-main v-show="dh13" class="section_xh">
             dh13-小组新闻
			</el-main>
			<el-main v-show="dh14" class="section_xh">
             dh14-历史新闻
			</el-main>


			<el-aside width="120px" class="bgcolor_FC"></el-aside>


		</el-container>



	</div>

</template>

<script>



export default {
        name:'fuye0',
		components: {
        },
        methods:{

                    daohang11(){this.dh11=true;this.dh12=false;this.dh13=false;this.dh14=false;},
                    daohang12(){this.dh12=true;this.dh11=false;this.dh13=false;this.dh14=false;},
                    daohang13(){this.dh13=true;this.dh11=false;this.dh12=false;this.dh14=false;},
                    daohang14(){this.dh14=true;this.dh11=false;this.dh12=false;this.dh13=false;},
        },
        data() {
            return {dh11:true,dh12:false,dh13:false,dh14:false,}
        }
};






</script>

<style scoped>
		.chazhao_alink{font-size:22px;color:black;}
		.sousuolan{
					width:250px;
					border:none;
					border-radius:0;
					border-bottom:#8D8D8D 1px solid;
					box-shadow:0;
					outline:none;
					text-decoration: none;
					font-size:22px;
		}
    
</style>




