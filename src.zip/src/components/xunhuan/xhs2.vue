<!-- 这是用户新增标签的模版-->
<template>
	<div id="xhs2">
        <zu1caozuojishu zone_id='souwenduan' :jishu="count_wd" :showloading1="showloading1" :showloading2="xhs2_loading" @zhankai="zhankaijian" @shuaxin="shuaxinjian"></zu1caozuojishu>  
        <div v-if="wd1 && xhs2_loading===false">
            <el-row v-for="l in wd1" :key="l.pk" class="br10px17px">
                    <el-row>
                        <router-link class="a_black" target="_blank" :to="{name:'wenduanye',params:{id:l.pk}}">
                            <span>{{l.fields.wj_title}}</span>
                            <span>{{l.fields.wd_title}}</span>
                        </router-link>
                    </el-row>
                    <el-row>
                        <span><b style="color:grey">正文内容<i class="el-icon-caret-right"></i></b><span v-html="l.fields.wd_content" ></span></span>     
                    </el-row>
                    <el-row><el-divider style="margin:0px;"></el-divider></el-row>
            </el-row>
        </div>
    </div>

</template>
<script>

export default {
    name:'xhs2',
    components: {},
    props:['count_wd','showloading1'],
	data() {return {
        wd1:[],
        xhs2_loading:false,
    }},

	methods:{
            zhankaijian(){this.shuaxinjian();},
            shuaxinjian(){
                this.xhs2_loading=true;
                this.$nextTick(() => {
                    this.$axios
                        .get('http://www.zhishiren.info/api/xunhuans2/')
                        .then(response=>{
                            this.wd1=JSON.parse(response.data);
                            this.xhs2_loading=false;
                    });
                });

            },
    },	
    // created () {
    //     this.lding1=true;
    //     var _this= this;
    //     _this.axios
    //     .post('http://www.zhishiren.info/api/showalldata/', {k:"wenduan"})
    //     .then(function (response) {_this.count_wenji=response.data;_this.lding1=false;});
	// },
};
</script>