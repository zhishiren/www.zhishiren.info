
<template>
    <span id="zhankai0" class="font18px">
				<a v-show="show_zhankai" @click="zhankaijian()" class="a_black">-展开-</a> 
				<transition name="el-zoom-in-center">
					<span v-show="show_zhankai===false">		
							<a @click="shuaxinjian()" class="a_black"><i class="el-icon-refresh"></i>刷新</a>
					</span>
				</transition>
    </span>
</template>

<script>
export default {
    name:'zhankai0',
    props:[],
	data() {return {
        show_zhankai:true,
        }},
 
    methods:{
				zhankaijian(){
					this.show_zhankai=false;
                    this.$emit('get_list');
				},

				shuaxinjian(){
					this.show_zhankai=false;
                    this.$emit('shuaxin');
                },

                addnew(){
					this.show_zhankai=false;
                }

	},

};

</script>


