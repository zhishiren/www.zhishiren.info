    import Vue from 'vue'
	import Vuex from 'vuex'
	
	Vue.use(Vuex)   
	const state = {
		KEYWORD11:'',XH11:[],SHOW_XH11:false,SHOW_XHK11:false,XHJS11:0,COUNT_XHK11:0,SHOW11:false,
		KEYWORDx1:'',XHx1:[],SHOW_XHx1:false,SHOW_XHKx1:false,XHJSx1:0,COUNT_XHKx1:0,SHOWx1:false,
		SHOW_XH31:false,
		CESHIKEY:'',
	};
	
	// const getters={ceshiget(state){
	// 	  return state;
	// }};

	const mutations = {
		// SHOW_XUNHUAN11(state){state.SHOW_XH11=true;state.SHOW_XHK11=false;},
		// LIST_XUNHUAN11(state,xh){state.XH11=xh;},
		ceshi_action(state,ceshik){state.CESHIKEY=ceshik;},
		// SHOW_XUNHUANK11(state){state.SHOW_XHK11=true;state.SHOW_XH11=false;},
		// ORDERBYRE_XUNHUAN11(state){return state.XH11.sort((a,b)=>b.creater_id-a.creater_id);},
		// ORDERBYXIN_XUNHUAN11(state){return state.XH11.sort((a,b)=>a.news_createtime.localeCompare(b.news_createtime));},
		// ORDERBYXIN_XUNHUAN11(state){return state.XH11.sort((a,b)=>a.creater_id-b.creater_id);},
	};
	
	export default new Vuex.Store({state,mutations})