作废，包含在jishu0中
<template>
    <span id="zu0fayanmima">
		<el-button @click="fayanmima()" type="text" class="font18px">发言密码...</el-button>
        <el-dialog title="设置你的发言密码..." width="400px" :visible.sync="show_fayanmima_dialog">
            <el-row>
                <el-col :span="7" class="font18px" style="padding-top:10px;">
                    提示信息：
                </el-col>
                <el-col :span="17">
                    <el-input v-model="fayanmima_tips" placeholder="请留下密码提示信息，限10字" style="width:90%;">
                    </el-input>
                </el-col>
            </el-row>
            <br>
            <el-row>
                <el-col :span="7" class="font18px" style="padding-top:10px;">
                    发言密码：
                </el-col>
                <el-col :span="17">
                    <el-input v-model="fayanmima_code" placeholder="请输入发言密码，限8位数字" style="width:90%;">
                    </el-input>
                </el-col>
            </el-row>
            <br>
            <el-row style="text-align:center;">
                <a @click="commit_fayanmima()" class="font20px a_black">确定</a>
            </el-row>
            <el-row style="text-align:center;color:orange;font-size:18px;">{{this.return_msg}}</el-row>
        </el-dialog>
    </span>
</template>

<script>
    export default {
        name:'zu0fayanmima',
        props:['k'],//k是区分
        data() {return {
			show_fayanmima_dialog:false,
			fayanmima_tips:'',
			fayanmima_code:'',
			show_shuaxin_fayanmima:false,
			show_zhankai_fayanmima:true,
			okmsg_fymm:'',
			errormsg_fymm:'',
			fymm_kong:'',
        }},
        computed:{

        },
        methods:{
            fayanmima(){
				this.show_fayanmima_dialog=true;
				this.fymm_kong='';
			},
            commit_fayanmima(){
				var _this= this;
				if(_this.fayanmima_tips===''||_this.fayanmima_code===''){
					_this.fymm_kong='内容不能为空！';
					setTimeout(function(){_this.fymm_kong='';}, 1500);
				}else{
					_this.axios
					.post('http://www.zhishiren.info/api/set_fayanmima/', {userid:_this.$cookies.get('userid'),fymmtips: _this.fayanmima_tips,fymmcode:_this.fayanmima_code})
					.then(function (response) {
						if (response.data.setfymmok === 1){
							_this.errormsgfymm='操作失败';
						}
						if (response.data.setfymmok === 0){
							_this.show_fayanmima_dialog=false;
							_this.show_shuaxin_fayanmima=true;
							_this.show_zhankai_fayanmima=false;
							_this.$emit('return_shuaxin');
							
						}
					})
				}
			},
            
        },
    };
</script>



