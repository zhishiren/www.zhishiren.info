
<template>
	<div id="xhwen2">
        <zu1caozuojishu zone_id='wen2' :jishu="listNum0" :showloading1="showloading1" :showloading2="xhwen2_loading" @zhankai="zhankaijian" @shuaxin="shuaxinjian"></zu1caozuojishu>  
        <div v-if="xhwen2_loading===false">
            <el-row v-for="l in lists" :key="l.pk" class="br10px17px">
                <el-row>
                    <el-col :span="22" v-if="l.fields.fymi===0">
                        <zu0niming :uname="l.fields.uname" :uid1="l.fields.uid1"></zu0niming>回复:<span style="color:grey;">{{l.fields.fy}}</span>
                    </el-col>
                    <el-col :span="22" v-if="l.fields.fymi!==0">
                        <zu0niming :uname="l.fields.uname" :uid1="l.fields.uid1"></zu0niming>
                        <span>回复:</span>
                        <span style="color:grey;">
                            <span>{{l.fields.fymi}}字密文</span>
                            <input style="width:1px;border-color:white;border:0px;" type="text" v-model="l.fields.fy.slice(2,-1)" :id="l.pk">
                            <a class="a_brown" @click="kcopy(l.pk)" style="color:blue;"><i class="el-icon-document-copy"></i>复制</a>
                        </span>
                    </el-col>
                    <el-col :span="2">
                        <!-- <span>2021-12-14</span> -->
                        <span style="float:right;">{{qian_date(l.fields.time1)}}</span>
                    </el-col>                    
                </el-row>
                <el-row>
                    <i class="el-icon-caret-right"></i>
                    <span v-if="parseInt(l.fields.title0)===0">
                        你的提问
                        <font class="spanlimit" style="font-size:18px;color:brown;">
                            <span><b>“</b></span>
                            <router-link class="a_black" target="_blank" :to="{name:'fayanye',params:{id:l.fields.id0}}">
                                <span style="color:brown" v-html="l.fields.fyhui" ></span>
                            </router-link>
                            <span><b>”</b></span>
                        </font>
                    </span>
                    <span v-if="parseInt(l.fields.title0)!==0" style="color:grey;">
                        <span>你提问的{{l.fields.title0}}字密文</span>
                        <input style="width:1px;border-color:white;border:0px;" type="text" v-model="l.fields.fyhui" :id="l.pk">
                        <a class="a_brown" @click="kcopy(l.pk)" style="color:blue;"><i class="el-icon-document-copy"></i>复制</a>
                    </span>
                </el-row>
                <el-row><el-divider style="margin:0px;"></el-divider></el-row>
            </el-row>
            <el-pagination v-if="listNum>10" style="text-align:right;"
                            background
                            :page-size=10
                            :total="listNum"
                            :current-page.sync="currentPage"
                            layout="total, prev, pager, next">
            </el-pagination>
        </div>
    </div>
</template>
<script>

export default {
    name:'xhwen2',
    components: {},
    // props:['count0','time0'],
	data() {return {
        xhwen2:[],
        xhwen2_loading:false,
        showloading1:false,
        listNum:0,
        listNum0:0,
        currentPage: 1,//当前分页的数值
        time0:[],
    }},

    computed:{
            lists(){
                let pages=Math.ceil(this.listNum/10);//
                let newList=[];
                for(let i=0;i<pages;i++){
                let sonList=[];
                sonList=this.xhwen2.slice(i*10,i*10+10);//
                newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
		},

	methods:{
            kcopy(a){
            let copycode = document.getElementById(a);
                copycode.select(); // 选择对象
                document.execCommand("Copy"); // 执行浏览器复制命令
                // alert("密文已经复制到你的粘贴板，请到首页右侧‘密’功能栏解密。");
                const h = this.$createElement;
                this.$notify({
                    title: '密文已经复制到你的粘贴板',
                    type: 'success',
                    message: h('i', { style: 'color: teal;font-size:19px;'}, '请到‘密’功能栏解密。')
                });
            },
            zhankaijian(){this.shuaxinjian();},
            shuaxinjian(){
                this.xhwen2_loading=true;
                this.$nextTick(() => {
                    this.$axios
                        .post('http://www.zhishiren.info/api/xunhuan_wen2/',{userid: this.$cookies.get('userid')})
                        .then(response=>{
                            this.xhwen2=JSON.parse(response.data);
                            this.listNum=JSON.parse(response.data).length;
                            this.listNum0=JSON.parse(response.data).length;
                            this.xhwen2_loading=false;
                    });
                });
            },

    },	
    created: function () {
        this.xhwen2_loading=true;
        this.$axios
            .post('http://www.zhishiren.info/api/xunhuan_wen2/',{userid: this.$cookies.get('userid')})
            .then(response=>{
                this.listNum0=JSON.parse(response.data).length;
                let www=JSON.parse(response.data);
                this.time0=www[0];
                this.xhwen2_loading=false;
                });
	}
};
</script>

