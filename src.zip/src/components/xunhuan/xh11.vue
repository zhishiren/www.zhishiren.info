<template>
	<div id="xh11">
        <!-- {{this.$cookies.get('sessionid')}} -->
        <zu1caozuojishu zone_id=11 :jishu="listNum" :showloading1="showloading1" :showloading2="showloading2"  @zhankai="zk" @shuaxin="shuaxin"></zu1caozuojishu>  
        
        <div v-if="showloading2===false">
            
            <el-row class="br10px17px" v-for="list in lists" :key="list.pk" >
                <!-- <el-row>
                    <el-col :span="1">
                        <el-avatar shape="square" style="font-size:24px;">赵</el-avatar>
                    </el-col>
                    <el-col :span="23"> -->
                        
                        <el-row>
                            <zu0niming :uid1='list.fields.uid1' :uname='list.fields.uname'></zu0niming>
                            <!-- <span v-if="list.fields.cztype==='加入标签'">添加了</span> -->
                            <!-- <span v-if="list.fields.cztype==='关联'">关联了</span> -->
                            <span v-if="list.fields.cztype==='发言'">发言：</span>
                            <span v-if="list.fields.cztype==='提问'">提问：</span>
                            <span v-if="list.fields.cztype==='分享'">分享了</span>
                            <!-- <span v-if="list.fields.cztype==='评论'">评论了</span> -->
                            <zu1yuansu :list="list"></zu1yuansu>
                            <zu0fy v-if="list.fields.cztype!=='发言'&&list.fields.cztype!=='提问'" :list="list" ></zu0fy>
                        </el-row>
                        <zu0fujianfutu v-if="list.fields.cztype==='发言'&&list.fujian!==0" :zhid="list.pk" :futujian="list.fields.fujianshu"></zu0fujianfutu>
                        <zu1huifulan :list='list' @shanchuok="shuaxin()"></zu1huifulan>
                    <!-- </el-col>
                </el-row> -->
                <el-row><el-divider style="margin:0px;"></el-divider></el-row>
            </el-row>
            
            <br>
            <el-pagination v-if="listNum1>10" style="text-align:right;"
                background
                :page-size=10
                :total="listNum1"
                :current-page.sync="currentPage"
                layout="total, prev, pager, next">
            </el-pagination>
        </div>
    </div>
</template>

<script>

export default {
    name:'xh11',
    components: {},
    
	data() {return {
        currentPage: 1,//当前分页的数值
        listNum:0,//
        listNum1:0,//这里与上面的变量区别开，用来控制分页条,listNum
        xh11s:[],

        showloading2:false,
        showloading1:false,
    }},

	computed: {
            lists(){
                let pages=Math.ceil(this.listNum/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                let sonList=[];
                sonList=this.xh11s.slice(i*10,i*10+10);//10为每页设置数量
                newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
            yonghuid(){return parseInt(this.$cookies.get('userid'))},
            chuan(){return this.$cookies.get('chuan')},
    },
    
	methods:{
        zk(){this.shuaxin();},
        shanok(){this.shuaxin();},
        shuaxin(){
            this.showloading2=true;
            var that=this;
            that.$axios
                .post('http://www.zhishiren.info/api/xunhuan11/', {
                    userid:that.$cookies.get('userid'),
                    chuan:that.$cookies.get('chuan')})
                .then(response=>{
                    that.xh11s=JSON.parse(response.data);
                    that.listNum=that.xh11s.length;
                    that.listNum1=that.xh11s.length;
                    that.currentPage=1;
                    that.showloading2=false;
                });
        },

    },	
    created: function () {
        this.showloading1=true;
        this.$axios
            .post('http://www.zhishiren.info/api/count11/', {
                userid:this.$cookies.get('userid'),
                chuan:this.$cookies.get('chuan')})
            .then(response=>{
                this.listNum=response.data;
                this.showloading1=false;
                });
	}
};
</script>




