<template>
    <span id="zu0fy">
        <!-- <router-link v-if="fytype==='fa' && list.fields.fymi===0" class="a_black" target="_blank" :to="{name:'fayanye',params:{id:list.pk}}">          
            <span style="color:brown;">
                <font style="font-size:20px;"><b>“</b></font><span v-html="list.fields.fy" ></span><font style="font-size:20px;"><b>”</b></font>
            </span>
        </router-link>
        <span v-if="fytype==='fa' && list.fields.fymi!==0" style="color:grey;">
            <span>一段{{this.list.fields.fymi}}字的密文</span>
            <input style="width:1px;border-color:white;border:0px;" type="text" v-model="list.fields.fy.slice(2,-1)" :id="list.pk">
            <a class="a_brown" @click="kcopy(list.pk)" style="color:brown;"><i class="el-icon-document-copy"></i>点击复制密文</a>
        </span> -->
        <span v-if="list.fields.fy!=='无'"  style="color:grey;">
        <!-- <span v-if="fytype==='fu' && list.fields.fy!=='无'"> -->
            <span v-if="list.fields.cztype!=='评论' && list.fields.cztype!=='评价'">附言:</span>
            <span v-if="list.fields.fymi!==0">
                <span>{{this.list.fields.fymi}}字密文</span>
                <input style="width:1px;border-color:white;border:0px;" type="text" v-model="list.fields.fy.slice(2,-1)" :id="list.pk">
                <a class="a_brown" @click="kcopy(list.pk)" style="color:blue;"><i class="el-icon-document-copy"></i>复制</a>
            </span>
            <span v-if="list.fields.fymi===0">
                <span v-if="list.fields.fystatus==='正常有效'" v-html="list.fields.fy" ></span>
                <span v-if="list.fields.fystatus==='正在审核'" style="background-color:grey;color:white">正在审核</span>
            </span>
        </span>
        
    </span>
</template>

<script>
export default {
    name:'zu0fy',
    props:['list'],
    // props:['fytype','list'],
	data() {return {}},
    methods:{
        kcopy(a){
        let copycode = document.getElementById(a);
            copycode.select(); // 选择对象
            document.execCommand("Copy"); // 执行浏览器复制命令
            const h = this.$createElement;
            this.$notify({
                title: '密文已经复制到你的粘贴板',
                type: 'success',
				message: h('i', { style: 'color: teal;font-size:19px;'}, '请到‘密’功能栏解密。')});
            // alert("密文已经复制到你的粘贴板，请到首页右侧‘密’功能栏解密。");
        },
    },
};

</script>



