<!-- 停用，待删除 -->
<template>
    <div id="chazhaolan" class="font18px">
                <span v-if="this.sectionid==11">你关注的用户共有{{$store.state['XHJS'+this.sectionid]}}条动态。</span>
                <!-- <span v-if="this.sectionid==12">ceshi12</span> -->
				<a @click="zhankaijian" v-show="show_zhankai"  class="a_black">-展开-</a> 
				<transition name="el-zoom-in-center">
					<span v-show="show_chazhaopaixunlan">
							<input type="text" class="input_jian font18px" size="mini" v-model="keyword" placeholder="在以下结果中查找">
							<a @click="chazhaojian(keyword)" class="a_black"><i class="el-icon-search"></i>查找</a>   
							&nbsp;
							<span style="color:orange" v-show="show_chazhaokong"><i class="el-icon-warning"></i>关键词不能为空！</span>
                            &nbsp;
                            <span style="color:blue" v-show="show_chazhaoshu"><i class="el-icon-finished"></i>{{$store.state['COUNT_XHK'+this.sectionid]}}个结果</span>
                            &nbsp;
							<a v-show="show_shuaxin" @click="shuaxinjian" class="a_black"><i class="el-icon-refresh"></i>刷新</a>
                            &nbsp;
                            <a v-show="show_huanyuan" @click="huanyuanjian" class="a_black"><i class="el-icon-refresh-left"></i>还原</a>
                            &nbsp;
					</span>
				</transition>
    </div>
</template>

<script>
export default {
    name:'chazhaolan',
    props: {sectionid: {type: String,default: 0,}},
    computed:{
            url_xunhuan(){return 'http://www.zhishiren.info/api/xunhuan' + this.sectionid+'/'},
            // url_xunhuanjishu(){return 'http://www.zhishiren.info/api/denglu/'},
            // url_xunhuanjishu(){return 'http://www.zhishiren.info/api/denglu/' + this.sectionid+'/'},
// 这里是对这个循环列表的计数的功能，在展开/查找/刷新的时候，会发送后台计算数据后，返回给全局变量
            },
            
	data() {return {
        keyword:'',show_chazhaokong:false,show_zhankai:true,show_chazhaopaixunlan:false,show_chazhao:true,show_paixunzuire:true,show_paixunzuixin:false,show_shuaxin:true,show_chazhaoshu:false,show_huanyuan:false,
        }},
    
    created: function () {
        this.$axios.get(this.url_xunhuanjishu).then(response=>{this.$store.state['XHJS'+this.sectionid]=response.data.login_ok});
    },


    methods:{
				zhankaijian:function(){
					this.show_zhankai=false;
                    this.show_chazhaopaixunlan=true;
                    this.$axios.get(this.url_xunhuan).then(response=>{this.$store.state['XH'+this.sectionid]=response.data});
                    this.$axios.get(this.url_xunhuanjishu).then(response=>{this.$store.state['XHJS'+this.sectionid]=response.data.login_ok});
                    this.$store.state['SHOW'+this.sectionid]=true;
                    this.$store.state['SHOW_XH'+this.sectionid]=true;
                    this.$store.state['SHOW_XHK'+this.sectionid]=false;
				},
				chazhaojian:function(keyword){

                    if(keyword==''){
                        if(this.show_chazhaoshu==true){
                            // 这个情况是查找关键词是空，且在已经查找过待还原的状态，这时候输入空值后显示排序，还原和不为空值的字符。然后再判断是哪种排序形式。
                            if(this.show_paixunzuire==true){
                                    this.show_chazhaokong=true;
                                    this.show_huanyuan=true;
                                    this.show_chazhaoshu=true;
                                    this.show_paixunzuire=false;
                                    this.show_paixunzuixin=true;
                                    this.show_shuaxin=false;
                            }else{
                                    this.show_chazhaokong=true;
                                    this.show_huanyuan=false;
                                    this.show_chazhaoshu=false;
                                    this.show_paixunzuire=true;
                                    this.show_paixunzuixin=false;
                                    this.show_shuaxin=false;
                            }
                        }else{
                        // 这是说明刚展开的阶段，这是输入空值后的表现
                        this.show_chazhaokong=true;
                        this.show_huanyuan=false;
                        this.show_chazhaoshu=false;
                        this.show_paixunzuire=true;
                        this.show_paixunzuixin=false;
                        this.show_shuaxin=true;
                        }
                    }else{
                        this.show_chazhaoshu=true;
                        this.show_huanyuan=true;
                        this.show_paixunzuire=true;
                        this.show_paixunzuixin=false;
                        this.show_shuaxin=false;
                        this.show_chazhaokong=false;
                        this.$store.state['KEYWORD'+this.sectionid]=keyword;
                        this.$store.state['SHOW_XH'+this.sectionid]=false;
                        this.$store.state['SHOW_XHK'+this.sectionid]=true;
                    }
                },

				shuaxinjian:function(){
					this.show_zhankai=false;
                    this.show_chazhaopaixunlan=true;
                    this.$nextTick(() => {//这个nexttick是一种Vue中DOM的异步更新功能，用于刷新循环列表的数据源
                    this.$axios.get(this.url_xunhuan).then(response=>{this.$store.state['XH'+this.sectionid]=JSON.parse(response.data)});
                    });
                    this.$axios.get(this.url_xunhuanjishu).then(response=>{this.$store.state['XHJS'+this.sectionid]=response.data});
                    this.$store.state['SHOW_XH'+this.sectionid]=true;
                    this.$store.state['SHOW_XHK'+this.sectionid]=false;
                },
                huanyuanjian:function(){
                    this.show_huanyuan=false;
                    this.show_chazhaoshu=false;
                    this.show_paixunzuire=true;
                    this.show_paixunzuixin=false;
                    this.show_shuaxin=true;
                    this.show_chazhaokong=false;
                    this.keyword='';
                    this.$store.state['SHOW_XH'+this.sectionid]=true;
                    this.$store.state['SHOW_XHK'+this.sectionid]=false;
                }
	},

};

</script>

<style scoped>


</style>
