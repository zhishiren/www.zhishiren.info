// 这个评论栏是用在每个知识点页面之下的评论功能，他有异议和匿名两个多选框
<template>
	<div id="xh43" class="font18px">
		<zu1caozuojishu zoneid=43 :showloading2="showloading2"></zu1caozuojishu>

        <div v-show="show_xh43" >
            <el-row class="br10px17px" v-for="list in lists" :key="list.fields.act_createrid">
                
            </el-row>
            <br>
            <el-pagination v-if="listNum>10" style="text-align:right;"
                            background
                            :page-size=10
                            :total="listNum"
                            :current-page.sync="currentPage"
                            layout="total, prev, pager, next">
            </el-pagination>
        </div>

	</div>
</template>

<script>


	export default {
		name: 'xh43',
        components: {},
        props:[
            'zhid','title0','type0',//这个type0是用于判断是否为用户页或群组的
            'fanwei','createrid','creatername',//这个creatername用来录入被操作的原始人员
        ],
		data () {
			return {
                show_dialog:false,   
                show_xh43:false,
                xh43s:[],
                currentPage: 1,//当前分页的数值
                listNum:0,//分页总条数
                zhi_id:1,

			}
        },
        
        computed: {
            lists(){
                let pages=Math.ceil(this.listNum/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                    let sonList=[];
                    sonList=this.xh43s.slice(i*10,i*10+10);//10为每页设置数量
                    newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
            zhid(){return parseInt(this.$cookies.get('userid'))},
            
        },

		methods: {
			pinglunjian(){
				this.show_dialog=true;
            },

            zhankaijian(){
                this.show_xh43=true;
                this.$axios
                .post('http://www.zhishiren.info/api/xunhuan43/',{zhid: this.zhid})
                .then(response=>{
                    this.xh43s=JSON.parse(response.data);
                    this.listNum=this.xh43s.length;});
            },

            shuaxinjian(){
                this.$nextTick(() => {
                this.$axios
                .post('http://www.zhishiren.info/api/xunhuan43/',{zhid: this.zhid})
                .then(response=>{
                    this.xh43s=JSON.parse(response.data);
                    this.listNum=this.xh43s.length;});
                });
            },
            
        },
        // 由于created不能收到props的传值，所以只能用watch的方法。
        // watch: {
        //     zhid: function(newVal,oldVal){
        //         this.zhi_id = newVal;  
        //         this.$axios
        //         .post('http://www.zhishiren.info/api/count43/',{zhid: this.$cookies.get('userid')})
        //         .then(response=>{this.listNum=response.data});
        // }},

        created: function () {
				this.axios
				.post('http://www.zhishiren.info/api/count43/',{zhid: this.$cookies.get('userid')})
                .then(response=>{this.listNum=response.data});
		}


	}
</script>

