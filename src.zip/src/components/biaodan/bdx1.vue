<template>
	<div>
            <el-row style="line-height: 40px;" >
                <el-col :span="2" >
                    <span>标签标题：</span>
                </el-col>
                <el-col :span="14" >
                    <el-input v-model="bq_title" placeholder="请输入标签标题"  style="width:96%;" maxlength="10" show-word-limit></el-input>
                </el-col>
                <el-col :span="2" >
                    <span >公开范围：</span>
                </el-col>
                <el-col :span="6" >
                    <fanwei ref="huanyuan" @set_fanwei="set_gongkaifanwei" style="width:90%;"></fanwei>            
                </el-col>
            </el-row>

            <br>
            <el-row >
                    <el-col :span="2" >
                        <span class="font16px">标签说明：</span>
                    </el-col>
                    <el-col :span="20" >
                        <div contenteditable ref="contents" @paste="onPaste"  class="pinglunlan" style="width:100%;font-size:16px;">请输入此标签的介绍文字。</div>
                    </el-col>
                    <el-col :span="2">
                        <a class="a_black" href="javascript:;" @click="f_blod">
                            <b>所选加粗</b>
                        </a>
                    </el-col>
            </el-row>
            <el-row  style="line-height: 40px;padding-left:450px;">
                        <a class="font20px a_black"  @click="fabujian">发布</a>
                        <span style="color:green;" v-show="ok_msg==1"><i class="el-icon-success"></i>发布成功!</span>
                        <span style="color:orange;" v-show="ok_msg==2"><i class="el-icon-warning-outline"></i>标签名不能为空!</span>
                        <span style="color:red;" v-show="ok_msg==3"><i class="el-icon-error"></i>数据库写入失败!</span>
            </el-row>

        <el-row  class="font17px">
            你共曾添加过{{this.listNum}}条标签。<zhankai0 ref="zhankai0" @get_list="zhankaijian" @shuaxin="shuaxinjian"></zhankai0>
        </el-row>

        <div v-if="x_loading===true">
            <div style="font-size:30px;color:grey;"><i class="el-icon-loading"></i>正在加载...</div>
        </div>

        <div v-if="show_zhankai==false">
            <el-row v-for="item in lists" :key="item.pk"  class="br10px17px">
                <el-row>
                    <router-link class="a_black" style="float:left;" target="_blank" :to="{name:'biaoqianye',params:{id:item.pk}}">
                        <span style="float:left;">{{item.fields.bq_title}}</span>
                    </router-link>
                    <uploadfu :leixing=1 :fujianshu="item.fields.fu" :id="item.pk"></uploadfu>
                </el-row>
                <el-row>
                        <showfanwei :qz_id="item.fields.bq_fanwei"></showfanwei>
                        <span style="float:right">
                                <tj0shanchu :zhid="item.pk" leixing="1" @shanchuok="shanok()"></tj0shanchu>
                                {{formatDate_ymd(item.fields.bq_createtime)}}
                        </span>
                </el-row>
                <el-row><el-divider style="margin:0px;"></el-divider></el-row>
            </el-row>
            <br>
            <el-pagination v-if="listNum>10" style="text-align:right;"
                            background
                            :page-size=10
                            :total="listNum"
                            :current-page.sync="currentPage"
                            layout="total, prev, pager, next">
            </el-pagination>
        </div>

</div>
    
</template>

<script type="text/javascript">
import fanwei from '../fujian/fanwei';
import uploadfu from '../fujian/uploadfu';
import showfanwei from '../fujian/showfanwei';
import tj0shanchu from '../tijiao/tj_shanchu';
import zhankai0 from '../fujian/zhankai0';

	export default {
		name: 'bdx1',
        components: {fanwei,showfanwei,uploadfu,tj0shanchu,zhankai0},
        

        data () {
			return {
                ok_msg:0,
                bq_title:'',
                show_zhankai:true,
                xhx1s:[],
                currentPage: 1,//当前分页的数值
                listNum:0,
                qunzu_id:90000000,
                x_loading:false,
			}
        },
        computed:{
            lists(){
                let pages=Math.ceil(this.listNum/10);//
                let newList=[];
                for(let i=0;i<pages;i++){
                let sonList=[];
                sonList=this.xhx1s.slice(i*10,i*10+10);//
                newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
		},
		methods: {

            addone(k) {this.lists[k].fields.fu++;},
            shanok() {this.shuaxinjian();},
            f_blod() {document.execCommand ( 'bold', false );},
            
            onPaste: function(e) {
                    e.preventDefault()
                    e.stopPropagation()
                    let pasteValue = (e.clipboardData || window.clipboardData).getData('text/plain')
                    console.log(pasteValue)
                    var re = /<[^>]+>/gi;
                    pasteValue = pasteValue.replace(re, '').replace(/\s+|[\r\n]/g,"");
                    e.target.textContent += pasteValue
                },
            set_gongkaifanwei(data){this.qunzu_id = data.qz_id;},

            zhankaijian(){
                this.show_zhankai=false;
                this.x_loading=true;
                this.axios
                        .post('http://www.zhishiren.info/api/xunhuanx1/',{userid: this.$cookies.get('userid')})
                        .then(response=>{
                            this.xhx1s=JSON.parse(response.data);
                            this.listNum=JSON.parse(response.data).length;
                            this.x_loading=false;
                            });
            },
            shuaxinjian(){
                this.x_loading=true;
                this.$nextTick(() => {
                    this.axios
                            .post('http://www.zhishiren.info/api/xunhuanx1/',{userid: this.$cookies.get('userid')})
                            .then(response=>{
                                this.xhx1s=JSON.parse(response.data);
                                this.listNum=JSON.parse(response.data).length;
                                this.x_loading=false;
                                });
                })
            },

            fabujian() {
                // 这里需要判断，
                var that = this;
                if(that.bq_title===''){
                    that.ok_msg=2;
                    setTimeout(function(){that.ok_msg=0;}, 1500);
                }
                else{
                        that.axios
                        .post('http://www.zhishiren.info/api/bdx1/',{
                            userid: that.$cookies.get('userid'),
                            username:that.$cookies.get('username'),
                            bq_fanwei:that.qunzu_id,
                            bq_title:that.bq_title,
                            bq_remark:that.$refs.contents.innerHTML,
                            })
                        .then(function (response) {
                                        if (response.data.ok_id === 1){
                                            that.ok_msg=1;
                                            setTimeout(function(){
                                                that.ok_msg=0;
                                            }, 1500);
                                            that.$refs.zhankai0.addnew();

                                            that.$refs.contents.innerHTML='请输入此标签的介绍文字。';
                                            that.bq_title='';
                                            that.$refs.huanyuan.huanyuan();
                                            that.x_loading=true;
                                            that.$nextTick(() => {
                                                    that.$axios
                                                        .post('http://www.zhishiren.info/api/xunhuanx1/',{userid: that.$cookies.get('userid')})
                                                        .then(response=>{
                                                            that.xhx1s=JSON.parse(response.data);
                                                            that.listNum=JSON.parse(response.data).length;
                                                            that.show_zhankai=false;
                                                            that.currentPage=1;
                                                            that.x_loading=false;

                                                        });
                                                });
                                            // };           
                                        }
                                        if (response.data.ok_id === 3){
                                            that.ok_msg=3;
                                            setTimeout(function(){that.ok_msg=0;}, 1500);
                                            that.$refs.contents.innerHTML='请输入此标签的介绍文字。';
                                            that.x_loading=false;
                                        }
                        });
                }
            },	
        },
        created: function () {
                var _this= this;
                _this.axios
                .post('http://www.zhishiren.info/api/countx1/', {userid:_this.$cookies.get('userid')})
                .then(function (response) {_this.listNum=JSON.parse(response.data);});
        },
	}
</script>

