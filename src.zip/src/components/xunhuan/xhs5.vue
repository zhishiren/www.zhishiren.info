
<template>
	<div id="xhs5">
        <zu1caozuojishu zone_id='soufayan' :jishu="count_fayan" :showloading1="showloading1" :showloading2="xhs2_loading" @zhankai="zhankaijian" @shuaxin="shuaxinjian"></zu1caozuojishu>  
        <div v-if="fy1 && xhs5_loading===false">
            <el-row v-for="l in fy1" :key="l.pk" class="br10px17px">
                <zu0niming :uname="l.fields.uname" :uid1="l.fields.uid1" :uid0="l.fields.uid0"></zu0niming>:
                <!-- <zu0fy :content='l.fields.fy' :pkid='l.pk' fytype='fa' :zishu='l.fields.fymi'></zu0fy> -->
                <span style="color:brown;">
                    <font style="font-size:18px;">
                        <span><b>“</b></span>
                        <router-link class="a_black" target="_blank" :to="{name:'fayanye',params:{id:l.pk}}">
                            <span style="color:brown" v-html="l.fields.fy" ></span>
                        </router-link>
                        <span><b>”</b></span>
                    </font>
                </span>
                <zu1huifulan :list='l' @shanchuok="shuaxinjian()"></zu1huifulan>
                <el-row><el-divider style="margin:0px;"></el-divider></el-row>
            </el-row>
        </div>
    </div>
</template>
<script>

export default {
    name:'xhs5',
    components: {},
    props:['count_fayan',,'showloading1'],
	data() {return {
        fy1:[],
        xhs5_loading:false,
    }},

	methods:{
            zhankaijian(){this.shuaxinjian();},
            shuaxinjian(){
                this.xhs5_loading=true;
                this.$nextTick(() => {
                    this.$axios
                        .get('http://www.zhishiren.info/api/xunhuans5/')
                        .then(response=>{
                            this.fy1=JSON.parse(response.data);
                            this.xhs5_loading=false;
                    });
                });
            },

    },	
};
</script>

