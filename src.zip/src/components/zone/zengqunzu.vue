<template>
	<div id="zengqunzu">
        <el-row style="line-height: 40px;" >
            <el-col :span="2" ><span >群组名称：</span></el-col>
            <el-col :span="6" >
                <el-input v-model="qunzu_title" placeholder="请输入群组名称"  style="width:96%;"></el-input>
            </el-col>

            <el-col :span="2" ><span >群组类型：</span></el-col>
            <el-col :span="6" >
                <el-select v-model="type_value" placeholder="请选择群组类型" style="width:90%;">
                    <el-option value="兴趣讨论" key="兴趣讨论" label="兴趣讨论"></el-option>
					<el-option value="内部团队" key="内部团队" label="内部团队"></el-option>
					<el-option value="企业社团" key="企业社团" label="企业社团"></el-option>
                </el-select>
            </el-col>

            <el-col :span="2" ><span >入群口令：</span></el-col>
            <el-col :span="6" >
                <el-input v-model="kouling0" placeholder="这是用户申请入群的口令"  style="width:96%;"></el-input>
            </el-col>
        </el-row>
        <br>
        <zu1fabujian @fabujian="fabujian" :faloading="faloading" :return_msg="return_msg"></zu1fabujian>
        <zu1caozuojishu zone_id="xzqz" :jishu="listNum0" :showloading1="showloading1" :showloading2="showloading2" @zhankai="zhankaijian()" @shuaxin="shuaxinjian()"></zu1caozuojishu>

        <div v-if="showloading2===false">
            <el-row v-for="item in lists" :key="item.pk"  class="br10px17px">
                <el-row>
                    <router-link class="a_black" style="float:left;" target="_blank" :to="{name:'qunzuye',params:{id:item.pk}}">
                        <span style="float:left;">{{item.fields.qz_title}}</span>
                    </router-link>
                    <zu0uploadfu v-if="usertype==='内容整理'" :leixing=8 :fujianshu="item.fields.fu" :id="item.pk"></zu0uploadfu>
                </el-row>
                <el-row>
                    <span :style="{'color':(item.fields.qz_status==='失效已删'?'red':'black')}">{{item.fields.qz_status}}</span>
                    <span><el-divider direction="vertical"></el-divider></span>
                    <span v-if="item.fields.qz_type">{{item.fields.qz_type}}</span>
                    <zu0zengshanchu :zhid="item.pk" leixing="8" :yishan_yn="item.fields.qz_status" :time="item.fields.qz_createtime" @shanchuok="shanok()" ></zu0zengshanchu>
                </el-row>
                <el-row><el-divider style="margin:0px;"></el-divider></el-row>
            </el-row>
            <el-pagination v-if="listNum>10" style="text-align:right;"
                            background
                            :page-size=10
                            :total="listNum"
                            :current-page.sync="currentPage"
                            layout="total, prev, pager, next">
            </el-pagination>
        </div>
</div>


    
</template>


<script>
import md5 from 'js-md5';
export default {
    name: 'zengqunzu',
    props:['showloading1','listNum0'],

    components: {},
    data () {
        return {
            currentPage: 1,//当前分页的数值
            xhx8s:[],

            type_value:'兴趣讨论',
            qunzu_title:'',
            kouling0:'',

            showloading2:false,
            faloading:false,
            return_msg:'',

            listNum:0,
        }
    },

    computed: {
            lists(){
                let pages=Math.ceil(this.listNum/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                let sonList=[];
                sonList=this.xhx8s.slice(i*10,i*10+10);//10为每页设置数量
                newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
            usertype(){return this.$cookies.get('usertype')},

    },

    methods: {
        shanok(){this.shuaxinjian();},
        zhankaijian(){this.shuaxinjian();},
        shuaxinjian(){
            this.showloading2=true;
            this.axios
                .post('http://www.zhishiren.info/api/xunhuan_zengqunzu/',{userid: this.$cookies.get('userid')})
                .then(response=>{
                    this.xhx8s=JSON.parse(response.data);
                    this.listNum=this.xhx8s.length;
                    this.listNum0=this.xhx8s.length;
                    this.showloading2=false;
                    this.currentPage=1;
                    });
        },
        fabujian(data) {
            var that = this;
            if(that.kouling0===''){
                    that.return_msg='入群口令不能为空！';
                    setTimeout(function(){that.return_msg='';}, 1500);
                }
            else{
                var fuyan=data.k;
                if(that.qunzu_title===''){
                    that.return_msg='群组名不能为空!';
                    setTimeout(function(){that.return_msg='';}, 1500);
                }
                else{
                    // that.kouling0=md5(that.kouling0);
                    that.axios
                    .post('http://www.zhishiren.info/api/zengqunzu/',{
                        userid: that.$cookies.get('userid'),
                        username:that.$cookies.get('username'),
                        type_value:that.type_value,
                        kouling0:that.kouling0,
                        qunzu_title:that.qunzu_title,
                        qunzu_shuoming:fuyan,
                        })
                    .then(function (response) {
                        that.faloading=false;
                        if (response.data.msg===1 ){
                            that.return_msg='操作成功';
                            setTimeout(function(){that.return_msg='';}, 2000);

                            that.qunzu_title='';
                            that.type_value='兴趣讨论';
                            that.kouling0='';

                            that.shuaxinjian();
                        }
                        if (response.data.msg===3){
                            that.return_msg='操作失败';
                            setTimeout(function(){that.return_msg='';}, 1500);
                            that.showloading2=false;
                        }
                    });
                }    
            }
        },

    },
}
</script>

<style scoped>

</style>