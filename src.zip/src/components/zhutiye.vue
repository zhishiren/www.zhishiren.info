<template>
<div id="zhutiye" @click="turnfresh()">
		<zu2logo k=0></zu2logo>

		<el-header>
			<el-container>
				<el-aside width="120px" class="bgcolor_FF"></el-aside>
				<el-menu default-active="4" class="el-menu-demo" mode="horizontal" @select="handleSelect" >
					  <el-menu-item @click="daohang1" index="1" class="font20px" >今日动态</el-menu-item>
					  <el-menu-item @click="daohang2" index="2" class="font20px" >关注收藏</el-menu-item>
					  <el-menu-item @click="daohang3" index="3" class="font20px" >用户与群</el-menu-item>
					  <el-menu-item @click="daohang4" index="4" class="font20px" ref="active4">我的主页</el-menu-item>
					  <el-menu-item @click="daohang5" index="5" class="font20px" >共享资料</el-menu-item>
					  <el-menu-item @click="daohang6" index="6" class="font20px" >工团产品</el-menu-item>
					  <el-menu-item @click="daohang7" index="7" class="font20px" >关于本站</el-menu-item>
				</el-menu>
			</el-container>
		</el-header>

		<el-container>
			<el-main style="padding:0px;">
				<el-container v-show="dh1">
					<el-aside width="120px">
						<el-menu default-active="11" class="el-menu-vertical-demo bgcolor_menu_FC height_x00px" @open="handleOpen" @close="handleClose">
						<el-menu-item @click="daohang11" index="11" class="font18px">
							<span slot="title">用户动态</span>
						</el-menu-item>
						<el-menu-item @click="daohang12" index="12" class="font18px">
							<span slot="title">内容动态</span>
						</el-menu-item>
						<el-menu-item @click="daohang13" index="13" class="font18px">
							<span slot="title">互动信息</span>
						</el-menu-item>
						<el-menu-item @click="daohang14" index="14" class="font18px">
							<span slot="title">系统通知</span>
						</el-menu-item>	
						<!-- <el-menu-item @click="daohang15" index="15" class="font18px">
							<span slot="title">历史记录</span>
						</el-menu-item>						       -->
						</el-menu>
					</el-aside>
					<el-main v-show="dh11" class="section_xh">
						<xh11></xh11>
					</el-main>
					<el-main v-show="dh12" class="section_xh">
						<xh12></xh12>
					</el-main>
					<el-main v-show="dh13" class="section_xh">
						<xh13></xh13>
					</el-main>
					<el-main v-show="dh14" class="section_xh">
						<xh14></xh14>
					</el-main>
					<!-- <el-main v-show="dh15" class="section_xh">
						选择时间段；7天内；30天内；180内
					</el-main> -->
					<!-- <el-aside width="120px" style="text-align:center;">
						<zu2youcelan></zu2youcelan>
					</el-aside> -->
				</el-container>

				<el-container v-show="dh2">
					<el-aside width="120px">
						<el-menu default-active="21" class="el-menu-vertical-demo bgcolor_menu_FC height_x00px" @open="handleOpen" @close="handleClose">
						<el-menu-item @click="daohang21" index="21" class="font18px">
							<span slot="title">标签</span>
						</el-menu-item>
						<el-menu-item @click="daohang22" index="22" class="font18px">
							<span slot="title">书名标题</span>
						</el-menu-item>
						<el-menu-item @click="daohang23" index="23" class="font18px">
							<span slot="title">段落</span>
						</el-menu-item>
						<el-menu-item @click="daohang24" index="24" class="font18px">
							<span slot="title">发言提问</span>
						</el-menu-item>	
						<!-- <el-menu-item @click="daohang25" index="25" class="font18px">
							<span slot="title">数集</span>
						</el-menu-item>
						<el-menu-item @click="daohang26" index="26" class="font18px">
							<span slot="title">数据</span>
						</el-menu-item> -->
						<el-menu-item @click="daohang27" index="27" class="font18px">
							<span slot="title">用户</span>
						</el-menu-item>
						</el-menu>
					</el-aside>

					<el-main v-show="dh21" class="section_xh">
						<!-- <xh21 :listNum="n21"></xh21> -->
						<xh2x :listNum="jishu_chuan(chuan,'bq')" zoneid=21></xh2x>
					</el-main>
					<el-main v-show="dh22" class="section_xh">
						<!-- <xh22 :listNum="n22"></xh22> -->
						<xh2x :listNum="jishu_chuan(chuan,'wj')" zoneid=22></xh2x>
					</el-main>
					<el-main v-show="dh23" class="section_xh">
						<!-- <xh23 :listNum="n23"></xh23> -->
						<xh2x :listNum="jishu_chuan(chuan,'wd')" zoneid=23></xh2x>
					</el-main>
					<el-main v-show="dh24" class="section_xh">
						<!-- <xh24 :listNum="n24"></xh24> -->
						<xh2x :listNum="jishu_chuan(chuan,'fay')" zoneid=24></xh2x>
					</el-main>
					<!-- <el-main v-show="dh25" class="section_xh">
					25
					</el-main>
					<el-main v-show="dh26" class="section_xh">
					26
					</el-main> -->
					<el-main v-show="dh27" class="section_xh">
						<!-- <xh27 :listNum="n27"></xh27> -->
						<xh2x :listNum="jishu_chuan(chuan,'yh')" zoneid=27></xh2x>
					</el-main>

					<!-- <el-aside width="120px" style="text-align:center;">
						<zu2youcelan></zu2youcelan>
					</el-aside> -->
				</el-container>

				<el-container v-show="dh3">
					<el-aside width="120px">
						<el-menu default-active="31" class="el-menu-vertical-demo bgcolor_menu_FC height_x00px" @open="handleOpen" @close="handleClose">
						<el-menu-item @click="daohang31" index="31" class="font18px">
							<span slot="title">所有用户</span>
						</el-menu-item>
						<el-menu-item @click="daohang36" index="36" class="font18px">
							<span slot="title">历史人物</span>
						</el-menu-item>
						<el-menu-item @click="daohang37" index="37" class="font18px">
							<span slot="title">左翼组织</span>
						</el-menu-item>
						<el-menu-item @click="daohang32" index="32" class="font18px">
							<span slot="title">我关注的</span>
						</el-menu-item>
						<el-menu-item @click="daohang33" index="33" class="font18px">
							<span slot="title">关注我的</span>
						</el-menu-item>
						<el-menu-item @click="daohang34" index="34" class="font18px">
							<span slot="title">所有群组</span>
						</el-menu-item>
						<el-menu-item @click="daohang35" index="35" class="font18px">
							<span slot="title">我的群组</span>
						</el-menu-item>
						</el-menu>
					</el-aside>
						<el-main v-show="dh31" class="section_xh">
							<xh3x zoneid=31 :listNum="this.alljishu.yonghu"></xh3x>
						</el-main>
						<el-main v-show="dh32" class="section_xh">
							<xh3x zoneid=32 :listNum="jishu_chuan(chuan,'yh')"></xh3x>
						</el-main>
						<el-main v-show="dh33" class="section_xh">
							<xh3x zoneid=33 :listNum="userjishu.guanzhu"></xh3x>
						</el-main>
						<el-main v-show="dh34" class="section_xh">
							<xh3x zoneid=34 :listNum="this.alljishu.qunzu"></xh3x>
						</el-main>
						<el-main v-show="dh35" class="section_xh">
							<xh3x zoneid=35 :listNum="jishu_chuan(chuan,'qz')"></xh3x>
						</el-main>
						<el-main v-show="dh36" class="section_xh">
							<xh3x zoneid=36 :listNum="this.alljishu.yonghu1"></xh3x>
						</el-main>
						<el-main v-show="dh37" class="section_xh">
							<xh3x zoneid=37 :listNum="this.alljishu.yonghu2"></xh3x>
						</el-main>

						<!-- <el-aside width="120px" style="text-align:center;">
							<zu2youcelan></zu2youcelan>
						</el-aside> -->
					
				</el-container>

				<el-container v-show="dh4">
					<el-aside width="120px">
						<el-menu default-active="41" class="el-menu-vertical-demo bgcolor_menu_FC height_x00px" @open="handleOpen" @close="handleClose">
						<el-menu-item @click="daohang41" index="41" class="font18px">
							<span slot="title">我的信息</span>
						</el-menu-item>
						<el-menu-item @click="daohang42" index="42" class="font18px">
							<span slot="title">公告动态</span>
						</el-menu-item>
						<el-menu-item @click="daohang43" index="43" class="font18px">
							<span slot="title">对我印象</span>
						</el-menu-item>
						<!-- <el-menu-item @click="daohang44" index="44" class="font18px">
							<span slot="title">我的评论</span>
						</el-menu-item>	 -->
						<!-- <el-menu-item @click="daohang45" index="45" class="font18px">
							<span slot="title">我的相册</span>
						</el-menu-item>	 -->
						</el-menu>
					</el-aside>
					<el-main v-show="dh41" class="section_xh">
						<zu2z41myinfo :userinfo='userinfo' :userjishu='userjishu'></zu2z41myinfo>
						<xh41></xh41>
					</el-main>
					<el-main v-show="dh42" class="section_xh">
						<zu2gonggao :yonghuid="userinfo.yonghu_id" my_yn=0></zu2gonggao>
						<xhqznei dongtaitype="我" :listNum="userjishu.zengfenxiang+userjishu.zengfayan"></xhqznei>
					</el-main>
					<el-main v-show="dh43" class="section_xh">
						<xhcaozuo zoneid=43 :zhid="userid" :listNum="userjishu.pinglun"></xhcaozuo>
					</el-main>
					<el-main v-show="dh44" class="section_xh">
					共有1条我的评论和关联附言。-展开-
					</el-main>
					<!-- <el-main v-show="dh45" class="section_xh">
					我共上传了5幅照片。-展开-
					</el-main> -->
					<!-- <el-aside width="120px" style="text-align:center;">
						<zu2youcelan></zu2youcelan>
					</el-aside> -->
				</el-container>
		
				<el-container v-show="dh5">
					<el-aside width="120px">
						<el-menu default-active="51" class="el-menu-vertical-demo bgcolor_menu_FC height_x00px" @open="handleOpen" @close="handleClose">
						<el-menu-item @click="daohang51" index="51" class="font18px">
							<span slot="title">文档下载</span>
						</el-menu-item>
						<el-menu-item @click="daohang53" index="53" disabled class="font18px">
							<span slot="title">数据信息</span>
						</el-menu-item>
						<el-menu-item @click="daohang54" index="54" disabled class="font18px">
							<span slot="title">软件/源码</span>
						</el-menu-item>		
						<el-menu-item @click="daohang52" index="52" disabled class="font18px">
							<span slot="title">协作任务</span>
						</el-menu-item>
						<el-menu-item @click="daohang55" index="55" disabled class="font18px">
							<span slot="title">闲物捐赠</span>
						</el-menu-item>
						</el-menu>
					</el-aside>
					<el-main v-show="dh52" class="section_xh" style="font-size:18px;">
					
					</el-main>
					<el-main v-show="dh51" class="section_xh">
						<z51></z51>
					</el-main>
					<el-main v-show="dh53" class="section_xh">
					3
					</el-main>
					<el-main v-show="dh54" class="section_xh">
					4
					</el-main>
					<el-main v-show="dh55" class="section_xh">
					5
					</el-main>
					
				</el-container>

				<el-container v-show="dh6">
					<el-aside width="120px">
						<el-menu default-active="64" class="el-menu-vertical-demo bgcolor_menu_FC height_x00px" @open="handleOpen" @close="handleClose">
						<el-menu-item @click="daohang64" index="64" class="font18px">
						<span slot="title">行动方案</span>
						</el-menu-item>	
						<el-menu-item @click="daohang63" index="63" class="font18px">
						<span slot="title">住</span>
						</el-menu-item>
						<el-menu-item @click="daohang62" index="62" class="font18px">
						<span slot="title">食</span>
						</el-menu-item>
						<el-menu-item @click="daohang61" index="61" class="font18px">
						<span slot="title">衣</span>
						</el-menu-item>
						<el-menu-item @click="daohang67" index="67" class="font18px">
							<span slot="title">自由软件</span>
						</el-menu-item>	
						<el-menu-item @click="daohang68" index="68" class="font18px">
							<span slot="title">基础设施</span>
						</el-menu-item>	
						<el-menu-item @click="daohang65" index="65" class="font18px">
							<span slot="title">医药/教育</span>
						</el-menu-item>	
						<el-menu-item @click="daohang66" index="66" class="font18px">
							<span slot="title">互助金融</span>
						</el-menu-item>	
						</el-menu>
					</el-aside>
					<el-main v-show="dh61" class="section_xh">
						<z61></z61>
					</el-main>
					<el-main v-show="dh62" class="section_xh">
						<z62></z62>
					</el-main>
					<el-main v-show="dh63" class="section_xh">
						<z63></z63>
					</el-main>
					<el-main v-show="dh64" class="section_xh">
						<z64></z64>
					</el-main>
					<el-main v-show="dh65" class="section_xh">
					<z65></z65>
					</el-main>
					<el-main v-show="dh66" class="section_xh">
						<z66></z66>
					</el-main>
					<el-main v-show="dh67" class="section_xh">
						<z67></z67>
					</el-main>
					<el-main v-show="dh68" class="section_xh">
						<z68></z68>
					</el-main>
					<!-- <el-aside class="youcelan" width="120px" style="text-align:center;">
						<zu2youcelan class="youcelan"></zu2youcelan>
					</el-aside> -->
				</el-container>

				<el-container v-show="dh7">
					<el-aside width="120px">
						<el-menu default-active="72" class="el-menu-vertical-demo bgcolor_menu_FC height_x00px" @open="handleOpen" @close="handleClose">
						<el-menu-item @click="daohang72" index="72" class="font18px">
							<span slot="title">宗旨精神</span>
						</el-menu-item>
						<el-menu-item @click="daohang71" index="71" class="font18px">
							<span slot="title">设计理念</span>
						</el-menu-item>
						<!-- <el-menu-item @click="daohang74" index="74" class="font18px">
							<span slot="title">劳动实践</span>
						</el-menu-item>	 -->
						<el-menu-item @click="daohang73" index="73" class="font18px">
							<span slot="title">加入我们</span>
						</el-menu-item>
						<el-menu-item @click="daohang75" index="75" class="font18px">
							<span slot="title">操作说明</span>
						</el-menu-item>	
						</el-menu>
					</el-aside>

					<el-main v-show="dh72" class="section_xh">
						<z72></z72>
					</el-main>
					<el-main v-show="dh71" class="section_xh">
						<z71></z71>
					</el-main>
					<el-main v-show="dh73" class="section_xh">
						<z73></z73>
					</el-main>
					<!-- <el-main v-show="dh74" class="section_xh">
						
					</el-main> -->
					<el-main v-show="dh75" class="section_xh">
						<z75></z75>
					</el-main>
					<!-- <el-aside width="120px" style="text-align:center;">
						<zu2youcelan></zu2youcelan>
					</el-aside> -->
				</el-container> 
			</el-main>
			<el-aside width="120px" style="text-align:center;">
				<zu2youcelan></zu2youcelan>
			</el-aside>
		</el-container>
	</div>

</template>

<script>
import xh11 from './xunhuan/xh11';
import xh12 from './xunhuan/xh12';
import xh13 from './xunhuan/xh13';
import xh14 from './xunhuan/xh14';

import xh43 from './xunhuan/xh43';
import xh42 from './xunhuan/xh42';
import xh41 from './xunhuan/xh41';

import xh2x from './xunhuan/xh2x';
import xh3x from './xunhuan/xh3x';

import z51 from "./zone/z51.vue";
import z72 from "./zone/z72.vue";
import z71 from "./zone/z71.vue";
import z73 from "./zone/z73.vue";
import z75 from "./zone/z75.vue";
import z61 from "./zone/z61.vue";
import z62 from "./zone/z62.vue";
import z63 from "./zone/z63.vue";
import z64 from "./zone/z64.vue";
import z65 from "./zone/z65.vue";
import z66 from "./zone/z66.vue";
import z67 from "./zone/z67.vue";
import z68 from "./zone/z68.vue";

export default {
        name:'zhutiye',
		components: {
		xh2x,xh3x,
		xh11,xh12,xh14,xh13,
		xh43,xh42,xh41,
		z51,
		z61,z62,z63,z66,z67,z68,z64,z65,
		z71,z72,z73,z75,
		},

        methods:{
			daohang1(){this.dh1=true;this.dh2=this.dh3=this.dh4=this.dh5=this.dh6=this.dh7=false;this.show_touxiang1=false},
			daohang2(){this.dh2=true;this.dh1=this.dh3=this.dh4=this.dh5=this.dh6=this.dh7=false;this.show_touxiang1=false},
			daohang3(){this.dh3=true;this.dh1=this.dh2=this.dh4=this.dh5=this.dh6=this.dh7=false;this.show_touxiang1=false},
			daohang4(){this.dh4=true;this.dh1=this.dh2=this.dh3=this.dh5=this.dh6=this.dh7=false;},
			daohang5(){this.dh5=true;this.dh1=this.dh2=this.dh3=this.dh4=this.dh6=this.dh7=false;this.show_touxiang1=false},
			daohang6(){this.dh6=true;this.dh1=this.dh2=this.dh3=this.dh4=this.dh5=this.dh7=false;this.show_touxiang1=false},
			daohang7(){this.dh7=true;this.dh1=this.dh2=this.dh3=this.dh4=this.dh6=this.dh5=false;this.show_touxiang1=false},

			daohang11(){this.dh11=true;this.dh12=false;this.dh13=false;this.dh14=false;this.dh15=false;},
			daohang12(){this.dh12=true;this.dh11=false;this.dh13=false;this.dh14=false;this.dh15=false;},
			daohang13(){this.dh13=true;this.dh11=false;this.dh12=false;this.dh14=false;this.dh15=false;},
			daohang14(){this.dh14=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh15=false;},
			daohang15(){this.dh15=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh14=false;},

			daohang21(){this.dh21=true;this.dh22=this.dh23=this.dh24=this.dh25=this.dh26=this.dh27=false;},
			daohang22(){this.dh22=true;this.dh21=this.dh23=this.dh24=this.dh25=this.dh26=this.dh27=false;},
			daohang23(){this.dh23=true;this.dh21=this.dh22=this.dh24=this.dh25=this.dh26=this.dh27=false;},
			daohang24(){this.dh24=true;this.dh21=this.dh22=this.dh23=this.dh25=this.dh26=this.dh27=false;},
			daohang25(){this.dh25=true;this.dh21=this.dh23=this.dh24=this.dh22=this.dh26=this.dh27=false;},
			daohang26(){this.dh26=true;this.dh21=this.dh23=this.dh24=this.dh25=this.dh22=this.dh27=false;},
			daohang27(){this.dh27=true;this.dh21=this.dh23=this.dh24=this.dh25=this.dh26=this.dh22=false;},

			daohang31(){this.dh31=true;this.dh32=this.dh33=this.dh34=this.dh35=this.dh36=this.dh37=false;},
			daohang32(){this.dh32=true;this.dh31=this.dh33=this.dh34=this.dh35=this.dh36=this.dh37=false;},
			daohang33(){this.dh33=true;this.dh31=this.dh32=this.dh34=this.dh35=this.dh36=this.dh37=false;},
			daohang34(){this.dh34=true;this.dh31=this.dh32=this.dh33=this.dh35=this.dh36=this.dh37=false;},
			daohang35(){this.dh35=true;this.dh31=this.dh32=this.dh33=this.dh34=this.dh36=this.dh37=false;},
			daohang36(){this.dh36=true;this.dh31=this.dh32=this.dh33=this.dh34=this.dh35=this.dh37=false;},
			daohang37(){this.dh37=true;this.dh31=this.dh32=this.dh33=this.dh34=this.dh35=this.dh36=false;},

			daohang41(){this.dh41=true;this.dh42=this.dh43=this.dh44=this.dh45=false;this.show_touxiang1=false},
			daohang42(){this.dh42=true;this.dh41=this.dh43=this.dh44=this.dh45=false;this.show_touxiang1=false},
			daohang43(){this.dh43=true;this.dh41=this.dh42=this.dh44=this.dh45=false;this.show_touxiang1=false},
			daohang44(){this.dh44=true;this.dh41=this.dh42=this.dh43=this.dh45=false;},
			daohang45(){this.dh45=true;this.dh41=this.dh42=this.dh43=this.dh44=false;},

			daohang51(){this.dh51=true;this.dh52=this.dh53=this.dh54=this.dh55=false;},
			daohang52(){this.dh52=true;this.dh51=this.dh53=this.dh54=this.dh55=false;},
			daohang53(){this.dh53=true;this.dh51=this.dh52=this.dh54=this.dh55=false;},
			daohang54(){this.dh54=true;this.dh51=this.dh52=this.dh53=this.dh55=false;},
			daohang55(){this.dh55=true;this.dh51=this.dh52=this.dh53=this.dh54=false;},

			daohang61(){this.dh61=true;this.dh62=this.dh63=this.dh64=this.dh65=this.dh66=this.dh67=this.dh68=false;},
			daohang62(){this.dh62=true;this.dh61=this.dh63=this.dh64=this.dh65=this.dh66=this.dh67=this.dh68=false;},
			daohang63(){this.dh63=true;this.dh61=this.dh62=this.dh64=this.dh65=this.dh66=this.dh67=this.dh68=false;},
			daohang64(){this.dh64=true;this.dh61=this.dh62=this.dh63=this.dh65=this.dh66=this.dh67=this.dh68=false;},
			daohang65(){this.dh65=true;this.dh61=this.dh62=this.dh63=this.dh64=this.dh66=this.dh67=this.dh68=false;},
			daohang66(){this.dh66=true;this.dh61=this.dh62=this.dh63=this.dh64=this.dh65=this.dh67=this.dh68=false;},
			daohang67(){this.dh67=true;this.dh61=this.dh62=this.dh63=this.dh64=this.dh65=this.dh66=this.dh68=false;},
			daohang68(){this.dh68=true;this.dh61=this.dh62=this.dh63=this.dh64=this.dh65=this.dh66=this.dh67=false;},

			daohang71(){this.dh71=true;this.dh72=this.dh73=this.dh74=this.dh75=false;},
			daohang72(){this.dh72=true;this.dh71=this.dh73=this.dh74=this.dh75=false;},
			daohang73(){this.dh73=true;this.dh71=this.dh72=this.dh74=this.dh75=false;},
			daohang74(){this.dh74=true;this.dh71=this.dh72=this.dh73=this.dh75=false;},
			daohang75(){this.dh75=true;this.dh71=this.dh72=this.dh73=this.dh74=false;},

			// download111(){
			// 	let a = document.createElement('a')
			// 	a.href = "https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zpdf/ceshi18mb.pdf"
			// 	a.click()
			// }, 

        },
        data(){
            return {
                dh1:false,dh2:false,dh3:false,dh7:false,dh5:false,dh6:false,dh4:true,
                dh11:true,dh12:false,dh13:false,dh14:false,dh15:false,
                dh21:true,dh22:false,dh23:false,dh24:false,dh25:false,dh26:false,dh27:false,
                dh31:true,dh32:false,dh33:false,dh34:false,dh35:false,dh36:false,dh37:false,
                dh41:true,dh42:false,dh43:false,dh44:false,dh45:false,
                dh51:true,dh52:false,dh53:false,dh54:false,dh55:false,
                dh64:true,dh63:false,dh62:false,dh61:false,dh65:false,dh66:false,dh67:false,dh68:false,
				dh72:true,dh71:false,dh73:false,dh74:false,dh75:false,
				userinfo:[],alljishu:[],userjishu:[]
			}
		},

		computed:{
			userid(){return this.$cookies.get('userid')},
			chuan(){return this.$cookies.get('chuan')},
			// user_img(){return 'http://www.zhishiren.info/api/'+this.$cookies.get('userid')+'.jpg'},
		},

		created: function () {
			var _this= this;
			_this.axios
				.post('http://www.zhishiren.info/api/show_mypage/', {userid:_this.$cookies.get('userid')})
				.then(function (response) {
					_this.userinfo=response.data;
					_this.userjishu=JSON.parse(response.data.yh_tongji);
					_this.alljishu=JSON.parse(response.data.alljishu);
					
				});
		}

};
</script>
<style scoped>
		/* .chazhao_alink{font-size:22px;color:black;} */
/* body{background-color:white;} */

</style>


