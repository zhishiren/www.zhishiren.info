// 这个组件需要做一个判断，是不是开放性的文辑名，例如《知识人百科》等文辑。
<template>

<div id="tj_jiaduanluo">
        <el-row style="line-height: 40px;" >
            <el-col :span="2" >

            </el-col>
            <el-col :span="11" >
               你尚未上传这个文章的原文档。限小于2M。
            </el-col>
            <el-col :span="11" >
            </el-col>
        </el-row>
<br>
        <el-row style="line-height: 40px;" >
            <el-col :span="2" >
                <span class="font_yahei_17px">段落标题：</span>
            </el-col>
            <el-col :span="14" >
                <el-input v-model="input" placeholder="请输入文段标题"  style="width:96%;"></el-input>
            </el-col>
            <el-col :span="2" >
                <span class="font_yahei_17px">公开范围：</span>
            </el-col>
            <el-col :span="6" >
                <el-select v-model="value" placeholder="请选择文辑类型" style="width:90%;">
                <el-option></el-option>
                </el-select>
            </el-col>
        </el-row>
        <br>
        <el-row >
            <el-col :span="2" >
                    <span class="font_yahei_17px">段落内容：</span>
            </el-col>
            <el-col :span="22" >
            <div contenteditable ref="contents" @paste="onPaste" class="pinglunlan" style="width:97%;"></div>
            </el-col>

        </el-row>
        <el-row >
            <el-col :span="2" >.</el-col>
            <el-col :span="22" >
                <a class="font_yahei_17px a_noline_black" href="javascript:;" @click="f_blod">
                <b>加粗</b>
                </a>
                &nbsp;
                <a class="font_yahei_17px a_noline_black" href="javascript:;" @click="f_bgColor">
                <span style="background:yellow;">背景色</span>
                </a>
                &nbsp;
                <a class="font_yahei_17px a_noline_black" href="javascript:;" @click="f_clear">
                清空
                </a>
                &nbsp;
                <span style="color:orange;text-align:right"><i class="el-icon-warning"></i>内容不能为空！</span>
            </el-col>
        </el-row>

        <el-row style="line-height: 40px;" >
            <el-col :span="11" >.
            </el-col>
            <el-col :span="2" >
               <a class="font_yahei_22px a_noline_black"  @click="f_publish">发布</a>
            </el-col>
            <el-col :span="11" >
            </el-col>
        </el-row>


</div>
       
    
</template>


<script>

	export default {
		name: 'tj_jiaduanluo',
		components: {},
		data () {
			return {
				ceshicontent:'',
			}
		},
		methods: {
			f_publish() {
				let params={content1:this.$refs.contents.innerHTML,contentid1:"1"};
				this.$axios.post("/api/bdx1/",qs.stringify(params)).then(response=>{this.ceshicontent=JSON.parse(response.data.data)});
            },
            f_clear() {
				this.$refs.contents.innerHTML='';
			},
			f_blod() {
				document.execCommand ( 'bold', false );
			},
			f_bgColor() {
				document.execCommand ( 'backColor', false, 'yellow' );
			}
		}
	}
</script>

<style scoped>

.pinglunlan{
            width:100%;
            border:none;
            border-radius:0;
            border-bottom:#8D8D8D 1px solid;
            box-shadow:0;
            outline:none;
            text-decoration: none;
            font-size:17px;
        }
        
a:hover{color:orange;}
</style>