// 这个组件是在标签信息页下的新增内容栏
<template>
	<div id="tj_biaoqianjia">
		<el-row >
			<el-col :span="5" >
			<div contenteditable ref="contents" @paste="onPaste" class="pinglunlan">
			</div>
			</el-col>
			<el-col :span="1" >.
			</el-col>

			<el-col :span="16" >
			<div contenteditable ref="contents" @paste="onPaste" class="pinglunlan">
				<p style="color:grey">请输入添加标签的附言内容。</p>
			</div>
			</el-col>
				<el-col :span="2" >
				<a class="font_yahei_22px a_noline_black"  @click="f_publish">发布</a>
			</el-col>
		</el-row>

		<el-row >
            <el-col :span="5" >
                <i class="el-icon-paperclip"></i>输入要加入的知识点id号：
			</el-col>
            <el-col :span="1" >.
			</el-col>
			<el-col :span="1" >
				<a class="font_yahei_19px a_noline_black" href="javascript:;" @click="f_blod">
				<b>加粗</b>
				</a>
			</el-col>
			<el-col :span="2" >
				<a class="font_yahei_19px a_noline_black" href="javascript:;" @click="f_bgColor">
				<span style="background:yellow;">背景色</span>
				</a>
			</el-col>

			<el-col :span="5" >

			</el-col>

			<el-col :span="2" >

			</el-col>

			<el-col :span="2" >
				<a class="font_yahei_19px a_noline_black" href="javascript:;" @click="f_clear">
				清空
				</a>
			</el-col>
			<el-col :span="4" style="text-align:right">
				<span style="color:orange"><i class="el-icon-warning"></i>id号不能为空！</span>
			</el-col>
			<el-col :span="2" >
			</el-col>
		</el-row>
	</div>
</template>


<script type="text/javascript">
import axios from 'axios';
import qs from 'qs';


	export default {
		name: 'tj_biaoqianjia',

		data () {
			return {
				ceshicontent:'',
			}
		},
		methods: {
			f_publish() {
				let params={content1:this.$refs.contents.innerHTML,contentid1:"1"};
				this.$axios.post("/api/pinglun/",qs.stringify(params)).then(response=>{this.ceshicontent=JSON.parse(response.data.data)});
				// 这里接收的参数是来自flask的，如果想获得返回的数据，则要经过序列化处理
			},
            f_clear() {
				this.$refs.contents.innerHTML='';
			},
			f_blod() {
				document.execCommand ( 'bold', false );
			},
			f_bgColor() {
				document.execCommand ( 'backColor', false, 'yellow' );
			}
		}
	}
</script>

<style scoped>

.pinglunlan{
            width:100%;
            border:none;
            border-radius:0;
            border-bottom:#8D8D8D 1px solid;
            box-shadow:0;
            outline:none;
            text-decoration: none;
            font-size:20px;
        }

        
a:hover{color:orange;}
</style>