<template>
<!-- <div id="dengluye" style="background-repeat:no-repeat;background-size:100% 100%;width:1400px;height:900px;background-image:url(https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zhishiren_info_white1.jpg);"> -->
<div id="dengluye" >
	<img src='https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/zhishiren_info_white6.jpg' alt="" class="bg_image">
	<div class="denglukuang">
		<div class="dengludaohang">
			<el-menu 
				default-active="15" 
				class="el-menu-vertical-demo" 
				style="border:0px;font-size:18px;" 
				background-color="rgba(0,0,0,0)" 
				text-color="black" 
				active-text-color="#FF8000">
				<br>
				<!-- <el-menu-item index="11" @click="daohang01" style="font-size:21px;"  >
					<span slot="title">快捷登录</span>
				</el-menu-item> -->
				<el-menu-item index="15" @click="daohang05" style="font-size:21px;"  >
					<span slot="title">通知公告</span>
				</el-menu-item>
				<el-menu-item index="12" @click="daohang02" style="font-size:21px;"  >
					<span slot="title">账号登录</span>
				</el-menu-item>
				<el-menu-item index="13" @click="daohang03" style="font-size:21px;"  >
					<span slot="title">新人注册</span>
				</el-menu-item>
				<!-- <el-menu-item index="14" @click="daohang04" style="font-size:21px;"  >
					<span slot="title">找回密码</span>
				</el-menu-item> -->
				
			</el-menu>
		</div>

		<div  v-show="dh01" class="input_area">
			<br>
			<br>
			<span class="font19px">
				本功能尚未完工，
				<br>敬请期待...
			</span>

		</div>

		<div  v-show="dh02" class="input_area">
			<br><br>
			<input id="name_denglu" v-model="name_denglu" autocomplete="off" type="text" placeholder="请输入用户名" class="input_dengluye">
			<br><br><br>
			<input type="password" id="password_denglu"  v-model="password_denglu" placeholder="请输入你的密码" class="input_dengluye">
			<br>
			<span class="font18px" style="color:orange">{{this.okmsg_denglu}}</span>
			<br><br>
			<el-row>
					<el-button v-if="show_loading===false" @click="tijiao_denglu" size="medium" style="font-size:20px;background-color:rgba(0,0,0,0);color:black;border-color:grey;" round>确定</el-button>
					<i v-if="show_loading" class="el-icon-loading" style="font-size:30px;"></i>
			</el-row>
		</div>

		<div  v-show="dh03" class="input_area">
			<br><br>
			<input id="name_zhuce" v-model="name_zhuce" autocomplete="off" type="text" placeholder="新建你的用户名" class="input_dengluye" @blur="check_name_existed">
			<br><br>
			<input type="password" id="password_zhuce1"  v-model="password_zhuce1" placeholder="请输入你的密码" class="input_dengluye">
			<br><br>
			<input type="password" id="password_zhuce2"  v-model="password_zhuce2" placeholder="再次输入密码" class="input_dengluye">
			<br><br>
			<input v-model="remark_zhuce" autocomplete="off" type="text" placeholder="附言：如你b站昵称" class="input_dengluye">
			<br>
			<span class="font18px" style="color:orange">{{this.okmsg_zhuce}}</span>
			<br>
			<el-row>

			<el-button  @click="tijiao_zhuce" size="medium" style="font-size:20px;background-color:rgba(0,0,0,0);color:black;border-color:grey;" round>确定</el-button>
<!-- &nbsp;
<a class="a_white font18px" >第三方登陆...</a> -->

			</el-row>
		</div>

		<div  v-show="dh04" class="input_area">
			<br>
			<br>
			<span class="font19px">
				本功能尚未完工，
				<br>敬请期待...
			</span>

		</div>

		<div  v-show="dh05" class="input_area">
			<span style="color:grey;" class="font20px">
				<br>
				<br>
				新群号680445309
				<br>
				备用群号533629564
				<br>
				新增“问”功能，每天限一问
				<br>
				新增pdf版资料下载
				<br>
				通告时间:2022.1.21
				<!-- cyberanren@gmail.com -->
			</span>

		</div>
	</div>
<!-- <div style="height:30px;position: fixed;bottom:1px;color: white">备案号：</div> -->
</div>
</template>

<script>
export default {
  	name:'dengluye',

	data () {
		return {
		name_denglu: '',
		name_zhuce: '',
		password_denglu: '',
		password_zhuce1: '',
		password_zhuce2: '',
		okmsg_denglu:'',
		okmsg_zhuce:'',
		show_loading:false,
		dh01:false,dh05:true,dh03:false,dh04:false,dh02:false,
		allCookies:''

		}
	},

	methods: {
		daohang01(){this.dh01=true;this.dh02=false;this.dh03=false;this.dh04=false;this.dh05=false;},
		daohang02(){this.dh02=true;this.dh01=false;this.dh03=false;this.dh04=false;this.dh05=false;},
		daohang03(){this.dh03=true;this.dh01=false;this.dh02=false;this.dh04=false;this.dh05=false;},
		daohang04(){this.dh04=true;this.dh01=false;this.dh02=false;this.dh03=false;this.dh05=false;},
		daohang05(){this.dh05=true;this.dh01=false;this.dh02=false;this.dh03=false;this.dh04=false;},


		// denglu_name_notexisted(){
		// 	var _this= this;
		// 	if(this.name_denglu==''){_this.okmsg_denglu='用户名不能为空！'}
		// 	else{
		// 			_this.axios
		// 			.post('http://www.zhishiren.info/api/denglu_name_notexisted/', {username: _this.name_denglu})
		// 			.then(function (response) {
		// 				if (response.data.name_existed === 0){_this.okmsg_denglu='用户名不存在';}
		// 				if (response.data.name_existed === 1){_this.okmsg_denglu='用户名存在！';}
		// 			})
		// 	}
		// },

		check_name_existed(){
			var _this= this;
			if(_this.name_zhuce==''){_this.okmsg_zhuce='用户名不能为空！'}
			else{
					_this.axios
					.post('http://www.zhishiren.info/api/zhuce_name_exist/', {username: _this.name_zhuce})
					.then(function (response) {
						if (response.data.name_existed === 1){_this.okmsg_zhuce='用户名已被使用！';_this.name_zhuce=''}
						if (response.data.name_existed === 0){_this.okmsg_zhuce='可以使用这个名字'}
					})
			}
		},

		tijiao_denglu() {
			var _this= this;
			_this.show_loading=true;
			if(this.name_denglu==''||this.password_denglu==''){_this.okmsg_denglu='用户名和密码不能为空！';_this.show_loading=false;}
			else{
					_this.axios
					.post('http://www.zhishiren.info/api/denglu/', 
					{username: _this.name_denglu,userpswd: _this.password_denglu})
					.then(function (response) {
						if (response.data.dengluok === 1){_this.okmsg_denglu=response.data.msg;_this.show_loading=false;}
						if (response.data.dengluok === 2){_this.okmsg_denglu=response.data.msg;_this.show_loading=false;}
						if (response.data.dengluok === 3){_this.okmsg_denglu=response.data.msg;_this.show_loading=false;}
						if (response.data.dengluok === 0){
							_this.userid=response.data.yonghu_id;
							_this.username=response.data.yonghu_name;
							_this.usertype=response.data.yonghu_type;
							_this.chuan=response.data.chuan;
							_this.fymm=response.data.fymm;
							_this.lastwentime=response.data.lastwentime;

							_this.$router.push({path: '/zhutiye'});
							_this.$cookies.set('lastwentime',_this.lastwentime,'8h');
							_this.$cookies.set('username',_this.username,'8h');
							_this.$cookies.set('userid',_this.userid,'8h');
							_this.$cookies.set('status','logined','8h');
							_this.$cookies.set('usertype',_this.usertype,'8h');
							_this.$cookies.set('chuan',_this.chuan,'8h');
							_this.$cookies.set('fayanmima',_this.fymm,'8h');

							_this.show_loading=false;
						}
					})
			}
		},

		tijiao_zhuce() {
			var _this= this;
			if(this.name_zhuce==''||this.password_zhuce1==''||this.password_zhuce2==''){_this.okmsg_zhuce='用户名和密码不能为空！'}
			else{
				if(this.password_zhuce1!==this.password_zhuce2){_this.okmsg_zhuce='两次密码输入不一致！'}
				else{
					_this.axios
					.post('http://www.zhishiren.info/api/zhuce/', {
						username: _this.name_zhuce,
						userpswd: _this.password_zhuce1,
						remark:_this.remark_zhuce})
					.then(function (response) {
						if (response.data.zhuceok === 0){
							_this.password_zhuce1='';
							_this.password_zhuce2='';
							_this.name_zhuce='';
							_this.remark_zhuce='';
							_this.okmsg_zhuce='注册成功！等待管理员审核...'
						}
						else{
							_this.okmsg_zhuce='注册失败，联系管理员';
							_this.password_zhuce1='';
							_this.password_zhuce2='';
							_this.remark_zhuce='';
							_this.name_zhuce='';
						}
					})
				}
			}
		},
	}
}


</script>

<style>
/* 这个页面的元素风格比较特别，所以单独写在组件里而不是zcss里 */
.denglukuang{position: absolute;width:35%;height:70%;top:15%;color:black;}
.dengludaohang{height:100%;width:120px;float:left;color:black;}
.input_area{height:100%;width:auto;color: black;text-align:center;}
/* .input_area{height:100%;width:auto;color: blanchedalmond;text-align: center;} */
.input_dengluye{background-color:rgba(0,0,0,0);border-top:0px;border-left:0px;border-right:0px;border-color:grey;height: 30px;width:50%;color:black;font-size: 20px;outline:none;}
.input_dengluye1{background-color:rgba(0,0,0,0);border-top:0px;border-left:0px;border-right:0px;border-color:grey;height: 30px;width:30%;color:black;font-size: 20px;outline:none;}
.bg_image{height:100%;width: 1280px;position: absolute;z-index: -1;}
.font_yaoti_21px{font-size:21px;font-family:'方正姚体';}
/* .bgcolor{background-color: black;} */
/* body{background-repeat:no-repeat;background-size:100% 100%;background-image:url(https://z2020-1302616346.cos.ap-hongkong.myqcloud.com/bg_gonggao0.jpg);} */
</style>




