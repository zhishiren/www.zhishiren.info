<template>
	<div id="xhs3">
        <zu1caozuojishu zone_id='soubiaoqian' :jishu="count_bq" :showloading1="showloading1" :showloading2="xhs2_loading" @zhankai="zhankaijian" @shuaxin="shuaxinjian"></zu1caozuojishu>  
        <div v-if="bq1 && xhs3_loading===false">
            <el-row v-for="l in bq1" :key="l.pk" class="br10px17px">
                    <el-row>
                        <router-link class="a_black" target="_blank" :to="{name:'biaoqianye',params:{id:l.pk}}">
                            <span>{{l.fields.bq_title}}</span>
                        </router-link>
                    </el-row>
                    <el-row>
                        <span><b style="color:grey">说明<i class="el-icon-caret-right"></i></b><span v-html="l.fields.bq_remark" ></span></span>
                    </el-row>
                    <el-row><el-divider style="margin:0px;"></el-divider></el-row>
            </el-row>
        </div>
    </div>
</template>
<script>

export default {
    name:'xhs3',
    components: {},
    props:['count_bq','showloading1'],
	data() {return {
        bq1:[],
        xhs3_loading:false,
    }},

	methods:{
            zhankaijian(){this.shuaxinjian();},
            shuaxinjian(){
                this.xhs3_loading=true;
                this.$axios
                    .get('http://www.zhishiren.info/api/xunhuans3/')
                    .then(response=>{
                        this.bq1=JSON.parse(response.data);
                        this.xhs3_loading=false;
                });
            },

    },	
};
</script>