<template>
	<div id="tj1yonghu"  class="font18px">

				    <el-button v-if="manager===yonghuid" @click="yaoqingjian" type="text" style="padding-bottom:0px;" class="font18px">
                        <i class="el-icon-plus"></i>邀请...
                    </el-button>
                    <el-button v-if="manager!==yonghuid" disabled @click="yaoqingjian" type="text" style="padding-bottom:0px;" class="font18px">
                        <i class="el-icon-plus"></i>邀请...
                    </el-button>
                    <span style="color:green;" v-show="ok_msg==1"><i class="el-icon-success"></i>发布成功!</span>
                    <span style="color:red;" v-show="ok_msg==3"><i class="el-icon-error"></i>操作失败!</span>
                    该群组已有{{this.listNum}}名用户。
                    <zhankai0 v-if="qzjoin==='不需申请'" ref="zhankai0" @get_list="zhankaijian" @shuaxin="shuaxinjian"></zhankai0>
					<!-- <a @click="shuaxinjian" class="a_black"><i class="el-icon-refresh"></i>刷新</a> -->

		<el-dialog title="邀请用户..." width="400px" :visible.sync="show_dialog">
            <el-row>
                <el-col :span="7" class="font18px" style="padding-top:10px;">
                    用户ID号：
                </el-col>
                <el-col :span="17">
                    <el-input v-model="item1id" style="width:90%" placeholder="请输入用户id号">
                    </el-input> 
                </el-col>
            </el-row>
            <br>
         
            <el-row>
                <!-- <div contenteditable ref="contents" @paste="onPaste" class="pinglunlan">请输入这个用户的备注。</div> -->
                <div contenteditable ref="contents" @paste="onPaste" class="pinglunlan">请输入这个用户的备注。</div>
            </el-row>
            <el-row>
                <el-col :span="7">
                    <a class="a_black font18px" href="javascript:;" @click="f_blod">
                        <b>所选加粗</b>
                    </a>
                </el-col>
                <el-col class="font18px" :span="11">
                    <span style="color:orange;" v-show="ok_msg==2"><i class="el-icon-warning-outline"></i>用户ID号不能为空!</span>
                    <span style="color:orange;" v-show="ok_msg==4"><i class="el-icon-warning-outline"></i>该用户已被邀请!</span>

                </el-col>
                <el-col :span="6" style="text-align:right">
                    <a @click="fabujian" class="font20px a_black" >发布</a>
                </el-col>
            </el-row>
        </el-dialog>

        <div v-show="show_xh1yh">
                <el-row class="br10px17px" v-for="list in lists" :key="list.fields.act_createrid">
                            <el-row>
                                    <router-link target="_blank" class="a_black" :to="{name:'yonghuye',params:{id:list.fields.act_createrid}}" >
                                        <b>{{list.fields.act_creatername}}</b>
                                    </router-link>
                                    <span style="color:grey"  v-if="manager===yonghuid">
                                        <el-divider direction="vertical"></el-divider>
                                        <a @click="kaichujian(list.pk)" class="a_grey"><i class="el-icon-close"></i>开除</a>
                                        <span style="color:red" v-show="kaichu_ok===1">删除失败</span>
                                    </span>
                            </el-row>
                            
                            <el-row>
                                <span>
                                <span style="color:grey">备注介绍:</span>
                                <bianji0beizhu :qz_yh_id="list.pk" :beizhu="list.fields.act_fuyan" :manager="manager"></bianji0beizhu>
                                </span>
                            </el-row>
                            <el-row :span="24"><el-divider style="margin:0px;"></el-divider></el-row>
                </el-row>

                <!-- 下面的div是用来显示原始的未筛选的分页条 -->
                <el-pagination v-if="listNum>10" style="text-align:right;"
                                background
:page-size=10
                                :total="listNum"
                                :current-page.sync="currentPage"
                                layout="total, prev, pager, next">
                </el-pagination>
        </div>

	</div>
</template>

<script>
import tj0huifu from '../tijiao/tj_huifu';
import fanwei from '../fujian/fanwei';
import zhankai0 from '../fujian/zhankai0';
import bianji0beizhu from '../fujian/bianji_beizhu';

	export default {
		name: 'tj1yonghu',
        components: {tj0huifu,fanwei,zhankai0,bianji0beizhu},
        props:['qzid','qztitle','manager','qzjoin'],
		data () {
			return {
                return_id:0,//这个return_id是用户添加评论成功之后，
                show_dialog:false,   
                show_xh1yh:false,
                blinkyellow:'',
                xh1yhs:[],
                currentPage: 1,//当前分页的数值
                listNum:0,//分页总条数
                
                ok_msg:9,

                item1id:0,
				
                fuyan:"",
                
                qz_id:0,

                kaichu_ok:0
            }
            
        },
        
        computed: {
            lists(){
                let pages=Math.ceil(this.listNum/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                    let sonList=[];
                    sonList=this.xh1yhs.slice(i*10,i*10+10);//10为每页设置数量
                    newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
            yonghuid(){return parseInt(this.$cookies.get('userid'))},
            
        },

		methods: {
            f_blod() {document.execCommand ( 'bold', false );},
            
            onPaste: function(e) {
                    e.preventDefault()
                    e.stopPropagation()
                    let pasteValue = (e.clipboardData || window.clipboardData).getData('text/plain')
                    console.log(pasteValue)
                    var re = /<[^>]+>/gi;
                    pasteValue = pasteValue.replace(re, '').replace(/\s+|[\r\n]/g,"");
                    e.target.textContent += pasteValue
                },
            fabujian() {
                // 这里需要判断，
                var that = this;
                that.zhid=Number(that.zhid);
                that.item1id=Number(that.item1id);

                        if(that.$refs.contents.innerHTML==='请输入这个用户的备注。'){that.fuyan=''}
                        else{that.fuyan=that.$refs.contents.innerHTML};

                        if(that.item1id==0){
                            that.ok_msg=2;
                            setTimeout(function(){that.ok_msg=0;}, 2000);
                        }
                        else{
                                that.axios
                                .post('http://www.zhishiren.info/api/ooyaoqing/',{
                                    qzid:that.qzid,
                                    qztitle:that.qztitle,
									item1id:that.item1id,
									fuyan:that.$refs.contents.innerHTML
                                    })
                                .then(function (response) {
                                    if (response.data.ok_id === 0){
                                        that.ok_msg=1;
                                        that.return_id = response.data.rrid;
                                        setTimeout(function(){that.ok_msg=0;}, 2000);
                                        that.$refs.contents.innerHTML='请输入这个用户的备注。';
                                        that.show_dialog=false;
                                        that.show_xh1yh=true;
                                        that.$nextTick(() => {
                                            that.$axios
                                                .post('http://www.zhishiren.info/api/xunhuanqyh/',{qzid: that.qzid})
                                                .then(response=>{
                                                                that.xh1yhs=JSON.parse(response.data);
                                                                that.listNum=that.xh1yhs.length;
                                                                that.currentPage=1;
                                                                that.blinkyellow='blinkyellow';
                                                                setTimeout(function(){that.blinkyellow='';}, 2000);
                                                });
                                        });
                                    }
                                    if (response.data.ok_id === 2){
                                        that.ok_msg=3;
                                        setTimeout(function(){that.ok_msg=0;}, 2000);
                                        that.$refs.contents.innerHTML='请输入这个用户的备注。';
                                    }
                                    if (response.data.ok_id === 1){
                                        that.ok_msg=4;
                                        setTimeout(function(){that.ok_msg=0;}, 2000);
                                        that.$refs.contents.innerHTML='请输入这个用户的备注。';
                                    }
                                });
                        }
                
            },

			f_blod() {
                document.execCommand ( 'bold', false );
                document.execCommand ( 'backColor', false, 'yellow' );
			},

			yaoqingjian(){
				this.show_dialog=true;
            },

            zhankaijian(){
                this.show_xh1yh=true;
                this.$axios
                .post('http://www.zhishiren.info/api/xunhuanqyh/',{qzid: this.qzid})
                .then(response=>{
                    this.xh1yhs=JSON.parse(response.data);
                    this.listNum=this.xh1yhs.length;});
            },

            shanok(){
                this.$nextTick(() => {
                    this.$axios
                    .post('http://www.zhishiren.info/api/xunhuanqyh/',{qzid: this.qzid})
                    .then(response=>{
                        this.xh1yhs=JSON.parse(response.data);
                        this.listNum=this.xh1yhs.length;});
                });
            },

            shuaxinjian(){
                this.$nextTick(() => {
                    this.$axios
                    .post('http://www.zhishiren.info/api/xunhuanqyh/',{qzid: this.qzid})
                    .then(response=>{
                        this.xh1yhs=JSON.parse(response.data);
                        this.listNum=this.xh1yhs.length;});
                });
            },
            kaichujian(k){
                this.$axios
                    .post('http://www.zhishiren.info/api/qz_kaichu_yh/',{qz_yh_id: k})
                    .then(response=>{
                            this.kaichu_ok=response.data;
                            setTimeout(function(){this.kaichu_ok=0;}, 2000);
                            this.$nextTick(() => {
                                this.$axios
                                .post('http://www.zhishiren.info/api/xunhuanqyh/',{qzid: this.qzid})
                                .then(response=>{
                                    this.xh1yhs=JSON.parse(response.data);
                                    this.listNum=this.xh1yhs.length;});
                            });
                        });
            }
        },

            watch: {
                qzid: function(newVal,oldVal){
                    this.qz_id = newVal;
                    var that = this;
                    that.axios
                    .post('http://www.zhishiren.info/api/countqyh/', {qzid: that.qz_id})
                    .then(response=>{that.listNum=response.data;});
                },
            },
        
	}
</script>

