// 这个评论栏是用在每个知识点页面之下的评论功能，他有异议和匿名两个多选框
<template>
	<div id="tj_qundongtai"  class="font18px">
        <span v-if="focused_yn===1 || qzjoin==='不需申请' || manager===yonghuid">
            <el-button @click="tianjiajian" type="text" style="padding-bottom:0px;" class="font18px">
                <i class="el-icon-plus"></i>添加...
            </el-button>
            <span style="color:green;" v-show="ok_msg==1"><i class="el-icon-success"></i>发布成功!</span>
            <span style="color:red;" v-show="ok_msg==3"><i class="el-icon-error"></i>操作失败!</span>
            这个群组已有{{this.listNum}}条动态。
            <zhankai0 ref="zhankai0" @get_list="zhankaijian" @shuaxin="shuaxinjian"></zhankai0>
            <!-- <a @click="shuaxinjian" class="a_black"><i class="el-icon-refresh"></i>刷新</a> -->
        </span>
        <span v-if="focused_yn!==1 && qzjoin==='需要申请' && manager!==yonghuid">
            <i class="el-icon-lock"></i>你需要申请加入群才能查看该群组动态。
        </span>
        
		<el-dialog title="在该群中发言..." width="400px" :visible.sync="show_dialog">
            <div>
                <el-row>
                    <el-col :span="7" class="font18px" style="padding-top:10px;">
                        发言类型：
                    </el-col>
                    <el-col :span="17">
                        <el-select v-model="fayantype" placeholder="请选择发言的类型" style="width:90%;">
                            <el-option value="求助询问" key="求助询问" label="求助询问"></el-option>
                            <el-option value="新闻简讯" key="新闻简讯" label="新闻简讯"></el-option>
                            <el-option value="公告通知" key="公告通知" label="公告通知"></el-option>
                            <el-option value="感悟思考" key="感悟思考" label="感悟思考"></el-option>
                            <el-option value="名人名言" key="名人名言" label="名人名言"></el-option>
                            <el-option value="公开言论" key="公开言论" label="公开言论"></el-option>
                        </el-select>
                    </el-col>
                </el-row>
                <br>
                <el-row>
                    <el-col :span="7" class="font18px" style="padding-top:10px;">
                        发言类型：
                    </el-col>
                    <el-col :span="17">
                        <el-select v-model="att_value" placeholder="请选择发言的态度" style="width:90%;">
                            <el-option value="-无态度-" key="-无态度-" label="-无态度-"></el-option>
                            <el-option value="紧急重要" key="紧急重要" label="紧急重要"></el-option>
                        </el-select>
                    </el-col>
                </el-row>
                <br>
                <el-row>
                    <el-col :span="7" class="font18px" style="padding-top:10px;">
                        公开范围：
                    </el-col>
                    <el-col :span="17">
                            <el-select disabled v-model="qztitle" style="width:90%;"></el-select>                    
                    </el-col>
                </el-row>
                <br>
                <el-row>
                    <div contenteditable ref="contents" @paste="onPaste" class="pinglunlan">请输入言论内容。</div>
                </el-row>
                <el-row>
                    <el-col :span="7">
                        <a class="a_black font18px" href="javascript:;" @click="f_blod">
                            <b>所选加粗</b>
                        </a>
                    </el-col>
                    <el-col class="font18px" :span="11">
                        <span style="color:orange;" v-show="ok_msg==2"><i class="el-icon-warning-outline"></i>评论不能为空!</span>

                    </el-col>
                    <el-col :span="6" style="text-align:right">
                        <a @click="fabujian" class="font20px a_black" >发布</a>
                    </el-col>
                </el-row>
            </div>
		</el-dialog>
        <div v-show="show_xhqdt" >
                <el-row class="br10px17px" v-for="list in lists" :key="list.createrid" >
                    <div v-if="list.news_type==='a02'" >
                            <el-row>
                                <router-link  v-if="yonghuid!==list.createrid" target="_blank" class="a_black" :to="{name:'yonghuye',params:{id:list.createrid}}" >
                                    {{list.creatername}}
                                </router-link>
                                <span v-if="yonghuid===list.createrid">你</span><span>分享了</span>
                                <router-link class="a_black" target="_blank" :to="{name:list.item0_type,params:{id:list.item0_id}}">          
                                    <span v-if="list.item0_type==='fayanye'" style="color:brown;">
                                        <font style="font-size:20px;"><b>“</b></font><span v-html="list.item0_title" ></span><font style="font-size:20px;"><b>”</b></font>
                                    </span>
                                    <span v-if="list.item0_type!=='fayanye'">
                                        <i v-if="list.item0_type==='yonghuye'" class="el-icon-s-custom"></i>{{list.item0_title}}
                                    </span>
                                </router-link>
                                <span v-if="list.news_comm_content!=='无'" style="color:grey;">
                                    附言:<span v-html="list.news_comm_content" ></span>
                                </span>
                            </el-row>
                            <tj0huifu :shuaxinid="shuaxinyn" timek=0 news_yn=1 @shanchuok="shanok()" :act_id="list.news_comm_id" :act_yan="list.news_comm_content" :create_time="list.create_time.$date" :fanwei_id="list.news_fanwei" :it_type="list.item1_type" :it_att="list.news_attitude" :creater_id="list.createrid"  :item1title="'你分享了:'+list.item0_title+'>>>附言:'+list.news_comm_content"></tj0huifu>
                    </div>

                    <div v-if="list.news_type==='a05'  && list.news_comm_id===return_id"  :class="blinkyellow">
                            <el-row>
                                <router-link  v-if="yonghuid!==list.createrid" target="_blank" class="a_black" :to="{name:'yonghuye',params:{id:list.createrid}}" >
                                    {{list.creatername}}
                                </router-link>
                                <span v-if="yonghuid===list.createrid">你</span><span>分享了</span>
                                <router-link class="a_black" target="_blank" :to="{name:'fayanye',params:{id:list.item0_id}}">          
                                    <span style="color:brown;">
                                        <font style="font-size:20px;"><b>“</b></font><span v-html="list.news_comm_content" ></span><font style="font-size:20px;"><b>”</b></font>
                                    </span>
                                </router-link>
                            </el-row>
                            <el-row>
                                <zu0zu0fujianfutu v-if="list.fujian!==0" :zhid="list.item0_id" :futujian="list.fujian"></zu0zu0fujianfutu>
                            </el-row>
                            <tj0huifu :shuaxinid="shuaxinyn" timek=0 news_yn=1 @shanchuok="shanok()" :act_id="list.news_comm_id" :act_yan="list.news_comm_content" :create_time="list.create_time.$date" :fanwei_id="list.news_fanwei" :it_type="list.item0_type" :it_att="list.news_attitude" :creater_id="list.createrid"  :item1title="'你发表了言论:'+list.news_comm_content"></tj0huifu>
                    </div>
                    <div v-if="list.news_type==='a05'  && list.news_comm_id!==return_id" >
                            <el-row>
                                <router-link  v-if="yonghuid!==list.createrid" target="_blank" class="a_black" :to="{name:'yonghuye',params:{id:list.createrid}}" >
                                    {{list.creatername}}
                                </router-link>
                                <span v-if="yonghuid===list.createrid">你</span><span>分享了</span>
                                <router-link class="a_black" target="_blank" :to="{name:'fayanye',params:{id:list.item0_id}}">          
                                    <span style="color:brown;">
                                        <font style="font-size:20px;"><b>“</b></font><span v-html="list.news_comm_content" ></span><font style="font-size:20px;"><b>”</b></font>
                                    </span>
                                </router-link>
                            </el-row>
                            <el-row>
                                <zu0zu0fujianfutu v-if="list.fujian!==0" :zhid="list.item0_id" :futujian="list.fujian"></zu0zu0fujianfutu>
                            </el-row>
                            <tj0huifu :shuaxinid="shuaxinyn" timek=0 news_yn=1 @shanchuok="shanok()" :act_id="list.news_comm_id" :act_yan="list.news_comm_content" :create_time="list.create_time.$date" :fanwei_id="list.news_fanwei" :it_type="list.item0_type" :it_att="list.news_attitude" :creater_id="list.createrid"  :item1title="'你发表了言论:'+list.news_comm_content"></tj0huifu>
                    </div>
                    <el-row><el-divider style="margin:0px;"></el-divider></el-row>
                </el-row>
                <!-- 下面的div是用来显示原始的未筛选的分页条 -->
                <el-pagination v-if="listNum>10" style="text-align:right;"
                                background
:page-size=10
                                :total="listNum"
                                :current-page.sync="currentPage"
                                layout="total, prev, pager, next">
                </el-pagination>
        </div>

	</div>
</template>

<script>
import tj0huifu from '../tijiao/tj_huifu';
import fanwei from '../fujian/fanwei';
import tixing from '../fujian/tixing';
import zhankai0 from '../fujian/zhankai0';

	export default {
		name: 'tj_qundongtai',
        components: {tj0huifu,fanwei,tixing,zhankai0},
        props:['qztitle','qzid','manager','qzjoin'],
		data () {
			return {
                return_id:0,//这个return_id是用户添加评论成功之后，
                show_dialog:false,   
                show_xhqdt:false,
                blinkyellow:'',
                xhqdts:[],
                currentPage: 1,//当前分页的数值
                listNum:0,//分页总条数
                ok_msg:9,
				att_value:'-无态度-',
                fayantype:'公告通知',
                return_id:0,//这个return_id是用户添加评论成功之后，
                blinkyellow:'',
                focused_yn:0,
			}
        },
        
        computed: {
            lists(){
                let pages=Math.ceil(this.listNum/10);//10为每页设置数量
                let newList=[];
                for(let i=0;i<pages;i++){
                    let sonList=[];
                    sonList=this.xhqdts.slice(i*10,i*10+10);//10为每页设置数量
                    newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
            yonghuid(){return parseInt(this.$cookies.get('userid'))},

            
        },

		methods: {
            f_blod() {document.execCommand ( 'bold', false );},
            
            onPaste: function(e) {
                    e.preventDefault()
                    e.stopPropagation()
                    let pasteValue = (e.clipboardData || window.clipboardData).getData('text/plain')
                    console.log(pasteValue)
                    var re = /<[^>]+>/gi;
                    pasteValue = pasteValue.replace(re, '').replace(/\s+|[\r\n]/g,"");
                    e.target.textContent += pasteValue
                },
            fabujian() {
                // 这里需要判断，
                var that = this;
                        if(that.$refs.contents.innerHTML==='请输入言论内容。'){
                            that.ok_msg=2;
                            setTimeout(function(){that.ok_msg=0;}, 2000);
                        }
                        else{
                                that.axios
                                .post('http://www.zhishiren.info/api/bdx3/',{
                                    userid: that.$cookies.get('userid'),
                                    username:that.$cookies.get('username'),
                                    fy_content:that.$refs.contents.innerHTML,
                                    fayan_att:that.att_value,
                                    fy_fanwei:that.qzid,
                                    zhid:that.zhid,
                                    fy_type:that.fayantype,
                                    })
                                .then(function (response) {
                                    if (response.data.ok_id === 1){
                                        // that.ok_msg=1;
                                        that.return_id = response.data.rrid;
                                        // setTimeout(function(){that.ok_msg=0;}, 2000);
                                        that.$refs.contents.innerHTML='请输入言论内容。';
                                        that.show_xhqdt=true;
                                        that.show_dialog=false;
                                        that.$refs.zhankai0.addnew();
                                        that.$nextTick(() => {
                                            that.$axios
                                                .post('http://www.zhishiren.info/api/xunhuanqdt/',{zhid: that.qzid})
                                                .then(response=>{
                                                                that.xhqdts=JSON.parse(response.data);
                                                                that.listNum=that.xhqdts.length;                                                                
                                                                that.currentPage=1;
                                                                that.blinkyellow='blinkyellow';
                                                                setTimeout(function(){that.blinkyellow='';}, 2000);
                                                });
                                        });
          
                                    }
                                    if (response.data.ok_id === 3){
                                        that.ok_msg=3;
                                        setTimeout(function(){that.ok_msg=0;}, 2000);
                                        that.$refs.contents.innerHTML='请输入言论内容。';
                                    }
                                });
                        }
                
            },

			f_blod() {
                document.execCommand ( 'bold', false );
                // document.execCommand ( 'backColor', false, 'yellow' );
			},

			tianjiajian(){
                this.show_dialog=true;
                this.$refs.contents.innerHTML='请输入发言的内容。';
                this.fy_att="fy3";
                this.fayan_att="无态度";
                this.$refs.huanyuan.huanyuan();
            },

            zhankaijian(){
                this.show_xhqdt=true;
                this.$axios
                .post('http://www.zhishiren.info/api/xunhuanqdt/',{zhid: this.qzid})
                .then(response=>{
                    this.xhqdts=JSON.parse(response.data);
                    this.listNum=this.xhqdts.length;});
            },

            shuaxinjian(){
                this.$nextTick(() => {
                this.$axios
                .post('http://www.zhishiren.info/api/xunhuanqdt/',{zhid: this.qzid})
                .then(response=>{
                    this.xhqdts=JSON.parse(response.data);
                    this.listNum=this.xhqdts.length;});
                });
            },

            shanok(){this.shuaxinjian();},
            
        },

        watch: {
            qzid: function(newVal,oldVal){
                this.qz_id = newVal;
                var that = this;
                that.axios
                .post('http://www.zhishiren.info/api/countqdt/', {zhid: this.qz_id})
                .then(response=>{that.listNum=response.data;});

                this.axios
                    .post('http://www.zhishiren.info/api/check_focused/',{
                        zhi_id:that.qz_id,
                        userid:that.$cookies.get('userid'),
                    })
                    .then(response=>{
                        that.focused_yn=response.data.focused_id;
                });
            },
        },


	}
</script>

