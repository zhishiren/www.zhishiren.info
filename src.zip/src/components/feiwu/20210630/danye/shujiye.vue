<template>
<div id="shujiye">
		<toubu0></toubu0>
		<el-container>
			<el-aside width="120px" class="bgcolor_FF"></el-aside>
			<el-main class="bgcolor_FC font18px">
                <el-row >
                    <el-col :span="18" >
                        <p class="font21px">国内生产总值(中国大陆)</p>
                    </el-col>
                    <el-col :span="6" >
                        <xiazaishuji></xiazaishuji>
                    </el-col>
                </el-row>

				<p>
					<b>属性<i class="el-icon-caret-right"></i></b><!--
					-->数集id号:10000001<el-divider direction="vertical"></el-divider><!--
					-->最早记录:1949年<el-divider direction="vertical"></el-divider><!--
					-->最新记录:2020年<el-divider direction="vertical"></el-divider><!--
					-->发布频率:每年<el-divider direction="vertical"></el-divider><!--
					-->所属行业:宏观经济<el-divider direction="vertical"></el-divider><!--
					-->所属地区:大陆全部<el-divider direction="vertical"></el-divider><!--
					-->发布机构:中国国务院<el-divider direction="vertical"></el-divider><!--
					-->维护人员:zhaoxiaofei<el-divider direction="vertical"></el-divider><!--
					-->公开范围:所有用户<el-divider direction="vertical"></el-divider><!--
					
						--><span style="color:green"><!--
						-->关注0<el-divider direction="vertical"></el-divider><!--
						-->分享1<el-divider direction="vertical"></el-divider><!--
						-->关联1矛盾0<el-divider direction="vertical"></el-divider><!--
						-->评论1异议0
						</span>
					
				</p>


				<p>
					<b>说明<i class="el-icon-caret-right"></i></b>
					这是该这个文章发布的说明文字。
				</p>
				<p>
					<b>附件<i class="el-icon-caret-right"></i></b><a href="">
					ceshide wenzi </a>
				</p>
			</el-main>
		</el-container>

		<el-container>
			<el-aside width="120px">
				<el-menu default-active="12" class="el-menu-vertical-demo bgcolor_menu_FC" @open="handleOpen" @close="handleClose">
			      <el-menu-item @click="daohang11" index="11" class="font18px">
			        <span slot="title">数集列表</span>
			      </el-menu-item>
				  <el-menu-item @click="daohang12" index="12" class="font18px">
			        <span slot="title">关注分享</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang13" index="13" class="font18px">
			        <span slot="title">评论</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang14" index="14" class="font18px">
			        <span slot="title">关联知识</span>
			      </el-menu-item>
			      <el-menu-item @click="daohang15" index="15" class="font18px">
			        <span slot="title">推荐阅读</span>
			      </el-menu-item>
				  <el-menu-item @click="daohang16" index="16" class="font18px">
			        <span slot="title">内容管理</span>
			      </el-menu-item>				      
			    </el-menu>
			</el-aside>
			<el-main v-show="dh12" class="section_xh">
				<el-row style="line-height: 40px;" >
						<tj0fenxiang></tj0fenxiang>
						<tj0guanzhu></tj0guanzhu>
						<tj0jiucuo></tj0jiucuo>
						<tj0jiabiaoqian></tj0jiabiaoqian>
				</el-row>
			</el-main>
			<el-main v-show="dh13" class="section_xh">
            <tj0pinglun></tj0pinglun>
			<br>
			</el-main>
			<el-main v-show="dh14" class="section_xh">
            <tj0guanlian></tj0guanlian>

			</el-main>
			<el-main v-show="dh15" class="section_xh">
            <tj0tuijian></tj0tuijian>
			</el-main>
			<el-main v-show="dh11" class="section_xh">
             <tj1shuju></tj1shuju>
			</el-main>
			<el-main v-show="dh16" class="section_xh">
			<bdg5></bdg5>
			</el-main>

			<el-aside width="120px" class="bgcolor_FC"></el-aside>
		</el-container>
	</div>

</template>

<script>

import tj0fenxiang from '../tijiao/tj_fenxiang';
import tj0guanzhu from '../tijiao/tj_guanzhu';
import tj0jiabiaoqian from '../tijiao/tj_jiabiaoqian';
import tj1shuju from '../tijiao/tj1shuju';
import tj0jiucuo from '../tijiao/tj_jiucuo';
import tj0pinglun from '../tijiao/tj_pinglun';
import tj0guanlian from '../tijiao/tj_guanlian';
import tj0tuijian from '../tijiao/tj_tuijian';

import bdg5 from '../biaodan/bdg5';
import xiazaishuji from '../fujian/xiazaishuji';
import toubu0 from '../fujian/toubu0';

export default {
        name:'shujiye',
		components: {tj0tuijian,toubu0,tj0guanzhu,tj0fenxiang,tj0jiabiaoqian,tj0pinglun,tj0guanlian,tj0jiucuo,bdg5,xiazaishuji,tj1shuju},
        methods:{

                    daohang11(){this.dh11=true;this.dh12=false;this.dh13=false;this.dh14=false;this.dh15=false;this.dh16=false;},
                    daohang12(){this.dh12=true;this.dh11=false;this.dh13=false;this.dh14=false;this.dh15=false;this.dh16=false;},
                    daohang13(){this.dh13=true;this.dh11=false;this.dh12=false;this.dh14=false;this.dh15=false;this.dh16=false;},
                    daohang14(){this.dh14=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh15=false;this.dh16=false;},
                    daohang15(){this.dh15=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh14=false;this.dh16=false;},
                    daohang16(){this.dh16=true;this.dh11=false;this.dh12=false;this.dh13=false;this.dh14=false;this.dh15=false;},
        },
        data() {
            return {dh15:false,dh11:false,dh13:false,dh14:false,dh12:true,dh16:false,shuji_id:0,shuji_info:[]}
        },
        created() {
			this.shuji_id = this.$route.params.id;//获取上个页面传递的id,在下面获取数据的时候先提交id,这里的id不用加前缀
			var _this= this;
			_this.axios
			.post('http://www.zhishiren.info/api/shuji_page/', {shuji_id:this.shuji_id})
			.then(function (response) {
				_this.shuji_info=response.data;
			});
        },
};






</script>

<style scoped>
    
</style>




