<template>
    <span id="zu0editshu">
        <el-row>
            <el-col style="padding-top:10px;" :span="6">{{this.jitype}}:</el-col>
            <el-col :span="12"><el-input-number v-model="jishu" label="描述文字"></el-input-number></el-col>
            <el-col style="padding-top:7px;text-align:left;" :span="6">
                <a class="a_black" @click="tijiao()">提交</a>
                <span style="color:green;" v-if="msg===0"><i class="el-icon-check"></i></span>
                <span style="color:red;" v-if="msg===1">X</span>
            </el-col>
        </el-row>
        <br>
    </span>
</template>

<script>
export default {
    name:'zu0editshu',
    props:['jitype','jishu','zhid'],
	data() {return {
        msg:9
    }},
    methods:{
        tijiao(){
            var _this= this;
            _this.axios
            .post('http://www.zhishiren.info/api/changejishu/', {
                    zhid:_this.zhid,
                    jitype: _this.jitype,
                    jishu: _this.jishu,
                })
            .then(function (response) {
                _this.msg=response.data.msg;
                setTimeout(function(){_this.msg=9;}, 1500);
            })
        },
       
    },
};

</script>



