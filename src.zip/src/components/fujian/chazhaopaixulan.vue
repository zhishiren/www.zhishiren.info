<!-- 这个transition是elementjs中的动画效果，要放在显示内容的外部才有效果 
// 这是基础的查找组件
-->



<template>
    <span id="chazhaopaixulan" class="font18px">
                <span v-if="this.sectionid==11">你关注的用户共有13条动态。</span>
                <span v-if="this.sectionid==12">ceshi12</span>
                <!-- <span v-if="this.sectionid===12 && this.sectionid===11">ceshi12</span> -->

				<a @click="zhankaijian" v-show="show_zhankai"  class="a_black">-展开-</a> 
				<transition name="el-zoom-in-center">
					<span v-show="show_chazhaopaixunlan">
							<input type="text" class="input_jian font18px" size="mini" v-model="keyword" placeholder="在以下结果中查找">
							<a @click="chazhaojian(keyword)" class="a_black"><i class="el-icon-search"></i>查找</a>   
							&nbsp;
							<span style="color:orange" v-show="show_chazhaokong"><i class="el-icon-warning"></i>关键词不能为空！</span>
                            &nbsp;
                            <span style="color:blue" v-show="show_chazhaoshu"><i class="el-icon-finished"></i>{{$store.state['COUNT_XHK'+this.sectionid]}}个结果</span>
                            &nbsp;
							<a v-show="show_paixunzuire" @click="paixujian_zuire" class="a_black"><i class="el-icon-sort"></i>排序:最热</a>
							&nbsp;
                            <a v-show="show_paixunzuixin" @click="paixujian_zuixin" class="a_black"><i class="el-icon-sort"></i>排序:最新</a>
							&nbsp;
							<a v-show="show_shuaxin" @click="shuaxinjian" class="a_black"><i class="el-icon-refresh"></i>刷新</a>
                            &nbsp;
                            <a v-show="show_huanyuan" @click="huanyuanjian" class="a_black"><i class="el-icon-refresh-left"></i>还原</a>
                            &nbsp;
					</span>
				</transition>
                
    </span>

</template>

<script>

export default {
    name:'chazhaopaixulan',
    props: {sectionid: {type: Number,default: 0,}},
    computed:{
            url_xunhuan(){return '/api/xunhuan' + this.sectionid+'/'},
            SHOW_XUNHUANXX(){return 'SHOW_XUNHUAN' + this.sectionid},
            ORDERBYRE_XUNHUANXX(){return 'ORDERBYRE_XUNHUAN' + this.sectionid},
            ORDERBYXIN_XUNHUANXX(){return 'ORDERBYXIN_XUNHUAN' + this.sectionid},
            SHOW_XUNHUANKXX(){return 'SHOW_XUNHUANK' + this.sectionid},
            COUNTXX(){return 'COUNT' + this.sectionid},
            },
            
	data() {return {
        keyword:'',
        show_chazhaokong:false,
        show_zhankai:true,
        show_chazhaopaixunlan:false,
        show_chazhao:true,
        show_paixunzuire:true,
        show_paixunzuixin:false,
        show_shuaxin:true,
        show_chazhaoshu:false,
        show_huanyuan:false,

        }},
        
    methods:{
				zhankaijian:function(){
                    var xh11=Array;
					this.show_zhankai=false;
                    this.show_chazhaopaixunlan=true;
                    // this.$axios.get(this.url_xunhuan).then(response=>{xh11=response.data});
                    this.$axios.get(this.url_xunhuan).then(response=>{this.$store.state['XH'+this.sectionid]=response.data});
                    // this.$axios.get(this.url_xunhuan).then(response=>{this.$store.state['COUNT_XH'+this.sectionid]=response.data.count11;});
                    // this.$store.commit('LIST_XUNHUAN11',xh11);
                    // this.$store.commit(this.SHOW_XUNHUANXX);
                    this.$store.state['SHOW_XH'+this.sectionid]=true;
                    this.$store.state['SHOW_XHK'+this.sectionid]=false;

				},
				paixujian_zuire:function(){
                    this.show_paixunzuire=false;
                    this.show_paixunzuixin=true;
                    // this.$store.commit(this.ORDERBYRE_XUNHUANXX);
                    this.$store.state.XH11.sort((a,b)=>b.creater_id-a.creater_id);
                },
				paixujian_zuixin:function(){
                    this.show_paixunzuixin=false;
                    this.show_paixunzuire=true;
                    // this.$store.commit(this.ORDERBYXIN_XUNHUANXX);
                    this.$store.state.XH11.sort((a,b)=>a.creater_id-b.creater_id);

                },
				chazhaojian:function(keyword){

                    if(keyword==''){
                        if(this.show_chazhaoshu==true){
                            // 这个情况是查找关键词是空，且在已经查找过待还原的状态，这时候输入空值后显示排序，还原和不为空值的字符。然后再判断是哪种排序形式。
                            if(this.show_paixunzuire==true){
                                    this.show_chazhaokong=true;
                                    this.show_huanyuan=true;
                                    this.show_chazhaoshu=true;
                                    this.show_paixunzuire=false;
                                    this.show_paixunzuixin=true;
                                    this.show_shuaxin=false;
                            }else{
                                    this.show_chazhaokong=true;
                                    this.show_huanyuan=false;
                                    this.show_chazhaoshu=false;
                                    this.show_paixunzuire=true;
                                    this.show_paixunzuixin=false;
                                    this.show_shuaxin=false;
                            }
                        }else{
                        // 这是说明刚展开的阶段，这是输入空值后的表现
                        this.show_chazhaokong=true;
                        this.show_huanyuan=false;
                        this.show_chazhaoshu=false;
                        this.show_paixunzuire=true;
                        this.show_paixunzuixin=false;
                        this.show_shuaxin=true;
                        }
                    }else{
                        this.show_chazhaoshu=true;
                        this.show_huanyuan=true;
                        this.show_paixunzuire=true;
                        this.show_paixunzuixin=false;
                        this.show_shuaxin=false;
                        this.show_chazhaokong=false;
                        this.$store.state['KEYWORD'+this.sectionid]=keyword;
                        // this.$axios.get(this.url_xunhuan).then(response=>{this.$store.state['XHK'+this.sectionid]=JSON.parse(response.data.data)});
                        // this.k_l=this.$store.state['XHK'+this.sectionid].fields.username.indexOf(this.keyword);
                        // this.$store.commit(this.SHOW_XUNHUANKXX);
                        this.$store.state['SHOW_XH'+this.sectionid]=false;
                        this.$store.state['SHOW_XHK'+this.sectionid]=true;
                        // this.$store.commit('COUNT_XUNHUANK11',k_l);
                    }
                },

				shuaxinjian(){
					this.show_zhankai=false;
                    this.show_chazhaopaixunlan=true;
                    // this.$axios.get(this.url_xunhuan).then(response=>{this.$store.state['XH'+this.sectionid]=JSON.parse(response.data.data)});
                    // this.$store.commit(this.SHOW_XUNHUANXX);
                    this.$store.state['SHOW_XH'+this.sectionid]=true;
                    this.$store.state['SHOW_XHK'+this.sectionid]=false;
                    // 这个nextTick功能是刷新键后让新的数组重新渲染组件
		            this.$nextTick(() => {
                        this.$axios
                        .get(this.url_xunhuan)
                        .then(response=>{this.$store.state['XH'+this.sectionid]=response.data});
                    })
                },
                huanyuanjian:function(){
                    this.show_huanyuan=false;
                    this.show_chazhaoshu=false;
                    this.show_paixunzuire=true;
                    this.show_paixunzuixin=false;
                    this.show_shuaxin=true;
                    this.show_chazhaokong=false;
                    this.keyword='';
                    // this.$store.commit(this.SHOW_XUNHUANXX);
                    this.$store.state['SHOW_XH'+this.sectionid]=true;
                    this.$store.state['SHOW_XHK'+this.sectionid]=false;
                }
	},
};

</script>

<style scoped>


</style>
