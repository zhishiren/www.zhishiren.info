<template>
    <el-row id="zu1huifulan">
		<el-row>
			<span v-if="show_huifulan===false">
				<span style="color:red;" v-if="list.fields.fystatus==='失效已删'">{{list.fields.fystatus}}<el-divider direction="vertical"></el-divider></span>
				<span style="color:orange;" v-if="list.fields.fystatus==='正在审核'">{{list.fields.fystatus}}<el-divider direction="vertical"></el-divider></span>
				<span style="color:red;" v-if="list.fields.fyatt==='紧急重要'||list.fields.fyatt==='强烈推荐'||list.fields.fyatt==='反对异议'||list.fields.fyatt==='胡说八道'||list.fields.fyatt==='矛盾'">{{list.fields.fyatt}}<el-divider direction="vertical"></el-divider></span>
				<span style="color:orange;" v-if="list.fields.fyatt==='疑惑不解'||list.fields.fyatt==='让人困惑'||list.fields.fyatt==='言论怪异'||list.fields.fyatt==='更细化'">{{list.fields.fyatt}}<el-divider direction="vertical"></el-divider></span>
				<span style="color:green;" v-if="list.fields.fyatt==='点赞支持'||list.fields.fyatt==='聪明绝顶'||list.fields.fyatt==='古道心肠'||list.fields.fyatt==='一言九鼎'||list.fields.fyatt==='互补'">{{list.fields.fyatt}}<el-divider direction="vertical"></el-divider></span>
				<span style="color:grey;" v-if="list.fields.fytype">{{list.fields.fytype}}<el-divider direction="vertical"></el-divider></span>
				<zu0showfanwei v-if="list.fields.fyfanwei && qzid_yn!=='群' && list.fields.cztype!=='提问'" style="color:grey;" :qz_id="list.fields.fyfanwei"></zu0showfanwei>
				<span v-if="list.fields.fyfanwei && qzid_yn==='群'" style="color:grey;">仅限本群</span>
					<router-link  v-if="list.fields.cztype==='提问'&&list.fields.id1!==0" class="a_grey" target="_blank" :to="{name:list.fields.type1,params:{id:list.fields.id1}}">          
						<i class="el-icon-paperclip"></i>{{list.fields.id1}}
					</router-link>
			</span>
			
			<span v-if="show_huifulan===true">
				<span>共{{this.hfjishu1}}条回复</span>
				<span>·<input placeholder="在此输入,明发需审,密发不需审" v-model="hf_content" type="text" class="input_jian" style="color:grey;width:220px;font-size:16px;" ></span>
				<span v-if="show_loading2===true"><i class="el-icon-loading" style="font-size:19px;color:grey;"></i></span>
				<span v-if="show_loading2===false">
					<span>
						<el-dropdown @command="choose_taidu">
							<span class="el-dropdown-link a_grey" style="font-size:17px;"><i class="el-icon-arrow-down el-icon--right"></i>态度</span>
							<el-dropdown-menu slot="dropdown">
								<el-dropdown-item command="点赞支持">点赞支持</el-dropdown-item>
								<el-dropdown-item command="反对异议">反对异议</el-dropdown-item>
								<el-dropdown-item command="疑惑不解">疑惑不解</el-dropdown-item>
							</el-dropdown-menu>
						</el-dropdown>
						<span v-if="taidu==='点赞支持'" style="color:green;">:赞·</span><span v-if="taidu==='反对异议'" style="color:red;">:反·</span><span v-if="taidu==='疑惑不解'" style="color:orange;">:疑·</span><span v-if="taidu===''">·</span>
						<span><input style="color:grey;" type="checkbox" v-model="niming" unchecked>匿名·</span>
					</span>
					<span><a @click="fabujian(0,list.pk)" class="a_grey"><i class="el-icon-chat-dot-round"></i>明发</a>·</span>
					<span><a @click="fabujian(1,list.pk)" class="a_grey"><i class="el-icon-s-comment"></i>密发</a>·</span>
					<span><a @click="huanyuanjian()" class="a_grey"><i class="el-icon-refresh-left"></i>取消</a></span>
					<span v-if="return_msg_huifu" style="color:orange">{{this.return_msg_huifu}}</span>
				</span>
			</span>

<!-- 这是需要判断一下，如果是提问，就没有回复和删除的功能，只有重发的功能 -->
			<span v-if="izeng_yn!==true" style="float:right;color:grey;">
				<a v-if="show_huifulan===false" @click="huifujian(list.pk)" class="a_grey">回复:{{list.fields.hui}}</a>
				<span v-if="show_huifulan===false" ><el-divider direction="vertical"></el-divider></span>
				<span v-show="yonghuid!==parseInt(list.fields.uid1)&&show_yi_dingcai===false">
					<a v-if="show_loading_dingcai===false" @click="dingcai('顶',list.pk)" class="a_grey">顶:{{list.fields.ding}}</a>
					<el-divider direction="vertical"></el-divider>		
					<a v-if="show_loading_dingcai===false" @click="dingcai('踩',list.pk)" class="a_grey">踩:{{list.fields.cai}}</a>
					<span style="color:orange" v-if="dingcai_error===true">操作失败!</span>
					<span v-if="show_loading_dingcai"><i class="el-icon-loading"></i></span>
				</span>
				<span v-show="yonghuid!==parseInt(list.fields.uid1)&&show_yi_dingcai">
					<span style="color:grey" v-if="show_yiding===true"><span>已顶{{this.jishu_dingcai}}</span></span>
					<span style="color:grey" v-if="show_yicai===true"><span>已踩{{this.jishu_dingcai}}</span></span>
				</span>

				<span v-show="yonghuid===parseInt(list.fields.uid1) && show_huifulan===false && show_loading3===false">
					<a v-if="list.fields.fystatus!=='失效已删'" @click="shanchu(list.pk)" class="a_grey"><i class="el-icon-close"></i>删</a>
					<span v-if="list.fields.fystatus==='失效已删'" style="color:grey;">已删</span>
					<span v-if="return_msg_shanchu" style="color:orange">{{this.return_msg_shanchu}}</span>
				</span>
				<span v-if="show_loading3===true"><i class="el-icon-loading" style="font-size:19px;color:grey;"></i></span>
				<span><el-divider direction="vertical"></el-divider>{{qian_date(list.fields.time1)}}</span>
			</span>

			<span v-if="izeng_yn===true" style="float:right;color:grey;">
				<a v-if="show_huifulan===false" @click="huifujian(list.pk)" class="a_grey">回复:{{list.fields.hui}}</a>
				<span v-if="show_huifulan===false&&later24h(lastwentime)===true&&list.fields.fystatus==='正常有效'" ><el-divider direction="vertical"></el-divider></span>
				<a v-if="show_loading_chongfa===0&&show_huifulan===false&&later24h(lastwentime)===true&&list.fields.fystatus==='正常有效'" @click="chongfajian(list.pk)"><i class="el-icon-right a_grey">重发</i></a>
				<i v-if="show_loading_chongfa===9" class="el-icon-loading"></i>
				<span v-show="show_huifulan===false && show_loading3===false">
					<el-divider direction="vertical"></el-divider>
					<a v-if="list.fields.fystatus!=='失效已删'" @click="shanchu(list.pk)" class="a_grey"><i class="el-icon-close"></i>删</a>
					<span v-if="list.fields.fystatus==='失效已删'" style="color:grey;">已删</span>
					<span v-if="return_msg_shanchu" style="color:orange">{{this.return_msg_shanchu}}</span>
				</span>
				<span v-if="show_loading3===true"><i class="el-icon-loading" style="font-size:19px;color:grey;"></i></span>
				<span><el-divider direction="vertical"></el-divider>{{qian_date(list.fields.time1)}}</span>

			</span>
			<!-- <span v-if="list.fields.cztype==='提问'" style="float:right;color:grey;">
				<i class="el-icon-right a_grey">重发</i><el-divider direction="vertical"></el-divider>
				<span v-show="yonghuid===parseInt(list.fields.uid0) && show_huifulan===false && show_loading3===false">
					<a v-if="list.fields.fystatus!=='失效已删'" @click="shanchu(list.pk)" class="a_grey"><i class="el-icon-close"></i>删</a>
					<span v-if="list.fields.fystatus==='失效已删'" style="color:grey;">已删</span>
					<span v-if="return_msg_shanchu" style="color:orange">{{this.return_msg_shanchu}}</span>
				</span>
				<span v-if="show_loading3===true"><i class="el-icon-loading" style="font-size:19px;color:grey;"></i></span>
				<span><el-divider direction="vertical"></el-divider>{{qian_date(list.fields.time1)}}</span>
			</span> -->
		</el-row>



		<span v-if="show_huifulan===true">
			<el-row v-if="show_loading1===true" style="font-size:30px;color:grey;"><i class="el-icon-loading"></i>正在加载...</el-row>
			<el-row v-if="hfjishu1">
				<el-row  v-for="hf in lists" :key="hf.pk" style="padding-left:18px;">
					<zu0niming :uid1="hf.fields.uid1" :uname="hf.fields.uname"></zu0niming>
					<span v-if="hf.fields.fymi===0&&hf.fields.fystatus==='正常有效'" style="color:brown;">
						<span>:</span>
						<span v-if="hf.fields.fyatt==='点赞支持'" style="color:green;">支持·</span>
                        <span v-if="hf.fields.fyatt==='反对异议'" style="color:red;">反对·</span>
                        <span v-if="hf.fields.fyatt==='疑惑不解'" style="color:orange;">疑问·</span>
						<span>{{hf.fields.fy}}</span>
					</span>
					<span v-if="hf.fields.fymi===0&&hf.fields.fystatus==='正在审核'" style="color:grey;">
						<span>回复了一段明文:</span>
						<span v-if="hf.fields.fyatt==='点赞支持'" style="color:green;">支持·</span>
                        <span v-if="hf.fields.fyatt==='反对异议'" style="color:red;">反对·</span>
                        <span v-if="hf.fields.fyatt==='疑惑不解'" style="color:orange;">疑问·</span>
						<span style="background-color:grey;color:white;">正在审核</span>
						<span style="color:grey;">·{{qian_date(hf.fields.time1)}}</span>
					</span>
					<span v-if="hf.fields.fymi!==0" style="color:grey;">
                        <span>回复了一条{{hf.fields.fymi}}个字</span>
                        <span v-if="hf.fields.fyatt==='点赞支持'" style="color:green;">支持</span>
                        <span v-if="hf.fields.fyatt==='反对异议'" style="color:red;">反对</span>
                        <span v-if="hf.fields.fyatt==='疑惑不解'" style="color:orange;">疑问</span>
						<span>的密文</span>
						<input style="width:1px;border-color:white;border:0px;" type="text" v-model="hf.fields.fy.slice(2,-1)" :id="hf.pk">
						<a class="a_brown" style="color:blue;" @click="kcopy(hf.pk)"><i class="el-icon-document-copy"></i>复制</a>
						<span style="color:grey;">·{{qian_date(hf.fields.time1)}}</span>
					</span>
					<span v-show="yonghuid===parseInt(hf.fields.uid1)">
                        <a v-if="shan_loading===false" @click="hf_shan(hf.pk)" class="a_grey"><i class="el-icon-close"></i>删</a>
                        <!-- <span style="color:orange">:{{this.return_msg_rmhf}}</span> -->
                        <span v-if="shan_loading"><i class="el-icon-loading"></i>正在删除...</span>
                    </span> 
				</el-row>
			</el-row>
			<el-pagination v-if="hfjishu1>5" style="text-align:left;"
				:page-size=5
				:total="hfjishu1"
				:current-page.sync="currentPage"
				layout="total, prev, pager, next">
			</el-pagination>
		</span>

    </el-row>
</template>

<script>
export default {
	name:'zu1huifulan',
	components: {},

	data() {return {
		show_huifulan:false,
		return_msg_huifu:'',
		return_msg_shanchu:'',

		show_addok:false,

		hf_content:'',
		taidu:'',
		niming:'',

		hflist:[],
		hfjishu1:0,
		currentPage: 1,//分页相关

		shan_loading:false,
		shanhf_error:false,

		show_loading1:false,
		show_loading2:false,
		show_loading3:false,

		show_loading_dingcai:false,
		jishu_dingcai:0,
		dingcai_error:false,
		show_yicai:false,
		show_yiding:false,
		show_yi_dingcai:false,
		show_loading_chongfa:0,

	}},

	// props:['shuaxinid','list'],
	props:['list','qzid_yn','izeng_yn'],
	//izeng_yn是用于我的提问页面，其中有个特殊的功能是重发

    computed: {
			yonghuid(){return parseInt(this.$cookies.get('userid'))},
			// createrid(){return parseInt(list.fields.uid1)},
			lastwentime(){return this.$cookies.get('lastwentime')},
			lists(){
                let pages=Math.ceil(this.hfjishu1/5);//
                let newList=[];
                for(let i=0;i<pages;i++){
                let sonList=[];
                sonList=this.hflist.slice(i*5,i*5+5);//
                newList.push(sonList)
                }
                return newList[this.currentPage-1]
            },
    },

	methods:{
		jia1_huifushu(){this.list.fields.hui=this.list.fields.hui+1},
		jian1_huifushu(){this.list.fields.hui=this.list.fields.hui-1},
		choose_taidu(taidu_value){this.taidu=taidu_value;},
		huanyuanjian(){this.show_huifulan=false;},
		chongfajian(kkk){
			var that=this;
			that.show_loading_chongfa=9;
			that.$axios
			.post('http://www.zhishiren.info/api/to_chongfa/',{czid:kkk})
			.then(response=>{
				if(response.data.msg==0){
					that.show_loading_chongfa=1;
					that.$emit('chongfaok');
					let kkk=response.data.new_wentime;
					that.$cookies.set('lastwentime',kkk,'8h');
					that.$router.go(0);
				}
				else{that.show_loading_chongfa=0;}
			})
		},
		shanchu(kkk){
			this.$confirm('确认删除这条附言？', '确认删除这条附言？',{
				confirmButtonText: '确定',
				cancelButtonText: '取消',
				}).then(() => {
						this.show_loading3=true;
						this.$axios
						.post('http://www.zhishiren.info/api/change_caozuo/',{czid: kkk,czxxx:'失效已删'})
						.then(response=>{
							if(response.data.msg==1){
									this.$emit('shanchuok');
									this.return_msg_shanchu='删除成功！';
								}
							else{
									this.return_msg_shanchu='删除失败！';
									setTimeout(function(){this.return_msg_shanchu='';}, 2000);
									this.show_loading3=false;
								};
							this.show_loading3=false;
						 })
				}).catch(() => {
					this.$message({type: 'info',message: '已取消「删除」操作'});
				});
		},

		huifujian(kkk){
			this.show_loading1=true;
			this.show_loading2=true;
			this.show_huifulan=true;
			this.huifu_shuaxin(kkk);
		},

		dingcai(type,pkid){
			var that=this;
			that.show_loading_dingcai=true;
			that.$axios
			.post('http://www.zhishiren.info/api/to_dingcai/',{cztype:type, czid:pkid,userid:that.yonghuid,})
			.then(response=>{
				if(response.data.msg==0){
					that.jishu_dingcai=response.data.jishudingcai;
					that.show_loading_dingcai=false;
					that.show_yi_dingcai=true;
					if(type==='顶'){that.show_yiding=true;}
					else{that.show_yicai=true;};
				}
				else{that.dingcai_error==true;}
			})
		},

		huifu_shuaxin(pkid){
			this.$axios
				.post('http://www.zhishiren.info/api/xunhuancaozuo/',{zhid: pkid,cztype:'评论'})
				.then(response=>{
					this.hflist=JSON.parse(response.data);
					this.hfjishu1=this.hflist.length;
					this.currentPage=1;
					this.taidu='';
					this.show_loading2=false;
					this.show_loading1=false;
				});
		},

		fabujian:function(mi,kkk){
			var that=this;
			if(that.niming===true){that.niming='匿名'}
			if(that.hf_content===''){
				that.return_msg_huifu='输入不能为空！';
				setTimeout(function(){that.return_msg_huifu='';}, 2000);		
			}
			else{
				that.show_loading1=true;
				that.show_loading2=true;
				that.$axios
				.post('http://www.zhishiren.info/api/to_caozuo/',{
					cztype:"评论",
					fy:that.hf_content,
					id0: that.list.pk,
					type0:that.list.fields.type0,
					uid:that.yonghuid,
					uname:that.$cookies.get('username'),
                    fymm:that.$cookies.get('fayanmima'),

					fymi:mi,
					fyatt:that.taidu,
					fyhui:that.list.fields.fy,
					fyniming:that.niming,
					fyfanwei:that.list.fields.fyfanwei,
					})
				.then(response=>{
					if(response.data.msg===1){
						that.return_msg_huifu='发布成功！';
						setTimeout(function(){that.return_msg_huifu=false;}, 2000);
						that.show_huifulan=false;
						that.show_huifulan=true;
						that.huifu_shuaxin(kkk);
						that.jia1_huifushu();
						// that.huifujian(kkk);
						that.hf_content='';
						that.taidu='';
						that.niming='';
					}
					else{
						that.return_msg_huifu='操作失败！';
						setTimeout(function(){that.return_msg_huifu=false;}, 2000);
						that.taidu='';
					}
				})
			}	
		},

		hf_shan(kkk){
			this.$alert('确认删除本条回复内容？', '确认删除这条回复内容？', {
				confirmButtonText: '确定',
				callback: action => {
					if (action === 'confirm') {
						this.shan_loading=true;
						var that=this;
						that.$axios
						.post('http://www.zhishiren.info/api/change_caozuo/',{czid: kkk,czxxx:'失效已删'})
						.then(response=>{
							if(response.data.msg==1){
								that.huifu_shuaxin(response.data.hfid0);
								that.jian1_huifushu();
								};
							that.shan_loading=false;
						})
					}
				}
			});
		},

		kcopy(a){
        	let copycode = document.getElementById(a);
            copycode.select(); // 选择对象
            document.execCommand("Copy"); // 执行浏览器复制命令
            // alert("密文已经复制到你的粘贴板，请到首页右侧‘密’功能栏解密。");
            // alert(copycode.value);
			const h = this.$createElement;
            this.$notify({
                title: '密文已经复制到你的粘贴板',
				type: 'success',
				message: h('i', { style: 'color: teal;font-size:19px;'}, '请到‘密’功能栏解密。')            });
        },

	},

	// watch: {
	// 	shuaxinid: {
	// 		handler: function(newVal,oldVal){
	// 			this.show_huifulan=false;
	// 		},
	// 		immediate: true
	// 	},	
	// },
};

</script>


				<!-- <el-row  style="padding-left:18px;" :class="blinkyellow" v-if="hf.pk==return_id">
                    <zu0niming></zu0niming>
					<span v-if="hf.fields.act_fuyanzishu===0" style="color:brown;">:{{hf.fields.act_fuyan}}</span>
					<span v-if="hf.fields.act_fuyanzishu!==0" style="color:grey;">
                        回复了一条{{hf.fields.act_fuyanzishu}}个字
                        <span v-if="hf.fields.act_att==='点赞支持'" style="color:green;">支持</span>
                        <span v-if="hf.fields.act_att==='反对异议'" style="color:red;">反对</span>
                        <span v-if="hf.fields.act_att==='疑惑不解'" style="color:orange;">疑问</span>的密文:		
						<input style="width:1px;border-color:white;border:0px;" type="text" v-model="hf.fields.act_fuyan.slice(2,-1)" :id="hf.pk">
						<a class="a_brown" @click="kcopy(hf.pk)">复制密文</a>
					</span>
					<tj0huifu1 @hf_shan_ok="hfshanok()" :comm_id="hf.pk" :creater_id="hf.fields.act_createrid" :creater_name="hf.fields.act_creatername"></tj0huifu1>
				</el-row> -->


