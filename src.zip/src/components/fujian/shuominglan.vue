
// 这个说明栏是用于“内容说明<i class="el-icon-caret-right"></i>”字样之后的内容输入栏
<template>
    <div>
            <el-row >
                <el-col :span="2" >
                <!-- 因为这是一个通用组件，这里需要对不同来源进行一个判断， -->
                        <span v-if="shuoming_type===0" class="font16px">备注说明<i class="el-icon-caret-right"></i></span>
                        <span v-else-if="shuoming_type===1" class="font16px">段落内容：</span>
                </el-col>
                <el-col :span="22" >
                <div contenteditable ref="contents" @paste="onPaste" class="pinglunlan" style="width:97%;" @blur="set_divcontent">

                    
                </div>
                </el-col>

            </el-row>
            <el-row >
                <el-col :span="2" ></el-col>
                <el-col :span="22" >
                    <a class="font18px a_black" href="javascript:;" @click="f_blod">
                    <b>所选加粗</b>
                    </a>
                    &nbsp;
                    <a class="font18px a_black" href="javascript:;" @click="f_bgColor">
                    <span style="background:yellow;">背景色</span>
                    </a>
                    &nbsp;
                    <a class="font18px a_black" href="javascript:;" @click="f_clear">
                    清空
                    </a>
                </el-col>
            </el-row>
            
    </div>
</template>
<script>
  export default {
    name: 'shuominglan',
    // props: [ 'initContent' ],
    mounted () {
			
	},
    data() {
      return {
          shuoming_type:1
            
      }
    },

    methods:{
            // 这是设计一个失去焦点以后就把div中的数据传到父组件的功能。
			set_divcontent() {
                let data = {content: this.$refs.contents.innerHTML};
				this.$emit('todivcontent',data);
            },
            // 这里是想加一个清空div中内容的功能，清空后获取焦点的功能,因为我上文设计的是失去焦点后赋值的，所以清空之后要获取焦点。
            f_clear() {
                this.$refs.contents.innerHTML='';
                this.$refs.contents.focus();
            },
			f_blod() {
				document.execCommand ( 'bold', false );
			},
			f_bgColor() {
				document.execCommand ( 'backColor', false, 'yellow' );
			},

    }

  }
</script>
